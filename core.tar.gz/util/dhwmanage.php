<?php
/** Adminer - Compact database management
* @link https://www.adminer.org/
* @author Jakub Vrana, https://www.vrana.cz/
* @copyright 2007 Jakub Vrana
* @license https://www.apache.org/licenses/LICENSE-2.0 Apache License, Version 2.0
* @license https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License, version 2 (one or other)
* @version 5.5.1
*/namespace
Adminer;const
VERSION="5.5.1";error_reporting(24575);set_error_handler(function($Ic,$Kc){return!!preg_match('~^Undefined (array key|offset|index)~',$Kc);},E_WARNING|E_NOTICE);$id=!preg_match('~^(unsafe_raw)?$~',ini_get("filter.default"));if($id||ini_get("filter.default_flags")){foreach(array('_GET','_POST','_COOKIE','_SERVER')as$X){$Oj=filter_input_array(constant("INPUT$X"),FILTER_UNSAFE_RAW);if($Oj)$$X=$Oj;}}if(function_exists("mb_internal_encoding"))mb_internal_encoding("8bit");function
connection($h=null){return($h?:Db::$instance);}function
adminer(){return
Adminer::$instance;}function
driver(){return
Driver::$instance;}function
connect(){$Jb=adminer()->credentials();$J=Driver::connect($Jb[0],$Jb[1],$Jb[2]);return(is_object($J)?$J:null);}function
idf_unescape($u){if(!preg_match('~^[`\'"[]~',$u))return$u;$Te=substr($u,-1);return
str_replace($Te.$Te,$Te,substr($u,1,-1));}function
q($Q){return
connection()->quote($Q);}function
idx($za,$x,$l=null){return($za&&array_key_exists($x,$za)?$za[$x]:$l);}function
number($X){return
preg_replace('~[^0-9]+~','',$X);}function
number_type(){return'((?<!o)int(?!er)|numeric|real|float|double|decimal|money)';}function
remove_slashes(array$gk,$id=false){$J=array();foreach($gk
as$x=>$X)$J[stripslashes($x)]=(is_array($X)?remove_slashes($X,$id):($id?$X:stripslashes($X)));return$J;}function
bracket_escape($u,$Ha=false){static$yj=array(':'=>':1',']'=>':2','['=>':3','"'=>':4');return
strtr($u,($Ha?array_flip($yj):$yj));}function
min_version($jk,$mf="",$h=null){$h=connection($h);$pi=$h->server_info;if($mf&&preg_match('~([\d.]+)-MariaDB~',$pi,$A)){$pi=$A[1];$jk=$mf;}return$jk&&version_compare($pi,$jk)>=0;}function
charset(Db$g){return(min_version("5.5.3",0,$g)?"utf8mb4":"utf8");}function
ini_set($vg,$Y){return(function_exists('ini_set')?\ini_set($vg,$Y):false);}function
ini_bool($te){$X=ini_get($te);return(preg_match('~^(on|true|yes)$~i',$X)||(int)$X);}function
ini_bytes($te){$X=ini_get($te);switch(strtolower(substr($X,-1))){case'g':$X=(int)$X*1024;case'm':$X=(int)$X*1024;case'k':$X=(int)$X*1024;}return$X;}function
sid(){static$J;if($J===null)$J=(SID&&!($_COOKIE&&ini_bool("session.use_cookies")));return$J;}function
set_password($ik,$N,$V,$F){$_SESSION["pwds"][$ik][$N][$V]=($_COOKIE["adminer_key"]&&is_string($F)?array(encrypt_string($F,$_COOKIE["adminer_key"])):$F);}function
get_password(){$J=get_session("pwds");if(is_array($J))$J=($_COOKIE["adminer_key"]?decrypt_string($J[0],$_COOKIE["adminer_key"]):false);return$J;}function
get_val($H,$n=0,$xb=null){$xb=connection($xb);$I=$xb->query($H);if(!is_object($I))return
false;$K=$I->fetch_row();return($K?$K[$n]:false);}function
get_vals($H,$d=0){$J=array();$I=connection()->query($H);if(is_object($I)){while($K=$I->fetch_row())$J[]=$K[$d];}return$J;}function
get_key_vals($H,$h=null,$si=true){$h=connection($h);$J=array();$I=$h->query($H);if(is_object($I)){while($K=$I->fetch_row()){if($si)$J[$K[0]]=$K[1];else$J[]=$K[0];}}return$J;}function
get_rows($H,$h=null,$m="<p class='error'>"){$xb=connection($h);$J=array();$I=$xb->query($H);if(is_object($I)){while($K=$I->fetch_assoc())$J[]=$K;}elseif(!$I&&!$h&&$m&&(defined('Adminer\PAGE_HEADER')||$m=="-- "))echo$m.error()."\n";return$J;}function
unique_array($K,array$w){foreach($w
as$v){if(preg_match("~PRIMARY|UNIQUE~",$v["type"])&&!$v["partial"]){$J=array();foreach($v["columns"]as$x){if(!isset($K[$x]))continue
2;$J[$x]=$K[$x];}return$J;}}}function
escape_key($x){if(preg_match('(^([\w(]+)('.str_replace("_",".*",preg_quote(idf_escape("_"))).')([ \w)]+)$)',$x,$A))return$A[1].idf_escape(idf_unescape($A[2])).$A[3];return
idf_escape($x);}function
where(array$Z,array$o=array()){$J=array();foreach((array)$Z["where"]as$x=>$X){$x=bracket_escape($x,true);$d=escape_key($x);$n=idx($o,$x,array());$ed=$n["type"];$J[]=$d.(JUSH=="sql"&&$ed=="json"?" = CAST(".q($X)." AS JSON)":(JUSH=="pgsql"&&preg_match('~^jsonb?$~',$n["full_type"])?"::jsonb = ".q($X)."::jsonb":(JUSH=="sql"&&is_numeric($X)&&preg_match('~\.~',$X)?" LIKE ".q($X):(JUSH=="mssql"&&strpos($ed,"datetime")===false?" LIKE ".q(preg_replace('~[_%[]~','[\0]',$X)):" = ".unconvert_field($n,q($X))))));if(JUSH=="sql"&&preg_match('~char|text~',$ed)&&preg_match("~[^ -@]~",$X))$J[]="$d = ".q($X)." COLLATE ".charset(connection())."_bin";}foreach((array)$Z["null"]as$x)$J[]=escape_key($x)." IS NULL";return
implode(" AND ",$J);}function
where_check($X,array$o=array()){parse_str($X,$bb);remove_slashes(array(&$bb));return
where($bb,$o);}function
where_link($s,$d,$Y,$sg="="){return"&where%5B$s%5D%5Bcol%5D=".urlencode($d)."&where%5B$s%5D%5Bop%5D=".urlencode(($Y!==null?$sg:"IS NULL"))."&where%5B$s%5D%5Bval%5D=".urlencode($Y);}function
convert_fields(array$e,array$o,array$M=array()){$J="";foreach($e
as$x=>$X){if($M&&!in_array(idf_escape($x),$M))continue;$_a=convert_field($o[$x]);if($_a)$J
.=", $_a AS ".idf_escape($x);}return$J;}function
cookie_path(){return
strtr(preg_replace('~\?.*~','',$_SERVER["REQUEST_URI"]),array(";"=>"%3B",","=>"%2C"));}function
cookie($B,$Y,$cf=2592000){header("Set-Cookie: $B=".rawurlencode($Y).($cf?"; expires=".gmdate("D, d M Y H:i:s",time()+$cf)." GMT":"")."; path=".cookie_path().(HTTPS?"; secure":"")."; HttpOnly; SameSite=lax",false);}function
get_url($Vj,$Db){$J=@file_get_contents($Vj,false,$Db);if(function_exists('http_get_last_response_headers'))$http_response_header=http_get_last_response_headers();return
array($J,(preg_match('~^HTTP/[\d.]+ (\d+)~',$http_response_header[0],$A)?$A[1]:''),);}function
get_settings($Fb){parse_str($_COOKIE[$Fb],$ti);return$ti;}function
get_setting($x,$Fb="adminer_settings",$l=null){return
idx(get_settings($Fb),$x,$l);}function
save_settings(array$ti,$Fb="adminer_settings"){$Y=http_build_query($ti+get_settings($Fb));cookie($Fb,$Y);$_COOKIE[$Fb]=$Y;}function
restart_session(){if(!ini_bool("session.use_cookies")&&(!function_exists('session_status')||session_status()==1))session_start();}function
stop_session($rd=false){$Yj=ini_bool("session.use_cookies");if(!$Yj||$rd){session_write_close();if($Yj&&ini_set("session.use_cookies",'0')===false)session_start();}}function&get_session($x){return$_SESSION[$x][DRIVER][SERVER][$_GET["username"]];}function
set_session($x,$X){$_SESSION[$x][DRIVER][SERVER][$_GET["username"]]=$X;}function
auth_url($ik,$N,$V,$k=null){$Uj=remove_from_uri(implode("|",array_keys(SqlDriver::$drivers))."|username|ext|".($k!==null?"db|":"").($ik=='mssql'||$ik=='pgsql'?"":"ns|").session_name());preg_match('~([^?]*)\??(.*)~',$Uj,$A);return"$A[1]?".(sid()?SID."&":"").($ik!="server"||$N!=""?urlencode($ik)."=".urlencode($N)."&":"").($_GET["ext"]?"ext=".urlencode($_GET["ext"])."&":"")."username=".urlencode($V).($k!=""?"&db=".urlencode($k):"").($A[2]?"&$A[2]":"");}function
is_ajax(){return($_SERVER["HTTP_X_REQUESTED_WITH"]=="XMLHttpRequest");}function
redirect($if,$Bf=null){if($Bf!==null){restart_session();$_SESSION["messages"][preg_replace('~^[^?]*~','',($if!==null?$if:$_SERVER["REQUEST_URI"]))][]=$Bf;}if($if!==null){if($if=="")$if=".";header("Location: $if");exit;}}function
query_redirect($H,$if,$Bf,$Ch=true,$Pc=true,$Yc=false,$lj=""){if($Pc){$Hi=microtime(true);$Yc=!connection()->query($H);$lj=format_time($Hi);}$Bi=($H?adminer()->messageQuery($H,$lj,$Yc):"");if($Yc){adminer()->error
.=error().$Bi.script("messagesPrint();")."<br>";return
false;}if($Ch)redirect($if,$Bf.$Bi);return
true;}class
Queries{static$queries=array();static$start=0;}function
queries($H){if(!Queries::$start)Queries::$start=microtime(true);Queries::$queries[]=(driver()->delimiter!=';'?$H:(preg_match('~;$~',$H)?"DELIMITER ;;\n$H;\nDELIMITER ":$H).";");return
connection()->query($H);}function
apply_queries($H,array$T,$Lc='Adminer\table'){foreach($T
as$R){if(!queries("$H ".$Lc($R)))return
false;}return
true;}function
queries_redirect($if,$Bf,$Ch){$yh=implode("\n",Queries::$queries);$lj=format_time(Queries::$start);return
query_redirect($yh,$if,$Bf,$Ch,false,!$Ch,$lj);}function
format_time($Hi){return
lang(0,max(0,microtime(true)-$Hi));}function
relative_uri(){return
str_replace(":","%3a",preg_replace('~^[^?]*/([^?]*)~','\1',$_SERVER["REQUEST_URI"]));}function
remove_from_uri($Og=""){return
substr(preg_replace("~(?<=[?&])($Og".(SID?"":"|".session_name()).")=[^&]*&~",'',relative_uri()."&"),0,-1);}function
get_file($x,$Vb=false,$bc=""){$gd=$_FILES[$x];if(!$gd)return
null;foreach($gd
as$x=>$X)$gd[$x]=(array)$X;$J='';foreach($gd["error"]as$x=>$m){if($m)return$m;$B=$gd["name"][$x];$tj=$gd["tmp_name"][$x];$Bb=file_get_contents($Vb&&preg_match('~\.gz$~',$B)?"compress.zlib://$tj":$tj);if($Vb){$Hi=substr($Bb,0,3);if(function_exists("iconv")&&preg_match("~^\xFE\xFF|^\xFF\xFE~",$Hi))$Bb=iconv("utf-16","utf-8",$Bb);elseif($Hi=="\xEF\xBB\xBF")$Bb=substr($Bb,3);}$J
.=$Bb;if($bc)$J
.=(preg_match("($bc\\s*\$)",$Bb)?"":$bc)."\n\n";}return$J;}function
upload_error($m){$wf=($m==UPLOAD_ERR_INI_SIZE?ini_get("upload_max_filesize"):0);return($m?lang(1).($wf?" ".lang(2,$wf):""):lang(3));}function
repeat_pattern($bh,$y){return
str_repeat("$bh{0,65535}",$y/65535)."$bh{0,".($y%65535)."}";}function
is_utf8($X){return(preg_match('~~u',$X)&&!preg_match('~[\0-\x8\xB\xC\xE-\x1F]~',$X));}function
format_number($X){return
strtr(number_format($X,0,".",lang(4)),preg_split('~~u',lang(5),-1,PREG_SPLIT_NO_EMPTY));}function
friendly_url($X){return
preg_replace('~\W~i','-',$X);}function
table_status1($R,$Zc=false){$J=table_status($R,$Zc);return($J?reset($J):array("Name"=>$R));}function
column_foreign_keys($R){$J=array();foreach(adminer()->foreignKeys($R)as$p){foreach($p["source"]as$X)$J[$X][]=$p;}return$J;}function
fields_from_edit(){$J=array();foreach((array)$_POST["field_keys"]as$x=>$X){if($X!=""){$X=bracket_escape($X);$_POST["function"][$X]=$_POST["field_funs"][$x];$_POST["fields"][$X]=$_POST["field_vals"][$x];}}foreach((array)$_POST["fields"]as$x=>$X){$B=bracket_escape($x,true);$J[$B]=array("field"=>$B,"privileges"=>array("insert"=>1,"update"=>1,"where"=>1,"order"=>1),"null"=>1,"auto_increment"=>($x==driver()->primary),);}return$J;}function
dump_headers($Zd,$Pf=false){$J=adminer()->dumpHeaders($Zd,$Pf);$Kg=$_POST["output"];if($Kg!="text")header("Content-Disposition: attachment; filename=".adminer()->dumpFilename($Zd).".$J".($Kg!="file"&&preg_match('~^[0-9a-z]+$~',$Kg)?".$Kg":""));session_write_close();if(!ob_get_level())ob_start(null,4096);ob_flush();flush();return$J;}function
dump_csv(array$K){$Gj=$_POST["format"]=="tsv";foreach($K
as$x=>$X){if(preg_match('~["\n]|^0[^.]|\.\d*0$|'.($Gj?'\t':'[,;]|^$').'~',$X))$K[$x]='"'.str_replace('"','""',$X).'"';}echo
implode(($_POST["format"]=="csv"?",":($Gj?"\t":";")),$K)."\r\n";}function
apply_sql_function($r,$d){return($r?($r=="unixepoch"?"DATETIME($d, '$r')":($r=="count distinct"?"COUNT(DISTINCT ":strtoupper("$r("))."$d)"):$d);}function
get_temp_dir(){return
ini_get("upload_tmp_dir")?:sys_get_temp_dir();}function
file_open_lock($hd){if(is_link($hd))return;$q=@fopen($hd,"c+");if(!$q)return;@chmod($hd,0660);if(!flock($q,LOCK_EX)){fclose($q);return;}return$q;}function
file_write_unlock($q,$Pb){rewind($q);fwrite($q,$Pb);ftruncate($q,strlen($Pb));file_unlock($q);}function
file_unlock($q){flock($q,LOCK_UN);fclose($q);}function
first(array$za){return
reset($za);}function
password_file($i){$hd=get_temp_dir()."/adminer.key";if(!$i&&!file_exists($hd))return'';$q=file_open_lock($hd);if(!$q)return'';$J=stream_get_contents($q);if(!$J){$J=rand_string();file_write_unlock($q,$J);}else
file_unlock($q);return$J;}function
rand_string(){return(function_exists('random_bytes')?bin2hex(random_bytes(16)):md5(uniqid(strval(mt_rand()),true)));}function
select_value($X,$_,array$n,$kj){if(is_array($X)){$J="";if(array_filter($X,'is_array')==array_values($X)){$Me=array();foreach($X
as$W)$Me+=array_fill_keys(array_keys($W),null);foreach(array_keys($Me)as$Ke)$J
.="<th>".h($Ke);foreach($X
as$W){$J
.="<tr>";foreach(array_merge($Me,$W)as$ck)$J
.="<td>".select_value($ck,$_,$n,$kj);}}else{foreach($X
as$Ke=>$W)$J
.="<tr>".($X!=array_values($X)?"<th>".h($Ke):"")."<td>".select_value($W,$_,$n,$kj);}return"<table>$J</table>";}if(!$_)$_=adminer()->selectLink($X,$n);if($_===null){if(is_mail($X))$_="mailto:$X";if(is_url($X))$_=$X;}$X=driver()->value($X,$n);$J=adminer()->editVal($X,$n);if($J!==null){if(!is_utf8($J))$J="\0";elseif($kj!=""&&is_shortable($n))$J=shorten_utf8($J,max(0,+$kj));else$J=h($J);}return
adminer()->selectVal($J,$_,$n,$X);}function
is_blob(array$n){return
preg_match('~blob|bytea|raw|file~',$n["type"])&&!in_array($n["type"],idx(driver()->structuredTypes(),lang(6),array()));}function
is_mail($zc){$Aa='[-a-z0-9!#$%&\'*+/=?^_`{|}~]';$nc='[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])';$bh="$Aa+(\\.$Aa+)*@($nc?\\.)+$nc";return
is_string($zc)&&preg_match("(^$bh(,\\s*$bh)*\$)i",$zc);}function
is_url($Q){$nc='[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])';return
preg_match("~^((https?):)?//($nc?\\.)+$nc(:\\d+)?(/.*)?(\\?.*)?(#.*)?\$~i",$Q);}function
is_shortable(array$n){return!preg_match('~'.number_type().'|date|time|year~',$n["type"]);}function
host_port($N){return(preg_match('~^(:([^:].*)|(\[(.+)\]|(([^:]+://)?[^:]+))(:(\d+))?)$~',$N,$A)?array($A[4].$A[5],$A[2].$A[8]):array($N,''));}function
count_rows($R,array$Z,$Ce,array$Ed){$H=" FROM ".table($R).($Z?" WHERE ".implode(" AND ",$Z):"");return($Ce&&(JUSH=="sql"||count($Ed)==1)?"SELECT COUNT(DISTINCT ".implode(", ",$Ed).")$H":"SELECT COUNT(*)".($Ce?" FROM (SELECT 1$H GROUP BY ".implode(", ",$Ed).") x":$H));}function
slow_query($H){$k=adminer()->database();$mj=adminer()->queryTimeout();$xi=driver()->slowQuery($H,$mj);$h=null;if(!$xi&&support("kill")){$h=connect();if($h&&($k==""||$h->select_db($k))){$Ne=get_val(connection_id(),0,$h);echo
script("const timeout = setTimeout(() => { ajax('".js_escape(ME)."script=kill', function () {}, 'kill=$Ne&token=".get_token()."'); }, 1000 * $mj);");}}ob_flush();flush();$J=@get_key_vals(($xi?:$H),$h,false);if($h){echo
script("clearTimeout(timeout);");ob_flush();flush();}return$J;}function
get_token(){$Ah=rand(1,1e6);return($Ah^$_SESSION["token"]).":$Ah";}function
verify_token(){list($uj,$Ah)=explode(":",$_POST["token"]);return($Ah^$_SESSION["token"])==$uj&&in_array($_SERVER["HTTP_SEC_FETCH_SITE"],array("","same-origin"));}function
compress_alphabet(){return
strtr(implode(range('"','~')),"'\\","!\n");}function
decompress_string($Q){$wa=array_flip(str_split(compress_alphabet()));$y=strlen($Q);$fk=($y?13*($y-1)/2-$wa[$Q[0]]:0);$Na="";$Nh=0;$Oh=0;for($s=1;$s<$y;$s+=2){$Nh=($Nh<<13)+$wa[$Q[$s]]*93+$wa[$Q[$s+1]];$Oh+=13;while($Oh>=8&&$fk>=8){$Oh-=8;$fk-=8;$Na
.=chr($Nh>>$Oh);$Nh&=(1<<$Oh)-1;}}if($Na=="")return"";return(function_exists('gzinflate')?gzinflate($Na):inflate($Na));}function
inflate($Na){$Ze=array(3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258);$af=array(0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0);$hc=array(1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577);$jc=array(0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13);$J="";$G=0;do{$jd=inflate_bits($Na,$G,1);$U=inflate_bits($Na,$G,2);if(!$U){$G=($G+7)&~7;$y=inflate_bits($Na,$G,16);$G+=16;$J
.=substr($Na,$G>>3,$y);$G+=$y<<3;}else{if($U==1){$gf=array_merge(array_fill(0,144,8),array_fill(0,112,9),array_fill(0,24,7),array_fill(0,8,8));$kc=array_fill(0,30,5);}else{$ff=inflate_bits($Na,$G,5)+257;$ic=inflate_bits($Na,$G,5)+1;$yg=array(16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15);$Hf=array_fill(0,19,0);$Gf=inflate_bits($Na,$G,4)+4;for($s=0;$s<$Gf;$s++)$Hf[$yg[$s]]=inflate_bits($Na,$G,3);$If=inflate_table($Hf);$bf=array();while(count($bf)<$ff+$ic){$Ri=inflate_symbol($Na,$G,$If);if($Ri==16)$bf=array_merge($bf,array_fill(0,inflate_bits($Na,$G,2)+3,end($bf)));elseif($Ri==17)$bf=array_merge($bf,array_fill(0,inflate_bits($Na,$G,3)+3,0));elseif($Ri==18)$bf=array_merge($bf,array_fill(0,inflate_bits($Na,$G,7)+11,0));else$bf[]=$Ri;}$gf=array_slice($bf,0,$ff);$kc=array_slice($bf,$ff);}$hf=inflate_table($gf);$mc=inflate_table($kc);while(($Ri=inflate_symbol($Na,$G,$hf))!=256){if($Ri<256)$J
.=chr($Ri);else{$y=$Ze[$Ri-257]+inflate_bits($Na,$G,$af[$Ri-257]);$lc=inflate_symbol($Na,$G,$mc);$C=strlen($J)-$hc[$lc]-inflate_bits($Na,$G,$jc[$lc]);for($s=0;$s<$y;$s++)$J
.=$J[$C+$s];}}}}while(!$jd);return$J;}function
inflate_bits($Na,&$G,$Gb){$J=0;for($s=0;$s<$Gb;$s++){$J+=((ord($Na[$G>>3])>>($G&7))&1)<<$s;$G++;}return$J;}function
inflate_table(array$bf){$R=array();$kb=0;for($Oa=1;$Oa<=max($bf);$Oa++){foreach($bf
as$Ri=>$y){if($y==$Oa){$R[$Oa][$kb]=$Ri;$kb++;}}$kb<<=1;}return$R;}function
inflate_symbol($Na,&$G,array$R){$kb=0;$Oa=0;do{$kb=($kb<<1)+inflate_bits($Na,$G,1);$Oa++;}while(!isset($R[$Oa][$kb]));return$R[$Oa][$kb];}function
script($zi,$xj="\n"){return"<script".nonce().">$zi</script>$xj";}function
script_src($Vj,$Yb=false){return"<script src='".h($Vj)."'".nonce().($Yb?" defer":"")."></script>\n";}function
nonce(){return' nonce="'.get_nonce().'"';}function
input_hidden($B,$Y=""){return"<input type='hidden' name='".h($B)."' value='".h($Y)."'>\n";}function
input_token(){return
input_hidden("token",get_token());}function
target_blank(){return' target="_blank" rel="noreferrer noopener"';}function
h($Q){return
str_replace(array('&','<','"',"'","\0"),array('&amp;','&lt;','&quot;','&#039;','&#0;'),$Q);}function
nl_br($Q){return
str_replace("\n","<br>",$Q);}function
checkbox($B,$Y,$eb,$Pe="",$rg="",$ib="",$Re=""){$J="<input type='checkbox' name='$B' value='".h($Y)."'".($eb?" checked":"").($Re?" aria-labelledby='$Re'":"").">".($rg?script("qsl('input').onclick = function () { $rg };",""):"");return($Pe!=""||$ib?"<label".($ib?" class='$ib'":"").">$J".h($Pe)."</label>":$J);}function
optionlist($wg,$hi=null,$Zj=false){$J="";foreach($wg
as$Ke=>$W){$xg=array($Ke=>$W);if(is_array($W)){$J
.='<optgroup label="'.h($Ke).'">';$xg=$W;}foreach($xg
as$x=>$X)$J
.='<option'.($Zj||is_string($x)?' value="'.h($x).'"':'').($hi!==null&&($Zj||is_string($x)?(string)$x:$X)===$hi?' selected':'').'>'.h($X);if(is_array($W))$J
.='</optgroup>';}return$J;}function
html_select($B,array$wg,$Y="",$qg="",$Re=""){static$Pe=0;$Qe="";if(!$Re&&substr($wg[""],0,1)=="("){$Pe++;$Re="label-$Pe";$Qe="<option value='' id='$Re'>".h($wg[""]);unset($wg[""]);}return"<select name='".h($B)."'".($Re?" aria-labelledby='$Re'":"").">".$Qe.optionlist($wg,$Y)."</select>".($qg?script("qsl('select').onchange = function () { $qg };",""):"");}function
html_radios($B,array$wg,$Y="",$li=""){$J="";foreach($wg
as$x=>$X)$J
.="<label><input type='radio' name='".h($B)."' value='".h($x)."'".($x==$Y?" checked":"").">".h($X)."</label>$li";return$J;}function
confirm($Bf="",$ii="qsl('input')"){return
script("$ii.onclick = () => confirm('".($Bf?js_escape($Bf):lang(7))."');","");}function
print_fieldset($t,$Ye,$mk=false){echo"<fieldset><legend>","<a href='#fieldset-$t'>$Ye</a>",script("qsl('a').onclick = partial(toggle, 'fieldset-$t');",""),"</legend>","<div id='fieldset-$t'".($mk?"":" class='hidden'").">\n";}function
bold($Qa,$ib=""){return($Qa?" class='active $ib'":($ib?" class='$ib'":""));}function
js_escape($Q){return
addcslashes($Q,"\r\n'\\/");}function
pagination($D,$Mb){return" ".($D==$Mb?$D+1:'<a href="'.h(remove_from_uri("page|next").($D?"&page=$D".($_GET["next"]?"&next=".urlencode($_GET["next"]):""):"")).'">'.($D+1)."</a>");}function
hidden_fields(array$vh,array$de=array(),$mh=''){$J=false;foreach($vh
as$x=>$X){if(!in_array($x,$de)){if(is_array($X))hidden_fields($X,array(),$x);else{$J=true;echo
input_hidden(($mh?$mh."[$x]":$x),$X);}}}return$J;}function
hidden_fields_get(){echo(sid()?input_hidden(session_name(),session_id()):''),(SERVER!==null?input_hidden(DRIVER,SERVER):""),input_hidden("username",$_GET["username"]);}function
file_input($ve){$rf="max_file_uploads";$sf=ini_get($rf);$Sj="upload_max_filesize";$Tj=ini_get($Sj);return(ini_bool("file_uploads")?$ve.script("qsl('input[type=\"file\"]').onchange = partialArg(fileChange, "."$sf, '".lang(8,"$rf = $sf")."', ".ini_bytes("upload_max_filesize").", '".lang(8,"$Sj = $Tj")."')"):lang(9));}function
enum_input($U,$Ba,array$n,$Y,$Bc=""){preg_match_all("~'((?:[^']|'')*)'~",$n["length"],$pf);$mh=($n["type"]=="enum"?"val-":"");$eb=(is_array($Y)?in_array("null",$Y):$Y===null);$J=($n["null"]&&$mh?"<label><input type='$U'$Ba value='null'".($eb?" checked":"")."><i>$Bc</i></label>":"");foreach($pf[1]as$X){$X=stripcslashes(str_replace("''","'",$X));$eb=(is_array($Y)?in_array($mh.$X,$Y):$Y===$X);$J
.=" <label><input type='$U'$Ba value='".h($mh.$X)."'".($eb?' checked':'').'>'.h(adminer()->editVal($X,$n)).'</label>';}return$J;}function
input(array$n,$Y,$r,$Fa=false){$B=h(bracket_escape($n["field"]));echo"<td class='function'>";if(is_array($Y)&&!$r)$r="json";$Ie=($r=="json"||preg_match('~^jsonb?$~',$n["full_type"]));if($Ie&&$Y!=''&&(JUSH!="pgsql"||$n["type"]!="json"))$Y=json_encode(is_array($Y)?$Y:json_decode($Y),128|64|256);$Mh=(JUSH=="mssql"&&$n["auto_increment"]);if($Mh&&!$_POST["save"])$r=null;$_d=(isset($_GET["select"])||$Mh?array("orig"=>lang(10)):array())+adminer()->editFunctions($n);$Hc=driver()->enumLength($n);if($Hc){$n["type"]="enum";$n["length"]=$Hc;}$Ba=" name='fields[$B]".($n["type"]=="enum"||$n["type"]=="set"?"[]":"")."'".($Fa?" autofocus":"");echo
driver()->unconvertFunction($n)." ";$R=$_GET["edit"]?:$_GET["select"];if($n["type"]=="enum")echo
h($_d[""])."<td>".adminer()->editInput($R,$n,$Ba,$Y);else{$Md=(in_array($r,$_d)||isset($_d[$r]));echo(count($_d)>1?"<select name='function[$B]'>".optionlist($_d,$r===null||$Md?$r:"")."</select>".on_help("event.target.value.replace(/^SQL\$/, '')",1).script("qsl('select').onchange = functionChange;",""):h(reset($_d))).'<td>';$ve=adminer()->editInput($R,$n,$Ba,$Y);if($ve!="")echo$ve;elseif(preg_match('~bool~',$n["type"]))echo"<input type='hidden'$Ba value='0'>"."<input type='checkbox'".(preg_match('~^(1|t|true|y|yes|on)$~i',$Y)?" checked='checked'":"")."$Ba value='1'>";elseif($n["type"]=="set")echo
enum_input("checkbox",$Ba,$n,(is_string($Y)?explode(",",$Y):$Y));elseif(is_blob($n)&&ini_bool("file_uploads"))echo"<input type='file' name='fields-$B'>";elseif($Ie)echo"<textarea$Ba cols='50' rows='12' class='jush-js'>".h($Y).'</textarea>';elseif(($ij=preg_match('~text|lob|memo~i',$n["type"]))||preg_match("~\n~",$Y)){if($ij&&JUSH!="sqlite")$Ba
.=" cols='50' rows='12'";else{$L=min(12,substr_count($Y,"\n")+1);$Ba
.=" cols='30' rows='$L'";}echo"<textarea$Ba>".h($Y).'</textarea>';}else{$Ij=driver()->types();$yf=(!preg_match('~int~',$n["type"])&&preg_match('~^(\d+)(,(\d+))?$~',$n["length"],$A)?((preg_match("~binary~",$n["type"])?2:1)*$A[1]+($A[3]?1:0)+($A[2]&&!$n["unsigned"]?1:0)):($Ij[$n["type"]]?$Ij[$n["type"]]+($n["unsigned"]?0:1):0));if(JUSH=='sql'&&min_version(5.6)&&preg_match('~time~',$n["type"]))$yf+=7;echo"<input".((!$Md||$r==="")&&preg_match('~(?<!o)int(?!er)~',$n["type"])&&!preg_match('~\[\]~',$n["full_type"])?" type='number'":"")." value='".h($Y)."'".($yf?" data-maxlength='$yf'":"").(preg_match('~char|binary~',$n["type"])&&$yf>20?" size='".($yf>99?60:40)."'":"")."$Ba>";}echo
adminer()->editHint($R,$n,$Y);$kd=0;foreach($_d
as$x=>$X){if($x===""||!$X)break;$kd++;}if($kd&&count($_d)>1)echo
script("qsl('td').oninput = partial(skipOriginal, $kd);");}}function
process_input(array$n){$u=bracket_escape($n["field"]);$r=idx($_POST["function"],$u);if($r=="orig")return(preg_match('~^CURRENT_TIMESTAMP~i',$n["on_update"])?idf_escape($n["field"]):false);if($r=="NULL")return"NULL";if(is_blob($n)&&ini_bool("file_uploads")){$gd=get_file("fields-$u");if(!is_string($gd))return
false;return
driver()->quoteBinary($gd);}$Y=idx($_POST["fields"],$u);if($Y===null)return
false;if($n["type"]=="enum"||driver()->enumLength($n)){$Y=idx($Y,0);if($Y=="orig"||!$Y)return
false;if($Y=="null")return"NULL";$Y=substr($Y,4);}if($n["auto_increment"]&&$Y=="")return
null;if($n["type"]=="set")$Y=implode(",",(array)$Y);if($r=="json"){$r="";$Y=json_decode($Y,true);if(!is_array($Y))return
false;return$Y;}return
adminer()->processInput($n,$Y,$r);}function
search_tables(){$_GET["where"][0]["val"]=$_POST["query"];$ki="<ul>\n";foreach(table_status('',true)as$R=>$S){$B=adminer()->tableName($S);if(isset($S["Engine"])&&$B!=""&&(!$_POST["tables"]||in_array($R,$_POST["tables"]))){$I=connection()->query("SELECT".limit("1 FROM ".table($R)," WHERE ".implode(" AND ",adminer()->selectSearchProcess(fields($R),array())),1));if(!$I||$I->fetch_row()){$rh="<a href='".h(ME."select=".urlencode($R)."&where[0][op]=".urlencode($_GET["where"][0]["op"])."&where[0][val]=".urlencode($_GET["where"][0]["val"]))."'>$B</a>";echo"$ki<li>".($I?$rh:"<p class='error'>$rh: ".error())."\n";$ki="";}}}echo($ki?"<p class='message'>".lang(11):"</ul>")."\n";}function
on_help($qb,$vi=0){return
script("mixin(qsl('select, input'), {onmouseover: function (event) { helpMouseover.call(this, event, $qb, $vi) }, onmouseout: helpMouseout});","");}function
edit_form($R,array$o,$K,$Rj,$m=''){$Vi=adminer()->tableName(table_status1($R,true));page_header(($Rj?lang(12):lang(13)),$m,array("select"=>array($R,$Vi)),$Vi);adminer()->editRowPrint($R,$o,$K,$Rj);if($K===false){echo"<p class='error'>".lang(14)."\n";return;}echo"<form action='' method='post' enctype='multipart/form-data' id='form'>\n";$xc=false;if(!$o)echo"<p class='error'>".lang(15)."\n";else{echo"<table class='layout nowrap'>".script("qsl('table').onkeydown = editingKeydown;");$Fa=!$_POST;foreach($o
as$B=>$n){echo"<tr><th>".adminer()->fieldName($n);$l=idx($_GET["set"],bracket_escape($B));if($l===null){$l=$n["default"];if($n["type"]=="bit"&&preg_match("~^b'([01]*)'\$~",$l,$Jh))$l=$Jh[1];if(JUSH=="sql"&&preg_match('~binary~',$n["type"]))$l=bin2hex($l);}$Y=($K!==null?($K[$B]!=""&&JUSH=="sql"&&preg_match("~enum|set~",$n["type"])&&is_array($K[$B])?implode(",",$K[$B]):(is_bool($K[$B])?+$K[$B]:$K[$B])):(!$Rj&&$n["auto_increment"]?"":(isset($_GET["select"])?false:$l)));if(!$_POST["save"]&&is_string($Y))$Y=adminer()->editVal($Y,$n);if(($Rj&&!isset($n["privileges"]["update"]))||$n["generated"])echo"<td class='function'><td>".select_value($Y,'',$n,null);else{$xc=true;$r=($_POST["save"]?idx($_POST["function"],$B,""):($Rj&&preg_match('~^CURRENT_TIMESTAMP~i',$n["on_update"])?"now":($Y===false?null:($Y!==null?'':'NULL'))));if(!$_POST&&!$Rj&&$Y==$n["default"]&&preg_match('~^[\w.]+\(~',$Y))$r="SQL";if(preg_match("~time~",$n["type"])&&preg_match('~^CURRENT_TIMESTAMP~i',$Y)){$Y="";$r="now";}if($n["type"]=="uuid"&&$Y=="uuid()"){$Y="";$r="uuid";}if($Fa!==false)$Fa=($n["auto_increment"]||$r=="now"||$r=="uuid"?null:true);input($n,$Y,$r,$Fa);if($Fa)$Fa=false;}}if(!support("table")&&!fields($R))echo"<tr>"."<th><input name='field_keys[]'>".script("qsl('input').oninput = fieldChange;","")."<td class='function'>".html_select("field_funs[]",adminer()->editFunctions(array("null"=>isset($_GET["select"]))))."<td><input name='field_vals[]'>";echo"</table>\n";}echo"<p>\n";if($xc){echo"<input type='submit' value='".lang(16)."'>\n";if(!isset($_GET["select"]))echo"<input type='submit' name='insert' value='".($Rj?lang(17):lang(18))."' title='Ctrl+Shift+Enter'>\n",($Rj?script("qsl('input').onclick = function () { return !ajaxForm(this.form, '".lang(19)."…', this); };"):"");}echo($Rj?"<input type='submit' name='delete' value='".lang(20)."'>".confirm()."\n":"");if(isset($_GET["select"]))hidden_fields(array("check"=>(array)$_POST["check"],"clone"=>$_POST["clone"],"all"=>$_POST["all"]));echo
input_hidden("referer",(isset($_POST["referer"])?$_POST["referer"]:$_SERVER["HTTP_REFERER"])),input_hidden("save",1),input_token(),"</form>\n";}function
shorten_utf8($Q,$y=80,$Ni=""){if(!preg_match("(^(".repeat_pattern("[\t\r\n -\x{10FFFF}]",$y).")($)?)u",$Q,$A))preg_match("(^(".repeat_pattern("[\t\r\n -~]",$y).")($)?)",$Q,$A);return
h($A[1]).$Ni.(isset($A[2])?"":"<i>…</i>");}function
icon($Yd,$B,$Xd,$oj){return"<button type='submit' ".($B?"name='$B'":"draggable='true'")." title='".h($oj)."' class='icon icon-$Yd".($B?"":" jsonly")."'><span>$Xd</span></button>";}if(isset($_GET["file"])){if(substr(VERSION,-4)!='-dev'){if($_SERVER["HTTP_IF_MODIFIED_SINCE"]){header("HTTP/1.1 304 Not Modified");exit;}header("Expires: ".gmdate("D, d M Y H:i:s",time()+365*24*60*60)." GMT");header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");header("Cache-Control: immutable");}ini_set("zlib.output_compression",'1');if($_GET["file"]=="default.css"){header("Content-Type: text/css; charset=utf-8");echo
decompress_string('+c0=@iDWB2P?H+.Sh=;^l:{,zS(WKASq!V)jBmWb?2$th#Z-Ku]_;>Lan<jnKeCU;:~t5y5*eC7ehsBn^yDY2;h.o6kG`I;s9C
)r`$=4hC#.fpJw%?YwL)mj-qNj1#L>,CO1y.amH0(RpCZ1G"yjmkq-_R-.iBdAq:6sKYqdsMi9p{
;Dh5b-]C[00Vuu~-r].#d<y3??SZOYfAs^[*sI*i3FAx("`^,&jKhl`PXm8rvI:]pZ^n40+0sDIxK.O?g3[wmh9(BpHB:oy4*3yMo!0/G2+c<KpnP[2^zCJYKEq/M@<I
d91xW})*U(1VbQ>hF{sZ:v;;4p*/Y6kxKmE%fSxhy
WvupXRo985$6.$t1.o`SEgxt?2]J_t&!m
?E]Zt/S7j_,HS[kyX/]xM0Ej8@GVFnKOjGSk
y[%aV/THZsqO)Z"R71/qZCM!|l~@kQwFTHQ%UU{"/q}>~(V$z
plAor[*UnR,dC4&L;+e?"]_a0o|d1GWOSa]03EO8`.lu`8SUn,(V2:CW"D@1.[&&R???Wl)G;rzhl_bkj*s.TL%l%I~?)=eys$D;!u^;)t!opm^d=bYQ2gf_=Ua!m
BU*,bQ)=omlZD&@eU6vVX?b%0.n%VS]GbVb;VJYrsB>Si9H;.He[#,n8Lg`K!`<WU;!GCGmP)&:>b))?bYiB$YGoJkl*#$`3+owpU)$(OE[VgI2*+(5Mgi(D%lQt3YS..0~By#tL6it7ta>SC..k{uX3e!U
b-.V"Fs/xILp&5s*9+U1#;Wtt0lPX]d=tunSSW[3+ql+{$RV|l
`fci"x]k!I.;Y7hehmY1?ss%ox4PVnT>%6ttbriZGLE2*Vum36g@4(-Q6GQ
?Ann.}2Pc8T0GwD;Y|l*UyML,N-x4Lg/)9YL<e&,518>!DL.Op[(HB$WhkyuQ6pP#oNIr>o-4<i,:/ds8sS
?}Z)wyE46!*Y
[*:up.)%Z(W;#ttO@Sws~L8,9DT6?O&+pF>+eIz4+t|(m]8E2ODd1"sPQMp,pFXd0aa:AXYfQ=0K$gm8[4--76%e!x"yy#|3TQu%nk(E%;{>g`ABN^r[CEK]GU_-F,bSnA:>yO?X+%
n#_Da(KuaFo1KSVZ[5M9YgfdGF0bN-)j`$E7v3RRGO#C-I@J$k-c]P1,mc?d0lm,"AWQf#>&$Ty0$x"LMKEDVb%Chy&<p{?lBx<8F:?[uNA$b41&;*EP.w18
"O1ep*n3Q+7>/0}x)y[wj<FWXOS7qi<ry,Nn(&>UV_*D4*i#/A#m"5*#/B&4E;[g<tAenG5,gZfDx5|F36NFnN?6oWK]"F}p0S7xHER;:Tk8{y2irFYxs7S-a>AfC+0Z6]DAAk80k*b<;-}P7OI#+oL^<D7$u/Sk-E%6[dw4j;pKLJ<6v#"?@]28Gm-pQn:#L;DGIqneW
P>kk,rBE|anI%2g%Ih6%KO0[CqzV2y(R+E!-&Z<&{l<[8gxP;-[T#=~Jo6c
&:9qs?*i%?7[j/,&=[)gR,31a461N4`sC)L9lUuh"3`;N;Go}s@6Jf`%ocVd<1bc
<2(jIBa*lo<SOL.W>UI2s<gfY8*xoboIM~RC!#,AS,FoR/p]3wEkm;Ga,9G)Pf+k
>7/VN!<tBdkcHodco#>/,[+DU93C+yJ&qoW(vkA$PNG6c(]X
/U(`dMKoW?*BBndz<2yS)n@ot:kFsH&kD<7S^%syOf$5ASlCW[vNq&CW8,lF0L:tHVWKNAr1A9I`]O`MJjNaP}?_3k"V[u6*/0
;1"I=RRs~F,5PnVxv8]?[9t:bG3:M>bT^/E.d*b*KV"h4p`9Ynl?j2WJ&u6)(JqcC.IM&"BX}@FTmA@A%#q$#AJlwv*#Pw3tf
X)]aNskV4H#6Bku5iZjHj^OdWH:n~N3-!7AK-H-6`h%tfV$t9vh=)o}%:=(?Qq^W{k)_#x?su7Ej,7ml7AEj6"y3#4v9nHC-?Hqm8raoE7g"Y(jE)Q/KwT:2{-G:b_uFDRl2bNK@:^{X^$OGv(4+DK{^#TF/;
a
#:yRz(<TRXj+ZbRV">7*,O
@UAr8E@=[`3#oD-?2Rt@n6u8$)&X^APDeZ_[;!EKqKswXFWo_i*4rKxA*E,/N7oD
xSxqj;";X,>Ak=p&9JgTTgVkaq!D%9U@#,?X[jmxZTRyDweAIx)W,qMm:WTy()UQ%jgZ-x37ue7kkq.@{[jq1P^uhnSnhy6WNyEmpPgJQm^Go23m_tO,Gn:L_B^wUx"a[oFtLM/n]c|ecn*yVF}v[by,ap5x{5.9F1%]EEj27ypKkK&KlFQ_,b[yve0XsP"cf2_*/qiuyLrIMM/7_lI]zz)0;MCFubqBp_bQU7MwVy)-tr%Q
l8WUIbF6)"c?SFKIXwIZZ|SKm`A.</ancccTY"w<.wi2l:_T&lww){p5CN>wGo_~Z"_$([qgb8A=H:XwJS!Kji[ke|D&+fTN(aS$xayFy=0/D=mXXgeDh2]ne=>JH3ATi]fj:;=N++#W]<4S`mXsd<Fhw]b1)aMt("Iv)&^6xo/@R%De
40s.d8V2$0u>*
5LS5BrbEvJB:G
QrG=bQyo2hKiSagWBC*[03iq@
;8AG{CI[vgMbo=&]CUH<2J#$I)1Opt;
6T_jLmdf=2?`o;ceXMwP>-gZ#179]@=tG1y:#fDl~DPi3@0Pjer:?BMi#3O-$sf6Y-10c<%b.Y<N]q+EwBy*!.u)_J/:$1ZjZmVc;jAJz]imwg,Qtb/S)/lX$Re17Kkyi`5%p*2)Bc3C72~KdCcBLgteSrJdei-TeF-_jdE>im]H"6GkaM;`]=iIA1dp`5NaSeBn%PUU.T$cQSlj3E8A8X#K;/ZT*D?H|Z3_vxvQ&?&OEDYaz0f8PA@]U/
HrU3]~c7hieBb{7/crTVx%/+5-*@S12x^^
Tv
NI5,KYeq_~a8coh/]c#A&jg"
&,b-vH%!vWf)Cd?u$.4!t;luAGj,?6:4#c9tp+AX9^K-Tsh(]mx9)5m[0[6`Y[f0AU(j(G;#Lu7;hN1E^x<Jw.H?@^wF*
E+>WNXA0zOIN%9NBtef`lb4:]RLqoc4u4UX7}S9M**i;G,WqWJil4oFtPVS%6d&,IlU.BB&6v0|ojAX#bG/)sV6mX<7,(YbjMSVB?Y;@XTx@>Rj_x9I4yB-4pjwniDT2``8K1q$fi>RudNs1(kY8VU]/x..C=[7:.o]KW?L^j^^^5*>BHxaY<2bRZ4,SiA:c
cb"61L;(Y^&fSkA,:+o;TAcVL-8ihCI^:Mm@@nB2.o4mYJK.Keb:h=@a?=V(&@/|rn>})es]IsX)Ijwn3hT24#Y@j%5x?:o"m@b}V#ncaM@*Kt)86t.ocwm(K5H=0XfdV"&vit9HOnYfYxKT8k936(jg`1`G%SH83}bA_s,&>u=ATHaA^]*/`W8D&&*<Zi@K]%lo"S^TQY%&yL%~("8.r{QK3QqW7e+y%(=)3`<CbS(mFiXzcj<i?6ql@nEHXf/eFxM)>)a~Nc2=)LnV^?4J+T-T-vw#5vt-RvC_*MD"d$?u]S6sJM2^-=0;xuAOQ>P
?0v|T/LfA,1P[ZK^[F3o]m,1LPkT`@,+R}%<RG&/l7iwR@$/lPC,]9sw9+6L<c%k2S4}PJUULEfX[kQn<"8gEn("A1v}M:;,tCka]2w1"q]]wj2Nd[x^TIA)G<(yw.MTtX');}elseif($_GET["file"]=="dark.css"){header("Content-Type: text/css; charset=utf-8");echo
decompress_string('%OsbOb3V?!K0U*/_K8!!_q-f@v$o[s#eo
DBus<$lON[d8].,qN*m@-poH?R.tyR)O-"TS%KHdM%X3Y.^#Y_hHfaP;q*c?klD(H<QI%Lx,N=.GQ1$T#bV4tq#Nz%
?3w,vbJXqxP3M+9rv`E3"+&ta#-z:q#uH,gsfr;30Y
YD](8VM$vfC0N0c@>"2)GKk6Or*glU2;_e]
lG[qCHj,)N{dgvz5Bxo,St/",-!<m&YguCEOcf=QW&YqSe0y
4tMFl.S5
Q&<3MG&3I$EKa#w5d>?0G#ziI.mcH[Y^xh]n`F<v_9TD-S)yGMvrG^6L=^u]hu~T)XX@%sH2|^MUMM~_O=Lb/j<P[#8jzJ=&?+Lf&PJqQq.7RL#R!3,OUtS?m?2iGs<Z53YxESS/kZ&u!9n9m4#Z~@-oU.[]>QKtIKdd<Hl)Jt[fL#S_x"K+ANa$N"-vrNv

s;AjH"K_hHtyTN0yfA1K;/;F1cD>Dq?!D}QS[!.vMbxL7Yt*f95&ALDq5fB7EhPixM9U-DAhYDVZvb&*VNnYm(ws!LkSX1hT*rf?L?8pLXxiM@vwMc5+L:2N1cn6*pvi+]b-Aj?Ky>:w8"9"eJEDH7YPC/H4sp2BTlYJ4)>xqL$7MHqrU^F
Mq,+cY]Z4{i1WT_a+CI<OH2!jmJU5RI>@LSbVBv>m0_UI3wJw,DVQw*|?w%hHQT(fAdA:}Pu?y<E7VZ;o&F!SfCnKXXmJG3b-0(S1ciBQRFKE$/KyBZ-x~Y&F6),Vt<HA&pAezJiGbD]=9MElur7.Zf,Qp^{f?%4w+^N,&@4A@$CRbNWa
BpG&xQXj#<V0ho]GUh(F0y)N*XAG09Hi!8MGrt3p7rNw=qLDJ7BG1f8rSCi^;*wx=3-B=cetZY63!qW$uGUnB%^t^=7NDGe@tP');}elseif($_GET["file"]=="functions.js"){header("Content-Type: text/javascript; charset=utf-8");echo
decompress_string('*hcbOg~ZSGrK,tnTpUC"nSgx@i@Au14)aq,?AJwvi&hL-=aQ=P|#W=sd(@=1d0#u
.Dh9L{3$vyM[!L&}1
o)Z&TjD5G9jK5-IUAr/2utCtE`FD<N4e_mc2W<c60>hiMM/`qL$1QlWFAYW#hIG_m1*ub?EHk)ZQMp4m_SG[
{GtgNjd`{cWocVqWla-"!N>PM:dEf/.(cs/Tvc.V
t}/;D)c~39?dv{Bsj282IuM8,{G;"WQl/W_eX&aD)k5_y
U$czc4T3;7hcQj>yJ$-s;U%xdq6+SzkhO-Hnk]%Qq<5QZx]eb[O4Z6C~,~Q~s.K6Q}H;)71&lMM{o-Hqy:^9SK@+uAB"OZJL3B`Q3RE!6N+4TV,fIeY#Wu<^oGnRYUYlh@M
y?`|><Qvv/DQYtSWb&;LyPgjDR%gXw"j+mB*!>q:Qp60w&<WL~r;gk;_J.B/`FcQRZ:6EU(jN<l*tn@n)5A&d0i
rUm3.+_nPLoa88x-LN_OVr0~Z_JC+&U"(M?Dt&_Y*%Uf_R8qH7:["om(P&iLTuxk,H/P!HZc0wrd:^cw!bvAM)wnlI"SO,ZoETvlFH^LDa@MvlN?yPFmWlmZsNk^q*X=[zLwGNC%`-E]_NEjvNO8(7)76+JLJy-8<e]jBhDO@2xC=7R8TM@6J?u9Qb#%j{^7;<IK#0W<G|pVKBWgQ;yLg]wWoB*^@%6VxLb;3M$6L^)^RRB2eSa=n3,E,i<L>4@^3v=q,^Lp0x=k5^b}n=Ie8?v3r8fR_D2wqj6mKFyyJ.yQ`3E1GWk@v_BXHBL&`}U1g~>-f;La*{%g($PUor+!%UXQxN_)lMc`b1LGmX`uP+g!,S=n>s^yp~0"MR/6PhTCn(<ei+Wk[:Map~q.c0"A
A=WJ:JnwJVR
;PN<(H^&J"{4(+a%A_>_iZk(7<>twY{!>_5uvn`)zn7"..@y2U,#Y*ri^D3*4rwgjvsG=G
K
KU?CiYQhtubWZ
mCZo
h;D-BobX^u}Ce]Hs^iGfYZ_(DR/ndSj<"#iMgoIdP!8Qv#!7f)rT}NF*"NGc=EW<SxQ?YTP!{QkFpZsO$--(!!z*?R=&M]D"A(nL^h%eXO?MVb)xb,P_G2>EE
}A+T*s`hRd[No=]@>e"PsIw_3-}UNK#p{A+x8V"Og>tQ#>NYnEh&_4^Z2jUvVgqmPVwB>kW$lUOt:$qVvi?xY/k(65OPqG)dQ<@3xR,&P)+=[FN.Y]3/=P}dW4ruq>L(q>->9tS/eDEDlLyp}Gb)317pN5iApal[o-2&][jcnfv]/mYbbSN4gVhSU"q9!]+R#g`oNn$<e64^W$7IRmjWMN3+B/jo}eC:$fi:hPbIS>R:_oO!;IB[Q?=PYO0MceXC+khRL0!`$;"_vtXqx)q&dCB<k#[!IS2]n8uC&$|Lc$/4e2Y$H2M(*X$)r/Y2E#n9b*eK]v!3@lL@|yxPpGa=oi1r9JM(LYDR8md7-"5cIMyxRupBVm7l5->FpSVGsx%5T3aB,
"=)&785(~IP([%Q(MF8]<*5e:lD9Z6yGN-WlD?""i-|
Pj[MpVT_;[Wavge?K1}&>3uOI&_
]:SS_K{-n@Cw7u_uV!lw:"}65q3f8taY:sp6]-pT$f~L!2`3H8=i|T}KuBVTH[jS2n6"Y+Ru>.l*U7RQ/L&bNcAbOlHiSsS1b
Iv(j#Uk=Gi:":$pHNLb0LgWviMY0J%.15D]]h%,b[8q5fOO`8Vs?XF-pbs7gvl!8?]mI~io8/:Go635o/Pek:Zr5bGhVdD3>v:ZInby5+^n4uFTkcE7M{<R6<3F8^7-jJGXfDw_lTY2JsY["XWX
!OFHqdDwHkle%PL`j))S]oO1@n-,h7RkpF&p{oDj5vluaWZ+i`EBIw|+@wB0V3kJ8X9%K&ko2<egaHP8I&x5AOt63:"bbNufQPfv]#C[VQuio(MQ6[e5dYamQ^:.L-ctoH/[AN(1JN.DUx?E6Rs=<w@25$)#V
Rb!17>UXQ^&ZSL*]OAgch/phl*)oEiuwE#PR/>[NyOdC?p?oml,:"v:0y=]VUyjZH)*ZqVr(I2a2_*PH<<t*8J0I?uoT@/$GKJZ.]fO-60`@G@O;lDjXA-bym
OH)usO_ZsVQtL=!.d9?<_CQqyh~HI9q1",u.st#Tb!7rHGg4"1kZ=n}vTh_riA_i?c5K>G5[E^`,gDr3EDy&#+GkS3Zd,E&Q`<1J[XT+s7E(?5|Pl2?X`VWVgwkKQdZ#IFJ_Th[y#nwmOWRX~mceTF-<T,S_j#n:?V6N
c=LhNYgREbxRKDP^Kscc]@d0b0uyQbcZ$*[qL@hc-Ai_nocNGLmvbq`O3YQ_=cu6j$xKg8[_%sP$Z@rC&[Vg5IJX"H&ow;p:mO`9%YDK&r-1-d$ompw0T&IZtswB8!W1C&f&6?:<na?y7>lUViBZJm3CFF$,kUV#UzO,9n"j1dk<I%m$sda$!Ta1%w&4YAc%])mQwgoh6xl@FUGb6&
p_ZjaCj)t0:5$!1PkoQ(T%zu}A?Rd
/dLn8!_JS56"U%;avgyU&fu#K#$7zCyk1n7KOhq7AyW@Lj[$q(noA,VYWfo#w%7b&TJ8r1_3V>)PCP3-dt>X!A|sdMBOI1odddY;v_F^
C%!L^kYV4`u#I])b[u(,?gLp
EQNN/D6I/22OA?u!FnJ[KL%ZH#HHICmia7lk|@)9--I3f6xL.I
whcR_g[t^|S)2h!;P2R-_i)CWVxM@?OCdMEvIqADhOJQkb6k=9e_de&1-~2nu]d~XN1BZ.QX-{]Y$OIJ[@2!h,R_">Clt}X>,#b`Kmpy:p?8bBN}Eaq7dKCoPVgwxP/8*gTDfL1z*edbM^<Xsj.G$x=YcFxZUQh-D0)]?$rL2DBLh5/F*7Sjke/sTdWR8Qfz<S90z!VR1AyQg(]n`UoLobr@w]HPVU5=HD-0=z#vwcMb$7k>/YSH%&]U5{jFfu<4fFYLu[2P8mI:"]qJD~Gbj_nV2h<j$ud*e8q*OT8Ww2V1L
Hr/?Jj>UR?VZ7:ve&e#0ssVN!)Y`1ZQRl6)Hx
oU:%6Vsg-Id.?va?A7x`k(aCu+EE&3%w8
p[Wa`m?G?hm9JIyi#A,-qokLI9AQ%*[V
=EAm|kVKu]|IL+:6
UVSum?[c,@GOsJB`_$"t/{@Z@{r6409|)Z1#l9RSax72ob4^k@[IKq$cb<?C=7NcKe<,CAnr
%rtr%>>%v.]v:^QtZ-ACm5v
&>&`Iaf:nF7heJs454xBFBHt2`f53:.od>W
ns>AIwDM"dNJ3y&!]DVi6C90xsme:c;Gu3"9)2,qMJ8r1TSHV<k[}C>Wuu!7iw">^UA_-prB#:ew"
q@FEjt#r|flmYy8j!CMZel#(t6%lvF4o]GVxqn&HRp|4RGn*$<d$;jD`fa3c+x]x9-b:W95[G6^p4o1U7`n.Q_pZ1P_5awJZtNLd2IlTbBYnly!okK|ctT{%O>z"Re08tAM&qOv<n@X`@oH9kq[R47/?u6l_d=a+n<W57G`^Kl
Y7D8(N?>]:%$`SL
51g|"LgKMMw3v_9JtB0Ly[;C9&8QT^-px)Q|4<yWO-N/[qWAba6`jiC5-69LrZx?H*i4iCPYiFHJ!&rZ,qj~@AX)3xKwtjq=](?UEu%XO|_Ww8?cMr`(1/w%XmvPkBQXLw(0r]@,w0Hx.v;5_.^bw"KVxK514>2yy|y:It9{dC"U4=H/!6$zbG*=^P%+s9:Vwck_<1&3dT>|T~UoJsM
P*bgL`yS79s>h"=`oAxd/YAo^tUsju*.-f1(Yywbb%lJA3!Rc4%Y+}QMax(#_eW<FZYqLa<409s*6]w5eG!Gtnt.;@FgF)DsHd@78,)9gA
7dcS3Z{d+;@B3_yL
k
c$M()qNM
W91Sqg4)LL%##W5U$U<rJrqr*QA%!9UOSPkUR0qY(lQK>6FP~h6?%w#e%H+?s7#.n(k_C]He*lGWY=J6vq}cM,(MtT~K&"9#*:R>xd3u)kgJ$fn2V[YpwTBZ65S(B@[v!ti!~^aW+IRy;3m2Sm?@>#_$]72nU#aR~mJ8B]P0R(Dvhr*`/I0fY[eY0p?_Qe<5"`T:aD=mcE2tFtce|yz^"%t/DftQ0*/[G-58uN9hpwqh;RLk2@?!4I(8r*R+u;Uj^LTwI7^?,pfh!A4S
"8[Jt<R[0(o|pv$a9V:-H7UNxJQAdS&!nT"H6]3JkfR8nAp36"XbH[8coaHzZ
%-dU=0gii7EE4~"j6I6:ql."BLcYG61|.2eMu%wZHomT7c#rFZWX@
&ky$2>3$D7GI(ayW3).XbnpW))@~,Qi,KnCh@96K)J9!p!+a8%/1r[/2Mx#m(H/F&.H]r_CYf:KI,u2P*w!yl1.)eCIFS6fyEZv?aVr.)GXR*WUKV]ha,*5[(~Kk.@A$E2"8lZF{I(yKOvc3"
<XCsIObKs#:~"(y5Q3oU,jHNhs/g&ZlYE?CD>%;S"<KUdIkf.Kq/wB:}Nnj>Dd[Q^ZK9utoZ)"70=)Z,q?R"._JNWO4an][GgJ<
V@)Q)sf=#l8xbgQ[[|6MG"_cgc;l@*Z"=ofpo-<B$V<DKM9lcEV/4gt4i#r7.NV$DqRb_R:xJN&>Vl,K=.X2I?Y=*BT9lE>{<v@#q@Z7w*0N)1Y/DEG-)X-^#AA["d05;tfrbd+?.Q8XuW@@<8q^lMiq5v>X>G/^hlbFO=v+
9+xw`-FxpS->2+?KsC=<t)/=EB373&wA^@Fd,O{H2Cvse7<!ZsGlB03@dx1<@ie<}.)QVmEMg8"jHG@4L`~qyJ`O5*g^"@$"ngdYr?I+d>.5Tea$Y,*E}JH.%7m&lNXjjVJ1X8P>u!90xce"xQgokpN/Hqar6WU<GiscV%^0No,:R-Yo8YD9m7}a_2A.SBn:L9I31tu^rha8;]._G&h("Reei=?>}6;QFGQ0Z[@7pyGe6?UZ:R~%[!h0O3E8P^Xc53za-P@VW_e!<#<gB(gmW_!4*_Et+mo8RYs)<tyt?0yABXwyZo+UZVkb94~EC22R|OHh=dhJLqo*GNbIhPH!}<V#8REnu(ntxX-_|c[ELBghCB7/S2YY5(n
9f$8caxoNFWNmIrZZ;@+/7#t}ICS^Y1G/U$
F<yu04AOJaJJ>=Dj22n,[.KWZ$BG8t&LRj[$5s;QEN@--.%evg!-Nm_1y
fdpTaNo6W*i,%($b[lz<Z7Z>1()ubPQ+CjdQ:9F&1mBAp4no,ru:kJBaG%WtiRD
jkg[5Fe]0m]v)X4p4AxOPBbOL!?q.oLc}@2xNWrV1jgD,@zfSp+P`qk.Aq,#w2H@!6S>l@FO0Ftu"WJP-P<fW2r+et_#>4EU
@/o%A,!v$3D:!Q
Q6<@|My6C&T4jtN)Kb1o:utHI56Rr>VnldMJ=en=A_*8]Sbh0W6ssEZ^~4C=]0s)+blaXMl5mSQy2t`S3mGf*^,N-h;W6>?m8.-goKWio+O["xoQk/8.So[@zj;&RE0<VtYAv)Zc9q<&a5Psuqi#kj{_dVb0Xq,Tp
gW!K5kMM+UVoo(g`a6>fW#abE!6#GWIHuXvku474|u0-K9-2B81Gnp7huLUf;JR#uB>P2pTQ<ZE;#G@k#.9$:,q3@BLo?`C7m8RkL@p@GFXiOz!l9QQUn#]i8`_jc;i0*mm-MfcXD`-26Q6/OopY{
ocv3ewLIz/#
jL1*C7u,9VTt4;^e[3GgteoLvZJy2VPi92_YWjSp=Z*=I1t-X+En*
oLx=9fjbM<#6N+GVLfb7)D/6o^ktdRx3?ggF|=Vkq2=G/cr8=%w4iN^`p_}!:Cy?JSxWDOkfMCZVpws<)R9*MazkYgn=&g?_klr`|M4V8Cu@Mw<B5<b[f%ZQA7RdJ^F@E!Fd!y$yzwIw7`RANZIyaz)o`U>Z>KL6Bvhb:h):*UZw<66yyTBz%*-chD[]}J8qA"p
ihF8>IISe:P/[JPHd<d%ggDGnVae|^~HP>.i.C=>"`)a=s3oES2`ce*6e%~DF_85N>`KnYk3;tWUOIlCktBF]0@GDt(uDPf6q0*3fyZJxN%7(5"M&DOPt^xw)OjdK3%LBl#doK%E"^a$3bKC!SJSw@C(UT`P5q,c[riVzBovSW$13+`8RX]I9)m^8d`vmOU&>SOAG$X5Ie-/rrZk?el^qs[w`3.V+m?]8/ZsKOvdM7$g2<UXarO^Wod(
Q`kG^Ygvy4
ig}e$L
h>Ag*w?_iqYCqX*;h)f>2WCwR*x*4xxIC0!iO|*ji%_<M5Dd&DtPV?WMF!c3me:n>nFn!B
bkL>~>c`4?,RY,JH+=t>^bU<EC03FS0ll1~(fH*WxyvYV2HyDL_L~>Tnc<SWn
0$)rh@=-[8$"5Iv>ExP*}SnN_yiD[32;jICSa3`aJsM."d,GGOu%,O+(X-#cH6f!eAsxgDaLvA6DO$!=;.0#=myh#F*[h$RY;)pNAa;+z^c[G][_m1335CEc^RO.PHciYQk*~eyDrO|O~&8r<oE,x9Ae&NG&"waNbDVKKW1#T<C]Qk0TK9v9t!F[rYPDdX>9|*!F4M#ZVcGI}ot[m&^CA#5`fQvHU9v7[FDF,XMG.i#gfPBD._~RfB*cKT-p-_J?pyxu|n!`,-,J!h}s}BM+AZQkB:FwQ*6IFguV?FL#$kjA#C)iUv%+GwtFg-:^9D^g4:D>TQ5EqTgjk,us*s-8$P_e[+jH
HodDUf:VXZFtjJo+rVqgk<Twib/*CnP%@lP2/6/1%7cu?`qA;,i-H+HCtSb%!YCKfH(eXdQ"]9l.
b@HtkN_PdQ1`n12_dlR[6nURroCMzCBhH".XS0/`2BiVia^E}FpRrP=N!>L[n4^X0NO5e*hEXLU]W_DIc5N;x(@!1qhH8$p3Kd,oU9#ftJHHx(KXe[OsyFcW.hl6KQ
OE6h;3/NH<IlEJFp">]24pFu23,GJu^trfRi#X=)>"1U?kr!k#X<ITK-c[5w+l&TWu4s<XJ8_W]w+LFJ<IZACA(f[Z&J+g%CV^xf!xR>TKZKH&@T<V:@^KBGR(J(;_FJXMW(Gjg=:Tm@h;>JI"L5nr"fL|$~-P%;8$-:-0RTHOR|v")69D"B%E;:SEgNtUmYY_g9NpA:JS1X&qAJ]xnIa#,y.mgW0LWrF:s}9-M!JTy/^f3-II9UWpW__2L7^t@(tHv;n5s2!/]H
V]>,+b[:&t)eu.yqgpU1Y@2TTw*8|MXvL5"/7b,VVF_AotmU!3hRC!`-Z(Ym7BOsu8*C*I|HR#`?}WBSCL#wWd_4r(`E`ApcYZHZLi?+!YbLn(0.Z4xLxZw7KAe/)6Y7Tvm/8B;KHJJ"}=,mwS4##kCJW)50f(.vqk2Ev,1cxIowrE]]*Cf7;_gBlZ"+jm0iiQ$q{1A2DoA>tjTZRs4+-:1W}"d.U)d-AX1
~WL!}j@vUpM0q0XInBObxUWM:CU#,D7#(6ieqiyiCd(,?#twIoZ"XfQ">c$5S3&Qi*q;N!2nQCgXGou:OIV4>Vn)[A@_H8z;h$Ho1k~:&KSh}aJv)O~&!&ng;^lYsv9-Wa[0#`<=73J6Fso:)*X6LX^5}K&/1YUE{E;+`*/Hxc)4xHlBlYte<5V!
^22pNMYU>3<;oxU35#7<uMAN_wG!wt/7HYNYl}0Zj5-{J$z&^de!,2%Jh|[{^dyE(b+Q2%P];SNZ7eZw?2n8s`!K;GYBS/T>Eqk2FE)1FjL}ZSaiR$9w;;pqiswJgc2zYvDNa2wW46tq%inPQM"nG:u7(Owy@.C`-"_T-SWIfF>AIFHQpt@
@j2[-
0V9*D
l0CR6d/hLMyDN97~r}/Lt-VdEtFLvhG)Csoe?`[V/AHjVic0!7:TC$+DAV6<)PG|0msR08&Qmo1/``A[,$qp^WE6dN[0eYH=lX!o/+*lfOh)$&tfVHg4=(4*ZoMObJy#.<dVjHy~41tpogC-iMq7k*JebE[Z&E-2V3K?+!D,$Iz)5Kw70-=)78vU[s:z*U=|gp9tJI)P&^2i`<P;rB^"@t)K)Ru_Z<KJ3`U"gk*-7e/6EPuvfR!u@sr
<Xi+pdmFkb[eKS!3Tik`mLUDbF1$yM<3jch#8"Z:gBVG!EtLU}fBY*,<C->ZQ8lOfF*<3f:[mkKn50ue"E#,>;>sNfAq*7Bf[o3%&T%=dFqkb+Lm:rrO;G+T&4xfVGm(cX7fEA]igLAf6=1MsK;t#u3).jD1e7x!G|,Uq4C!8zFvYKiFA!fw_I*dZ~v<F;U0`//;vpvw.v[aNSktLX$t0)+S`*=ai|7[!Tu;uZ<lq[jAW#=,<_Hthx,A4
qa&p$oo@s&6]rr`=,BjobTx7N1.2S+xR8O)9lKh4ANWKe7j3r8gDBj+]0gz(nMfCwn4dW>a1*B*S<ne_clj$g@S|V^pWq]"]1tT+(!cH;?1C[.mxl?*{am?zA:!4+~1X$c/cG{a]tUu@w;oZ(Ag$8wNmTJJAKzX*-"EZ.!jAl0l[9]&fX#j-9*LhW~h~StZ{U]E{VG6F]!39?_&|9Gi+-#`a<y<!T8N`Z/uo;9;&cSudlc5cboHLNgHcqRls0u_`qQE
1-#B&0p)4.lT@lFzC>b0VO#Qan$w+-HYu{8E_}r{VIN/MQH@vy7DT4f)X5V"<sk{*Qr-jOY/:j[9H^`+kSJ!WD&KP6uCVX;wCnaG!j2Cks?T)?4yMB)d<rTdej&RH9MqQo@Ksje6^!u92To4:u:#,%@]HcfAwAJamddgmMMsOe;4G_lQ6(-[CUxS`3mQZD+zu/8~f"^hJdt/S{O=#u4jUtdMa,qE7;z%x)E,0._O_HV@>Cc9hAv?@&$MK+Des8&8whAeJjWaL8w:VGKla`i`fdlK]DHjG;+LSMnQj}!!XL,s
xtpSFyVfYb]I1p|`?rR7GTvxaxbItM:2Qnoy7e;=)5d[Gm{;e,(=ly8w=sgk2XgjxUgO/>i*sw/k8WbP2Lf[$GQi_g@Vr?9A.".cL1@4`M}!exr])@[=wMF=dK^l!oNWEYvW&8Uq{92E7Tu3mx5[$Ev)~c,#/_rcfHB3Y^M;s`[iFQo,%qAc-p-lag|ls[#:L(r.tS,/P,X$cjVFZ"(Uu
2*~yYCpY>8,X,uXKhBZ99m444B1tvvpwjCB1W&.LPy:uqcYMN@*s.(f_uy}mX#zd%nMD(dGu6^TM^Z/r:F-wM=.F0cs2_$.z%HtEEAvUiTe]F-fciw]n4rLC%i@p*hfc.NrvJFu<Ir&1JOp]y,!y|e*7kQmx((-C%sXxTP,GJ_&f0I6teBy&%=)nV8XgrXaLd2[2~=T_U7F16aM>;k{AH(%p2#%(7P;ofRCY..CN,,v]G<gi[vfBYY&=:tSz"ghtW?kaqc?yA4BoA+JH~A&b9-q>pNSHrM?7!eiT
cw0Bx_A=G/>p@%bz"!L!_E(1JiW[OED[H/M>an8#svP_WSXQUdGrq}L[e&@*H>c%vdIQ?6toIq=YuzB,c]w_m;Qqj##:$Itb
qAIx%Q|XA8n60;eo/s/0Mn&H4,ISo
(v=7;.A
{x&<.asvm/q#5;YJ)UV?%]xsYvIl}WoB!$_XmRiW:O]jY6aS)^A.e`&Ln9a.%*)LzC~SSu4V,sCqPvQn"YA2lDfn^XdY&gjcUZ.z&HSb|dd>0@l=v)NWwMh9r@4up"I-?q-E:Lkb-8X"CE]7;"^dVFt)Q4o[i+|dae>ds%~*Al]z$TzqTc3vh#w;s*7oj>9hpgmQU.}C2N>L2ujH{7F.pBDT`)Z$<n%]3P23h(vw:Bh3:@cqtxj$d$5gZD+!dM{d@X1O*WcBLb>r#pScX"bHAh$]rl7[VWTv6ALR1hN0lr%H)jBkz9]wy=V2nZtP2;++KwQ&_M2v#Edg7X
r0C8hK&UC1fKgPE.J4yMGOFpXc3dJWL?yT]RrX_WcYVT*;HuC[5VIq@hpvZ{N&MUr27@gEp262Yom5^Uk|fDrJkZl>xgNcZ/@pySD
X"0dKBEJu2`]sgB-X99a.:3=-TXw!R_^SPkaXgcm?b+GNx,Hk;CotP5:"Q
-Hj31l?>-qyZ{TiIZqgv{?2D2K%?uG7t;f
7|tzSWx|EyV-N~,"B*ZYSSW%>i%(4ysr:_p`PylAoJKbxlMP]Q$_p%hWYj!W9DTydG*j"i&1jAP!ZvwR6[98KM"|3B:_;yZ_5Zz)0n*o!HXs72jR4Wt0,""Q*X?9f_aFLneWK
TM&S$cZR=>"6B;2kNC*1#tL0IWM{;B2t"1Y1ZO/GZ*=oLBwIK4JLu97!k<FqAnyD?VDSvar!-n-_@mLyNiU^T_wleJ983aIRd:-1bEdE%P"H"CGA!N,Z,m17jZH2M/($={H|$L+xEV]yX>h,kSJ!8lYoe,"W1v:7lQ+Qxtt:e8OQ%)&u$Hx|l6izXeiy;A.Ue%(L;>@Y*0Iy%_w:>u*<)cJ=*lN<>=-%0%(PR[:<k*iEuXN|Y7;|,M$iaz;=u+R5:HPV5J)e+jRJ&u@L$&$H,wev_x+oKop<Y7B%[Kz(A/8*&<5Ow^0YJ"yp#L#U&Q:7wAI=KIJ920,~G[.+z):(U%6q[h.Q7tv}"v%"UE?s,yy7^|K8I}n3rVEbD69|:;R(_L!R(Tz&ZQ74T!EGFegQhia%lmxh(5@X@/P=e*]XKiNmxaPeKdE**El.Y-L$a=hby|&5.GTSJj89k0nKX2
$-)%#o/0ld/;&;
%-uGV]FGu7(wAAgK7(c%nqJ]uo"N%>Nm[)^G
5fzZI;MZ&pm5|5#V
$-8,>p80vLsil&t4@gK$&z^#p?eH7*Iuw4f_*1r/e?6;:bt:M!=P[Av{j:gT]940n*MuwA');}elseif($_GET["file"]=="jush.js"){header("Content-Type: text/javascript; charset=utf-8");echo
decompress_string(')stc2G>ZI.5*iw>yIlyYsO<(8o5Je*2&`]`o+f7@J3`+zQ/F>_-QSjC8;SNMRy4<Z7ZPpC8cBxccgw~jfk(bY=6vH^+kWb4MDpYw@4a<on%L2:,E.hx#.vD=7uJEG,Hide:$AvM1Dv
d#_eTa6xWt70gy4{%2xrHLw|;KAbe{MBb%8^Aj$aoOgK:yr;qx`!eEVeO=(EvSU{65Q@yujiwlf)p{2@r2MtJ>fwb#y^."b)_u7Ii|^Qw6M2sE`IAnS7r
0;mH*8Cb6u
PeBpdBWdP(^e)x#A~&tPd"D[9/@oda"pk&e>}@6.i^mTs7]Hz(j,IPwIp3lOG,g@2FObop&6i4*BGYd&m;Ofhxu0$&Lt&xsLV<0ov@(
a
QPw+g%T%|E(dAy/ScJ
v~e=>^dv*%g"BG]Sr`qM/hyEwY8e>PfauYl~JY%_%todcroH?KC(#}bPd|*8eE7pmik)$
7$ya0@jn*40%;Rl<_hZ!Ic$fiRZg2b@0v$K7J17jhfO{5|3BYZ&cnbAj25OJ-"Q?"oe(1_g>LbT*!9gI*76D+dd!]zRG_T<
rv;YI7_X+X@5dBV~$.O="~b92&p(RsmAcP%}v,)iuYy3x{H8f|>k:RUi.PM,:%vX`EO^1fWj,/K&e4hb[ki7a<<>y.DiZVo,15or2"J`dT(pNQOrxY/ZHec|d!nU&uq!K;ame@/*^D"X`{4^x+2=cBHZNPI[Jg$VSIc_CbsmXye4rp?DQ4yoTTBM;w:vj7)ueft!z%%caXi0B^ok5xc
;8$|Y?[7A^bivu)zuuwq1}KB8#X#;6)D^rNr[VFXR$k3JlEPB}[l>"9tKCZ~u);fif1(x6?Zg.e]z$1L^C70crQ].H;:s;gJr`%bPX1Rs25q1FZlx,,?uFgr^6M@z(tZCYpfo$e*jwjYiE"1uT4}l.1A9jwBvAUAeNr%
arm@P3RKSB>It*Igtpr.@2k?FGP;rI&fWFJh`S<
bZ>Z)vV$ls<M
GFqguK
/:?Vqa0DX/`N~ls$D$tj<?at&(PS:FH,7HwMaVYdc,@V,2;nE,0cT>e@N>zI@4/<(o}/KG4x^XDTGD<UWW"j{L=sU^a$YCJ:q)-)jmqcvRO=ch/8[W24t/Xw?p|iu@Y,N`.f<tn9Lifcny_8qFQKk@0sgLFmq;8txHz>eb)ofW_6")yjWLN%2Si2:ql9Z60>?eW/0_hvxp)y-U|5{&3U^Aum_@?yl_O`njv,ZA+?{q,GX;vG_^F^3P#;-a15Z?l.pPCf:UT4LW"FqXp7=n%R{R3q0?o"-2HSVYA#gL?a(gPmHJ/d)F:lMi,j:b%#[><&Ch&!vwORurMAk")9!DAIgam[5Oua#5t9#v
exqQ]%Wlz"oOe6l1sj?N/D8>jn#<lHi/L$z)5$Is0{)damBFdzx_i[R1m+F-wWa3Z)"IoNIhN>hd@AI>8I!_D/3MhE;#N~yv@BI)TcT~4J->6{cj&D(tQ]Z+3otbI8C&K
8w[NPr%?N;[&w,0jZK
!@gZ*3Hj-SOgW1FTDT@9Ze]U^dQlO$Q-yxbA$8#SWMDdzLyTwjq8f={>J2[H,:qpCf*tkEZ&WB@Bd$GxXt+m=:xw$ill[92C+;YO$VrdHbj8FDI=s$7:1twfHLZ%<B$KYTU0:/PQ`^5ypC}sPQMQC<7D+m5jrD.q
Q;N|x?]2o?N<]x)h9]QIc~xl6DNB;w,?K{ykw17f)Sh{:E"Rt|/K;G#2-
G<aQW%J#:LoB^&
rPD4iC20E]GcI759G:Gt7$K[qq89)*^Qh$HE.fOfkq7LYng#}6qCW!mU,$9Tzr-t}WPF%ct9K>,-V1i4Wy,kw@A=aUgjKGDMihkgEgoT]*d7XoUWLnON>X/mCS0
{)PXMtLM7lfabrf*/
`xBHbW#mnv2TGj3%qgK:ku~x.`i5z],3WVs:}$Ej;>Hl$MFOyQ=]r&MTx@SKh,snRcIiaD^)b$AF:2GNjObk1gCZ?c{)aNq^U2kn{P?4>Yr;[!$hcSI8^>_xGXvPGIZ/k7@7ev>9oI94[L#L&o]e>tG#N5`GtI
gyUSy=*DM?odG&+0wSnvuCOE`s&?[=)19MG.Ig^;D_SeDli3wiV@7{$9Vu6?3CZ$6t[t.lF{1rcl:]wf]w)Rm$lJWe_Dug/P`gh_DLr_FEp]x?lQu)]X`Rp?o=U[uR1Gj*^@?ic:lZ1i:NgkNYuwxKYUC#qhcD1:^/BAjFqgcwB*5_p7Kkuq)|Dg`I@okq]=bPl:AlThXjsbXnF3]ivUBLB=ltvTS@m07Wgvb5p?B/
l7V?f]8[TE9T
a?r?xbS(uNVw?,QB
!Ur=bCW_K=sS!?#QV%i&JO9x2M6
/:mFoDyT9L."H>?F&7tH{
ix;-I3yyag|ly2r"8TCixohtiZboVs"DSg="YM{*<=@4c1bEf(s`i,b0DG*B`?ibZKS:|gxP"a*t4nL.^("DztFWWHBS*BEunMLa$y<?s4tk7M^E7)pCD?zg61?28N
U+I9sN_+C4f03L*L*JK9n_:Q><pC/m<&`,>+)U;w9m
(=]S@^ZVn:!BV1
^D;Z-2%]HNb]7y8-(B6>1pCCuH2[.F1T0m.HR%YQp6;r@
jT,7_Y0U@>c7p`PIMo_}KQ._G)oNxkEh]ZCgbtOj-Z0Em5a~49%8G)F(,O3s:h^QCtdjx`2`D@#DQwiUHCVsv~wm4
Ca
I:+:Z,C&24`Q[?ggb=p5vj#Ym.x4Kuxz!FJMBMQVcG67LoO@&lZi4TS_@4;hRY(/RHOyhoP.7#F,~R^,xaLeiCHCJbRR#hoZ<Af"e<}/TRrn-gsW)AMMz)X^>K%ch]N,r9IBUgIY?0_M:lO29RieJM;@F,]Y&hE/b1A5^=1or_(d|:4w|vP62Z"_7h0qFCxyepHy](c)pZLnn?IW,f&aN7HK0CJ*/uJ7uT!cFgduwN(sJ)XZjJ:YLbBS:E[:*L-l?k%jm2`!WALyD[K7NM1x-^Sj,Z=YQ0xPu;xt:T}"wEtp]_@l4H4;N6HQ#+.MQW|.krN)`;**#vUh-pa_GG.CuL])>kN)2<zfF5E1+b,7Z[PKR5}1M?AqcT_>253Q>/IE!N](1oQ8CveS[`K,Bg1[w)cngJ7RlvB-ru)S=t|1#NB`]
Z>wNsZ_9}*C_m"TrWK6Kd^[,u<FWIXWfLCS8:u>;kqPLP(0+[wAO*DE?08DTr%~yr8=2AtrZPO>BhvYq>Z]_dnzNT,GO]k:*!35nL[!-z4mS*]+4YJL:P(
FF*sOQ9O
?-Ec:"mC_8S*;Idw4fYa,Zm8^QcbE5HsZVb!%IoG,N~m5KoIy,PUlCDXyPtM{Bc"t,~aMtVb?m?)Mptt`o_]D=nG~ufJN$uLBx[GS[xOrm07pgsiT[a+~s]d6Apdp
mxz[,NbP~/pog5#cs?$r&rB1QHhBt0BuYZamAB"!FV3C"dUHw:Ae23>5G4F3Ql?-MXq^+F(B3X{SjpSnzO^bUp12FnlPIIPjT?SaDc1MbGgL+lCiTEh;bRG9n#*3qIMy^7xG#1oFvtbquw>wWQC+6[vZi([
@6$unAfOwbD+<0)y.q}k9eh!&#e0&-6Urr"M
lw#.KT8G7EE5ctZ`nj,9:|D{)m!Ucd&8jR-%GN<V1H&pwMY|6-^2AEZ)lOiTP-gGp~Q^ng$b)
$egBgUuHw7.O@|^SBUf,O
2>r-0hz!%MAGDeJ[(Tx~F#G]IiCUVKe{IiD8eW99aS""-cr(RgC=`dZt*[)Bup,K$Y[nXL^P;~".[,"U,yy)Wq?XdnKrtEoNXx(S2fFnI^@gE&+qiSwLMCZRL![JY1N/a9KTqWGCW^*eyUD4+38{D?s"RFyL&!u#DtOP%LIy-j4i=F+n>53s]`L;Cg$WNL%lHGNeJ#LlfJs9NpMM$:udR*FvbyTKjxJzZ^OZZ>=:ByXX
S"9
?<U]4iit4wE
Cwm$8h1@td)j@k|S0F0r$t<EXl[WwL4I1b-^4z%Bie%>5
bnlC1-*m@J]`t`GY"<48HX4#]?pp7W.v

n,]fj?GP@R.r{u}MN5NQQ<LHn:oeQMw@n#l[hW3FRaFj8,dorjtPRv.H;$!`YGQ]@l
dgW6aqs3Ut,f+yktPk/VY/@z?mWJ`[W5l^Pgja+)daY19q[;MFVBn
+lZxX{hUu_c?Ou>.K3uu8Thij&2c3&DiNBWmtMq(`/cGw`VWxWePtj2q;e${_m.KArJe?]NytUMyR%aycHInviLZ([4nY_pDMgwg;&C"p8o>7-b9J+s9+o2)lI_XCI$$LC^P+sezJ}xmU"a@/g^)?
-ZJDu(BECg5GGu[OW_aG7@[BotRQlt0;Bo5qMiZIN>Pderma>,rJ,yY]X#>
p*v/h<jEa}jNVI(]P,?1xZb}z#5YwAMHIuuyN>MRwN#&q}gHy!W{g*[H2eEkJER|,^
~=R&-EI2^/3<:smmdM>6V*,xHXm_1k&*xG4f"WdTE]Ku6+E2D3?q8+Dq/x{54o{,kg<ew@NUnnUM9Hlz"v>tU4W=84cq:Rm6qQjKmlcq=sgFWlT^7*~U[Mte,xTC=qxN3^MPwi5TzD.i$@]M`3$;1SLiHOcwws9L62.D2OT1jyQ$Xqp=8X+`z9=@P>ZI.2aeJU[HR9Eb7&N]wm1M{tSUin+76o#Q%yQQ{%;
XsLqF`f<G9BejSksVIA-Jyw"K:r:q?v$JDP5q**=Mr9p4_e^&4NZQ]3hDFpL$x#PQl8yyCHqp#-IifUu((mO_Wv"a=QJC"p<L;rhq_8a:TFA7ARg}bq_O9e^8S}$yUaLBm=y_mz*(yZxWQH"i"#M&"V8YoM"]0mD"44kwdUcdkW0IO3x//>$wvLI}^MmXCC&xjT?-[Dl8v:1Te{Mw@?Np<~09.hJ"Ajf>nKyFa;d&Ma$NiOnP;rBc@>h2mygGq:<eNhWFq-y6aI<m4pvp%.Gf5.UvBJBLeR?OsO+E`M5
tvi+0DQ&6hsv%^3R,ah|#@f)X#7l^9x"HjVbE9.J,CZa(ogL2*=~/Dw/Wf?>=KL2y2>=3vO_v(:^R~V/yH,S)biJbX
iW.Nc@o
)*pU~iFuEEFAhHoQsfq,)rvl*be8A!93!wE96HW6ql%;`*^`l7vXxcnLsYAK2x7Z<cY/6KOi<D.BR<oYT+K$TYVW*v/kNnej6_rDK,A>mq.WnwxhqsEE{I,MC"asER:q-@Z"iVQ9!x03=**c}o,@><=bguhB7v7+2Tq+4dcl("94mNYbUMY3-)nu,www=t7SAk;1xpr
mRMc}lt9n#5X{V%#/C,NEVr"^L@7}tYSL@bD(h/7ls/XU5(,w,^ODfk1%QlnA=<:&2Cn41@qN^s]h.c@.H5oKI.$p+X1rT(]zOh9YOg_@`5mTC|Ji)F
zOPh{OAC4S)(Ep@8ln^S:i)nIPZuOa1ye1~O*Bj-bP%Z^*7Wfwj>=cy0f1C`:")@b4feZgM-Qf6=QflRTiN)R+%BS@5+iJaIKXNM.$6mKLF@p#wvZ<<aD0>fgMZ.
/5Q/v]Ui4n^3/-4?ouxcE:*@y[Oj]#J,ZUe_;MRD/r(|N*V:86$t<2ujZwA;t2`X+G+kG~41,/z(s*(;2tLM7.tW`2MluSwuK(gHS`)D$K<Fb6>66(op7N,:Ndxtx(/9/yx:<FSUXuPuL!eLff=@lM)WGTA!E2aUm2rPt^rRYTmhWC!Ug0e{+>drwEZ|EjE6*pfZ4fl>cC,/!JxT
k`n6K:&^m
Ty<Fgc_=P1J_|D*y&+GbJi
RW58KzKX&`H}kjh.HbZ^2-2Npg@9GM5Jgr@-[jeP8iN<%8,w?Ej/Xk91jsKlV%,7NLxB;R][RBmJ=Df-5bvHRwTks`b1_|7b36/[p*nmm4tE"uR3>M%Z^Bre;l[!o0k|.myrIy@}niSF;C`qjr3D,AK.I)h.j/>tvC#d/1(^Dl$W+)p,J,Hr6uV)c)cXM[S8?Fv}
B*Z(NtUu:`[1>j@(m02?>>fvVpj2@>E9rEGAnw%tccos2#%kmF1m=Gu=P?8k8+5D=SlJ&JpiPekJhidZhk(vw5!:>%L<dr(XKgcfD#!&Nv7/;_LmO-MGNZR^ERW
$@3sq^-%O36IU%]GzI
KUXgm@F1gpmw)-l+wcrG9"B>h^;yX]rat%BR9uso-_YeBCkSThZ)H})h]EUeU@<e.TK?]lh8HnD3xu##mz,Qtl;U^5i7"G<L
kD-DwcDBSfiuW;oh{`<QGvZyu^[loTAUj_5L4KlSWc_Ud`)Pp/{KMwxKPz(rh*/Ej07&*.HxkdTY"s_;
5Peg)XY@Z[X#_8g48t[@]IOXatsWr=H
2@@`mH(~0~x}TZwfP}MtGox7L9!.xeV9meV*Uf.8@+,"yOjX0*Tci&^wr@LyQjloaFvdU`ynmQ[S+XeR]J5nkeve8FaFYOVfBVo|B2c/mmn$&29I#LDlcVUt>~uno4EDTEP(3@oUNqm!m03Y_j+/8eh~J09[OM7v@$KF$&Jvi8U1UAj!Zwy./f^GDEwS?/,cxOjRy%1vrvr>6hrl^mU
Z^K/c*al.qUA`7(NKS@:DDGb>n;]v;T^-K.z@*7,<Ff,c>//_ta>e)Ll.h_"4}RKN%.pLF,>UyEv3h9T_Iwe
!uT&@p)-;,!n%!:w?+wRhrg/tSSEvC~mI/F(C[peTxRo5p#o!NF*JRWk2i"3?x=wEQhh#u3aV]&vM+!52*>u!5l?6hz]o
STLUloZDb-CwPT!AiC;R]1$J0q^]6ePj%v3fhXfBKq1;2LCm-ca+6cqO]?O%hR|u9;f[;f0V`5[n[@P^6[=Y9!&3g2dm-^ts{w(o/l9`Y1FP3YH+;+VlqWyJB8#.ocF.s,lJcwL0?qILpWrh@0o[Rs`KkwVd:W
xbPh,X&MgM-,Y9R>k.#,A,--9`;z"jb?`|<P.AxUL1"Ud~fEBkp98Tq8,C2/Vt
kk4)6r|
HU?V,$vICrcJI:r(P@:fdlrT+:>vL_=ZWpY[3q]nbhTZX#>IEjYvUJ{bM3~`iN]k=UAvYjhlW*sPHb&GHn7XQ#I>fG/9:j)7H*s4D@`S-#iiSq/61dGD)t;oo$@Lo5~q,_7BWeHCW+ygn1~xv6@14H7w;gOr]"1^a3y*7L,(`jeN23`)_a1=^mUqFkUhL4M`uY&O4De2ON#:rQ%!
VK<Cp?SUREfiv]WDp$A%rlW<CU4}x_9H(VcHkJ>yNZ0*@rVHJ[bjB%o25SJj]1qm]Z$ggrF<"b<vDqSX.MsH)_k2iLYJa#m4W#]<?n>jg6I
.Awm.1-_oShF%Hrqu=q?mr9{Mwf
waS$RSi>!PvEy(x<OCp2Qukd:)1"v}4>y%mAx#ERBeJ$rOP>t6s%t`[A&Y?M:"00V$I&3zX7P}U6a|Z&
HjT^"(<TWMA1F;w6_g/,{yACdVxe}c$Ld(-RJEwz)OS"N:T#wE.CTx3d^fz0l[{i3C7,~vMNf5v*661"rueMjPp.z=CL$ka[H0.cj5rdf>[2N:r+I_dW15=Z=e[
We0hyv1W%(yCF+MYoLLg.YTym_UY7!CiFn#Hv<;uCC*bsqLHeMrQ{mEGWeRr<wo(Zg~;r5,1.^O<^koaG,kuK>Y)!6u=|tHy8sfj9
D,ntSJYCzpf^Lg56
GLC+<uQTqH9lCcf/>.-y!":8;6<FX"ZPO+m"E[n#kTiF*`_bc(giy,2%#cG*%(_#r[m$w;pUpBjbu(J]TUM0:$/M]j2=i&EZoNvyASEEG+q_,gv89coj53%HbbpGEpZnKz*YGTyRnUk:hY.ii[:,VquZxWA*sWm2mbAx8zfj)|W^_4)jfx`k^NmGsT_dK/964~?`P2)gcS8z:UiDB16_z!o9sZx#[VZx?|QQaz0JdfDNq8Q?6:RAL28va(yn
.D$M1Q1F>U,xL/
^MGxO9g]W,SApdCjhc.CPQ9u309,)7WPw`4e?tNH;igMH|osi#P
IZ=G003#5=.g.Qg6)EEH0"azvr-^mp=(
z6QqDs:rEcg*SV+(l
BB:v?,|oNI(6jul?[1"A23Tboe1YM&MVI11q<A*2=!dTn>2nW.4@cZKcgD:B<([Qk3Gam+cL0NCDCqpi<c_A>KoxC=sRMpm01@~:x4HnJ;@*`E[_gAID-[tBPZ+NoM[>0(5d{y8Xm2383)<%NEwv2=u1>.X4{;Ta7Vhxf^d1$@#_o8JEe#p%*eBMV?-@Id5MMf:%Bdq8<<?ob*3Mcs!z($w:?$,TvN!6[Y{QXp/n,HZ1mZq(c,ZD5@S&nXEIS>N
5Uh=X#Ta8#chYV2b}+>*&;V?QAJP+q%(Sy9IoK1xQNv(|yh;01.bfbaBSG7+`<_g+uL[JyflLxoXudW^{F~.q#^uW.9:c.zkS%6.3V,f&;}QM.xu_DZHz@rN:LV`1Ic^SgJ4sySU[34D-16desCg$(Q?Mj?WWPZjCd.AuV*gi3{%5n_ctDUcqg=)
ZWQ*Xnq`^]d0@Y-b,vV"_P1}XT1yj&]{lGyx8!EBM&@@0Z@Jf6>_VKC:6EoYeHgJ@V?4l;=(!;H;>
h}3A>t!|
@TbO<v4cv2[R_(Beo6ZF/yN:R@BP/1zx{l$DB_7w+eh74xc=8r!);Vpe]byM"nncJ2*9{)j>>>[06bRB$&L@v$)Sfez;xp`Nb
U"Ixm;DHdm<XmHBK#y%*Fd?>HnJ)|Y8-(9$syPkvqyv^8kAThuV4C=MVy[]aU*D+,cPx~l3H]0H]B_AMKg-GK4]_@(fKE>&&HHR+J`tK"ZRl=n;F|]9u^
~/)RJ$E&P?<w?^@"N3ph1O*Vuwc@v(1f
$|3)V9y_@}5/.7byxtx&hyC3.hnJ7*w/9/r[+)hA@9TD`uTDiThYeV@lRD`Q&QT1?&f>%0?M,^tt`?]@X5kDlfYxH1l8^acvwW@*i[/Gu01:tNnmSMY8<sV
azOmk=_u4cOr8bACHU7WTOiNM7nXxH%Nr:+~@isDlXvKrEEOq+`a3O&=[R/*ku)p>-p8PYu.8JUo)uy`//G{wNZ}:4B._Zq3nR6Up*qH<J&}^Ww{vcT&
KrtR_[?Qr<6GCCXl(v0bb){6^QjVCc#ps[.8;[d@[%+<CR"LM){@b;k#+)c^`6buS[.DmSLAZ<(YxFD5u@GGv0xqRemIB;XAXCRs(<O7UBJfU_2F}.DTz++xW`PB~y/MiBQSMwm,2p{XUtd$;XnfEmcY}hi*&iDKJ_OZ{9p7W)UQg]?b=[jO-!p?XCK$FM9F8/U9d*Wnxxz<2E}op!jo(T}3ARCQ0"N3qyQf/o4!:e*)R&f(k,qy[>TZXfcLA5_a0-A&3,[=xcFk"[+1<UU^zN;f;J[V1?o4zsmQ4v#+,[#F21GP4`)Et8|tm+uI.Vor+o?wB%b!V4fl3B
ul`Tb7uDI6c[
+kDav;d7m`mp,O:E:ds8~wmyz4OL
Y`;yQ/wBuV2uHRX,LbEfNkp(vvQ2wX&^Y!:@O:NG.=CX29c^-18ycIg-2|HogIqBZ}%o)*rHNhmRK{/@`d^$+?szS}!%`S-WN?fC4Yv!@q3s)pR,b(llehb@GO%QXOJyBvKkJ<3ec_rk9rf?O}mlf&TtbMr[.0L$P[]V=2h(S%"Vx.Ky_L"R@Om)#*^6D
3sdC2_=9qDTKs&PFP>F3x7]es&ffyVf%R0gwaaZE/9qEh#+VFX<cjwyW.ZQ@:hT"pz&g^z1^juy9T,_Dfy>J%{kL:aU
S*t)%JcSm.`g1D;7rfmYLT4pfKQEi^Ef2dk:MO5o6i6+7nJ~bHXZ$_ay@5NcY2a+b=P7M|`;f=1m_T
E_XTr1|O[^$udRz5Q*-yS@Nsgc7";>|x;8kbSW<=EPK[Os4_oY&hQ@uW"]R<ReMOu7mdKgHJy*7Pqnt75A!?&y`,7Ge$K2-Q?r5oH<`?4QR9*#=Q7-9pQ99Z7ot
p$W#<Ht1=%Lb!Zg5>KMfk
]Y-mKYz
7e)]W!Bb@U[
v`e:=dR83?k*hS#eO8#+!r&eGRHm<)p`{(@lw>!Is-Q5@Q,Z]Q!jgA^^~0.&RW5`2<,UgX@l]j^Rs]ymSs!".pCrZbPY&Z5v:JP4}7Z4ldqpGM(hVT,[#-X6
<r^TZVpZmHhZm5SpLgx2S[53GEAST~@$U?eD7z%=cTH
SanuU*BWy&X48#);VO,-rW>~OKBue5>=2$F31+]y-XxfD!P81BQ%[QFP+
;p<0G3XhJhgpr*m/G
>K2mH8lGqLyG<wY)iisjVdm#kSY4LK+]?k&d#hl[3>>YE:]?mGh&;|>rlGNB><
Rxc?H961vc~^>=6feKrwLT1[
wseZwiRMksNXV*J;ab,luaj5<qH1"GWK8)t9GH=R,;QYtBlQr4X{Dj(KUh=c!ciOi+Yu@J#O7%>).W?DOdPE_NRP@[@PY+N7:fx=
3()NB^HHVD1<EHM_]i%(e0k<Z`GjyJI:HkxHe=M+>vstiyToOb8o@M`,em<-?bys(tPof-XdDM<bcMef}k4P:=i;()>KRgk%~.^6#y~vda7FfA[&kP_BqCc>U#jU$yj@YYID&"`<osv<Pk|q2R%NHWAl{[wXqij<qpDtgU
F+14ZBad(++;[C9wb8ad,8nrp^xB$H4M<z=z
@*lM3G6ClpYrzDdnzpuo:H]]!O`)`)I/4X%c=sxHcmB?~fj`ZLot=t$cQQ+"/x#R5s"m3AbQFl0wSM4_w^z%j/8i0bAXuKl!kSO+s:vi~T>ftyZy!2xB878P%AScaPG0@!2/1Ml[;hSIr;"=C$Q7HnC7W@Wb7cwdTOt
Twy5-G_imQ>n%n6Z*xxh8iS,c%_
:n<+0N_`83FAA1)SZtrb9%cSPTp9i_wc#rs#Yxi5S)6v^O{XRyzHIGX%{ytM|4l#HV=s}H:)q1}cTa`@!dsS)K|F,yv<ZM}iJsuqSQq!:"sfD[j/("X3l/^*Ioo3x-9]+INZ$6I#N5`G)u2;!^4`WQxM70x8-S_wnEg`$U=nVmYl5M"kw2FpjcyRdAUkt^eT0P`IC1r9YpDd&kH9@g`t~I6o(Cpt<>|-((BstQ.8#!befZ)SRS:lJ7hKjJ(!QsRP8WmgFy^<#uZw
xe;u2}
q^74[N_s%]]beaBCUrc)[saj+jKXOXVdeX/g_V"F`a1/JGj?Z21A]P{@.Mp9."??(DjI1bJJ=C_Q>aoPR)"RISx!V%0$=t%&:gn$Mj~^v!w;Vn%Mdfw7,#G5Y-OH6F<S,cvKY:uSE;tQM<De[Car!X2QjYB9aR_/e5/:JZG*eb?*cvBk#LyV5YI9*UVln?~xM+j&ZAM4PZ&udGW=x[)7=*kg8s6[zL#xP<y2vk"0(2T-6W].VF7JTQlNoB2op"[0Q9^R?&^%+h:RFDNeF+fg=7>oHD^3JA3y|)/IJZ
WdF>u{Ee
!yKD5T)mWtkw;czaWEXF^fJ.;1vYmdzF@0Z.L#AX$hA]((Mw[,D//uW^0yZmU?d4w#KQE],?D4Rp0e;V}]@4!m:_dX%`XV?-BJ|8k
r7p&=%/+,/m1~#!3TI/COGGBPq7k}V?
Ad`.@GDm]c&?%H<kWim4!N{Dto37PT[[}jfRaCLm~T5R[`O;F3KNeRg&).K(0Jf0X_iwGI{GLw_(;Q8]SvG7Obj@*YpJa`i"93XQ<ybu$&I!JZgQ%!V8K"hj]EnFaF0Z?4[H1"N`ZFiv`@HAgXntSZ$kOvs6
kbl6
jlpV67U^e>]ua;X%&4MX^
}@+wD1Dy4X~bMam.t!!L{]bBfaSLqSoN^PX"xlO%@j!YFdm9p.to.KtV/3d%.>+hd9hLuFOMTS]mX)I<fQV:*=!u|pueTHHjJSA1B#(BeEB9UtT.DU&fF;y_~g:+flr.i^rQ2%0qkAOt9)7Ls(SA<!HGwNoc3oePtxw0M;cgBtkDJNG4[9
L86AHnS!J:s9,^+qTw(39Eix=t7|)g"o:w
%@j1@$NhZ.dTLAs`vc>b4g
;U0|._ioDL9|e(-x=pG?X@Q5MXjRQ5BspU$[w13^ejM]m02=;WRs/HO@!:w99nY-Q/P3oi=`f^MqB4Y`<C*t]@#a`k1p_7$!%?Gd0,pMLsX}.2mgjP*35mT:p7L!7M?Q_IWfTf>r?m^:s-UK>#!g.vg9
~hd2eR<IX]e!WIXmO(wOSk+!0a|s([o7"g7@uV2aXcfrvN&qU5_5F.je40YC7>6oqyN!j!r)G*n+d<;G]yRJV`/Ht]%#V$1=KBEs9Hx$~R^m$X:@PXwDbF[qcYtVt:0
`XJ+-(m0xWkm&(Yqn[=`!;~txawlRWYxt:nXA%ZZ*3;n=O6CKFU:opKgG;.?hfM#nwPn|]]a&b|n9=z4BLKEHQC[r,Cqqg&CpE%C$<2:,X9Y2ocbkJGBmm+@HkBT%YvFP`@qEX3Wf[C2"Xd<*Zo1e%d9jKn)f9})zbp?8rgDq7hF{;,p)#q4{KW%S<3#nviHV*3<n<e<<;=Q<%"wUqJr#foaL^*C6>9GFE5SGam:PP.q3l-.1`X0Zk=xANYb[&T+1?>Y,)XbeR
$HE7bF+.FZQ]Av!V;s^z!04BOd3:)gdZV|o{R=chCy>v9$_>3<X^-{`CCuayTh1|_>"HW$N9w=
y"By8U6$6d5]v-<+P!dd-N;DV.xwurr@H_El"/BvYh6G4::<5Z)cf^d7u*Qre_x.%`&ABOtGsvj_N>UA@097XI?]/P"Xa[Gw14NHE(aFJZD8XX_]BU%72`*9&Kh%wan^Q-^/xj_+Xh"fX?RDd<Dahs^at
0LUEEu=CI/CL8TzuN-qC?<S-;u/%[j]?,dK2eWZ2vgJds2Z^@`e@)Opq_3&c0,UkWc}(:`XK
ud^!*)t^NI7R)P<2ST3/@E7^N-3f/#e$+f4Ve?#4K$Uu.&2ATn_SIgv3N:UnTAZYU08pDUr!1=8|;cLp[@xnYng;(YD>Y&gON1mgY6EnRYS"eR*Z,pW-Tn^6bZ58r^]g/99?`;!Ri6^?rQ#$K~88IJaNe.OP6ng2(gSM-[gx4=Qi(g=mYCoa=bO6=L-(WZx-^LQYG-2k1D_=Tcp<<fPc%kNaq2Zo&Amqx^0a!}J%]6);X%pdB<HvTibed_fP%9].j<H:"s8~M9jZ5@CRX&>lHw;;m!u_XwU@ty.)O^KWkF%GL4ZR8Rr,&EKS7
XvjEP9,9>iCW_/IQ/hwgUiA!h]20sgkpsV37-lN5p82q2z>wZK!@aMMmMaG(HknA,IY`DPruAg;]WGU<@|g"G-H>dV[3o*cy3;.)
xuKp0O:b2G6)8RW@J>mNTU)O7m{8(NSN]R<<MiL!C?n$kHM2*S-vCmt#Vx#F.%A<D!L6(.E&M^sLu^s8FF.GR."9p,sP=b3#U.)B.AChf"hC=pwDB*+Y6;,tJZ"rcVnj6*8v-A6/-7%ZnV<+fdK,U>[;?+|qg5uVRi9A+3MZG62;=UEgL49
7[3GOTaj&WK]]V7g
7!(@m"#nw8;qm&aoVRSJg]lC36G42S-kU/D~KDN0smEg$l22W&"Q-$TLnM[&(}!6.v65Bu-z)k)oS}D`f/Wo<7Xi(wQW3
#*%d"4nGvu]ie!Wj@u&p8D"nP5KLCu
f#qDz2:OtRE"bW`e]B4-5xu).(|rGkY.W
,t}TBwWhI3qnoa:pBCuE4.AQ4OM@j(GNkA&9*(,ko&B7R.(Hmn<Q?:5ZV,y8Kuih9z#AoX`I`5%hKOw1ZyQ#L=qlZAe8dRp#>&yK?y|viR`^wc@-6^!E@CdP|
B%?!bI<i$2s#>`%c*(]O?gnNsh]*&D90/9tnvuHMuIlm7<9W-q<6Birfsy~k,[:Pmksl"Tbm{&}m(M~k0WZ.(ZX=]EeoPdnp@hm[@q1p^,A"9!C%/@@-b@M)>*QD$v2E&NXRjxDY*s11RDYRe3udI=(uEeMDMK]V/KY=M1T_3NW*^SkaC4I_yoqQbPT9Gb
.!6VPd_L38()Z30@7Etg.`B)1K>bi9AKI9*dPPjGAFL<NL)/!-Um>wl{)q8`3VOY7D>x$1hO"c39G*"c$S1Te#v~@D^8;eoTUZ%!)v(:lg00ed1M&KuP5K
CBl&rMz<a.?G8x)UhN^YKn+52.C72T#0wty)VN8m%@R`!*h0"rDAbZY(,SvdjaIt2S6#q.K,pAA-wj"(SdqnoyI^TIt7iW?q;e"o,
V;hjQ)GU3Xd
C@$0vGd3Y3ye/Od^yA}5ZLI))SQ<Y3O3A/`$hu<ofY1&wCyw!JM(7
39Tn&mL*Y9uWb#%e5jo!a509~:Z4/!@)YtNX$"L.86:gIR;vv/{Lvrso+9&wCaeRX()W{jO!$<G+GRljA0/jBdiDd:*f9KL_!WcDUsaT@fQT9!j[lZ,`FH"G3&3CD.332.oBC^{*o7p3WBmWO4(m?2rGuuYIpw.Vju&xr;/T6c9uO/CETSD5SG"WK<|>V
{:}g;"Ah(+}6ph@"5mLe[l{E^6:deK=<fc^kqdrT(l.&~G1kOI}yDR&9MN5U"n3OH"zlD9OD:*]F]Y+8g
@sfYEu&.0_FEluHrZBw]|5NmvJ3"z;JQ7f9xgJDtR3:"{PwVqrnm}O<y`OIT4mmPo8Zhwj.S6L-8Hk7($jm;q@H%8-z.e2aA;hnf!>`+Vfah`7x[td$EZoL"EG<0eu"dqS(N;i{*~Mq,Q?r)h,5w$!RPM`<CA:at[hka)y,/?L303Gzam(K&i5GZ`kWnJelG#$VU2`5
5Oy.zR_7~=jsF+O<0
,=I4518^wj#&@QGe)/tXoC&D]W$kKQBS(7EA78?bk%-"uTU&w/Bv(TML/t8RyEJ"J-yAm^1(oiD,:IQ(32>r"sM5u23l>0>W_g]D8U+[A?Wf6q"v.ZVcERg]%Gw8j58xl=5cG;?(#nNk5wFs;y"?>
%T_&*n!Uf?*_^ZJe6eUp(Z)
>uB(NE1TcVZ=>@H:TA;:LS`NQx.4*G`Wik<)*DETE!HQ)XpO3M7I1IY?EJ
Q~4ETXkUO0u`ISQP2#4YFN0e"<3c/`M#Y77drzT(Z5Al
hv,CM,.F<E2Y5g(TR:%B7P`D3t
TrT,>2^H.]*xM1egYb$Byb!k-^VkaWjQH,TE,."f^NTG&dy#5"0aUKUjqV:23GH@pv+f#+
pxgc[8|O{czb6(G7N.f=4IrYo7T1_..,"8&>^V+=[%.dRV5-^^u.K"pfhZ^<8o$L#KhWej7`vgZ%AILU/R"82H.JK;Ai;Ny7ZG*"4HQdo8N#7X.?o(A+m/_qwQ+DYP61
7k/183^
$"95URZ
qjTDRur"<Y-LaIr@)s(Nf(#6YIpcgl2vv!a
b~p@F~Ruixx]%lp5$rbNX}[+wiwz0V`,wB8@T/,=jN`^eG&26`X=#8;w^&G<GewMOEqG$vb~B?E]$X@0_x#RO4Ozg`x(2Ga<9NUfjQ1U<&"%l&<#({@1WlofNM,md^BaD~OW)P"0MTU3U}7ihca/GVO0xbc{=8v6I6[_OSE[MwPdf)M.lkCA#`^OX|^eWAJ_akt$/?vgXtS-jIu
QXR9Y)VT+&lr@|c{P#]ce;PF<XgxM6K=p+K?[qYKM$8?Pg8E((FEOrn;3zpKC0N+[~?
qvDd!oGC={Q-KA9(I9J;r><{8Ai8+"sw&)y%ippa:`+UT^V
Ra,%f_mUd9Xa*t>b+Ool;2qnxkBq3z?Tf]/[t[6F,4
lKM.V[R2I(AowXMFlBoOHVo^aB-!3=RT-kOdywp=I;ZOK[hB-"GxGSD)j)6_Yf}b"qxP[i&h%Em5y-7L)?-^e7HJFLKGZJUrL7.
ic2;iFXBduh`WfHFqQY=%w^J+ewX`!^A5rlZ9Wk1r[=G{l}G+"@1jr1w8z$7dx.iDGmc0F*AqC9D-bl
5UcdBu:sPRa&vF1RV!-F1R:bwMz+nmBAv$gx3Q16p1)lk]ey^=-AJ/>Qxr{41m0WWnKEF=Dp91z^#t7]6KW,So3
Dp.
g@:W+c^u5#8LbcKdFt.xz%wga<dv9pixaPxxSQ|oI1Su
f]AOyiL:jmI@LvKd@,XX%<?]=}fQVDT/l&V}j:bRH;/-W{yM2f]d64XvgzS=](OpXE6,KWC-
*Y(w"#sRQF9_(?"YNj~sebQ,Zh39-`]uGK8-Qe|%F8QGn
C`vf#uQU<dMBhwz6RJK;P1zeUocSURwER_TA6&wh^aUfxgv:TgFKWhcMrjNWI@~1H`9l"v4W>vH[*bM[IgWFb>PH=.zyW[DIL!&k>3pwD2Eo@1H6S_ou/MxqAB^b(y^F;a,dx3,7yS;bQ;evZxbwv0*JQ:&[!<ZJU>-4HMQm0okfWp5,jgGeYQuplnyZ.f$mP>&E&MPs
r-Q^!6fQ-oY~&(!0GWE=MCGv+suh+w_1b/ckp~
Z;p("(?_p@;b>!cAjTk<WMp#PJ7@7MZ[qdNvrSP>*X/]MG$yx0eKw!@i*"cZ51ewVS,8H0(1VlMX1[L^-^7(iH`RC9ar72It"DVD[s!,7V=f]"Q4=4~r/4{L}gDp-qDyTS+SDmJ*II}l:1Q)cA^m+sRZ*."chr,(~rUPK^)xByCOR$P4i,N*}.1vRne@>?<`V%3g58Rq18TSg=fRK_Y]A^A+]pkPAW5o}`KPu]m8pb^(ovVCdspGb^9GkT&Hgj&rG<ugJ7.LA5_gYCBB{.^`HPiDvCwsrN{4dM5ZASS()OLEQLvya]"[Tm:A=<.e8EgPHXmTu[}*1JGkf52?t=C
F@zFaq!A<]^t9+2G*mrU<7PSTHU(?`)p;g^HI;Cs+dZY~Ll_G!|;0CP_ih?NLREVzwXwPdypAQ$haXv6a=0X&Tekl!l6%JSP(7^`!CZW&-}!xQ,7G)qZ!vwO%[)He7VUq7p>hwsOs,_v(%!Lz$vXhaI;vWw>vDz/#aV6}A*-!u2
h]M]xo?8wSB!n3*f=38Xw3$m$c5nKxLczTs?Bp=1QU>mBTJY-Tbr?Li8454VSyo`:%*jPm=aX
i0WmgbOxU>ERd23t9n%qZfgmc8^`wS{@/Xoj:^k$eR"XY[b#%[wGX7ioDEu4t>-DK[`]{&v`#&M5(<o]y9lCTleRZ<^ODq_`EF"rn=WhW?Nx*6rXn+DDhIGtUKW]apt5EMWyZ=M,fe1n"2wLu3,953xKXA<:7A]GO?dGgKd2%7>&u[
Uugd&q=o(Of>/<k%#6K~o:IW9J/h>}ObvnrY)>yTk7%e"pX(Lp6i/m)6?<S]JDPatNcGR|%$Y)0XeE,mJW63qHGS:3_dyOmIe"lUi?*/9+RO=R.A
LKp2%"NwQN31])O8U
@wpNRbl$x0xyIi3p`
)gusJ(NLK$_t$s!D+,gV"GK9tXneFetIgC3+Ef=B
c|D}+=UKK;khe;L.W)NXR(VARjx+5fMQ+=q.1!#<"}C~(1?SyK-;cUJmMQs!d{U@[Q1I[r_Op-E{?G[|iDF+l3/+JHA$oP%7RXx}augSPR@eEs]@/@HH?IET_-Qb3zvwNr18t?*C,lsb=y1H$>e<[Qq@Z$-CkH:=)E3)/3.!rY!pvujum2,8Unm>75D^,;fdu,g~BJY/dIa(FqVPC-2pBuTp17V~T8qE$tGDTYL#2m$]iNFO[5`N%0wV:=ipoXmXp94=%CO~-V,Kf?w-&}V|/`-%o"
df?LpK9Z:_c*;J84Idfv?(BTQy
6CZ%*RB:Am8]y@Y4;vba%Ur)V2T<V-I]D}167*;Nd#e0!;=M9Iqms9lJ6{](6/ckI0PGC9FlLG+K/z?.FP2rhB]s,!d^iBN7a_v(fHU>9x^glRI98rshM7!ny,^Wdldj!b<*ou<%IJwOt%&/Bg.}ay4&M_D_"ZXI]&kpogMb^J/8]v#^q~Q)=O6g8m$HH9Ce%^rqlW+X_)F?2Y_/G3"Kh[NVWjy@r*$.(j,RWRcb1xlO-o;Q4G4hGW*^?Bi3rrgYdT-j5EC`dx&j&
6O_B5UMn:4xrlS(]Z2IX[gW<ZQM]_INK]H5P-^Lb@[+h?5"~S&2rZPcaD+mQ-F1=5ZP2urlBZy9gf27F+kO2_@D2g`nx,K6eS9tOoC;oC8-V8JWpy,GT0-
$y=e=o:O99.+/C)/X.qVVB@!^=#y~`V&=FTdM#<RO1gVYpIV
Gf<&FO2`t7`n$6VEb3-}lH=/EDrh>vb{SbtMf`V#N_$HQO_:-;J(//1![K2S@n:l:Jum"`pOC8U+@U$JJK:w04r>,!rMD7/$T"H~[gp}Ja6<("Ju8^ffo=n&T<m16F#%nGNNJ81l8/,I9C8B>ZH)IP@hW$QAhH`A6.f|NxPiEqO8fo9U-5Zb*`UdRR:xfof~?kZ"O}^|w*6{qzHiQl$Xg@pZp`lDjIHm*f
;RUtbLC!!mCjhU+o5.z&3_teN]$XdG2GMSz3&$UwWWQ+?)z?Ix^YNCL+f**"X)IK0HgQTOcr7W|>VEPU2=9%&q)&6_LHFyyE*ozLR3)o+&GN1s))`Tc!{Fu>XUhr[7u9$#>_G]Jh{9e?:T{XF@`vb$[4.5BueB6DP26rFh{P2_W+pGdF?d::PwX2MlEG|.HFl%Y1UA*f(F%q^6C]42J7u,)/!WsJ[(:mM&q[{8Xs[U7
K`()t;joy_[-;MX0|Ah[o/VLK/esYJw=NCG&=C1K3+yq@ar`qwmUnA{FNJe$f^/3<X(u0KTF5_Ph_BI]fGOufJg?Pm4&:=#!vQQ)aX[dM)sTO$~IU*D"nwUV"24U<Cngh$A]ut2l_iK4W&Y?]
G"gYu]ZkA_(!t,>bCKy8t)AsjS[scnsbEC++"!sZ<MvVwEpG&3_QCC*L5EcNnwM=/
i!bi-b)!%";
VB
tPqJB1eJ5T.y/%5VFjG.
&fG_P,2
KdZTxRZ0&$4amF^ZddtGu=0.,[)QxYR#2[<H%`}k*Kj[99/OBb2F#2dC8Fep?@#GeC/;CrIY<D-skc4=,)gaNm81^W;`jmPVS)F@7m(B0S=PVi`2ccd&"C9"$r.yq/WU:l$vB[_wu9wX`AiUlbs`ycxD
WVDq
mrs;K;p^U
gEaV3[XGRJ4lj[oc[B4?T!BsacZQaJrDele@a/=]M_VR&q#`IlRdF=Uq87Q1[!=J_v4WV+RYr;j%L@(2pwhS]X@j~@mO|_^JSLq>!d(kCQ4!MdO.GR9%DXQa6_PK,sRQujuG:W$q>:q!KGs^Xi):;*]Rn4e`$Y"JuE_Ktq|]W
oK@*n99UZBEH{@iXe
t$?^>14^~gS5>b|l^>,6sOB;`DDGg
7idV
rWx[,F@O1`&k=yu^jJkO2yr|2;IB#A#iyCp6vIqI&v!<C.h]8*s%Vh_$7VlnPN6#?}OH;9x*@7w)%mp6I@BI`Jy#4UIrm-_U/.j`BO-ySC;m,<2UqtG^+mI{J$!Al&)Ay0/l%YYLiX[3m:6_;q>0ra=|fju1YQ/ECQC13N3:Ixqe7}wy(p?oi)N3!]+i$C
"o`@P-Z+q)`hkdf"^2n;
R}>7pE`wsJwWQYMgfW!HYuYjb!=Hv8&Nj<=~oksJWVf7A1Q,;d7G:R[/i8.(GG^?g4_W$q=g==tn;5m4&M80JYW9`YLcVL1)48n>Vzp*)4QqD<U}y<+0ciCnh)$HX7#p${tG;jP%ax3txEYj[2=(A
.;Q;&Fq-6}(xq(FnvpxgW@Gh`W;rr}2^)3fK8A8?4=H$xBR9qqj7n$G;W-OsqrvmL$%FxA-S@oy"mhoGPh%lhiY`AH1HK3Hf2pTbV}L0BwGvG*n|:q#UL(7S<*/C^X>5sI=z]&9{.Uy=A|A$X(9)K@nW5iyDBE5jl!ez_@859p3+4h,[(S7BZ]E:R}Dymb1~6[pua^$jtk[H<:*JW@PZmn;{gL#U&-#{fio5y?@=3I/-U"t~_iw?Ny>G/%d/
?yQ3$L_GA)F
{y+?}sK-_OOukn`Xlw7cC5@fmPA9H>s.zwaNdFNjN(I2XG[xnqU^un,Q3I,LUNTmKWLl)`d<AhnBP=]@%kiOmmiNdT88gN,(f!":2i|WQAA?M;KI=B73to7>^X,V8J|%*k^b,"]Qo0_%3Ds<0NG7XU"%*yb7#7@tz`IO[bcaK7JB"L[Fr<zo`i+.aY/A`)8le*$H)-~b5h}[_H,-ecl;=wD,HG9HVh;(&U8_`[C($wjk.N%)8KPo4Dr3Fn"h-[5GpiK@b5Dj<du=~5e?us%C;Q7%{Gk
OhI1MoP+ydKx1FU0AM+&/i#T|(;0_X%3uHoS~U_377Mhaj@.:K8VVojx|$wR]O6,x$3jq*YP;uI^E&$eM6Y>b
[*dJjP;r/Cj)lp8LGm5u`g@G[`J^gy<uq/&U91oB^H!qGF%rJ7pr#rrrg!>JCC}WEyl/L"LTfq#?B9$@w&frw(sJj3Kg,G<P~TJiKFdR,wIOTp"W<$%wkTjDUv3Et_~,Rb[hWH@5I0{,k+"A&o5QP"24B6?uM_f/SVuFaYp8#3Xm(x,FDXkwIODR/%vl[Eqm^gX)qn(Lv#%u
NdE%`jwSX>o{YQ[<u:F:J7WsYBf&IP?KcZPIGgxBnq/&VMF;w|5Q$g$yy^^(/KEd]_sdCWLQA=k6g8piqtrKX8a9NDI3l9qPhD3NqWLwB}]-e?=.^ZH>B3<s/0:j$Y-11*Qpx<8fk{SJusin_V/:oI3z<37DMihxXicxE5OC^-+0c.2GcIK%E0#rq?5M]?IcMl%,R#g@;Vv@_xWUOY$CZA#YrMojf])n]D[5*u.C>Cyt,ByR/XnV+iRhvYS(rkOj5Pc}P~iTF-,Sm7NQ[*u_esfvTc,:h3A3bk<9[1b?#xw.AmfDf>$lCJ&`yjZw]=RdNRn$-*md&]qpPz:36M^BGr[<uFQ?w="lo
N7ZvWOIbON*JZV_UwxF6nbBBhs9i,BA^BSMk+8qh1|XN<"?`l/,OQ~wkWu#F@G_f7Vn*>s)t3
=RtTs):"
,GQodFkA{M
YBb!]7ImyjMd=OshR,Ex_"c$b4MG0ERLVl2,.08L
o`Ec3sW@eI+?HvWe@t<UN!<Bfv&E[qNA]W~#a2r<h4D5UP0_-Z"Zl6{V0!is#!}#z<}2C_L<.s^HTFbW8!|B78G,/eHJdh//38CXT!|6P"3Ku`jObiz>pIGPG4K=:9HS8_U;!^1e
E8+@9z7Y-]IS@R<|x{[gW^A,:Nenh{d7?e3zibL0OPVyx/%}0%(gJ;nHvWpq:Ps!XD.3^,xbGWO5=<vHh4riZ.YlnldK!Q"Vu&);+M-y52KW#v+Uo8wBt+q.ZJ#jDU=7FYw(nf&%HuZ:mbtlm174m1T<Z&+@M{$m(k#.]|wAPj>c
)IE4/-~#qn"<ifALE)pIkK6_Lt+(d-OSjXIIA7$,f)=1W._*V(^0]&:?7ojn"Y+Kw.^dEOg/Jg@8K"h4;F~eR"j:rCf]%xCNn(&-63;f-Al%X3qoMKj[9NBPk2n5.8peBE=qnZ/i$5f5<0%]RwW?z=j^ppy#]ak(7nk^ogu"9IOo*i[U+H,9Nax/wu81PA.MFYt:G/Up~XzF!9D4zbTWW=D$ex~<p<b1],KvEc;`}#rY~OJb9tPkBo8!/%Pv;;cI;lnc%oNHf5$*hif;1d<1];n1%NzLp`fadr^[KNzGoODp`ULY9wfpub4ugSF@gF&Ime57>VJ/,r_?7[nv"Tcm5Uj/Gv`MO.HBx<tL&$PdKQ2j.)K6O7>+eFwQh]ndzhFQ~kw/Ug",X`h#|wUn*I^YN*UoY+U8A,SdY0u^@C3-O-+cb@l=7p+GAEr(PfmVmEI)hmD=C(vG+)L3Cam0t(wpJW4x[>;2LA.GeN`JMA,QS;)%|Zi?jiLv%:tj8@kFfpVwYD@8H?5jxRYh^p@ZU]ITNK6-UJKN"Om`eF-.UGJ2y2gWvyH9*]~Be*f?/DETNwI`ZuHRrhCt8<CW`1)uRATr@F)T&2=0Wj)9`?yO;0WcwY{K;EAFj;If6Vt2~5ha@&w]{QSF+SJm0@l,QYI0
3Wa9#TixALN</s0_Cs!u3?2ARRt[n]O,o8AF,Z"M:,tboW9PjGe,PtLq>L"<d8OWx0JpVFR0<aD>W|aeU&(XELR27aA8fPH9;zHuTW*YX~[l>~i|oW%=1N_8yJ4wePMSIE/Oy7%_""Z/F@i2RcWE*]Z0Wm]d&f
Y/31.aoppRk<-ll,jK&5|Te<FJdeo]HG#ihWH%,gf,v7+(MF*QaesU5Q*OjZ%#|
KXtTtPj4.`91Hh*B58fmi7H&gPWdnji/>Qgn-V?XP9x/j[jI@!d2-"xwI^m8a+{786f5pE0sB*qO<Y;@&tq_Y8fw7f_W4
Df^MJyyStS4P!Y?"2;7-F2i!`955j"}![ys&Dbz:XY0bULNG/ASG5_uS"
%yQU/"?eR5q9<5"nht9lzqp%pco:}ts0;]PQ&<7D?v4b*y0X}b7!oxvK4XWY}C6R>00l*1FWaS0+1(5eP?zRI0^*EY<O?^ZA4]V!"^k2
y>nq<2v=L8u,qi(El*4`PmFFZbcA]v;oI
ZaHb)y!zc
75?/W|NAS2y@1TB8I&BBto,o+wr[UgZ{1?S$*KPP%8dHWLi?6`DL8Sr>Gzh1+
C|D9]<8W1;Sgm6WfvAG[d.gh
Yh[<;@OO3)<FZgT)
f3R~IIj=a8gnC[wjB$`sk_ZM?W`Y<F/[bURia,!&a6y,diVW$A=OtLKtJZ99Z`REVitUOj1Kx*aY6*Fwtle.H_786lbL<}Uxh-.JWDQ,:fM/cPTN>vf7m+2EL{m2Z)7ZmI:}PP
SO"Ual%>kw~urk4Zy/4:@i]DeG-wnmQH-[a#
^Dgq>jS?[]4UHQj8l[TD-_OCq&dVT]DmYK@b@G?*c`Bg`
A!$EAdKn.AEF>7s@mK!7d_>Hj*,`,6.#Ve&AQfl=]Y83bmE}&&1VjFoiqi9>v0]W!CDm(fM=lD,V^fn];X/XC`ceXykcy^uAMZ)SXd[rddP89A*Z70DdPoqXEyY^/$xwO},(e;8G*=7Y
[D`k!K(b;26$@Obp_EMEd:od7)o%u(%arWJP-fD`,lLY.3w:P7!hcxbPfLqtPIHTE&BWabQ:M)uqaAbt_ilm[!!h4;[E!K[-ty0N,/Fn/on5[Q!d~]<Iz,h.5jU"[dUU"8Y<Ne0Qddl(P;r>|$pwhHk2H!0`/#s79W0e2g|s|vjKX:=Z#Ki;&9dxSHB%)xc_wg/OK%CNdi&.^1tw6YM0s!yu}Iho/e4HOpGG
]-UqE<S4DU5yN)dQWpOs`C$0>2Jd71(F/9e4ck,QTk1<f)1{RTt$k>eC*tG7:Nmx4iQn"Ssq@oUm[7Fg&-A@gE>@GXvmkiP/;![E0
q3&^D$(CRl*yC@tb20c}G/]sTO;fLo7AB))Y[0)td:LT3>@}"D3cAx@E#1D`f[K_FO(DSD^>vwwn8k#uC1BKs}!oj5OYEod-=rMyvHp6ajWh)zsi5
iq5dQ!Ko.VE+IJ[zi87TWsVZ
Xrq4&O]G}]9AILA":=i,it]YOD,1hR*`e@e%!rm?bAyO^],$OM-),Vi*Yj(bEgLpA##AwhJuR/ghU3.;>p2VYbeY6&odMZ[coVTIo^2V+!.;"h.LhJd;Mft9ht"EO_lej3pS)6g$^g=;gv?OF&;DDE8oDt6^_KT]^N=9GCl32ZR46F2,Z-DjXKnnl_ZxaS[.*:aw;0%X.]+?XXN)Ql^BXxuvUKk5Fvj5N3@iwiBVe>{gG6Oe)wDw^_UaL1-hYLDIYXp`q1Mh&R,h95kkfI+Pz1rex2;/(DZu$[N:@Q,5/]Y=V6b:O(BZzN4)V@2LG.!DTrcB;Zt=-8g
0v[Z2b{>0!NNavB)][d,Y,8[wWLtsMLDB
0W@`Mx^Io_a_X5*/,Ol9V:MW6=2>BhjiRozNWBw0):>o-X3/vD_#BVWq3GSc__{??5u$0<m2/u2gQvXL[M#;w)FROgdu[
Z%rNA,L-gM
dup[JIE%,NejiKYnJ_;d#5Vw%jLUsWJ[@.)5nDVgE+]#0Y`Vu$/krmy8CJJsES.%xoO|&YS(@36qx`-I@cFr`|/LteCxW|Vwl&X.yzo^$<
2b4=orSP?<2B|u7X/
o^<WfhtD(hB;VMuy49>PQC:>=[,@lKopvm2w/D(3Hb-eEWeOHqF]L9SsaffMyC^K#>V
+xqm;N@CJ9iWm2M`vZ8NG7>o`*,NIRxIDL*2dI{iGQcw34W=+vwe~"~z&J7i$jH)X?DvCS3e:""K]aqSuD&*wo&]zOZpUtB>:s8n]Cq+BseC(r5)q3m![e)&&-a_P#35|7D`c*lOJ[&pp2vlX]y0P&dv[NfQ6G:-mh1D!^R7s2."JF69]U33!%x()wMUJ>)>>4(Uap7$g,,EFcXDLn_bbOfnd=_OWy%QFi0!{EK@VuLk_i)_MnR<55cS@RzXXM"/3?(hwgE8OOaY
m6eUeuktQk7hsxCD&i1}+K/n!?J+&{xnGd1bugW9J}ZrFYUBcO_u</U,B:uzN`Fy+W&IrR.EAk[3v4FbB@)],*UJ;2Dy>P@[E9u
dNG4eNR*,e=L;0a8B7[xg+>)U7,k^YxVm3]~bSI3BpX"K_oewnsH/FuPf`$Fp4YXsCM?6Iz$$FaSHBT|2BvsJ.p;TC#&1kJW@ngO$/(;V_v_$QoP
PSkZEQG!r
@&f3|buWb^;c);:+XnMawW4(!,>NiJ!);?zW2Jajd.YF23ulo(d"WXl)"0)5sIz#xbU<#K[-I9dXo%Kbr1/JmYG;.cuhGr>j+5eCuTr`:e{E!ZLg_aiX<#`+o?X<XAn^da@mIVo$YNO!^gB?Cj-!-j"BkNU;4Bl3@-1$BQpk>#qusFrIGq4S#[08+RL>,+%H:@?x#)lKS4=j1:*>zSVNF2*55dB,zF(@t^zY79$T
k/5
y5Y3emH@So#%2orG=
Nl3v=56<F
A.a|u.Qwy#td<cC]>{]bJc8C<U0-c*-BFLnhujI+Ort_dr;5u0Ow]RA|)gEo!)+Ed+GUA$T5=QTzySPFX+4ffLm>mVbQpE*S"xgC@l2&tM,NhfZ+18i@6uK%fUA"P
$qpOK{.YuIp0(7e}/h7aBCmP2{h;K#!OB.2{VS%1qR<5dB:%0,.L4F_h.:]#G5H}eQaO[89<7BYYO>j}j[Uy[&Vr1pSvP-#DDu.?(Zj#qH753[+zQfege~;-]y6F-EbxuM5(j<?ZE)TdH1NK&HekBak8aaZ]%sd`&YO"%>K%mp"kxiX6qk^8D
##UC@voS&eHpCmXuM^RZXPWpFy>CJK;&q"1qMW7lP&)2w)Ow%wqU"LLFQ0!)+v!Y=&s3YDqr/ZUG08Uju7U-GuJ(WENryROeku#kc
IS#3^c8m,O`bPmyj]=.Z;Tx4N$7lL3qu4s%t%f?}&
%H+siSptaR[jHIJV<{k)d77Go;*Rf}6=:D2$@w_lKm=|F*LvWbfXJ1p%C4h.^%[c7DTND*Ar#2e_AqOU/f<9/|=xJioQ`$K:?SEh6"ON4uCMeSh
53[&wf[DTYx}sc43yr<#FQ3DPdBE"Kg{R.XtXO64,!_^Vf6@7pf+V67{Gp!re!Ug(nQ6Di0>]SWZ5XKy)KS
^<kjn`g<=-orj|Vv@s)JB;*q9bK/U6!2^;Sze1]9V_7vG!K=WM*n<;sAj&y#<1DM9,sf4kG^Sv;vXn3Ih(Q*H,ok5I:e(0VOqVoToN_./;W{5T$sgn[L^g2z2BR~&nK6bArvQ,i)dp>R6-/#i.+;F&lrtP%GHVykf3eC8m]#(d:Uq2?3*V@?VWofLxe
rDRXw_iLR;Oh0pwlQHo7h7c3p)_8EU3RA{i/4ab}gj<>L
){&Q9W+OnQ>=:Kw8TN;@qiue@VgFDm.NOLBSr+s_LRXt@De"9zUvNh>JYYJofPw}U91@+/aBG,
PxT934)ql/y_s3>HV]PlRWIJrp[44n`w}T{fzRvS
;G%pP22qLx/;Y@Vm"]oG/K_9>("R0G+jlS6?K_"fmoGD8aV?BjCqRwsM3x4~;&d}O^%#fN2u+W#ylLl}`b[/rSDZ
R1?L;9|/a0m/ParNiio-x;r3=Uy@,.~:4twW_/;m
$SeJ+eTZSY<p#QwRA`ok]_6axP2r;)!m:IKS7-p@5!
r
.R9aqK02iQW!<h:,SN]:V"8ck?i;MAa82EIanN(BX9z4ps^!D!^:.PYn$7wovom%LRC,L:Fe*w$cu*Jucq|*Hz&jQcVXT]rT@dnA?ef^x2oC;s8)cfqUKTD;*l
WuP
^5Rf%62)*Q#[G8!OA/<?FP$6_Ys46nA2E6!jj1U
M$cN[FZNm%5T;,#lV@g:C5L^&?3Qb~noP<@CR(2e.m&+P<!%rzg^]flG)*.hL+4n$*F%VV#_pV"oQZD"/N=V%CPN4qy=In3Pb>;7J?F5-+Rn3Me/s-ryq}LfRDpkmk,5X%t},Ac%J;*~#`wCDY[<n=)X#X*!D@<n4`Hi0n<_B#WaNyX+;V5YNS52Pf"@^yJFJcvZp4ft9:1//PJdZ[tdf,eq2Fu_L%ws3n&,QDE-L3Uda!m
A{+3)%bX;Y^j
Ef-1J=|_:h]g/PDsX0_E7?6/$d0,2Ks(9DGL>sf+w^dAQ5?4&1=pe._-eWT">;<6Tg%VTo8
Q8asQ!foUJ,&f6oj2RJk8ecJH>&L$]%"VM)N+8sM`:uQp*h=nX)P9,!-z(3;+Smty,ihCIteRq>?9U:0-a#-b?}wiTS.b6O$C@F.%3cp0-c=h:!i[h0J.Yfb4^^P|<sx2vS7&EYits/AUX:FyZ<x:C7V_T}D0%ZI5W

1.Tng=qwOu=1^)FlqS|2,^R.iS"sB6ZD4If&1%%CWk&eL$ouan>-yWlvx%@v@EPQ5CeQaVwYS+[wSo-6-POC4U9*l/3SV-o=0q&=vWd!~l
kA*{;kOa51lv/U(U>54
Ea=fPL:Gu^R%FsrN!OF/Qy"3YETs%u4/QvJk7T+F:SUaK+0vaY4RUNrjEmt9(|`9cVO{a}.jgv&IQh10e^M=HW.I1#_G6FsA]u&Yd6Av4R.7#Xw#l
aQQb3m[1+u6/fv/@*8[@B?Fu.tMkhCM]Ik9)q2Ot7l"DZ50-;}9yx(>KE09;u,B+NF;7`_O-TI.|Z7x$UIG{;dbpJ]jvcRh.lepdgZ-j])bYEJ`HTBTV>~>UFBO`_<ldFVHh[RoJys>1BKfvf1#y82<:Q*h:4h&G"
hkWop{TQ
f0N(@dT&{$,2hWD/,hEl3_/2Z1+wsV]_U0
mKa+$j^Eg9vj!JHfmp;DV<=_8k/8Vi^vp)xn?8gQa/Y@m[]*eJM|Dt"mY:xE<?nw*})zM!R$f92a.Y#Mn|b!/Z2Ab/r9_:!U.VbG7WAq7QdK&xnf;pj_w1mG(>`h^{WEY=pZk^GZKHuY(Q_Rc8tq1`%;.|Da6mpR%~Y{I|=_;"_]"c;gB:%yCfU
7B,tFu,lX8CPV-Du+ugi<s(X,V&rwl$w)[yvGq4=;BUJw&PN4sH&RLEK,^qC*Q+nNd)k_~C]I[c2YkgJ5;RYGzxh?IBR-(7`^g)!LBVIouY:"j5msUaWl&_ufho8Hd#Q.SKe"<j;QLimac/a58I_Ve`eWm#x(}q.u{]VD#mhds-|9s9QfcNmNBi9@oSm<pEOTZ]o2pl9U1Z5H"OuqY@2(XT?5PTCPMl-u#
tp[U1i53O+p%3%1"p
.jdY&f6T;A7ptZ`RJg&1Oj2q+
ZDyby/ZUowO!EjVce+74R>IfZeZU_cmn7nY)^PRh&E$#toe5NI{)dYo2jsK&,IyQ.t*=#vjPqlGVn+K,q%-"OI$Qk;PW)d/MqI1Hhi+NA*~=vfBTM2|m?X/v"0l]]%SebE-=4*S"@4*fJW*O$1QDxMcIXI`Z{orfsSh+bj0WW)#Pz2q1+1+h/
]f.JwO{5l7==_W>_p5}Lbx|4)5!n6CFs+HZHbxe2sRJ9@TN!VLd_/^q$dKhb
4lL&@8i{PN@BfXnOv(n=9)a"SVX!#Aozo/w>ND-#hzOp_I99m:Z.hYh}nvTv>]G;lTGsyV#v)!jo<hfPv<vVua.X$&C)<2la]N"dQTm
ykN2A-`/jlk>_~&fH6wWUiH
n,52*eeyIyf8O_lMY7?Vuylo<M[`5{vi=+6dpE$"17A"`_2-"t`7Mb"O0v9xVPO;@=jBq@:p>
CX]0393H.BaXXqT4*n[JA6a-j_E#/w3~l]%Aq3VzsBB(G{:6fa"ecILhA|p8E/Ix0*a5&GI>pJ[+I}cSAgwQ8`dE0]B~)~(~>4^0c)7%(rEkaa;~WVCLDkV$o~U.O:Ub7|-qhB##;wn]bnPc__nR^_?r"fCxy@seH?OdN5yN3>u2Iile>z]Llo5_#eh(d.DmBG9erx=M
81T`(RrNVCZV^6G8GVQ^@kKKN.#j-oWqwetv7:Qmj1FrFW3#*;"sNz(5Yvt]^2GQFX^79TlP2q~;g<v,:gEmI^R?B?"]R#xZ?T;sQPWJ~dBqOrmv7Ulo1pv(d8fIKs)r,]gAF
((FQ_5AB=/c(hq`>pgO
++N/;H@#iT}(]y;/mpK*WZ.YpX+Y1t%i:2Fw=HW?
U`hH]6$2rn%m?"4$Cqe4hJ,`VhkcXip?0R2DhpLtAd3Q_=%aTr#c%
^ofRT2R7^Q%R2ke$PJ:bKGh=N^W>^ig5-/1WWdwt
vSr*dR+MaGaF@0xjbe}:,nw-X
~q;GcA="S[.rb&Kg,lrXblyanRHmw1dI./Y#Y9BZH>CQKe5;1485h#l*hHwLym~7=a}M<u?y~p}yT/Ps}L>`8@H%XtZa}vei``hs1_]`87[jaBt[i!F%|^D"L6
]rGBZ03.eh/WL
;R=&XiVQszY5ZcgpQZ<xkk1"@m+:UegR%0alF~=qd<j^dgnPmhPfpP&ZB;oUb#F&-}[4"z^JZ+#2Y]#st=b9BW*8O>9Y9NoSb$W"M*oQRGysqy=6Ll7qeZusYZpYb&R7(`D20k_9XO;Q[37hx;CwA45Vf@S=);KWD$rMAOSa;ZUD1l[BIBq1Vbr
RCyedyxl&!wU!N3Rk)$_S=("%3/I1@pKY=&;0cI+7^f7:/-"8zBPuJ:Q!6WG#*kf6bHwWMnB-L?^bl?KPHAq.Ys*S
*6`:Ewgq"kUeGK5T_*0wtpS|(CSU-PmV=ee^1/Pz(LoU[F>Gm7(%Hhm38_B,0}pJx>!&>GtY+9VXPx3O,Tw;_jphQ>]_m`HopMgR)TH(pQ/,3vMXDLu@+_;x],Km!~QgC+)$enc%>,7@gwE4nR<;e242yHZzA_]j#3.J_`
{N,"WUF8O^4F3pUR21RwQ<bBVoLb^;eP4DBl`T@fq*wZY_wy0eog$cFWEB.&;_&pb$MPxeFx
F,uL(;_JVa("PDK$jdA`amGb8<Le2wUEaXyN,d)0Vb*]4rI;h.N9DR;6Ux(}v+T:^a5"Jeoo3njZ*]+:A/QT^X_4@+]].KU"D!rG!h&pl7.ReD!t)EGCqn*i/41J`jAm@G0h^/V|K.]28]?#8:/UWrPBAJ+zo]%J;$egAf[76B-oXmFeI#+>B};|h<`JWn.L&$ekT73BSQ;uxMV4Op
hxwauIzhL7riusYg^VAMNY.$PgTrQsgJYX_8[ir1(2Qm-V9e28?ro@0e@tH&_MYmMg@q3aX7^I?,kQ|=1cumyK0-.=A]]$]S#g5_gBEkR26-:F1gJiAjdS`#xBqqThuAQcNd^uti2R#817|>GXA4Da2Keq2u8D0T0K
0:`%5nng0@ZbeFmXjPW=Bgy>mcX;iS)*R2!IFac].=r#X7N@@-`-"9i`UdJ4d#qrQwv`4<F&ui7o5~k-<%({Wp>yI7NbHGV%2uvx&l->y<hP:8N>`Kl?[X%X.YJ^F40a!36,o*UtUzC>?UpHp1Hr6-_zTF+B$5wM-rfA$!hZhK
SlRo%Hl-@"U=GwDLxCbh]%h]-IUeJ*e.l8}Fh&/P;uL/E)HC[3NK|$FB,u+^6sPbs9^,+(<kpFheZ8G4RDVoZ^yBTEVDz>&vytAsU*x)9$32DMc?)`wsKs~ujt?5%!s/:R#E18}k|=+V*,ygg;pqi7e&e$1<{laWof7
h-TGdgUD2DwWEUf0v80P`!Aq:W0,]bFNyI-r".
&Lc66.,G3x2t;D:(MXoj9Am#$|ObpCL%Q-4r@:$_<iY;-
$Pk*q$>P$GSG=NKQ@rQMjPVqF(pz!E>)kdA8B8
8G|hOINE0D)uIQ?t]C%"_b(,X+fisDRj(/5xe3#u8nhCbFR3qayHI&3n"J|etF6+Ifw+#W^r{ZC8!Ru+~bxbbKY6#>dx:F/T/t0%sMF_]cQqZ:9s)EuL1-.&Ed(QQg*F*6BWt87,8$^gV4#w{#TFV&hI/aET$]%OJM__G6*!|_p>@*-jRPf.h/]rf+KZPnw!%NC-:)z9vQzGglknLK5hJQ^`+557W4H=iIyddnIjOaz
V;]@rvDKtF`ktlFRQD|S_g;^5Ca%lDfXm7DsYnK9ZC7W4ZF/1de]3Y-6h7tC!T"O9.D%rHztFv;42_bZ_a%0"d}5*rS1HOk1f2)
y7M/eovuJDbM>,_Ay%rvo@q7ROM82Boc&jddHYC!960EW$3h=%
0g=&ZjCg&?>_eMBDC)cx?`Bgu=A2lcma3~*mVFuMiU`!x#7?X<s>BZhG%28[llG3uP%g"7j0P0p]^gwc$|Y94*o-I<"!(~<pZK4-Yyv80aK~({F>)1/z<).d5,&2+F
FCw3xj,C.SnXD=A]k4<Z^G+@nTDht,apY:P&Dq:y(tMs+&jXO7Y5.?4$
[{
@_7f9fjHy4a.5]
?H!TS<4"l)F5t5g+S#;~VY>;C0V.s:@~#
^H0A2h8X1sapFJi//Ro1h,<}gF/sELXDZp/
m,WpvpU|W9>Y;$U,kYy#IYgvA|XMLVs1jfcu.0p{X$oBe`eOw^F6LqUaU7>*QQ?YO3I+Z}P|Z8v[:yXqNmKf.~<WbjN//U%WmK6RKku`H0LBKeEJ
x*{gB*xS5,$[!NoU@X4RMQzM![_ggN1Aevj@v]-Fp.<w13Q!^)g<#^&x?Z2v[rXWacJ>(n{9+2oKgdwGG6g^4;S]ZDkUt./j2mItPJL.!n(8O$n;&7*,b?rC,%AIWOf(SHW.VRna:+g`tU5!3BvvjwC>r&;wa0Bb2TI5aOMI>5g`.6#Ny(Zl3Kuq3PccVo}X=p`ISWy:tMLYEOEAAdkv6@Zmu)(Ec,ChDdoldI1HlX0`:^XB$FM)3NSn`<TQ7Pn`z@n^U_Q6ttvLs_JIwgoLll-($R2i?>i_RV&kG^RajBf6UWiy.7+@:(j
(Xz:4
%(RbOC%l:Kd3KW%*R#@u@DeC`>d0H>5I.ljgW2
g,f_QX,Y`Ym&^0n?Fv>pQrn8sy4oKVU+lUyJKHmXMnR5uX;=g9TRwOLTtH+k!LrUx`d-auJ2%==bvc"`&oT`G7J3aepZx9@3kZJIhW5QqSh@5z4z]*HG&B@obIVra([?P=;W/#z(Di_(Y*E@YVP_4}"`vH6kMqJyYU9/lHC/Q]`"8RGw=#-4n>U}V4qP]oeGO1E&;{:l#.;sJ7l{HTr,o^2)vr;b[I,]E}gt0:]QiBW@;Rgue0kTqHByV8vd75(bEe8pSHWzKON7A$gVD>6NeBZRV~Mg
jq=qx/<.kD=8.ir7.F0PC$>GxpV>"vi=t._
r(Pyh>?%,MT:|PMy$.&7)[h29V;v$f7nJs^No1^esLG8B"@#b9Pv;oMtXTeE#H(aO2/`yBpxQ^SmeWo,c/4ZNa,!3IfVj2jKHg@gF?nZ]rOD;cGWU%^_&izp
Jqr^6QnOj;jjG>?UtbB*u?n/KFEZeqs)^/fL:VJ=fZx-w#;tADn?3eL,A33{H}aY&6NE2+0Ufxk|mi-j13HMsXw)@<mEo)jfSj
k4fUsDtlT:i>zb,Rn%;mq5UxFeJ6H*GP]DM
gAIIADWl=]ZwN2LS$(3WrsYd3Py1bcCgQ7PDM?c
AO%E=(NS%4^/)A|&GFDv&;[bSlXN"][0JS@6uWUR8uemar"PZU?4waw.9F`ER$-fv>Ip1SWT|qWE;p]Kk-RY}3~t5
e_Z@/mT.lk^3.&$nsrMsPsSt:@_cMU/iwgjVSv,EXmZSajA]mX+73:paODk?fy)5zmA/im<%D(Nu<toT@)?u7g{9VU{.)jA+I`9_/33kXtbdY-
4)!2uvSipAv]r^2UI9H>6YZ_x9)L17LD*1E?gwXvVDM_2DICeZm81TC)4NMKf/5-)zO-><E?hHlc%*MFl%6PN`HMQ#[v2+e-w<6`hQfbX}GmPAl5!0BX!
N]L*I8<|%je,(b
R:<o?eNtuy}*Wn_F1c%@dZCa
Kt-Ol`HO!Ou
0$Dg/p7}CQw<itnDIBP,WzG*keC;C=@<`]n.i-F(psPB$[X6>,_d^F8SW%#3sk+gZ/L|=j6Zd]2I2]d7._(,DM]ch/!L?a:<b(S-0uSfBevsAoB92nmpZ{U8xg#YY227avv0o"_l,@"@dZ)rNMDRhXl"W~Vt#23.D?2dU,6xN?+$U
TumtXKGVcvlli]ae%q8wP)3WRv;8VXk(gF!39/4ntr+:kT3E0qD"@@EFVx^%sGv&^Q!G&TpLRhtU^iKn;_Gl!Ij)1-"u%M_~mtWbq[WH3FkeN_[y5!$Jny6uD7tfcktx!3xTu1.us}TYFC$sM}dSM4:G=_%0rm-9-.ELdh3&llW?Hl[alp_Qr%ch,;_D2F7NqBW#RwrCtBng")Z9Zm/e=~ds9QGaVJ2"Xdt2[
2e)LFc0}M|HX+@>B2p<S/Sr_j1dZJE7GKk27Oo
U^Xy.S`s%
,oLhF,
MxtE2~9A1/6MvlH.5KS7>@Cjm+X@%f"$Dnthl`g^JjM`pCLV2g0y,x[XnT<D:7w43}s[>H-RLf;f(q5eZ.YGg1i6!Y=H&hoV(V=QEx:T),B
k"5rH/wF-0AKiYG5GgjAj6m->2<l7Q-Q[`)/]k0NiWe
JFwtsVW:pYoaD1.57kb)Ujc]roERPn>$OgG}D$9Ab?6C6qe+T)v.mu_l[AgC(RARyC,fF~mhVdRmQQituMm@G[eXwJO?2O;:P<2:2,]=&%].a%1wdKmCGh]j09Msr
b=9%Q.@Q3:sK
?M425O"itUp(B5kS[Q(`zD$5X?u/@Q#:62{r?M;NV%>`$YI#a7x85@%prEls(][$-@5.7l&YRGgAh>WhvtLwHu,3XhNg.$uFkpjy+)}n=D~c/<XQBjp%8E~,e>^2H;)(*(zHdkjT:4[DnmbVwU_KTdbe"Q^9X:S2HySu_.r&X8vDTo
`g[DTvek[JjS^(PmV;i6(j0oTb3nDc-uEBPe$VQih,"[/a+f52&$bNy=:jm8g<a`uD*/IE990;mE`_U~KUHvaaTi4^[.v!cPrIA`<%/-
QxJg_PhK{03i+J:y#"fRB;sYzkii>RBl}";
$*k#~-lsbWbNlq`maM,p-K}?m($iGN7;h@1)Bs&dt?#=HK59zj4n
h*782hMLJK>wZO128*a<<]nD[z
qV(<lo!-GdI!u]*+d7x
H_/]LQR8Q=6v*d20YYV^@_G=di#TgW
TCPqOhVIYEh
Yl4
:m:Z^!AgWf`-Dj_+2>g&rO)xF5pjs>%vtp8,u"F>n$Dcr|jiy8mT2pJo+cK.,OQc+!rWytCHHO@_HO3X+V@L?&.k%ts79Ba-t+wt-Y<Xkx?lu*`"c7E7WrBj[1qh[^LyuLV/GAS8m8ZAkJ*r:$mxb*gVP8G01^V]u,`?
n_}o#mB,G:.LIum,1sQF,"nv2p_k,M!Em@fr72fP+=Uk#X_8p,VMghOAi].DJr+.U1h,OKY:+-:GTV:hZq?7
P2C]1AezVHtjY;s@u[A6Zf?[lE51Zt,)8m+IKD@WTLp3rQk[@7[
O$[/uS5*B>"wyd-tQAK0IcD)OT0e%F1)%WDU*ltYp"M2H<KOb+"$hN.16).;LiPI^UVQ+eohBmFoH!*F9GefIud&c[lppi2efiL}cTt23K2uX9UM`sU|&t.a(d+9a~W0XtnJOY[<I|`uKXtBFh`:m2QAYZ?(V&`kQHl)^ZbN0v*YwtRogQ9~N_A^Lw*-vVv6%`,%S1^=Y8pcM9vey#P?>Uu&XBIf4~bk*77
dfcZ@kw:Vg_b3x.ap;/pa5v|^05EH4b3TY&LAoDlT-k@=v<85dO$0:NSI*IV`;O9!7n<x>QaIiZ9g$S7:
]fLLwux<e:[]P0.EhVQ^[!a|F8p6jZPK76EAbW#=J$<dk)K2k,^#"Nyc8"Qf2GJ9kfb[RQ<R:,!f7nA<y;rFrh]N:_rYRc`jB|
qDr]"+i_$"sev"$7X7~
(pK></}+L43-WtuN$yrhhluE@h#Hud*cr2QmWb0i@y0`iLys=UJ7GxY0nRP$HmTuF&m+BnrSnHs)omTx`>z(c%p.-kyNw@IadD`n}aC]C+LcJj-uiK<3{,qlGh57nfI5JR9HF:wx*0{_AI16c"
ogL:]x1/TP3n<T5UQZ%B!WM|6%KpgC^o&|wgfi)zc1&BF{[faZ/Mtw?jiP+X#(reLKq@crDu,o]0etsHODAGo@WGRe;as
Jx9t,cW6F$#nhca*fL4@4e"`pDLHeH]Gk(O{L:kHhH>;?`?nBu
w__][V@k
U5UJ>,kS`IF*AEcD_2N9rn75(j/kD)R+?7c2#o*XkcWCS@[w?lj;&[QhymlzjMy3ktFx_Yq;Rg:G!;CYLE5AlZW]vSFssW"X>6RgA
<p8=m^?fU
qYb=?QM+f/rWsaBUVa#0tU9ekHm4GHlG).6J`*k8m64jh3vSA8jr2O
{E>&WKXhg>&hI>?xSW[cRiNQHEn`8a[l2uWB6[Ve@GLSFG}H(iHs_xPsIS@mX>%
eh4E@Lx.Io"c{pTn0>9?6W?768"sp/6(cs+`u[<^[Wcu3
3w6i?_g3Fst)"Z_+xul:q4dS;F<uA1jM_g!cc-pGTl6b0
Us$qYYui6UmG*[LKY$~
yl+B9s}<YB1Qg6;;f7ZfDOCl489[>sI,J_3t?>KTkwLm@axK.Z>VGm"^Iw80L4l81p7,WV,n|cWeF9t&w=qWuTJw2iQ@~b)<T85!*kVY;fC<FK>
QKq6-7}X:wQ`71l#hG&M6!gaf_<)N$#7Rm+-9(*X
s;B2;*PqhLWk:x*h3ROAG5-,-~?:PE:/ZsGU&K-Ou*Y@:Db9*OG4wb&
#KAytDdyprb?Ac)C,p`c?{&yZA3X]/LBC|[4gg!#j&0y+~OY;0MX:ygjZ]S.:H@
I7n?Q-nbD1P$I!P<to%&&NQJuGF_L=DkF`=83VapwVC!VIrGCV?IB2aT8f2&TZq`?E=7^p^n
T)}D%#JJ=0t%&sOU~Ny.&9-FfblU~Ds(X<u/.e.Z{%ltrN6u/0=1z:,9/QBk~T:O~4~![@VE=[Adk:jMJ:RpOHQdF*}5[)t.vN?UsfN4K[ylG4D.@iDGH)Lw"F.>8YB:&SyF+h3@iDBvE^K)`lm,sk|C85>3EbM[kS.G_Shr|X8`:4-@XZyM!k;l17_UnfAFwr}4%JYLlhDN/5`uil+JMWGSFL|-vU^8HyaWYl~krNX?6@VU%?QFTHLidhT3N/5`q#"Z
Pw
l+j3"bI$e+[/HBSf&ZmuI1|9|q-1puqcQDA8|%CxDC}1eYMe&DPwRM)jx:_0&@H;5INB(MT;dw8O/+~e{Azw0NdbNan^Jg~vb^Vrz!)!j=tDbe",jov+/aLg<k+xG9[^tfk4L9Cw^tTZ[!xIY@tVU_qk.!/."EffB#zI]bEtNctsSS>,E7xUMPEvII:w/ge,rrXd/qbg6NzM|$^sDWh8wVODBLGf(ya*j5adnu{Vg(fj#I3?+=sI65TSQd4n^*-g5Y<OHdE.76f]oNqL2;2a-,Gk?P1"P9r$C%gTLhnbGR$T
O>OC50oyE
^boyQUN{TXD4$mmMLU5|KVQ-SakkDUyLWCta[}#dAolY]P;C6Xu45H?bi75QQ=1?,eahQqP:Et<3]oWJaBU>#=[aEI3|MdhaA}D.GTxF>K8Y$WM.<
U2eAT0pL1j=M.)"b3lizs,w)VL;-d+#>%L`(!,Md=bg}5<XdWTLiYaz"jP*rr[E;/%w-M2mwEDPxN^su];/8"RIz?gCk/Y%qi*U)W2Qz2T65L(uPLomfDgIux]G,=]"*y>K4:`C2DpOQ5xVg?nv"ggW4_1s}0(tOCSqu2y.NNkK;#0=fB^D[xa]7LL5%v>ZJh:&/-;+5#yGdhk=ki;tD"+0SV`rsWGXqVE)n"):k=DQpA?`R$4R;s}[P/wHW@zOImfxN]{:-h.IdTzq?jAAon9xTA?O#/lq>d0$T4Z27^"k=R,Z*4-FQqc[dWJ-vc(hE%Ubw)K*>@8RBJGVEm@$MBXh)m{wP"qAIv)P0"ZiC*/URAz%K&d"XULfA2s<
)xy?w!DP)w2BL=f,X),R<drr8Qsinbb:%L^nUSLg={:1Rcc52n#D31&G/ReUEKvNmKmrByB14NF+F.$h4mTChKh9J`6dIZ4nLn=C<v.4*;JfH:Lw5,A5C1%=
}"^RRE=o0qD<|k>/O?jLPk=6E4XY/P"#8bH[?cA$hg!wp!jDwlC80V58}NkJZn!,C5+N8$~#
q;l;:Y=09c<dJEu&/l(VFp(3<?vY#:TB^hZNne1M:kw{aMUN(c&SlR-!8XL<SNI9H8t4N3?oMDGwQiq9K@3:=
Ox(b;-%F2cwCrTaqyfb,#0)i=q)KhKii5*Z%H(qPoY.(fg^g1=]T]zDYp;M5qih[+v$kG/T0W
&3trPYi>#U!mGs%?Z&3rlxXw(&C%/NemZ6Ta<4s81"8M;LTT/!DJ,8dAWY*2HV&GScQWdN;]Hk&`6WI/O*e1%afQ_g5wJp)lJmq@,U1cipc#!IOb&B;T`iG7`ZmOG!3YUz%_xVNcO<%M;FO#,qFQaCk6@0Z}
b[`
f]r1Rx7Dz
|%]vWA3OF&:p+UJ[
.;oj*d!,l:Uumb0XsiKRL.10]ZTr_1wWN*w#$vQ#)(Y]bUG/)Sy3lnd&YVbR]5c4M
bXW5okct"*7s9I_HnN3,I-0yx/
Ucnn(z!rK76m&W-d9ajrjfO/~r~4#v:QzdaFo0Y>?G&)6I+<urQda6U<Plu_wlftB?6UFb2iOF$sawXh:^O
z$%xe^@9m7ZtKm&W;x``=mR/NvJCr1SL.J?ur;HAnEI#R:G7jh%IE<ZK~xC?ts81^ubW87v4uYy[lM0Vqm:Q^kw_Ya5c<d&_bDS<OpG7wV-5cPJH>;<;W]B>.g8`.mIRSqvUIlWfr85SSMMMfpuGcJnpDja?A`%pr0O9&8mr2G-uOS@M(qSx8R|6;rk7Yc)l(/OO=_~05UiSp4JyDGtJ+0zxl`(PA$6^)IgO5ZmKM:)Z%PUmXR9,wv)SwmdcZ/D^@d205`84XPhG+A^tDV
ngczv{H^0;s=9J]^[KOg^(fmv]7:2_(OXVX#cdpc"<<7(3+[?x6}wpIDm@Alr2R2nv,Q+}]|pz1qv*mCg`Filpc}%HcH;Eaw=P_aDBWYoy2d]-4I!u5j#9<I[gfdDuPi/kQPg(V{Bn_jbC(h8fiXTt.5,4R<Db>mQkIW#6$&tMPi!R`5aP<_Vt
vwb:BbZSx/9emb]WPauKdaHBXZ4V,.$okc9`K>:
~#4kpWZnb*G`,M/it5MWt&<rZ2#A(c7ECs)>DoJ2H(yodfAZ37:rV"vepD=JVyU]n/shbcGu+/cGq*7oHReUiPXC!+%kVXpHHq7@z$aRGGlH[^]w7TYGvZVXz0B:wj7VD/=;r[)TGdh=K(,iZ!sBa6*][ZQE=9KXwFJv;4D._".eVa3eU0owC,WHfsD")Woe{^6#bL2_GU%9sJ]8+Q|.f^Z7jV9x.F><2D@VRdu?-@pougu0bM)
J5RmQr`^_B;A27td6Yf[n<w?T2u)WsvBN7gN2QGdAh<T1R{0qkmV?ed_|)cfTU`r!t}c3w#&rLSbwImF}q
>?GA60[GW_PDnx*8o08y;
*;t*Wd[Vk<hqf5YP)3f$<{HmDN4&c&UuA*<=4z+:lZAMpHGNi"_6ah+Av,0/l.KV)BD;93?re!FhfucMdcPAlaRy[xar4cq;
]h;M:g^_fnvB3C"p!R!Fu:<9<`HZ&3]M,>f!&+QfIh|2[H>&zHH.bd6mK6qxfpcN`,11-"l5:%!ISrc?&KK!M48i*tap2tg*Oe{Pw52oKQGhj=Wae/&
IYvt07a8jfsv+e:sW7z
%9Lx"Z}>}C*`Tq2Y7x[WxLCDfCLBF)n%@)$xz#3<)W*Z3M]3m^J"&JIGgnqQ1cmC[-:(Khv,D2D
Dz#q-/t5"<]oh"$ZPo5Z>$$<%.B3~$F-m6aE>6h.^9XBcT*xbQL+C
6=;?X+aOWxM>B9L"p/Mpy*).
(av!m|UUbP:/n`oM+ce"$@T_jB#vXmeE-|ai*M^|9TPJ&|t(-isH;tn`4}lFYmw=AH?Ni[fAocE>:vKIjVvyKYu5yEB3^6%#R3PuyG)JkN<4oMx~Yir^LFHLKP-8ma.2;,tX3qN:JG[?21l[YK
+"9kcP$m!b/4I>;Q-Kv!_1YyPi7TIrE:X[OGziR5onWX>I2b09.="Gr,YWMfJW;3S<2m*<4M:F,SIiOIBTdlJ2lZ_fwQEpq2kmsPDK9LFW~&i
?.?L(V7]5u3k:GJ)U85#bsp3U,tvzO9ybsW6
:yYw-?C,g]6";)Ls5kf*CKFyYX5!G8)$2XF!+t25^Da-9+Gm_UW|-Pcy!>Nqp]2:G?W}%$?MW(K"<}*gN(S=H&++u@3@JQDL>Y08Z$?W(ABrTQ9x^!^Ts[1EfO+^!oOGRCAFe.o_0XNz9&Wv8(AiC?
2Ou9z>sNj^S_O4;&GKVV(An3[f/+]S{80F6mgZhvJr_eU%NPutm9hBPUxdd$<7.XDbK^/`6=.t6iXpumK4_>+DJpirZ[xfjM|u=>F7MR*!b/Rhj,xq6j`M$cLus^x*]g]3#+S%Psco9Ph8Ej)MA#yE]QKe6k5Y{*&j5/v&bVwU^f_ks@V;u:Ea{xwZ<y&OMUGVeh328[;q,crsXjhV3<(38o;R"]`BsZ^0hS8;(GoWRP]1`WC@#o#Op;N=(m9f[Znire"Ba_PeCHswM*SqQ_t9
9k4ZIo<Dvhpjc<!c@yazn%@q-/[=W"+23)"a+mLT:27-8XXsQSe`E^(Lnit7
nxWXKq3ebi/^S,[ypTT#z!d37-slFp,8TJU-+dek:#Hm/qw,+?A!t8R44FGeG_jn|e~o24IRg=^PaWe4k)[O&MLR[e/8]bNIY1;!GwVSVEo:M,Z(vM2:2@pag[^xF?_2_wD7).o.pUSi"(j->WsCy15U/_YnsIi>*#e;YP2/@uJ`djVUAsxwtet6I]Rh9P~l:^XD6Lx8&etH52vkD-Ux/i^nb/%r&uq[1GBT[5f[9J"igXbAtMb4"cSE0
O/S4V<s3nPRkTmVVOC_Kaq;AA:R<b)H]=R+=I=U4t3*oI37SYL_Ee:3_XXPBx[{9-R9
uCtn:`|q{ffEs%qPE_5HSa]
kg[^)uC!7=IS^CsO**]aQ&3Os
TD"ohdU%3vlOx+k/s"&pboa$jpTP7MACRQnC:Mt)]kR8M(C0&KZ^~m>VvERCrxqUe!I!mD2"t=eEIwQ^A5KD+]w)Ju*g@Tb@elUn&aXR@7*V7)@Vs=HR~&U%M4%okwq.dh,-%;u5@$
.=Lqry6cQ-&I!PX7jw!.;[s24YPiQ{EspR/&8F"_g:[YHwEVD>juJ
^5$}h;iJdDo7qUdg+*Ta.kw{FR]L/JsH"E>v23[RcfpgBf]hX=GYpUJ*8o;3[Exi@eFAh&I%qsm~AS7*0.#t"iIbyp/Li?*lK7Gee$t4;?Fo9$cVRQg@c1XXOJT9_zMH5t,ASy0VY=DYH_0Ty~@XVSmk6i,nc3I9@2QQ2*F^!gZNftSjNN;@$@5s<(@Zv#M,N(=`s)f<C4xZpgMg=Rhkwbjen9a;Fmplro^ZM:272ael29qsA~-a;b9
q_$<b2ONPTB9(7BO$P:w&"i$WfPzuBM
4C718F81YbXubsGZdf6+Dp)W%N$$,B8GVr(}PG04,b-m0LYCbeAhYrw+5(5hB;"Rr)0^M,hzTUawLT`c69IX^mKT:aB0,]he^0l
pijk:a&XJYM:QTA#_IL[`X>{VFr;Y&dh5o5_&g<MhMtx(Z7to?8n>,gy4.M_1/T<0T+2W5W-k]Paj=d:I#!q(5tds=pb4NGR@rtyX2d^O)C1>OqfmV
L
<70$:Qt2Xnkc,7VR9[j+-i!kV<Kh%4q/37[1C^AQR>Xy`L^ES"SC6em<>B,;SUwg@li=4hAb_()%ZxPS",xWEeW
n#Y7gP}g2Ku!3&<]P(Rc$PEf/Bm!>"P%73CyWwYx~/>flGkNcO`)lq:*PDtT)/%&[dRXGj:LP`Xrz<,:CXZV8>g)B2OoC)hVPRH<$]jQ++!;W;-meVS
)W<f>Uf8vW(P>#,QAhcm;LXV)1v?YK$Viw%&9a{d$4s_cL(cIxi]UuHu%agP+5G^;j3A>@5:%=xtsGo2[H#>CH57^](HvxFGVBIM{Dp42c]!6`%Q~<_Id:I`<:#pJ>+7MU8d%Lh7ZlXHt1N9Qup^7K#W}q^!(L6[`T
ioSP36Ktr^)C;l[EZuGe
f$U;Ui&]=pS9v#G`gTucq:<?5pS1L#=h(/S)3dcDn#jP;eM7gC.[Gb-20k^eeeQVeahi@r30Rn_B[Y&s%H+?1yz=}dnaoG<Z@!=b2!~rcMiEZ^$_jUj5Aw(5t"+P=,)s>7IS6_-q}a0+zX(3z$B8*b_73#M;&7-CT8Bc~VLj&O9R-BlMq^O!ZG&do`!?*1Sh*^Udo*Mo#$+@#:!4e?vuEce>{
J22(
2!vHweAa(cfH]mv!Bc
U1t*$g%1qT5FqVn[PRA1GTOxZ&#.ZdTFU!d(U&%@F*x
ANKD`g4uG<gWgZxnos!DyoQSy-Xh|R9CB0-gAAl9nY?mGBhZ.J/rYIqj9qz$lfH)DMwbFPAwtiuD[Pc
ZNX&g5`j5ofvkNn.NaZ$.y2iBd!h9s"fBL_Q{oxg&M3rZ1&yW;OCb^,QDiwI9)/y;Agot3,fQZcE#HxrW8#gq6"Ex-rxn1x?sVXO!)^)T_0y=uY1ZvnD>W[^l^|2o#49y,m%Mnok!]0hQ03c4etq$1rZQ=A7VH+Mq,(p::"VEiohhqdhXn6hna=:GWYS
o[+`(qW(@"xPi.9>SW0$dT/]("Q0*:fZ,67ICr?UZuD[ShbY.dLklr,$_N3xd-[Wt#)XmUjUw%&}>I=
71j)
f5?!vC%3^".o4a6$FGSbB,QuChS2kvJ6iiDeCgTkV%]+5nFtl)ulmakq)^gL,!c00f}6*:yvu$%1YSN(U.fyWsKT^[EyXt|:<nzc[N:txL
FUg2p+`<%y-!*RbJ`bh-s5Z4BCw$A=LBXx_E_>N8AeAVCBQ^5U;+hrJm(Zgg.c9%G?2*x$Y4W_WV^&<P"!a!?!:AUKs.,)=Wr:D6c[o$*&dRb.iATG4)Tl:Da+GWGAo?"W`"2C1}a6YfWZl[Qo[qQGKY3Mut:(%UU6cT,eT}rQFq
)R!>l0Z8a&<$xG_861U4+t]/J[d@eylt{Wb,LF,Oo9?./.<_:a%&T$=4:N>^kb`ROtSI,dlk[:l,db^a=9I4T`a?e$7>2(
/(pM$>F>yhCP3e2bWvv|_E#52B
[w"+1DobRK&nkRjVzlZt>U1.S7LKf4|9uY6!4:;$E-9*W6oAE%c^_B}TKs?FoLNbIMAJ1`:a@r{
l]FGVfP.ompH:&T;u[(sp%cc.sOW^S5p1UxcWu,O]deZOachYL)F/1;a(eF)Kumb0hLY/b4b=XLN;%l)uQ^81r+[pm>PH79GEKJ
SThq_5e@`L
4#$J9_bwla?8tJ({yT1E7@KLVE4m$,fkW,==Z=G,t9VaNiw5/W-SwXL|<3d4Ip(rngVeAga%904a6Z^kC.l`4/n^b4X5LrpPPTX~t3?aSo8.!&56.`RlqeRp!J1MfY2SJZ78v)1prGIzOthS6AF[fb[:O`GxU4T<fUkT(kF=47x)iG,qYUh4_E[cj#cgmAT9d9eu-bKgf|L"0{-W^$gGFfbaLj/-?^dGLk7(82n{vW9>_n*c]M,y:tLY_6cza2HZjnPQ?ps7KU!*.?oGNcPbE?z).Oamq|CeM6P@ao7wO"$
)vk?v-4vpN^wu]463jO.i+#q,xZk?_V|$(D7Y4U6rQ)l3<neR6:Mw(PRXb*o*R`OQ,R+l$tt%+Hk]D.jxYF!K
DU,{nqg>dn$4R]kG[[K_>2**twcXeq,2N_Cfya^Vs^[m2JV|Q1)gs&3?7

<.A#roQHEFI<(J<^~srEhxCM@OzOT=dF
(|X~HwRq^h#e8uF!uzE?yEei&Z<TMu9D)Q_m!)UH,ZxvxTk}5B+Hdyai/FeH%k.R.e4F(
Rh1NhACy"^CF<H)M4aTlXlJLbQZ5O,nL8G_23c["y8dT*?^,#:E;,^i.ZEFPGcP.Ul]=al=Qh"&0Z_itw2DBdaeHm|!E&G;l_*5:rStho_7-!aWNr*
)YuhFCpBrw4-"j>,W"=!(Hsbk"=PzsC3Ib63{W$JJWQZ3EImo3y6`nW.1M-9x)q&Q*0U+LIBZc
RJn^Vzki6BP8ED4e#@s%LY7+e{;Ci[`eokF|3XI
_4,0v:_RuNKrO0?(Xo8KRjk1EG)[Bqi4E$V2]8NT%1Pww&hV-[[F(.-#AE-zmYT?.w?qXHepAi6?XS+w#iYexgxVE~%TW<;wO^>~OMBvPl1OI^SH)Un:!:Qe5y<,^"xF5"=KF"Ec5U-CYy7QTrP
o,C9Uwvho/nJozo}EgJ/M`:YbL_gm?9l>s@&@o;+.|d<KoPuIeR(t:h5u$XeW
+<B~BeN~/urajnZ|[ugUqVXvN=eR7jXmn@hCv"ch4/DJKa@zLb9L@]PIYXJ:d.QhZebfr@p7nNgJjd4c>_Wy<D*&/R[124AowZF]">]oj?Twk&?S<KD^hhjjmhH|tSG{,<xBQ9a"`Ab>I}"WVi`)PpO2MGwJ]u3BtO:LwX0hd^"L;_y4bR:,
RX$FO:o<@8pi}E]pEKc_-lx3pg"qQ6J?PQk[LZ^d!<~vqQ$e/>e&`TjY$%t#ag&X9vVeE=K.ZEej
M6^Ht;68EF0YR*$].W"{Q<9[J[p`hb3^nO2g+a;o-/
]i^jhY]W1t.t{j:o>i9vK[7&yKS8Lqj8/IA.E[O0e2}`o>hvQV_+kIV*?Mh"mRMrBNi[nY^*uX]2Fo|8F*[l^i+b|5KcQ2sWI@80]5d:7.FT;hL$z-HO~;mBSE+6v*;?.r,E@Cf5^jTC0t|f=X@;<Q7i#m{&e"V4n;pvl!cx:OaC!N]baOW:q?QDA/Q<{BF;dT^,q&}7=(1X;oCl|;s<21JKpu5%ciGf_8CAl*n2<1Gbn?$H.q][7H)m-`YMJTOx.&b_x
M%PpylZ]>x"OR.]a<>eJ%o<?cuy+5*kLh$ER`!zPmc,j/"4
cf.sQBNtfJxpV+s)M={bHbvVFQ6_CZ):ofA!GrJ!*EkK^[{!^nfA%XMLe1"#>wX4+F*9z81#TnpX>ZWl>(s4ac~Q>j&l@IS>!fWKfs!YJ@@XJ,`umepy2f_q:ftVmDe6Q*Z0w+33}?Uk{W1&*f2+9U%izmsR!L5&.[:_ulb!M14)"S(.!lk0H#cBna@lt:8M;&&Tu/nK
3Af)iY%+m%tYk5pYqJ@#:)r@6Wqil>,teDB+$"yoDL6QUg<xUYkGyDak8>NkcTG(2DQ+I{S0l!l.DS*MTW*w?>mkqgPJ712nw-LAyRwAn~V>$I&|K_!TfkM`cIwD8anmFMlpop3BOPQ*d<h7hrv}nmyEN"*f8sxT<8ugn]?Mx6^tN_2Qsd46#s6y6g?cb}Aa;9
"w8Zr3{sAU,2UCFopbk8`!iS:gD(SStUn(!"C^bMroPM1vJi)`K`WL>QyHg&eI_FoOriC<W?d4U?2?7:dbPZG%#>%vByYS0u[CP+nW?7C[dBIl.gk`2X<OE1*-:J+7#eSc$u2vJnrR/Hu[;M_F3NuBsnr:u=H)$*4;}`r,<OtEI6^p:?t3
/R85Vga`u
6(7qP;s_7r`6u/iP8X@5K^E&,Z-L3V7cNkof[I>7?*73/>PfX{A`PeceuKc|
1m;=5/{Mf@UVzJ"FY^wo&mb:1g?Ycn[VnV<^$o@Jwm10pyC]jscTNbB4wn#5p.+@xrwZ37qa-G+BO[F^LwXEitkcIB{l`qh7>sBu
ujx;*AZFo+-c`mWMm&lBh;QoT4Hf#?KWP[#]"a7%qEF94O&?KXrqX~D;9kBxxDK:9RU$G@ZKM]RqD)4,X7ZIAO5mQYCsF$/SI0^:wj,tL+B%JAhEw~cE;!%*Q|W2)nF8YXR~YUu
HfO/_~DK.d]MK(-!h<:6B
DjXvI&S"LsllNPy|4.cZW:7G.@@1E`>hyY*~`LrOgp6?0)F|.EAYlO;rgT/+db
M76p3=;Xf9FvC%
LZB/Jo^?Ih8|X>C$?|mzX
)U>ib^Xrs0&y&0,tm@YID)u"y44.3@nl3Do[4Cx0)L<
W&Iv&HQ.q/hvhrFQa+LM9OEm7un0J=9]S"@**?2[p,5lpD^zL/itryk!,{0(*1[X:?oxp{RxAukUK]?{e%T.n3=kB9YLUFqctf+?sSD,05v=o
/JTg2ojtCT17-.:*,~<bSHc2$V0dul>
+iA|>y9^t`(3mk[0X/Rq/LU0[vPN6%rON]u5t
p?"yV8p/TC?zd+;15~:%9[[M
4oJr"!hpQdC_SrCDJf%B~GDh@Ri+<h~Q$y)KWQS*&9@HRE5)Q[R6Z&M5wO&9[ULf63h]6M[xLPy0BXf`Dh$[1r}BZxP6b/.fSBC`fb4n10X?=38s@r<IdlUoy#/6!?Hr;=tR$e9bYfpBkb:>ob6lJ6l9{rkDgF_AY+u8K6*k/pn`Bjv4p<6^#Ss[(!p`?jh55A#;R5?RWipZC@/)O>cCUf&jhD;ZDhtOD0BZ)lQcY9*/U,00b3,@SyBcEI6IPfk><s2C,^IJ#xprI
I,yUyN$N?VC[jGgdINuZNrOB(5^xTX<rs/k_4SD[BXwOFB%#67l`KR;z(UsNUePp,+kQGrqvYu@h|oH5wk_h$TLxlf_dopW_eZfUi:%%CVV.A7k:idyg!T5^EN-p!d!h(x"4Zu,u8s-Y`5`"]hN)W`;ne[2nB5?n)c>]>b[hAYfyL/WG%X=`pDG(ly4H/qzUxD%eIsu*iH1Z(@#9-x`L
k=5600kJZpur%*I~m
xW7ETT!1F"%:1if~!^]K@[%WadATw()+C1ahh6pca2Q^Ki)nQhSBqH)V7u8zk[_T/;29crAQF"QMvURFYOT&Q^<u0Yb8AvLT4UdYK~_2QRpFwy;EdRUl,b*Q]#4J&^9soB.h(8*2NSSCIZ#T1Mn{HLPNhKa#V/Q-D?^rhX_#%Nb_Ri359T:.]+&Zmp]IL^s1jbw6
9
wWm?kFw15V)2AQ0mm.^uo3JQdc?#`@ek5u#IX+zslE/R%/ok`!C3RiDl1G4qccrVC)z&/S(<"Y@Q-18I8-mu$wB=D#2+GU$VGVJCl+<_EO]r?
S`3=1M?m8j|wCPpT}I/
BV"@TgO9ci6QRd;Uggfw_S{Ibjsr.t7VjJ(.y7UJDcJX=,L%8nuut!]%)tb`?4);(i1x`EFnXrTy6gYiqJ6)z?7f`e9jaDPCc5pxB]|&SO}hMh1dI$f*~wESJv9x"9dm2=1v8n<6}NqTO.K$4R%UG!#B
*Ga{^g?=!47pkcDnxPQ<OE!KAnwk%.h,KVecq-<q"]@5YI@p&)&KLSiLE?_}@N
e#9%@1t0vW!D0SO`rl"!
]R,ME`=;E~u_B.!N@//S21vcRL_!;#H:T>
j,GvPd[vb4!L)(WRvJm7V,UC_Tg(@,gs3`9K*Do@}_DeYQ-$*[#Fwp!BtxfiEvxk8&)WRvyis+XmF:JEYsRshH2EbD3IdGxjGO8M1F[+XP795_tc[`e]ziCVs]>BLB=bQC~hKD5GL"RsB7PECiNGVDzu0WigGGfsfdTuct+_LcZJCw/rx@|w+v}mqhio
?FRi[p2,m~LBb14ffCn-9*==c`b?Ms5xF,nblT];n<f`[c#d7<GDFjCUG`5rEFc^Uqu4Vx0nbX<Kl5JqnaF0w.Srl[mQk=nU?wy8W|qC<-`s]:,67^_PVk/t({+7#<G4F@)0a(NtSilM6E(VLGY^K7uvdD5H&JLAmY>Mc",nnc`VGefcGIre#QbHi8m^%wnr.EmDbM4[i22vF3hdOAY4
mW|sxRi>[&#EuC{tIhWU8P7[<_oa#_0G;x=l[mEn/
}lz6[EXm,6Ih%nDi5nZlFK3n:Q|=xM7;ysp2iS&nb7abPi)lvT7LLV?[D*ga=X60zaT7ql{q:Bqn[jp@beBidO#?kG$/~uq15RX)%/t77hZtUhn`yWGhkKJ/V3y]d;zre&&9S4sZ;H1Y^e/uht;2|[fqlH/*u<qw.s
"3LzE*xzG-T1^3$Fp=*b]b=)e}f{F;w,C[LfW:ncb]evI0[#xz/~`eSY#_S$28yJ^Dtsn#AA6FSh,!E&FH*8WG+i&p.VtFXS6CS{0C@,*iT{fIW!]jFfA:nYqEZ
-x5I6_UmIUsks-><0?n=Ex6y?QqPw2+?A0xE`x+8<}k[pF+VgYx4nX%x@rXg"DiTnU4uV)DC]/"/mNjsaQY8ogpsvl;/6+?@+XFwG8ra<lm^)aKri`YUkNgG`zvO>m+qZ@y0pW+(?S1t%xl$U1`!xSEDE#uPb_g,,)+v
~s!j$C:O
jO5(xzK41
nHBQ`,38#=18
OU@_XnR1jgH,z]~Uge{M+EPm80_^z?z_5N(v5U~,(r@Z/c>FflNGFUNqgN5,NWH?)SsXK5-t/=)u-pKM67+mQlnP7_qmj1SSW%>pcde.4m&!n*%/01vamsfWy7Zobq)fJ4!^5qf`]Q!PMe1Xyn)_T"kitm]rCVw@P`wh)f[JUf#yR^lve[O9Z_/5)h&7
ke%mjOyCJF"22:%siE7~a,YIrIOxEYK{3^bHkfp~fK3]sY`psD:["S=D)wXF,%D6qYDzPfesc9TP>qSNW$Zwlv4mPTav]A&uM@6fa2bhE2X2_(079))Lmr`yS(c<JoS)g!Acw8]ZC_@k1N&ha{b<WLy%KYNsqU
n4KW~EfB+lzrz@NZ2E>jQjP^bO#E,#l!c/"QLmAae
Ej?m0XQbG&
?~ZJTljsmQ+.vY^rjGvTr~b10yn|2_4*1"fO!.lnbyb.g.hdpw+Sb%&gL$]@h"$Bn
S*ghlnKsZv7li&o<,H`)lzl+^.gm*(6Fvpi6BPsfubky.@=$h|?WoS&iBxcGYd/U!?vRWnR_]dt5?e;yD35I])qMJ&B04ec!:YA5M^+4::PDp!2C7dFE.H`y[ZaTQte$_?`R_eyL_4caMemgoO[S`T5ruV(oB5)$iB<uTIBYl&ew6q)Oyy_/A5p~>9Cgq{W+iwSzJrL|9/kTPCb]_F_0+~xEkoEAp
jEs|&RD#H89hgoqH_aGfT5ofw+RphhpxsSw6F;a#`]2I]OA%,FpBsoRka!]cq_n[6gizJUc@jUHK4[YixWs`!,R^VT_y9E_#S$;v^0m>XDwzgW&]/6B#g~GlGv#.S.E[0C&"q
QdgHPn]dB0uMgL<Ox]Vb!
+<CyU5A!0aW}QqfKPW_+$jAo+Ben4CD>PSC]D?n%fYKWefnWGnn?_/GaUy=+b(hZq.-5je:O]hoK.4t*LQ;!^o70_<=/%}n43;7!`j4uHX:h+OC[s<j&8dEAXstEhdulab?Ip0[.*eJpEv.8WC_#=@F{nonT1fC]nM&=Z9PYby`^C$s2;oL4m1"0g?r>p%Z_]hHSCSw]`/n*^
AUB&,:sV4>H:^/G]Z[4u
IT2c6G,);u`caD!b{(>$
7]J^S$G>i,mQt4NkvWt0Rxo&s
=l`tRZ<{H!0u2d
WH=VZK.rE=]#X^rs$+um
Geo_gCMqmIGR=N$*XbMoIEB7k*=|n@b3en^rPgRvUQ,(@P1)gblN]&^w%u5wyLPYV[&$52n>=xdhvK=K+K%(iw_fmUA=/VO
Qew5P}]J%XW.j8DzUeR.gm0Kl<19gh+cP%NGCXJCA]QlaJ
DT%p8Uw<$pKM;tUP!bI)s$F&Ta+l+xm/b<Xx`A,^}@+Ef@*Lg6ZPCSB9[p|HzEhbXxf]hXt;"7jZ}rn^)fCKo"=!uI&A.Soo#Z}L{Pj(>B>a".Dknf|@,0?#uJ^Gbd,r:gZT,G+_xf+a^.,a3tbe[ox!!5zsYL?LKlKqp2cTgCF"{*a&g2}LQ*;TZ0dEdDZ9j0]OI@i"Qa*&,3e$li_m{np
8yfqsy$`YGI@@HxkYy#G@5?4oUbCJ$v%}RE+4<}vv<.!TCB?w/2fbrgWGO$%a2E?N+&Y:&afn%#_F,aS1u
o08G,}wP7-VV9h/(awN+8*+7hG/ij^Bt`PI[J`8h
aG_/AuqZ:*6p3Xzgx)hjB*:5f4[Nw=QbCLgYN*UxU1|!3QVeukbh<aLbt+@O(vupOl=Xjnfk[-CP4*m"6aP5C.|JHx*M4L1Yisd93qd*9,O*ygX4Is1c1icu$@NjG2$w{Ptg`6>W>?PDx_qjgB][0Z[KIw,vni
`hTAUe>HuUlWPaU(W_]wJHDuvt])Q~z(lx.J&&)i!F
IB
`,p:gk8)u7^jeg4sm90e+316<$%F]Ek^6G,06higxlcMCF=oIg@N7yb8QwGz]s%6Ch6kRllpdCV+[vu=25%g6+wl%M=hVEY|=q2<Aw;}g$0rY_t`hN.G$9uAf[_Mg}?e[LP"iwSKEMA]HGW~#T_fOvwQ6*NadT`)D=q-EnqNKN"VwHH8al;WBOG
?("zdy4OWQ"km
^5uvu)e
@a3#d_B.Nrql;`J}5PdA.w1eNZYlC.^;=lEtNI9wQnjGU;HPmPK1_Neki2u(uw]d&DXy9{BkgNN*s8
n76>}$CEF_TmhP@N5

;6X*kW
ncRA4K0dfMO<sGTBO_.?N>lL/,Lbg)U*dVLWGU?DCCFv+[2QMG}IOSqVc1ai<@jJ[W!s,Mm:lnqccGs(HohqH@zGwm_8247[`+6A/f{RIfOY$HGb@6T=|r9H1_)]}g-PV
K@or"CXWrVILHK4-kfy2:]^JH=xdL"}<tcj5r%6E(19u*=7F$[6]o]AqJpBU(5WI0bpu"?H/
;iXK
|pFj9
$^H21XP+|%fMEQ}<T`e$<p2crfH5pD9Lz*^/<mt"HR`XJbKCA62V:.CKT0v4]TbKyGwP4/4Z9vkf6p)BNQ
NCc9W10O?7*bfAqCfd(5G`dCTaPLKxMGUzMQ+)yD5yfp)K+u%35BgZZ7:=/,[+A[5P$4/Zc/fQr(j.Yq!+/%h}qqIIl7]FPujB3I:<%=E|Z;Dl2RTa;09z>FU=#3RC-CME/1e!jBO/ti*z5t-0;<q4OMwT;?>p)S"fLaU-IlIL(!
DY9Wu>_P3Nw<N5a2yX`U7w<m5"|5.#MaBhfC{)~!c_B=x
4gES)#h/1Q7eGSh+Aw~02-CEE+#<:Pwco-m8m[^5[[+,dp>9OHW2yFf7s
A2Y4EZRr7u(u0ptZn8>8pT2>7c0<@ajYJjefvJm#4cWQ[0YJ.VH#J2-9ZxfwavZRC(Vim%f)87[&u"~

4ao[($w5d[TUU1!RjI1@QPDq8%;B1C*LO[G+]|1x-cq*k3X|iG$+!zP]+f)ZOg/<!apn=ehfZKEJ9X#eE8jZojuC*EZg/u^L)#rGW-`C0g``YS)ZKfP];rOyNMUoYN6n$R5jI9!8!0cvj,Zb5S`RV?"l&w
g[-9PCG%/hXt{1:^5;rK32=CvGuHoY4.J4^j3ur=65WlWGKo=ERqRc7J"4Yn1l?%der?)MFNt;pK,+;TTtDk.s,!xa$MvPiP8YhkCvOuPiL@snT
w#/B5Pd9qR7x#]*LZR_MW<9Zf<Ipkd(mVkL>+7,YAa/MefgAhH$%yg3%<4mBm;BO]RC`Gf>an($X0IaEXt:y+DSFKmxVoW3-%_@Jnw_PoX=4{Wz!,A6r~q#c98xaT[gb`[<BHe

mGz!).uRwXCX<K(.9Yr>kB
Vvt2izvjxHsz`u]M#2`v6#nm1u!=e
@!(k*GtX^"o{fOjJFqb97V(Y5f##iE>x9qY.v7oaK>>=xC75pKKg@Ire#M-0CY(Qp`+6lte:iHoc(CZIrPLdrtU<qY;-m")ODYAjc9pTFE/(cyrBxc^+<"F?`-aj&O%b9_Es!PVp_-d"n()m-ep9V^1jVWi;hO[BW*T`0-bSDkUvKX5R[=v(xVk1wE%?Y=TAVSd5?sCBinDxXV>We$Mp-Ie@ZPK]$VcE:]1U0qTe$cJ{Ou!Jii=qZhRnhZl6n55_RG<YNLE}inP1Dl^QOV!~<^V<?DAV=aDu4uU@5X=ML79qjcTig~3eqKCL`09#@&Ze)A=G>8*7ZV<P[e=x3].,BmFcG~u!,S
Ub|Dnjom@99wZT,A@^7xbk);"p9V|acPSCI]h,+jrh{SAZ/Z4<<ja(4EBc}hJ!KL=7m"6cU;!2m%QohuE9H>@b,F|
{43tb?U<kAlsZ.6=VId/JK;,;i4Kka^YH0
3
aT5+ce+/2D8gvtki`{b+p56ka*W]/AXq%l[7OPO]a`Mz`L"Oy(.`t<24@!,D[ST
RI3icjX^ALd/vy-2Z{5@(6m7Nc",^4jX30_}xuFv>3dR2qqz!=PDtj.y89oVDH*,$908Ii.2=s,/+wf0bq@Vj&-{4MIV]M*~:@6VGJ"Ep.3z^boPT4VYuk)mb5dt&Wi7L(/
"Vk:O3uz];=Hu4.c-rn_.#TYh#!?3%SHU
9iJ+.Qyd3zO.bM$^c0Ach2u~1M(U?|Dq$:_@L9U^4U_anJW5q,]Jw*8vWdbcYK4`DxUnKaM2prE6sVDnpDs2#:)U$UOr0@L/!Jgzgh]w92MI6=><7>aiERKu-KkiDu(
kJ)vQ"BSoh`pp[ykg`/-N^q1Kt"OLd.<gqGWHOyAr9U"#WDpl/*9f+VD?pvYT26{%S:Ls/]q]z`by:i%$5Evq/24lPYA"Fg%R#A,)75<OEjJoR5d1c<IALs2v)?RUly!rAL)"ME7<"3DWu;>1=t-H/a):4HdvyLGoIo``QP)1_iL;lInrSr#[(B=>+%QUL/RV`rvthVj)4R2Sdi$.c8_&]EM]Rk.;#L[/JWlJ04Qog@Z1B9_56<W!wbY*UU^cXWYa!Hp&foqBy
NTCX+&!#e@:];g).t7p9R?G5dZh^NTFN@p[YY2Y%xL%Ri*X,5ZPX*S2w>DusDi<rn6z5A7uIAZK1kF]=N[R9?5U7p!P@;aJ"OuPq4Y4svg]yf!/,mLIbc02KtvDyB1<X:avx1C|kuRIj/3LkdA5vljRBlr.t]ru*+ZtFsM6/["+jOQZ[!)N;Y0J0|c?@]L

Q1,:~ZD=x2gb,-FJ18zr@PY>S%C[g1AV!Gv2$aE1ls#Uu54B!Lu>MkS@c:TH&j54C45m=v|h^B#@Pb-_"J.d{rh%f[#*1;a+sRN^3Z9mW^MGHJwa+jqsgB}`gbLn|r=qJ2OWNn:HOH#r=)5kS3ZbFZXe4n*pB;Us;X><wD
S-FIZfJc;*P?b+fZU,lM6RWog:,0uop=
"X^`EG
J.jqgb1,LJfXxKZvMq_sMDu&,;x[;F6Rbyb-;xbYBY6LV&=(2#E?b%H}J/oZF)56b-q
UtjibVcSlmX*x[<,sglzH4P#`IjU:I1#^IGEvk`*j1Rl@7`f6Lm)FIqH1,mH,5H7J/uhU9RhblEjD]p!1![<vgBG_PQ[ysUWADKQiUg<f$@-<OsGbmDw)0y`1!`fu$Y$TOQ{^8V}leKSgo0?y9@-GFo|7|.u)pBG3o9UA2o8KQ#>KSy#lewze&p?[T[W^@vWkt&/4iIy`-4#^g`&C7>`mh^alE!Y_s7+)!-8AJprmB02fi<&7S?JvP]>]Hp)Dw)BK69}MWLCrX_!_h)BK69}MWLCrX_!_h)BK69}MSF}yNk(-%56uOq#n?8_Lq5aVuQZWQ`WaJ74QB@TavQZWQ`WaJ74QB@TavQZWQ^}F#LCrh_!bQ)BK6?OMXLCrh_!bQ)BK6?OMXLCrh_!bQ*%K6I-JQLC>l^{6M)jK&I-JQLC>l^{6M)jK&;CJNqR8Ap)H20"tRWMy0kdk:p)H20"tRWMy0kdl!eul>]N7nWCs(o~HSkjSIiHJKwl`{gwfhqg
jy
WHs#_7a.*%K.E"MYmJs#_7a.*%K.E"MYmJs#_7a.*%K.?PMXmJrp_7^E*%K.?PMXmJrp_7^E*%K.?PMXm$rCmG?::l4i9J4iIy^g`!Y:`&-?wV8[;":Bx(B``&Aux/St;g2@AD1zM(;,`I)N1iV"cWZUn
QZUz<",iA$t#Dmh#Zs,v]Ua$b4pcjNR-kn<"noI:r=+Ub:Ak`VAo^`j(3O02A80TlUF#*g?0.hU?9%`&AuQZSf;g0:A$1z9l;%`I).1QV"YyZRBXQZUl<"!zA$1z9lgypsFqrcI)j#3Og;:B
x
)FbVcC:CZY$.60:fBPW[#L/n5Dj?pX+
cQ_;TV%;_/fBGMNU@gDpu(s]uXii)pUuQR1U|=EqX>:y2ezh&[&3q
2Mxd{q(jVQM?jMuoRuWr<9f]+^OIKaeLu-rvV=oa9AouEj(IR0:AX0TwvF#5hk4.oU?;K`&6t
[Sigk1MA$7L=x;!JG(w1QT
Y*F"+:0*;94iATgbp^e8)NAt,I15j%JS>2TPGSa*U>g6PF0zai6p@IY}s!ZC.vm(H+0STC&b?vIKKa^q9tl%:
;n`&n4?(.
+E]mptuDC[Qj]}S9U^F#b>
.;95-Q|W8FlZK6UrSZa^ze!d<7NXaF-kvnQ@PDGB/Y%D"$/lBBLu.SLZI
}vFEd
>MxL:.He]0PkFKL&{)D`b8BMI9rFDL.GOX!X
Q>ZZ]X5@LK@mFOWv7&9X3)[#CjG_a$AU
nX^@ve3>)(7TOXs3"KYJAsH4
mf!T2mwUg,t?-}M|2ZX4aLZA=xl+X44%Av%&K+sbWWq6?Wv*T^Q:MXQD^qlsGK3~S3+kbhF*=O5mLrP?O?ha+_"_U2eRU-JYya^/OnDEaU[~,-aqrbyzT[u`sa3ASMZ6_$6yg9GM+6L~f!^bdtqud,5$f<`9E[yz>GLT5xcac:v+h[P#21+A]e87f^[?h(<70rS&:eU*iBotGjAo^9.zq:V+i"ogb=Hv_7o|_:KGs$TTcGCbZr^<<`Hod3IV&g#LGbw8w2u6VC0>ji]SQ{M]%s<@DgXq,EH-boPF8)]rGn-SLGhKO|UCrgo4U#6:pu8(g>
FJ_Ptx_vVg/u^^2Ls9~!lbVv;Zijn8pl|c,^]"u+:s;6eWOj`HRLL1+VYtG[`3$e~P07PVINLUQ#tMk0}cC<f,kB@
kmdM&Zgl0"5^B.x@0[$)~7xsJ!ZcFnqlpz(ckI(,iRjqP@4=?nniYxPYwJ.BrHdYNgHdocWtpijxT.*,ai]XuXd#TO`,FGwX-3&XGNn+j-3SQ*xS^.eRR@C!|d7#R(sSe9
8W5;jm1+D8&Dbj?7xeYV-4_-X<+KOV<t-O>Q%iLT.I#4,SWI5<dv#um{N8wEW:PJbe1R7TVN!p5_+$T;7wClTw;[$#&:D55|!eLy:=:P3PaYI1r|*?,vic*>yg4lCT83wSNN7GWowE<?KT`x/1Ea*
Q.,i&mx/VKny3Q]r4Myvvemd#Mez2XE3gZf*p1XO;N$!+3ZF,@Pr>m$SX
WB(&
TsOiH*LcjkEBDKAcT3fw>#Bf5oWV:o},N+cg-eeJFaS#XM+9k
KKfProBt8h85,hd=m=T=j#4%nnj"RSQ<U"^+q,=IIf&7B4Wmsn~4KHMd_dRGsth(Ot|+Twc$H9VwYM+Jl!-%kn~=Z2to]Bk5>akE!#iDE&~Cdp7c-[ttV(QLoY?&]XP6UW@]JT0wDNgu,"w&^V2,p`xJTr%%PD<GeKC%>flD8.
(x1>2[f8NU/Jv^?}[nas${4r=O.YV@N8R0VniHgy:&ISMytt$H4UejW7a/6N7?pNM}*,S
X]dKL8=a#8gfy9laIa,L*_&&"b_:`.7x1f<p[)iO[
L]/R</*C&U<oKV%"X"L`x061by>^)JJ2g@8I>t(xW*7$OZ&]dQQ[ep3RD
N6kk8j3!f>bu;Yq|i_R8Vz1Ocku@L)J;S^]]=F)y"@E%:LTYnxd.2}eB%YL(RWi[syVKU,,TK<1yLsbYE=qRw@i{yiE(a:YYR=25NZcJ/Z0u;3j)#aOA2t2y0i<6R!SsTX57JLF02#SCS|p=.$K9.Et
^S-,7wAW80WxZ[5"(Uk&PT/w-gZHLU6.k]?WiKS>/AwK@fQ2`w$}]_IZLQnG$}*,)~At4&4sCC4YeL"j,qCiI^$JiIGW1rB|yE3=4,[Z$zE0=0KF_S+qM*AGp[QD-*E%XFYV*VRpa-hXb.k%"vF=W~lvU99<RC2b%GBfLm![-Yb9^2;:9..(*8<A8V"=id;7*ClEudm#2ztI-]c,,Yl)2v!)N`@>=}Ps-O%s>_RS,g>9HwC;Ba$89ZI3VfEGdJhi9]Hw@,QfBvTaRduPlbfnhvfCt$682h$CwsnGIfC?7=LnvP.
&DEbu=C6Pd.MV}8Nncb$MKJ2U[Sh_PO.&l6M&3wb/!S=*7GmWJi6A
pQB6!z=[KKnS$*X/[g8J5B2k:09QO[RJZK_U#8<VQ@7Y4#"Fd!Xf/k(k+6u_ZP$:8ulg=MR`AMP9-gRvI]0;DkYv#1mD)T,{n;qi9
V<57>UBl`gtsjx)-yM[MV=oa&?,6j8c>@H@o,CvV2~](O@RR_.eux59_f8%o,rQ8D_6Iym_$dnZq.TPEoyxudg<+g[/EZ!OA-0NI=^lin,%94}(F>D8Qp-!b>5;uMLuvXfB$K8DbP7Kt4_yX@Tz"43m[9HSdd,=^bh2jjD/Z/1C0e>T#h6.>234zGmYeN>YRTy,_fe/Ea}u$ntYnp<J@!nr_o;P|_?(U2E5YC6vZdfX9+%.g$Nw&#aGW!d#L%J47u^iwVDenv*P;H+KqA<4GF{SE)#qH8Q_$
#S&fS=1itv-10Y
dVE7&8pX!80,G-*N8iLE0nTY,BN7id]D1]Q_KzYkb_J-0X
yih?U,R.z1p#CB~$h');}elseif($_GET["file"]=="logo.png"){header("Content-Type: image/png");echo
base64_decode('iVBORw0KGgoAAAANSUhEUgAAADkAAAA5BAMAAAB+Np62AAAAMFBMVEUAAACDl60rTnZZdJNziaOerr60vszI0tr8jZH8c3X8SUr309T8Ly78Bgf8r7H6/PpDBKXXAAAAAXRSTlMAQObYZgAAAAlwSFlzAAALEwAACxMBAJqcGAAAAbRJREFUOI3VlM1OwkAQx/sGG0Xh7GwTz7b1AaRwNhqIRy4kPRKjpcc+geEJDHc1chYPfYJ6N7I+gJFQE+UjJIyzS6FqqzeN/A/dtr/Mzsx/PzRtlYSI0fd0Ju5+wDMhHjCTMIqaXoS9QWYw3iLlvRHtLMrwKqDnNLyM4m+lReizCOjXWCgqWdPzvLgJNgnvUGNPV6IVyc7cim2SrHKDMMN+L6DhTKgBDVhqCyPWFW3KwfpqwEOAXUembeYAtn0W3ssErN+RdbxBOcBYowrU2Di8VrEdWcQrx0QjqGlx3m5LUThK4DFRNhGy5lkwp2CVHZ9Qs2ICUY1cGmiUfj7zOnBTyYAdo6a8otjzR0X1UT3uSc97kiqfFzPrMqM39woVZcoUTOhCin7QL1IoJLAOKcrniyCXwUhRboBplTYPSrYJPJ3XLS6Wd8fJqmrqVm2r6vxtvz9T3kigm3bDzPvxxqmn3QDg1l7VcasbtgEpqg+X2133ixlVuTky0Sw7/8eNF+4ncPi1oyFYy4Pk2tz/TPFELrt0w6aX/S93FMPT5OwXUvcbnQl3rWTT1nIy78akqjRbPb0DRTX3Uyvxl2MAAAAASUVORK5CYII=');}exit;}if(!$_SERVER["REQUEST_URI"])$_SERVER["REQUEST_URI"]=$_SERVER["ORIG_PATH_INFO"];if(!strpos($_SERVER["REQUEST_URI"],'?')&&$_SERVER["QUERY_STRING"]!="")$_SERVER["REQUEST_URI"].="?$_SERVER[QUERY_STRING]";if(preg_match('~^/[-\w.]~',$_SERVER["HTTP_X_FORWARDED_PREFIX"]))$_SERVER["REQUEST_URI"]=$_SERVER["HTTP_X_FORWARDED_PREFIX"].$_SERVER["REQUEST_URI"];define('Adminer\HTTPS',($_SERVER["HTTPS"]&&strcasecmp($_SERVER["HTTPS"],"off"))||ini_bool("session.cookie_secure"));ini_set("session.use_trans_sid",'0');if(!defined("SID")){session_cache_limiter("");session_name("adminer_sid");session_set_cookie_params(0,cookie_path(),"",HTTPS,true);session_start();}if(function_exists("get_magic_quotes_gpc")&&get_magic_quotes_gpc()){$_GET=remove_slashes($_GET,$id);$_POST=remove_slashes($_POST,$id);$_COOKIE=remove_slashes($_COOKIE,$id);}if(function_exists("get_magic_quotes_runtime")&&get_magic_quotes_runtime())set_magic_quotes_runtime(false);if(function_exists('set_time_limit'))set_time_limit(0);ini_set("precision",'16');function
lang($u,$eg=null){if(is_string($u)){$G=array_search($u,get_translations("en"));if($G!==false)$u=$G;}$ya=func_get_args();$ya[0]=Lang::$translations[$u]?:$u;return
call_user_func_array('Adminer\lang_format',$ya);}function
lang_format($zj,$eg=null){if(is_array($zj)){$G=($eg==1?0:(LANG=='cs'||LANG=='sk'?($eg&&$eg<5?1:2):(LANG=='fr'?(!$eg?0:1):(LANG=='pl'?($eg%10>1&&$eg%10<5&&$eg/10%10!=1?1:2):(LANG=='sl'?($eg%100==1?0:($eg%100==2?1:($eg%100==3||$eg%100==4?2:3))):(LANG=='lt'?($eg%10==1&&$eg%100!=11?0:($eg%10>1&&$eg/10%10!=1?1:2)):(LANG=='lv'?($eg%10==1&&$eg%100!=11?0:($eg?1:2)):(in_array(LANG,array('bs','hr','ru','sr','uk'))?($eg%10==1&&$eg%100!=11?0:($eg%10>1&&$eg%10<5&&$eg/10%10!=1?1:2)):1))))))));$zj=$zj[$G];}$zj=str_replace("'",'’',$zj);$ya=func_get_args();array_shift($ya);$vd=str_replace("%d","%s",$zj);if($vd!=$zj)$ya[0]=format_number($eg);return
vsprintf($vd,$ya);}function
langs(){return
array('en'=>'English','ar'=>'العربية','bg'=>'Български','bn'=>'বাংলা','bs'=>'Bosanski','ca'=>'Català','cs'=>'Čeština','da'=>'Dansk','de'=>'Deutsch','el'=>'Ελληνικά','es'=>'Español','et'=>'Eesti','fa'=>'فارسی','fi'=>'Suomi','fr'=>'Français','gl'=>'Galego','he'=>'עברית','hi'=>'हिन्दी','hr'=>'Hrvatski','hu'=>'Magyar','id'=>'Bahasa Indonesia','it'=>'Italiano','ja'=>'日本語','ka'=>'ქართული','ko'=>'한국어','lt'=>'Lietuvių','lv'=>'Latviešu','ms'=>'Bahasa Melayu','nl'=>'Nederlands','no'=>'Norsk','pl'=>'Polski','pt'=>'Português','pt-br'=>'Português (Brazil)','ro'=>'Limba Română','ru'=>'Русский','sk'=>'Slovenčina','sl'=>'Slovenski','sr'=>'Српски','sv'=>'Svenska','ta'=>'த‌மிழ்','th'=>'ภาษาไทย','tr'=>'Türkçe','uk'=>'Українська','uz'=>'Oʻzbekcha','vi'=>'Tiếng Việt','zh'=>'简体中文','zh-tw'=>'繁體中文',);}function
switch_lang(){echo"<form action='' method='post'>\n<div id='lang'>","<label>".lang(21).": ".html_select("lang",langs(),LANG,"this.form.submit();")."</label>"," <input type='submit' value='".lang(22)."' class='hidden'>\n",input_token(),"</div>\n</form>\n";}if(isset($_POST["lang"])&&verify_token()){cookie("adminer_lang",$_POST["lang"]);$_SESSION["lang"]=$_POST["lang"];redirect(remove_from_uri());}$ba="en";if(idx(langs(),$_COOKIE["adminer_lang"])){cookie("adminer_lang",$_COOKIE["adminer_lang"]);$ba=$_COOKIE["adminer_lang"];}elseif(idx(langs(),$_SESSION["lang"]))$ba=$_SESSION["lang"];else{$ka=array();preg_match_all('~([-a-z]+)(;q=([0-9.]+))?~',str_replace("_","-",strtolower($_SERVER["HTTP_ACCEPT_LANGUAGE"])),$pf,PREG_SET_ORDER);foreach($pf
as$A)$ka[$A[1]]=(isset($A[3])?$A[3]:1);arsort($ka);foreach($ka
as$x=>$xh){if(idx(langs(),$x)){$ba=$x;break;}$x=preg_replace('~-.*~','',$x);if(!isset($ka[$x])&&idx(langs(),$x)){$ba=$x;break;}}}define('Adminer\LANG',$ba);class
Lang{static$translations;}Lang::$translations=(array)$_SESSION["translations"];if($_SESSION["translations_version"]!=LANG.
1852892996){Lang::$translations=array();$_SESSION["translations_version"]=LANG.
1852892996;}if(!Lang::$translations){Lang::$translations=get_translations(LANG);$_SESSION["translations"]=Lang::$translations;}function
get_translations($Se){switch($Se){case"en":$f='-X/+JbTA`*46}NOR2NFRySg<l`iCKCS6u,,E`m:t+5A8V";GbAOO^;2
6tFy&>f]
;xt`_r2]Lq9i_&>I[^:R[L1KT8Lvy5Z2*mc7t;?-Y|ICZ3J^/g]^Fm;g[@aPUToTOH/~18u?XtYI+9kFWbm-r&L:^iCi0K!`N%W-nEys`[z!bPyLqc*03b[MJ}n3K"jXPGn5cgf@m]]C=mS+Tfde;=^,=W3J9u(m__gil1EWU+qE,r]L$h
PJNs`^p<odv]hL:/*)RH?eLgWY^Rc0N]z"/3`5OOX*K!PTq;ggK+>]il*>EQGG`"?[gUOu0J_[*kn>!F{V)n[[CI~clbNn>g<`zwyAO
F-;I-x(cVK0iaOo9"/O7")XZHw$iR7qa/<wEi+3Y^+IVAVHxF^`t77N.C-`V`rF18oiuQ$&-!LY1f++:g!M@[`)H+(VI*DQbDT7Fm_{vr2:kBHSkdE:WPrISEB0Lzdo!3=v)(GTT4P#!0e)1e]q>`+IaNSNk@>#8s<u-M;pY1^W:4]50RefBY9.,kNP7kJcm`L0xSru*)eBJ`gx_>%`;:Wlux[*WKeGv|eavU!)$)mU^ZVG2AS/Xs!z/{T>BK@-@s>*5#xJ8-SFBJWBoZL"G/ph*G1<`8O#cjGpE)Ta:c`mcn5:$V+_H3A5-4bZt#D9H"6V%0:/Ycd"Zy?4/tri<%`d<#na(A2SsrJq@qmD3|gCUt<jm}O6l^oMrYZr4=^y=nT`BZ1Q2MD|B:r|Hmg{PC411ODm"v>ub"
iEm=t6;Z_NR(e69Lc
.PBA9`%&*Qr=tv&:76ij+Z[!2"^tg^
ejLMYl&fx</O&JJ4TTf(Zyy99#Ve1vt{,R)1Bg7B4g^v-yt~AJ9_--_]4"xP>M%ph$Jfb:-+q?,W![Q.u-Doas"osao6tgr<5<V".s!ZX^IqD)UxF(+q#Gul)]2%5
0)`Na31L3LM%EmH;(E.M?&HivRvRY+rqJ@1Jz&vReA)1JH)CFr]0&p<Q)d0?]|*H;:^_[5>!wgO.<LDj3kv
=Dt0w1,i#$dMIjeXL}8nX
?uU/f*!T":jG%lIu?Ck+ycy7$n&RHR-/R<EW1+A<A}T++_nFT*H*&CV@Ycr5W/0z"S[40,fR#7g/$SU6#mkQD)79)W1G:zEK0M/{^n<-*TYoqN#Fd`UBE+>{l8aR$7_0[Y/G3C601H/3^jGv`_F8*m.~0^nq@>F_&$J%;q
1TH);W|2DaV[hSAQ<0H1Y[6jO(4E2PO6MkF._%@a$&V#z^Q%EjK0fSr/^p*6dG$,F`RSfuc[mFw&5<H0GTeaiT8!$COlw(x
VZz&J5zl#q5cfWC
kWf]f*y<;*GdN:2,aBqm#5QjVggBHOt
hs_C]03n8Fu/Lyu*
2|p
JUr+!)Nr=xu6Fw(=#mhBVK$+"+qlyo?3@As^^J1$(51wWZ2{<(bmk29-T<8jh~-S+9Y3__nQEbNXRl[62cu:TkuYB5q)cyJ)2!swjn=EDMicK
dl"_bkU8w03k
i@1#Xp?DCYBMkE<+*$I
1oKZ_c"/I_2@*aP?%gg1SXA7UHkXF7YU|^75y0)qPi7n[LB,q&GeiCT(kpcrwtCl>[($xSZYlF8S[A?rKB/90Ze341E;gj40ZC(S}D[8X"X"rG[-zPHv6iWN65p4QIEaw8:#-#<t[q#)D1IxTd#eV17e#C7$4=a:<^PU^:lajT`j8d#>RC;y*-_.*srA3?:aT!(pZ#+wkEoTQZRF{>+Y_[54ZP?8Ot6bE,l_pM;Q5.S_{6NV>in->[io4c4J!:}XB[E>R)M^:=tm1GG6.q</hr*6ZTGifom-kPvA}]J!PfX>W!amT>kH2LzvuOv-edUV-M<SNvF2?v|N%t:<ceb!Dw{RjKO+G4JHnhr2GU1+e^UDluMP.1Prwqg%Hl)3Os#rhTi`w4)h<Rr4F%,*&"}6dX/*YHdEc2NPMSTb19YV-<Do%vE=K9X-)WjHjmd;?0O,]as]TED,s.~i5Ij?]JA#wB9kUd]5YqN(Tr%&p-cNZ&F<fL:cYW=gc3oTu4HQ%<]p[4g*tTeEEh:n!ORA<g1?n/E@q="bQP,PP?X/1>025^wr(Rnk5#<D|^I"w`ap1>$0(@":8BZJMk0e=U{MxThXe:6K[^tU<jTJDPTJ]1AM>=y,LO:+pA1gI,LKj$*f0rx=@-^SmA"As<6
(.gkLJC-@n(m
#6S+];v+@4fU[9iP1uxD@pT/&B;fTMk6?*e@gL70<InC,G;YJsW0K/SLV&n%w,95M}T[.t;4B#6_rTh(M;3I(KdJ,^@`$DjB=!CaT<R@HvGip<6pj2fz(j]^6u]_!8Dp[wt(gw#-t<KdOzsZbC@Mt6P}mz-c_y1
"|!3P*YcY>R@`mNL
W0)k:rI_GgaoflY7k<`vo_?qnV5K,gNvE>InR`kad(VM</dPHt`ugiOD]w/^`QYBT-]nt=$yv`C:ca9
8>(Ls"FHOd-<Qyo*0W.??B/k|*EiGk?.;v?EF-ap}+7o^@B/})6M%FfT69?Ciqz4j&*AU0d
1h?r%L^?_oC8D4BUD/!C
06_TLk590RXD69M^h-yFGne"ULl8U%ApKp]!&cam96E6Gmg]m_#.[Hp231>w7_+Vg<4IPsdK*yVoMhmm@q3g.~&db^+v:c0}d$J*ivky_-"_Wga)Gul;G2;%""[MnWV|b&S3_o@2Agfen^y$/Th^*?bEVGD;G.;x]_YxX&H0*X>TGSG2<u[xl?1}NRnUJ*%jTpdX<Yj_o*
:x8@jvULo]Yp5I]>kH>`cu><jDh!1ug7f;-yn9oe$P$/@GQ[~wb`nn5dRT3[;Z5WoaqLwcEyG""';break;case"ar":$f='.R]7.aLp=C"b@Cy$i"C4A;CrF_N:uPRAe&i()H8Us
TMxacO%VYRGm._"@;J0QFie9{$RTL#ymvDxS;=EGp>jhMnA4/ZWOJBM3kE8XkIJcD3LFYozV43Xl)
#ZecnOeg_EBM(>]$NHcEBMdKZ>~S?:9E[q9J:(ZBk2y_``nW
7/q,W4_%@8?UfVhS!w1VIxkdK
/IJEos^Gg|n}szHCnttGd!ScCso<O3kfUYfm_L
L5}Qr^v_7QSrcH(K.aRu:</f*IwF"V3Ga(:m,HGyA8+Vqc?H3oG/p
Y=G+p$>*9#6-]ClYpf`B{OE<:M&e<sTw-88RpeDX>iCx>=D:ntyy,pnyI7ZUD]pFr!j;HT/y9n0YS>X)psoV/(XjHXK=Pr!1wKW,9+s?ZuCla;57%T~k+iSm|lc?qKuEc&ALZlOV~9~lP[Ll`y,/`)(sl#Y,0jPLcV&6>2$9q.!?;#-MMSr][Pf$4.ORi>g6j(O7HQk&"D3l.n()uTDl%2-${dGgyKXB/hD,v$pyjM!,2=BM=+ujy

oRo0B<rNb^:yA{CEW"2$Fy>Qx)L0k,!9<8?`L2ohPk0<aS9RB0FUexF-YnjBJWr6Rp#SEN.d#0]"vY=?yiAeT#_4!FZsA?wmOTcHGdo;Vy3E6V<0i!FfI0!j8VC7
(=gG$O~csWUp*>6N}Sx(cX4M[-~n;`_v?Z9LEr}?QP3v2XYQs7{yQ8VsAE0gw?Hmz.y>D[lKqj^TFbykxATx6
Lc2O[4%4:`OEW`SJGeyxMNxj;y0PVLA.D*iUrXrdk0YpGncG)o3T1u}$&f2lR-YK_>sDl(xE/E2jvjoS*&b-<.CK
M@KGHZ;o_#H`.^n"u/oDD4Eu$h23.KvkT4L7bpF?[(Y+s52T#3]*63aRa|UmrWX[VOdwSyWWyZ7N/&"5*B-N!#/*Xu+@c[/Rcq>@M::+4%5IbiKIN3I/_^*;*7)Lm1:e()L_$8p6dy,Fe8`JQz2.J:@/Zf>l:7clVD5C1u9Z7wuSGZ5[o|4]*Eecnzku6jDLki7J*Py:#p&k05m`.nB+7E7RW}k/MFpl^ub.WrpO?,a?Qk<Kjpon3H+>p9;N>5C~TyNR9]AU4aol,DE?TAaI.Fz(QsGn*}T`yA+}t.w):;<E",-v)
U|fkXQ-+0&^6x|&-l7Yg>Y#L&I6Y&C_JkEr80EsY"m&knN?R>iKlKbm?<%`^=il5NIbJ6OUq?hM9DMGdoInH
6ihnVEzm5$pkanT_FkIyJW;S]&EfC"ck+CXfss]Q$`4B`:,>ZZgS$/v0aVf
*LVbc!$uJTR*H$rcsm}_8$I_DHFf{,Z0a!WICIDS?HS992O(Twbs2_^fBPQ(8)E-v^?eK24gFO7f_rda8.c[8Aw#Hkyt.Q`G3eb?g`
Jm>J/DLY2B%E
.#U"NdjoAOkdOk5y,A{u0$$LDSe`H
@(oT<2TBfpMF#17t"VsrLX()I,c0m:6;(
`-!V#(zM2`ZU`](GThVD&ObpNV/67T+vU(CssgKPCl^rW;Rv:XNlAI72)peR<`x4H#a:_8Nwrhf9OeT
Y?90Rb7duJq%Z>"2*g.^`mY5/O^.]_{vO&V!K58PsG+?n"#y;,Na,qIg|m1b}%!Q)hD_.*S?Np8]f0tMV0{2Qi.PhcY^/DI,=d`E=.L)]%sH]*&2vKxDo)$jV/>gZN/jAnm,@b"gDSmd^1u04Q)h%9b(&I?:^G|0+*af_QG6sllJl6nnsh*
d)1[8uBrm?I#:r
+CmOZ:C?g~#k6eYuV.+DPAg_VO9=hziNmFI@U,DMcC4BNkrH0&NBo{!=>Kv6jR-[thj2g_7
$rj-"dFW,hHhZZE$6)n//4X)Iou8j[Nr>y7L-Mu}+,hvH>!G:$dp]lsDMNPW*`)gW_WH2ecL4>2jsMIgCz^O"IWe=M+*
9T
n(wJ_xV7uta-GX_{XJO=u8dZ:tA-g?dO=w9?E(lUWy$O.^S0M4`iI#=El:SICLKjM"[n3$Q|N
mnv#_>3;x)3+Ij
h
S!v"^y16!nKJ;6NftD%165=L&P8&]K-1~gP,$kW2UxC[4lR86JH/r2un.Q3uBJ2`sT]WW,c#XhV
EsM):gD91fbd"K=F)F3r$WV8;"JW;+7=:Pq8,H?<&
H!qCY#s/D&@jkG|b3V^#r#*kbbh$rPaOmim=T,@o-KL#YF0j,H[xEp%"pAPfDN)u
"c>K_?-s_3_^U+p(?2?yPBw$M-rkFqHwh,NS@N^QZFBX/X,9d>XL]NfUBGR~!g*l".cDp>Q9BQvL:Fd.A4h?*EpY]oe;,L#g:zykX[2u:j%&V$bn[zT?ERj@A7!BAQ;AL)[5Dg8;g>@e2n0%49KbGsl2i|_C=TC#`DDwYbo)UFj}3qdwXn=K8k5lF~qEo~n-Q1he/Vu^i&i>o#*q!a`{(s"QRvH4LNQg&&bg
q5;>FF-rEy+q{[3RMc_Co!gm<HGt<&Nj:;BnLu?i{UNs,*.hs!c!A.2<yN|D>B
]An^aodVW?jU1FJW)TnqIHI8$7e0:?6z:lyq
Fb$B1efgS"K(vw<`r4?4}Tfr8S(DP:e^@8>n1[YAy#AZIwET^H4i/E1O/%A
*hi)G#4yy.t@vM14$WSVZm-@LRphhA|1eCjXSe)FnY{gWr<^`6S
*-]@+DK&yG%m[/Sn;<7R;V&@eZi5gU>9]U]&bx90bu[P1nL(bs}0Hyq=_j1y/v|8srvc"!1T![1i<j2bYYibQ
WLz&m5-8Pg=vpvLMC,DPcEVjjhOU~4{]^PH##[i;+XOqZ[hv`@8xquT9Kc(sIj"]<;*,frD&jZNG0HvP}p.qse1@7Dt)cgZXeVq6WHLA*Op`2xK]o"4xx=a&X:~E7jh$=[x!S_P&,siJ_lXwm6pj4V?jR#P*R5,6cwd1h^b>1D7WJ?H9)ovSyS_p0])g)nOB.0YRXU/7g5Gw_+i]qQ+hEA:m[h&<Z+K@Y[eQ3Ww<AC%r)4^;t9&,ED`jSYruZU&0:Udc`T4[5IW>8F=ed@:bMuXt*/@a}3>QQwXdx/.n)X(DlR?JeuB>c1Wr7gqJ"%d1{)#

2:y10G@DI>[u%}buL%NmK?KoYKWSLVPp;sVjlYIN5KQar+.A6RMd]~?taeEQAsX"#dU$1wF+0VuJhg)EBdRKYaRZZDdi!g.GK_.k2A(WTE5WT{9lGg7>2/^_o=6UT3AOQI+Q?qH<j8POX"xj+jR*[cVT<ebU:"tTaPBtGSkvvJ`+qOnHn%HREB>b5qc|iaL=!rvAMvq+YUwfb}tCo.l:=h>|.[YQGu/9BT[;D:asGnX{>iBQhbT=?7uKlI98BW1&g04~<@eqOno"1FL)vi8q6bnqwgHp
/DkcNyV*:M0xfM}+mTSW,]afd#$%TMA#QD6?$rNTgi8yUiiEQa":f%7GwaX1+lc?~eC]k]._eR/iDSSoAi}C`%.8.cOLzR
XgIN2fpB52q5HW<ZIVl#.7w6j?He>sw7d`/"[_;m@BDN;zN9A~@$w>RoM]ski-MB?v5?l_2jUYrnVGrsx-6<Oa(o%XPbT}^.D!Hy_bE=G=H_F"w62VnZCqf5B1,c8|SdQjT:6m?lz$J)^%iVN&';break;case"bg":$f='-ev;:bpD9(pk|_#""oIR8@`h|LfH`ZZ"h&u.h-
Op-c9URE)*"ttYh"2.W.Q_m$q{(E9]FH<uezE9w!R"K;f-3s>+:e]*J8t+3lKeU&`/UAb9@*M2

v-o$9>(r?0po=HY*>O2ON%4|YlWnh`$4
kWSmfY|/ETXMVV]e2,jYf^,rpK)BL^S%h6Clg.cMn]?O_RkD/w&hy/%Z-@~
I0-J#-gV^3,!&j`C
x;pfA^g1M-ovCzQv4LW_7EGj!A;B8<`B*!
(z&HlyDyC>qw;_gtPL*uq?<+;3TTMV`0q/o9):`1cffhQ
d%`Zt2?"`/7b&"ZEQ2x=5^_b^27K6N/7uBPW_:*8hun[H?9V.Zxx
Ik5cEIbr>0@X,P*2U!$.9Hh1L)n@YL]y>H4ll~Ugg"q)voVC>O1h4*k>u$qi[1/1u{KJNf#"OFi>SpioHYR{4DHDB
FF4)(f&[;9#zP~`Cv+Q47DFzwrr_<1))g+^}n36I"_]?[iQfRF"IiK/"0%0.n?-$r34Q.-_[e;l@l<g9M|9NGbxG!+^*h6nNnURb;=1SsGj;ag
#1@1w#8Rn4cjOn3SnD:D^LGSb)mZ@o?Z]jfMl.m>SnxqU-;FXEcl[d/IQm[+Ond[W^R^TN,={hHi-X*V$(3ZEga]D]~<#x)wCML*(:LG@Q#^%
8wF@c"w)pLBwqBY,vHh)~!0&-Z1Mrw"n_n%sTh[tGMo,C8"H{E
mbc{z(4wIW2_MiO1gv+F;&Lv2<>Pkam[]KP0wKye]O<wxSF,`/2`uENxEic=ZFeAw/xiX8Wx4qGwHQlSnmbEw9<#Ma6ea6ANHAbXyFo$I>K:M3N$b8a-n@a9MBMro$O0s1g,yR$Ohe%spK),D:/u([MAsbX/:Z[.XXcx#!8{nZ*/OihG"dMhRH<H*RNohs:v?lOL4>dX:G>"K!<p*I2n4<Mh@VfvAl$UUtB[=Ic2+i62:-iB&kEGhqPP=~KAFJDTDw$#xE7FVhZH8Mh{$iw`-;ZC0t7W4cL<$e"7YVVnj0+VU<`1d8,.CCFc"jQQ19uC_;$
LIn?g0<V>-01L@r!+r.yO[<m-Z)!
$uEp0a%phak1E0#009E?[qXo~)"b.L<wHv,MZTIqA.8jEo~`?:uNHqJTR=$Y&fktD<B*VOSL9gjL~#x6,2jum0^%SOlRG.i[&;5;xm)f#a0QJ*LvXLW/Ng<-Z_#.5<0HZlxYp%SGvO=5]d:O/jTm3_9f780vqVgvz3!K>Z4OHa077)wI65m;,jGF(y*"cpmDy/Q86Nft=$oX"4=PaP%*Ke[;zKveR$0l4]/_?`hvg0>%Vg
6:q9=|c$P{%KB(j^a-],kG#0icVItxrZ:;=ZZ;oY2eWv!YKk3VqV#}h<SmJJjJvf"W
Y#wap<a(4#Ec8DsWkB3&#Bf/aGShs2~_1hoS;`CS<(H$4PpY5"/z%x~EDChAC>WGw:M&vd<;=-wn&f?SYa24bPDE`S#y0u6&%?l[IUaqDE)1USdTlrK_pv}iS0+sr]fJy>aK=$J><!<0[>yk"!qU)>OpWyM"<PpQR&T,<4(C*3laSqXGY>,Qk8Xp^)
/q)qmM>jc;ayfkx`7<LOZ<(%Y~#u)D*h7HAlN!^KJ[?G=5*j*n3b]&.P#$1a$"5upm"3;_
CArr-:v(|]sb%xiki1Nk&BfJ)%*&E9j]Wp]&T$)r]0QsbtR]|s@ou"=
SRN60VdL~O@fd(43uq
N~31wA-Lq01
o$l{VFAjc;L+x;NJr4A4UsboL|6HD29q2eq_6}UDi*NfwpZxLW=ep`uLG:6g48h`>lq)Xn/qi}El<9@?]n&<y`k.-UN(BZku2j=6VV-fwby[VDy6g[
hX5KLYL1AR^m&rkBUR*F7S#Y$:yBI_"kVw-:M]
!a;71;Zt>N(V#-)7=gSYE03<q9!LsNym#)EiT"%]`E02[R%{!5Hyr%1CeAes1P@{y!>MPI3F+pv0U,;Pfu`j?%dE@#=X?sG]RG,`OiW~;PrfY*_zuW%IO4@y_Co)=$A@m]l)
;OMWBf7:?0tO"$f+5O.QM+.dw;/kk#)i?W<;T*<RUo:Q!G-`9@^xmqb,alcS;]:(n/c({o
p1B,.:[Xnemdm9yJanfG&No<[y,Ns>?"3$Nw0eO0I)ZSIk@Xe5UMS~j}(mW/a+
W54i
gNIr"b(Cn+#Wc@Nm>Pl3kPW.*,/&`O9DV{P;*>C90M)BSh+WiuG%$5^B&(6bgr9.V]ge0L_>4{w/E0,i#`(ZB3qJvHi,<4(W#fnGJ[F"3^4JN3r:T^,yVJARNbM"g|;c6,:TIj"HB$Ixo9P">22&^Y.~1!a
hXKuB"]|`7I|p8S$4(55BP]W6m8RE95YQ2"jq?TM0[3x)j>V^s>]pv/&/ZVeon6
-g*_>u%G%cQCb`l^tvrsv5T>!J+jch7WN$pF1mmFsJ&vLBTRp|N[K*RSl:PTSa_F$/VWXOn{Gw[Zd)*{O"V1X2<J8$:[%DY@Z`Af!n`<+"U:=0e!/O
TYL[.wj?<SC.<u}oXN`fSWYpZ(|PX!;Yh29`ffy=nX+>`IWgzbfU=)j.S=dDDH<WE$Af)`@639rlQBgM{p-cQ1vwWYLS2K![b,hbV3[h_kSQt5P!z$+?+nxT(%60>D@s8]f[s&e?(hP3Xnoh-u@=>-%2:lnVsm34_>`ZAJk5dwRZ=-VV,mv5q?g%FbIp^T^taI{d~%pL/kgQ4OK,g
/0n3l%p00A7Lk8Z:^y$C1M57LVqWrGSGE-NX&:]UCG>(RjjA$rtWE4|KaY>vqXA
5d);xLpGHH(q>&kt
0JE#m$Rg2
4t)q](n{P7.%XVgm/>Q>A30:InDK^&Z5g9L,&UY>&L2k$Phg1OsFZW?gqr:vm(;3mNZ)p?C[PR#h0YcsIp1v@:>,_$ig(m4@Pn0M[3fICt<4o6))q6SQ`XF1eOa$X]IbbK
U9RQd@9/ON"&`==P_hjj(:tp1w!_BXkIxjWqZ10[X#ry6QMt0#?3L,u!ar&[^JfcGj=_+LjHOmOjfq2,Jqt_yYj?oag1npzt"TTEIJOU:-]
x;8
<%>:oh/0@n;iyho57IDK?p0:Jj]V(XDSH!1Uh#T22>BVD:85#2oP=6JcW()O6>&S
#|J{dk=AJ58=@bDNxJcJTo2IZ{teuXf+H-;*pBm.tKvY8jLar<n
$7H{=Cc9?vrTvuINi]iIcym@h0^e21IU,69&"At#oRgCmyRr@0f}2s@waCoa-mF22b62<Uj`f
PK3bgk_}pCOW?Q1O4Lw!*5f_u<=!=YcNB_dKkz6IDVB3j.vPp91Sv0nvQ,Dz5-eTYV2L7;amqLS#P$#oaeIzM=5oEk>ZP^+O.t0GJ-=*^.tJ+T&}XQ@Aq%]^6=v{<o?B>cZ(_Fo._P^*t1d9F%`2m!=1^]4=l>*WArUWs(WgcBoT?YVyv4^<Bo@n_QNU3(@Z`t,^/^(:Bw?st:O?lZv4_1AXdtyMGTf3_jPNTRpT-B5ADiUK50yr(T2B?]e#9`i3R}1ojc_A,7--Y?W]Hc7Ph/j~=y>acn+o;m`Cwr0kg
9"!Gh~x.#ryk+UiRw1yexb/6Ne$$f~@iAPvvn7T1cA:06)iX?LUs%)7qV6!UceyN:V?$^]0>floB4ouWqtcl=B1BcIb4quI8P:X-)SL<2<Tf]M]0Lh]X2,&]7^pud#=uIP:n^H6PWEI`lE)J6rsKa;3dsRe2:gR)?>Ieu=b:SzJX1r5/:ilW.aYTC:K?:0By$nYsZGhVk%)|hSJQ/D!!/<g,a&hSt%7!]_rr1d(c2`!UcJHF(hgCZ:J"oGfhH]K;@HdNF
P@*p483OF)[_*BG&I4b/%Yasank38_U(esuHdfe;S303KOJuG}usp"-,n37SxfN{<h(BW(vV9a!1?fK>EW0Om(uFd(';break;case"bn":$f=',ZuF;bop](po(o}2S"YHu^da_VVb-e[+#&.Su<Mjp"AU=PDBs>6eq_Bhn:uV@-8+`8I6"/uQIE72t[}8BEl8G(SVauF[B@*]Br55sd+q(eY^+v[nDt#2AeDw79~;I?Ak|Zx.d4kVfnE<l<7mx/As
I
l+`nKoE^7@q</Z6!bXV76O
/Ee4ia~Pi>i=%gFdB28_>xg3yXESXgZ..aXYdTM!K
{-B$tcVQKqxI5)3^+hEG.]/OmKa3)R>+=,L028.U9e=SKT<rB4FTIe9Dp]DE=/RT<VelyY%T
VBgnZc.o7WF@:/ihQ[/@aB+hwK>?fn*6YSrIO:>($*gSl=#i)
!l_WRC#9S.^F_HW
vvF[vrF{8%uT.T#Ld.#
MOA1EVc|@dpQ^~K?W+96E3=N3h%VES9K2b:3<Y0af1m+@06Na!g0p<C1jP>-5^a
(BIO03w3=I0r#ab;O@I>E.Op:o/r=xKj07imi}L@5Osr>Rox:weGgg
$i+[u2gAq)Y$/vn#y;SNrBA"-A4sU$CaBIo)_cgu}.g5{MwKql,gHU<]k$Ge<Lj-*A
JsOu9/gYUU$NqiP5"SD$O=#zdA[(mBA1.^,u#3,WNq#tg-e/1x0dENw<?rY;#i%)g;R/Mp.}?`!eMS<l!U.RWs8GUN^f&xn|ot;y*eu3RV,IOZ.n4E*&<5ML<@>HM0F>Hg:F=#!sN>QtaWt`Q_O=mXvf(5fQ=h*$%_Y1Ez(YQPYon>AJ[>VWC1<-9)4-7LUBc@LSuZKYKLB_krneg$_RugHCXpBe@$!=+o3}X$3a1KKBZ;4+fxhA9BR".?eN/!<BaIUXTYoErmiFw(jxb]1O`7h=yHJ;eF.Wk@
zg"$")eUnAQs3ad1-lMHKl+o"LWK(vvI-43a<pE^g#uys`;l39{5&hplmw@D|`bn@`vSI*k4@(saT@o,{1uqCJjN_P`6R6BuvGg&n^wU
t8aBnzp=2)2q"ES8YOV|uQ5C7_FbC@NXB*-?=t=~NA_VE37lFtL&QZeRA:><BGZ#w2[rjSU(bBm<>0i]hR<$<73x7@E/D09yht:PeM6ptd!3=#9VBEt]I4pAW/*R_b@?p<C,62S6uLRIn*bcsQokU6;,S4Y?6Bq8!)#}6=Dk)BEngoiB*Na=]VN/BaeCgwe^ME+8whE"TGU^4VOp3f<I.fqBYXSZ6}ASYAUuuvy~V]3{pe@vhx"4VY8z&wjf0O9sUcT!rj[4s4g9+ld|BnUoXbGKC@d#f(cPI8,!wH;%E[_=JddKb-PMCwT/fi]aIWm7up"0<7d8$YYI7ChD7}hcgI(~kK73<3%M&#cE9+*^LA?jX6R{e!th!X0Pcc6hdn@~_sHx]9aTZMvOQY%M
,jj*9)}%{_q+6Av_8pKTW`8+>-|>{3}a0!I
;9k?"L*bSek)t135]]ufB6~XfkJwjaNPS;ff8N40L)>gT!KLaGUsf@t0M-2>xW/SxW>#bJ-W3^,`Oo7e241UgPr2A2},D%|ED%4t}xG%.uoC31~F:6=_*r7^gifCqo3h>NBU-^1$^T6-4eX]!cc`juiH1sHX#,^.+,Wc;M89.#+H`FYA|F.s}_(gIl9H4/=u^4=[nHyA^I,Yp1gTZ9^rR0E%hvrX=[Vi=m>(~?):y01?^APUT^q5C`7^cLVP4L?ntG!u@!r[lb=<Vn&%9!O5|w=Q&RO`=[KSKq.?f,LVM**7PS[mDi(K456c6f"V?
[i88X1Tep3MN~s/
<IhI0cA:J5xY^,QFq!(2WbLa0.Uaw,Grg-;&UtCnajegGG-ylq$2XIh4!Xv`Ze(_=n0%N7O-er#oV7O,f]0[$E"A&sFlhRYrTSQ#V%V*EM+i:PL>G[}668(Ix]z>A+),p9rWm8}y~/(/@
$o|<djf?xSR>[Oa=*Z+$g-hkr0JM$F*HT_]F@c}=OxsXc7Y/TbnXUA#%CW^wV5O-=-br%>5Y22yN<?Fnb4u8j*{c]
#55(}t*D:L6[9d&*<vmrQ
zndS/Qa!W+_j~8A&~=L$:pe4)B,=8a;Sh3U"z;/TCNy
59o9|n*vveSfpFq$~y/,PZ}aPhy/)Gf6N3-A<>1UttStV9$_8$L3V[xX=MO)S
}vGQoA08tNA3|?0%v*16C>Eoa/fegcT&F3!kkv)_*!0"T`8JN[5</!(K`KqV},!"D]b[JrtJdO
b-.R6a02i07?(Qpp56N6>dEWY%f<Z0<wD>(,J]1g"4?"!9(aep,*BVo|P:0z?C
$mWMPnq202P3MP99)CypwN^TxvsdJrplII?(}
1oC8EaIIi%I<>rjo6Rwn)GN&oaM;A+C+%=jMH:XhVES!2%G]i+/,lo(BLwg6BBU68a/;2r==Z0[B5(++2rD?vBV))x6
e28pVZeM)NSNSH@1nDL8hCzF7<%e*%X<>$ETN!WJ_aMF>]{nDo[@q_Ze3QOWK[Yn9/3<o7;HILh81O8R~Umt9v%Al!R:VBsj|!
pdo:Ybk7NnlMlb^])d&,fKp/b~35V3o0(}@K0m:
ZPM4m.SdeUZbWN
"d</+-Mbl_&#8s(m~WBwtgmY+&+TvfLe)p)6=6-WFZ0a6H@;<y{5%6.t(Z;yH&N+Qf!m?V>uSCThl(>3Nat;q>+6]9nl
t
rph|UZrJ)}p)*skc-U)<B.&
CFoEN
.v@aXAwT2.`U`#1;bf]~P?BN/XSe$9^0oK1L%^EShc1_QS_mB%Z%qv(ue(2=+?DMA@HeAK,M]K*@@;US?u<$huuv,}X_5
Un@q`)E1bDt1/F537h8rTqCTo9RmM=1/h2n9G5_4*h1g*)xV1-<z

Az>Q_vjV7D?PP8f2P<4ve?<54s4|U;GGqN*w;Oso4Nj+=jkZv":Mk4%Q`pMD&$iYBLZ=N
=[n(AA+g/4@(g1f(
9m+j)O^k%CSZ!RAZ$Qt[Lnq;a]/KRf>g9Gt4lsUA,+YZ+WtBSbeR{Td=ss11dOdWo]Mi3(OxD:Rw/Hh&3SE<
D{T5B4d|LST=Nl]DbOy@@)n!`MS}qB+Bho+a2m0W@[S#uhF{#l9%mc@|e.
EUh*lAVN/]6B:jC/k
+?$>Cnw^U$uXC@2rv[Y!dIAbQLdY32:vD/|nA$g)GFD.Wjn_#$!6/!NcRyXIbkC>~%ggpPt)Br9$z[JA;jTdAbR"_4h!>VMZ-3&)D&9t_72J:KI1ZQLH1t"u`(=F+Om1/I2!.Dn6s#*M)L>(eTIey,].!+2Et,yE2S76ol7k?Eu^PX0s>lsgfm)B,,O9kfn*ur?xJVL
}]`NVa"tVW@UplGp6wfPnZG.la%#>@y05obZ/$
y?g!4E",Q$R~iL`t[ztfbsod[#C;P3/:I0V[Rq+"pf*y;^
$t)vVb6MtRXFb!},PljOHk)
J((K(EB&N@RJC4E,Cff<A2y=ClsIM/l*C?NF^f0/3q!DsSuEE
m%bTidd]8J^hM%t<IC_
@`;[Jp`*eP+9-QZ/0&C6uun(JSj8^IX.hpmJKYhD$N>n&?NI-a%[(TI)28<r8%OUD0t4,j2ftH"]ex)8Ebjkrb9FuJ"J!UL${wZf3$$]cx/lBbLMIn]5jik#;]T1iRMvYL$N=h_w?"fKeDNN#Z!(I(lQTbeC{g{)Cr@gf78,FH~t:A9%_uj4sn{3K;%sR0+j{$OwyI%Y"c})2PL2Y6|sYTY=7+Tt>#~gJATUK6,[gwSl%WUKPF^
jF(R/CC,FT1O%?[tK^):0.!<a`Lm|Q1CxV._32!9~Mg-q?8
3*x283!K#4
GWqbANuN-Bt..9(#aIc{7DNdVmHdJi?}HNN~qe?Gb.rUSaY+QlrOoIsRbS96$b>{9C)C"N+RS1OB;}9Skynq/nO#&5@""VY(ds
AoF2H=T9?PY#-<SFx8"MFdvfH[uZ=4{yulsv>C&n
(7+hlY@Zs
Id%z!{spY&72HRt-P<#>r4@}935CHyJ}NIVH->[eTh[2`VSz
V_5
|qbY2fvCagp?6IQ,
1|0SjTPhqyK>Volp2zIAGt3byCs#j@#5Y.ygC%';break;case"bs":$f='"Zu*gaMmt)R)ni_d82bK_`.;FU4*
8BB4GIpG[P1$KS$~Dn[A4WEomOEBEKyw%dMi!E9FepM-wy9}<,F**M()jWxf]`fU%bI^nqalA5)J/t.TB/_LZ|;(S:m[m7lITm=;kZ
.;it7AK?>$vh_;htS<,+7s8)VM487fX/l:~GNQ|ELIm.Gw`ZIx`H-xaz"Ipz(9~U`69O7`2A-w/e)D:4Jj0,2?PL]In:)QAY]Wl!/wx(@r-?TvTpJ?qcJG!YM<D%Xa))7;0`>InJ/#q.uK#`UQiG>;bP;faVha&aX5e[JR*p:`X^0uM^2Tlw,5*`=Id%Lml1DQ5m
w9XuME+GFC,6Z5r5a*w#tl@5YCuHe^+)@Z5XtcNiK#x5<6o{rMM1v-*)FbwnYp/M6-RmO,
4a(mZK5BZo9`)9wc*d])}tUf3kegnvrYe([xQ0wlhgGrM."pX`+6(8/l`k,^B*c7h+d0{dt@6*!nn+JGuadAL5IC?1K_5<M[f<L?/gi(*F._1gS]>`J@1h%,_D,
:o"r{]PM{`6nUW*FcrA>
t.gZSHmW)m`3T]D@l3lRq@NL,+;@l{haR`@isPcIyFSgvu<y4*yH`v9J
0MgBiMWvIpJw8n0Eepj7H&qP]WjW-b?`"gTPG?t!Kmy,GxQb0LO/v-Yl:m8j<o`up;6fP$XcnJ8>;F`dJ9N0jJ1X2s-t}Q$4YZwU2g]!a@Z1Xor`dSM/YlxlG841syXe9>$^EZiP/u[`A1nX9N-2&$iFz[Vh%<Ny`fO]pvYr4!|xvAhW&UwN>aKrc8qc*1w-*E((^]#5CH3opAA9#rkKf_`T4b%)BAK)S%tq*eToCrnT?,^r%m1p<.>NltkM(U$yl:W,*V_f>p|:_d#f89-EO/VL!&(jR@erD$wb~X[/P4IM@aO2)XSbav)+yZ_
=5
ekSwB?u~3m`CK?N1)NemftW
bRD?pCU.@Yq;t!!I/veljSF5p"l:dn&p"^"Dq0jGG(j8PoruhZZV;"rdT4N/TExh.OfRm,*]`Wo?-fz%d<#-*vy
`88xB,IS-.G^5SozP}6ZeRp<@=Q=R2D(=TOC7;+G+u#WT{hw#IGf`bu-MG2j99Bq74b}kjIumQAb@?L((>$n5K1HKW
])O4^JhSzLwm#5{;]&C!l4W0{Gy0ZF[C]L~uTthWhMn`]*?F}?:0"C:GMUhRx8R[gOWb.s>U}XUV~rASPlj]]STNRAIN)j8>ahtgH>"A_(XmjY@"i0j+nyL3D<xN`f5Fzhw,:FTD"X$/%W[?fPMb3"UnP"]YopQ7
$vB`_
&xJdO2RUP^V!4o)FLd4
${qxA>2f".[eS~k6sG9g;pm
JG?n5C^Th#cvZ_#|&ELrCCM7"ciX(4dP-$C5w*yc".(,.Tbc)TRkAwi)H/ZR@G5V&Z;~g"XY+7&0x(c0c!%a-,U;vb2iA2.5UxUk)Fn#_UF,iJw8"m*fi3ajDlCL^j]DX_NLe"Oemsn6@1H@>v/CceOr6+5yBF&VQ*X0BdZe6~4ZF~1MUY1xh|V@7pbJBWe4$vKNOP8O#)@:ut[/E~H)N{9r?;kX7ju[,3p+PmC:5@^XnJ%;U[#WEP>>VMoC8jmS5Kc
iM
]UnM=X^%RwZ11J?>nuqObYBv:xD"%F]&xw~/>hIrTR2[71xB{+kke2/DsH
k<N(];4r8|Ce%|J_:F]duyIVf{oi0(F+GVG`8tZX*YjSWoBySKeW8>
a+ErO$_BZeD>*UU+ka?#,.jhw@?hWVJQq
fS(d=,kQ
`A.o
lA<3P[M"f0>?<j}%Xxh;y7@YzB+T7s5C8l8QL1<1bKmbjafGFFQ4u`0,2c5#n4]&bFa1`NA5;#?dt*~PTa"y}>*Q&iD`q"mQmgC9x6i3q)tsx,`u4w-9j)gk[7f[M3gg~5SrKl3#,3isJfaNfY+:xdihG%%.zC
-?]3P}%y@Nr=c?KD;an{Wky?,`$p`%3<F=XELyIU+@X4n9cFjB?5&>XSJT
@&/u9F1QHb>Bg?2+
4b6e)Ck$4RZ3V__x$*^&8YaKZ?:pO
PpY}cF53RY<PLW:QZbRuRG:!Vwuj.D?ru{-X#GAO^]_6t/F~otyX8aQ&yq7l6pseF4gL/D[-C,J%htf;5+ts&3UX^A"iQG]w/(Fo
nHM8JfwwWE.;sTO#TSe3&ghxIn<EajI0SU[#X@qoe$$a2P{s^fI_Mxk%O@8V!V=OgwdgZP`2@FY.dBsq{[z`Y"CQc9>kvSfRv;j>{ALmr:~Fx6GG)$AU_K-<c[uWcee$+0!3krNk=YO:jvBh:EPP;"s&SZ6VK9`?-UwmO:$I-VVW0rVM=TqRXPrXG!QC<&k]F6HX0&-,:5,Wbt.mX%~&._ACd($n
"?bq+?cKhMaAC)(O:j?mO]e@+;]IapI,^cdtfa#]WA@N^LBxvaL?V$ch<^Hu/YOEy%,AU_#<Kv2]wWa2]=/B`5<cD}LLqs1o7[tf+kLAMl%v7h,<D]y6x}wi!ibF6%r8!2d_F-*CUz4)H6.CF="92l4F&UYcqyG:v":7PQ?|+}A20%ZWCrCyWCDN"%.n5a/!U6gtQi;m/?t0
.FB<wX^MH8$+j
`e;Kr(.6iDg0(o"K0r>(e/D29dp+O46+H5FUw>]Ikf9fQZfgvrQ$YS_)Yg%8E%Ff16tn@[WG{&%xo*{daQZ%k$;-QK2l,/IBIY:d;<z/^[&S"d#PrdNa`5rg?3OD{PA0_.XRfY~[DN6fecX;1.]"]^)C:hu[AL$q6_g,>*A.%Gk/x*<_7M.+QRDdLS]Bw-Eo`fh@-721G${U0+h"fJ)L7!zAOBcJ1I^o)m;HXf{6?#};"sV&H$@v_h0_~1#64_l/L_.wDEkU`.f:opSO3(T-TC.?N#FP5M>&/W;LDFB,8hour24HZ%N^BW&L1TWx$dZx3f*m-A}69a#c4/Mft>vBo>P=YwHb>uq]r1!0Ih,b+?/.~-4x_0/VA-HqNWtfUs}xoi@w9<9XK_U,tr{U;Hv;Sl[d5jC+h;JaNX_JGoz8draL%:u8D${9*@bqaNPc?Gz[aul[|=KP4Qv
Kn@[89"mZ3KYQQ-CW/{<M0CoKwlQp[Jwb9|!&K-3/qAByb{D0GEhPpW7MZlfl0##=%NbUg}.x^"dsH!rE>u9:K](hrpRFC5)e6RXv@$TWN)u:<IHc>w1p=iDx^S`2!}jkS3fc&d
mEU-<Lf.NncNOG-+M3y-KAXU"]NLM-<X<uY+chAGiB8k]6w]Tw00)`MPl)]$OmhY_csD7iv';break;case"ca":$f='"]^*gaMAp?T4oi_d8U!+nA(DZ8KPhElGfG1./Gy_;3v-$?G0zj$Fb_BkhE8xlN%#"WqYlNY;)m<ZYq"Vm@f`Oaf*Z+B.4cJq>Ipx{$^KwBkez+RHKqEm,;Wa:_E=
n/1F/DR^mlR&]`<a/gG8LJDwD}1%b@f|FrRMct2E/jy}dt1_m&,%cKqhY`Xu4!ePtWqDqfz%Q*o(njtP_.YDtM"ZtGU1LiOjuc5jc0i.aTV
vKFiY>Ig.GK~lw
dUJ<
tFZ~"BG)?yk`(f/^[9
y>z],FJ_w;H.gA20
B2ad)KdI1~+ReBTDV%*0%W/UvnI13(Z|JFhh[z(kjDB<?<1qK#()r}to1Y7`"rSMS;Oywh<)Z&kmSPE=]_Qc_eyGRmQLKJ8&M1l"g$F*pbfHg;t_e-u%)Ps"+BOVRsy78QjQB4:O/,#P0z>P$Y.]#ukLT%.]:B;8a1c/5m<$r8bRluDx<+q|B9`j74Vfw_vHhB/&`ZvY8S<zZKInkb1u%8RjeF$VKJoh0Zv](-`n*>E-P!*i?0+6auZxbk6[EuRgyaLoA<KCJmgim_ANJ.+*V*OE+o>%BF_$%"ub$|1AX4,hH+foEiHR5^Fg#Hi0AKioJ]U##t)U"4t{1[v8&Dxdi0s.*3:#/WXOnmw12"x<w`,wtSx#>t60E%kS7;5huRn}koa[6eyT5pf%RT@G!r8GiI12lK_VF:@>E5
7p#irlGob+ca`TD*@c;`5FZdMJKPCJ*Px2-J+#(J3alP4L.0O0ya758-bX`ewro;()]CFIQ<Dq`bgp?
Yk}S|@B>g$B
1T=(m20rVB#3`5PD3r"p+h>wi,j-lvn
Z0+-^$_xAZwDrWB%i5r&*.K.clh;D_(3HGo*vlUQJ
5Cm:ovbb~!]A>8-6v(u]1lJ^*-f_sop)4V8iQo1Qx)$S(r{O9B(o2sFQ`)c=&phADy^^}ypTU7
1?l
=~.f
!e%d#MupHOXBeC{!mxlQ0h-EYDGyZ).ab7(y+`$+dWmH{8
0=5Edd2$d/J6+Sk>H{9)L~#v%I`4$S3vpWwI>?@G<23ufiSyyz*aBh5ZCQ0&qaYh>.eUUL*TZFu`4^9VPz=naBFg*4!yVA@p#Pgx/~]TfS)BUC0d2bx-TC^47x!Q+>YR[w6W%!WNti-7`E$iT?[MyvTxMen`M>%hD8.eQKsphtyS7$`|q;Vgq`pn:HU3+Bb5jQ*L!ts8/Ze?woJHYk4^.]e-8g7K^4a7kA8~/r..<?AsKX<_H5pO(?1^5w)yvh^@&5m,>7Y`Vx+wJ3(MDK*>06]owDE#@il@5VsI,J1@*D<p*p@50i2T5dRfw~*%@Bi/%s9D[t$Veu;nio*k85%2)JL9esXxgEhh!,dMdqHK22e[OXIg#D"0-#2>
7oT:e^VNO3:K3oJJyAh<-fM%!/glp8"pb:@vxPc*[`0(
Bel3-Y?-B8&78vvZELnMf}!aER5a6(]x*+5^J8&6tz_0d3UlE1T"Z-2/fuT$8_AMjhyRU@]"OE;9=p]K@TZtIh!aHQPFDeAjuo4{qm9b(za,CrosekEK$~K~
X<"2l@lP=42]yu"`dQg]]H3
@6"!9!VQV@qdkc#J?P<(GS&8#rY#yQ!Ls&>Z~#ZCOPJ`RWBwSC-#p;*A>cT@6:I@p6dXH]&L<N{Q1^DVe3H&OD|=a(4-&YA&XVo)^5?HGQSa6(B6Jf5j1=*36SYxSo?Pft4TC-L.;iD>b)*r7=M,Od6Gif=*Bat3]Z38,b{?~x{^;rQRK$G[NI%*9*Mv?Z0sCUa(-?q0T[]9R$9#omd8u;l`1"6b
`Ub>"H=X0CMmZ/>C;&A`d2i4ZjC=f|os?mE6T;oz5oCP>x,)V_f=;faO*x%_OT[M&R;-OdXJ+[)OO5e<47&:aSgZaMPk`&vh^vDP0$
BP:kGA$]kjCF^fXM<5M
kk$Oqs=:)%V8P]q=ajQ0tS#UC)5V78j1OA.-]2ue#Hv&-?Y@p!m>~50O;#I+#/JS2=98&0*-.D/JBb|cu&}I*-w(;1C6?NNi$XU>b7BcS&IpfC0eTo[MWT];Tjv^eE/2sc<X
B*).^b?8]U;"_CsF@BN{);D,W?.8Vcd[Yx(4_4lDgj2.ZH>M@037=@f{Kv")5!&^SP$Mmco2C5Vk)gQ,6pnXmvSexId#*dt_So
!,1IdPf;9vKTFq7;dy6xSU}f^X`9tW.(;wA(6r~0KyUfGO7-WBEAgQj/T8525QGPP[D..nUD!fVPr7S.,"f@tO?!%l$SDvK^UbNM+Z<&yWAK)cv`~V"P?m)!&)3RVw]Gw6w8Q!H6|qp%6a]D[Pu`dP<M{^i!3w0Z.D5E8jlmkSnv_Dt!<LH;l2CdNLH=3vjRs(XZPvu)`.=G3Y%NSc;"s9ft<:7wSEUSQ?z<}5LoM]J<"*S-
7ffsH7iX.c+uD,m"r-dT5d_um72Pn`qYk;ClUBH$<jOuV<71Jc[4%tH4-u
C)rSKJ{AIXpW4O.p;8an,-_rH6LR^y%41(
oK;HHfJYh^,:ST4hN%tM45t5^a2p<-b?gI7<<TeUlby{(#rBYB[O!%.X$uJJdq>.+0>.]WD$>6j("s?pH2nv[/.*,6C."C9M.+(ttHD@/_r+MAp^#Alf2s/c<(#ZWV64"ROb)hr$P!4l+8wH]N3XO9b-O1KC/gMgs0@mw%yK9Mfk!yS1`Pf4f6l#wi`T%-2pEvK6(,sy.F9IZ&A)<~bP!1kc(/?$QA32+?7t7`g5bh*@ewH
q(<},)5!au."wpQe(6G&lBa[7gcMsNJnpdF5>]6QEM?!3qHY84v
fw%2l1tbqj!
sk;ZKS_g0XiLT/*(y&,2<|h~U.?_Ims6cvVeyMn%r^E/FuH{$2UJE",HRZsA:y1vCn(+A-MxTI,{a~wIBfscp4I1;tS0jRc?<_j,?4ppNidL*N>K+Q9[hnii<eoIP`2"f3Pl%we5.fWMgy8YA/7
$%Z;!MrTU]"&wF?hQmRSto?.I~:a2JH.XsV$lAX"0d0OMjs(Jg*hL.okrefr53B5tIh=T_ctsuqj
0$kMjg
@-.UgnLO(XW-.^dWp}L1m8.L_b9j^~M;/{*lGb]01.#nnv$fb7YM8IM;L8m~-k-..(=/464")6:kE1/O0z(C=N^,<o@7/:FzFlgJ4um1Vhm#_dsl_~kv+qWo^H(eux.nw#0TL+CNDQ>bx"Oz;v
)t5@z$5!{hDtSj`EtW?rf+Z;ThZ;Omnh]du.WcE=g;{1]]__ge~[1sv>~`ykqG~w?*Ze%LL]yJIR>2<-~8qq1Txk<UJ7w^Z.5r)';break;case"cs":$f='*]^09iEA`(p5*d?06?=Y})<@cUsaEmbheS,b[.+JA)7>wu[P>Hm#JC7.Oc}+Wy`>4hX-?JD,n<|?W=iHSgkt:801VHGC*os-688Mr^-n9(kY|w~p.xZ;OfZ1qFAepKbgiU:
{hYFa4BRm$g(i_VA<EZ2Q3yFXZehsq@aq;70kry4#g?y0,Hy:.$KrhI^(F=B!R5&Lz!yXxavVqnw=V3z)03+>weRL/3
yM{^+H.Jd"rQSv
y9_mmY^pUl;oxLj0X3F9w0/
!*C@
$#N@rt;8yRx4ntLFU]8.^kH6G+S8mDbEyuc[ck9D&GVXQ"QvbNd+[
d)Ng~m^;~*>s""Cl6
ib<R
bT]*,yJ:9r=~GLuhbnVBx}.V58eoAK_YiqXxO0nHJl]D+rr"W|Lel,n8jhglQA^MFn@I5RW&6@CjsJ@Cban>#`TI"HKL/n]I>guSF[@:K}["])@h8w1;_lB`u%WviApY;>Z8@W[3s^y|kgO^]+brIUlwYs>dMUnmn=W*B^oiP^8Ur|2Hz!V=R(
ZrX=Z0BjYb80Zp_0/<&iZhmlY2Pu{2A[,Yc;@eNgj
^Zmjm4g;HMGTn$kP#N)OqC(6ATV4|H]13+8vU.&vc&&UwUfL}+0qthb%~lJT3BZ<Ng*gr(jwgt`c*6}s$v`r~Bldcm]]^l2/+^8U>he50y_04
jvF3pw/y0,Fn}kKK_9E^O>LEfs"yb(UOVoy?AI_a+<H/5JnkI_n
m?fW$kRY!><%a
3TF$+N~CdCOdjhCgO)4Qa>[I0S.Q.%?a:Y&A^sxq2[
062.O;JuO(^h4qqE_1p]oK!hwhW3j<$W`Su[c/#.O!##8L`Ha|
~IJa|x))+)w8bWwU+Iy4Jk@0U#<siaAY3Y{TMNLkv!J-Nc,yA_Q0c3Sc)fRFyVF@TEeeZ[+g)>SX&M"]6L)9_jPAeXJ`IJN:3CVwEp.^I$$$t1$Z6,;f`.UrQhF@L-DY(1Ti#])@REr`{+{;3T>q>/J#c39$-O`
x9NslA>WPm{P[V2_4tvl+3@_#cZ8i&.$P*}%AI<<I`#$*SRNS*#6u2YVF2t9I[uJk9{h|OulOPAe~quUy+W[t8SqUjL(JBO3y:{)lIPTU_VpyQ^K|2kt{4Z!=Yw9QTWqX1J4Cmx]S?SK%&(k1V_l|O9)C"R!#q$$w[q$;t[n3s2+Uc^/X^mAWeF8cpt`AW<a0J*HWJOW]&?iK0>A2<K.l_-bp%H:&2I]A>z<za<o(SgUI0ym`qII91|xMk/@-8NxlN,&w9h*(^^ooSt02&qI,:J+1WB3j=*CVHo
1eSEPR3E|MU&~._hY>~MS"n$4=="].GEu]#&BB!hL`3lJmvTP-5DVFVEW/}pr8QMoyy2a
O.nf~q5K!lC`28|q;QVL?To`tN7)TAhtU*zpIVlv|]U<n3[RlN?Fp.Uuw1ag1jMqqlR:F`$kM3L[u/ddWb;fStMNv=LaS7P!5xkfCi5]b0.L-[e$;;NrV[7-t
DR;5scj(@WEuC?T)[V6<nA.
`<,>Pr_iC0HNLJSf6gr4G4uq?:AnsIF:tFBd3vN2XpXVcb|@a;O)=
;UB!JiQu&5K72Aw*)"(uL()@zW,SH5Taa+iQ}^C+VQrJBZgnF(DSnqlJRSI/[!eQgp.-gB{jRO$dI!lSG"+;[61P,Nxh6AFFp#S+9S/u;^:2M.xT$O>TyVHwA[BI<-j@,oF+Bd?bBI4"$+G/XUqq]XL/<TasV-qUbKdZkUp;GD1?@`8T.X&Hj_ei/iA^kP!?>g4@z6e-AVQ9"?3!q]ZB)v%vQe]>i/l4SP;_]"Jv~_~#HWZS_jm24Zr
%RdM,.R3KUE(4SC`>)-NK>]HG,!FaEAW84
CjW,hK?LUHGr@VA4Ue[ALA
t0"*$GKhL`GVTe%=lG]R]r"::p?>-+u<0x{Z&Np"H@S@)V`12AAh*U&OB8)!beut93oI,U%Ny0J9_9Q/_2ZCE3~291gD:r=7ocYr/(3j=)Oqo7QP<-K!XvdTY7;mf&Q0A:$=13GP}jo+(&E0_woYTEv.a"S_w5$@`_ZyB7"?HpG4li)xW=2^xSQc1lT%
.<o.[(?bXD)N__.fEZV~mh"~g_`Bg,@C/>!+Omf7e{Z{,#`O_Yk95g?i+T(7[z;RR:fi$7!jKC^N5f@#ko@2?7Z)B/Ctta5;xv+j7e.pK[%03Drg=Jm?MVBTX-XCqRm$j8(5])"<TDTXRmO_detfF8bbXP+ph.3sLKP]&bfGM
0
kC0h,)WOfo2Jd~"7AzUlf."!v*<;iLZII|nlPzXzTsu~m?Ctk~SfB6]s1X;yc91#]OxM(^J`nL3,;)Q"#tdG"W:)S_k=ZS2DBGg;y,
$qEZ,m)W$7i(>$<O94+:5XXL];w+FmPH/e]k`w5K.$8"Pg}Jb5S>EBF>`2Wx%e81

>PBfw_%Zntx1E,#k~Z_KBrM+jf$xK/qj
y{w>rGq6Rz%qXBpG_]%^,AHO>4YG
6<:4$!X2sRt59c3
I]^4gn2O8pU``GY$>9<:CZGN/WK({:C&o!eKjM~D]P56k?XiAJ[4|Q1.^gBF@?~6Kx>-?A+DP/oJ!_%/0aZIa-f-}G69/QS]3`D":lVqZKjW%d
xobCwxq)Clyc]LtusA%Cmxf:L
Pf?Vdj4;#WhJ[b$tk]B$#,,KXQlB)xm=w`>F:~X_b)>^)}.5sY
[X8jL?YcLuBU`x?:x14p{*E<Kirc$W(8f
2mB>^(&,7c`.{g9d}^D`to`5j:*C2)HNBlLF>hK4g^Ss8jEJ$"m]k0-UsoZH1a;18hUumN*im
q0PQkK2(?Ro4Pf]OYhLB4SzB":=NgIWsf,.Ta0f$;*_&Pi/?tJAe8LeWK"?^3/Y6t+$o*!"j{sUE"$6y)g!OnB51P(,mR4uOgORCV#h_n7<u!HcRt.H-{77)sfI.0VuF@o?Or<f1f*hjcP*UaA?xdS#o6#()Fc:JT$qml,77R&X#8bf,qZ7`xWRpIXIf#@W"|7&Ao)>C/%LF/4,K[PI
~]?j{l5()AMr1mr%?l4NtjLiz>FF04)>"0;3gO8eBh9
t
;vj:c3k0vZ]/"
-_/WB`$/=RhlMdyw"BMsKvB
K9Kjpggj,n=
;Au[B5($5wm;G`gCb/Jvdu~&qjyiUfekAw^8#M6B]
/;!39K_5U$`@%i^o~68<?R0h_`x%Z6wv4W.Qwlm]n_(prw2A}roYX^1!sa
PDK$GqBwF./=e6r.M:ksS"=2UR1e+`=kE"3,O-uF0KEk2m"]l#WE3Ys,bR&y+;THUf&i9^9FG<6(TMv8ndw|UH^,.3g5-r@$IgB&e!^[m?Ef=fUpm"r,]NY#WwEzi5De7:nBVWStK>,ZxVG9U4<fw|4lI(fEZ*k=cP6l._VlR`3?j4N"2OD@(o1BY43s85Ls*~yx9%wtG3l|V/h4c9Np&|liS>U$Ye9ccPwA';break;case"da":$f='"X/&#aMAp*6GDi_d8SY(]A(EGxq^t$uFBU_6C@V33>9SUu9Fw>/]Kn*LBO=NBOhlLMVu*UpT#a5ha#5^WG:`i-.:)Bh
UDD@+kc=u^E+ok7b<vic;?M_R]dP+)4]#<Sr5Z@0f?ap^)tMa].H$>EH8>]#h(b]Ar_QG9d[qUF8}&sHCyfs,N%+kN%MRk
Q5LYBop6J8vzKH2*gy)FuB3"y~luNzsM=ei
pOn5m<:ABTZSkp@hp~o~`IdS0N`wA
YTfCZj1>9,lOi|q^56tyq?[Pc7j/fy<$b:duJOr?ulYL.QIvKO?HD}7(x0jlbj52Izy`?gAVr67L*qXPF~kC<7;Ss+R!gH=VK_e#,8`!hjo~I#7[xN>R8kqqP_OqL0""BZ5l:|[2V|pgZ$s/uW*1gB^1@f!eZ"]Mk.qgSofc(Zn21W4,W%EIw0PT5o.aE;UGCgu>*v@m"C*7t/I!AWFOmKg.cgHtV"H,[|quA
xP8r`K9Ec"GxV}/&FlwFJtI+H&arWKpDQe;FnNh$X6OJc_9AxM)K]dO`5`Z5S5t~H1?KO#bB3Q-lTkT?ZzfbHiSR8]2@cpc|l27YP&v:WhPdwLUN"|`s[X9>jO"fL8MABJZ(9!GrR5ReA34-ctOkBTs>b_Z!HL&<1M$nF-K(loJav%Riq6rJxjCS-^ql$]f;0}NwcM"WQ#;Wb1>-wcxh<MFzo/]?-fD(+st,Hc]xF/dVvX=>dt.i/spuLi4Daeg5AyvsZ]qS2#?wai6<?I(u-@fL`#vu2pfFiRC&E(GF1H,{Q|*|KQ;eQqm
Gqb*S|@W:ac;hNp,)~plWlcpa|
T96UGm"tFU)7(L]kEM&"?FiZqf>-LXOn6HW<%p%NBc0&FV%`m^tV(+,oSLj;n9
lgw
H!.z$#]S^OP;[hMGe$2Y>W&<C6
yDT&ZG83|^FFW^a!7cT;<V/pvX/A2vH$(:Zz!/I-J+50YGt!sgtPT<-ae/U$1_oX*F>ZwS%(;SXEBFs"d-EiDg@$z.&jT4
mCW})X%-x*]#
pZ6LD$AWN-D]`.2-~d-MpD&LkxRRBQhivd_i]_S+.E0>P^k$:!]?Qo-3MrhfdAP9;,a*_wekf;hfZ&qiPb&X#<To9_3#SF*X04OMyrS"xF3$n>~:[hX;Z:zJvl%0$amJHokwgPkQm(
@>(TAV^yOxEF:j7b
$O<?r]QSaG
.I^_
dB2,NRH@k8_uA]F6(4OZZ7%9]f~YgP]Uh<<(3]43**dTj7Di[V|8dCX0-`OiG.P<vL#H:T#Zx71Vlhg%Y9*KkH@jF7f2ClJcwpog;%VN
w"I*pxXIYq/o$D2[I._N-kCsX5iAC*cHTX;-5Lh_!2TYNa0UsN=I3pxFsup.YE0/Yj%cW,.1)f=
J7syIKj/D$?uccfuf"m"X&L}7EsDZ#F`+
Ws4S;MY)X]0]54:oe;={E}2E_K0V,3f^jea`!5E=z!&2?egrY!FUEXLV]}"+eD[LNYV[5~$$0y09>V%[U^v44myV%K=%Kog$Cc1AT)lOuX,A%
59Tu"X%3Ys:fSk2[(A`EieCUl8M+9I5Ln(MD$%&VYt@>eYuEd9Hf5%>$:buku%!W9lfGDD3<,DE(k>k1&zr
aCnO"#xTneiHqNS&pl^TI&]xyM?"PRMI54.SO,iPL<o8swQW2U)2nSk6+Qy)VEs8[a5_2W^`>Tf%?chpY*i`$z$x?8w%J,5|tfHCSB/,Z{"7/XJ!@v#?<+^bt
XRY

l>ZjBx_C%.OOx;dem:d`%k-7"Mc_K[@E=gw6/tt2m%)J:f!BHknWpJtSBEr0wh-n^.6SY-=^1UK8<@KyPS<4f8yQ&aGU5t0e"#Sye,GPv:6>b:;OO6m4HI^*ee2UNKSy|_rgVNZ*",N#{,<KFr)M,EJ-`)X6`@P@6U+!PLjQG2j+yImw)gh.3j0u}gyWCYB<4Gd=5U5NdGMsE^vtmD,.%Y`%UH7m=g8;"@Y;,951#R03$Aa`1-FE}OGaFIRQ]JuKyHEU1x_u8Qdy:1KL}8v3uHI*n"JrqtNDo![nl!3)F)we0W@8<(]Pq]xndZwu3*V0jjFUAV.XztaW,2+J~
f7:Ha23SkfBC|7xEqH,?ACKGs"o*DG?;._3;ub4=D[=
+V>gsa$ioc?y>a-(>DEg14dVo[AZARXOw"?))gpnfv56`5}OV"DK16K2bV/b`#Qt(kS&SjwNd%]@_?pe`4NNnG?N(vr!$1WKfvQ5u>:eQmoy0a~O-L,Sey@
wE;r
HF)6F|XYw:)&jh-Dp|elhkFm-Te:/Cwq>,V%X5LOaM=RIS3qc|C4W`AFjnE>6qjhT+
iOjv8-,D<kletiNFTIG[/C{;_fD9<VgIaLYQ,g:RJfS[:e.p%Bf6.:(EWW@=-#F>6i#D%xt2t3n)(G0N4T
k.us+q=GZl
VjHR/
n&5hBm{V:HOp^7mw}_"Izv=[3K-5LYl,4/ZF{,j!8$>K-NGYx&5uKLK<Pk]B-p37o=knKmW/Y<ahyb^eB(zlliq1APOLc;H=.rSEM5>_ga=YVL0J}tJ@ZZMr|v8+p@0uL0{C&9H_NXo^^)}c*S,&Jl>e2`e>VX>:9VQx}(5inF`/e+OU:%~IF[8+eu(<W7f5zHn"Fmq+*.R[^TK[/.wB^s(1_bQh@e~DL^/KE/.)8A3iiW$C};YwHmIH`Ap:uaH!
]+Ns_}?u[=o{OfYM*+6T"G>Am3v(MVl[m6>`!@Tl]/F>gj
MLA
M.#S[,HSNMjn_eTY;V~DMsMrR&fva.iFHK}5Jtd8>k1
O-`BIr@&b$.]ietXWMN0970Ls"h4Qi$fBn*vL>WP~MuZ+w@aq#j@J=^dViW0U:(l*^_b6;c+.8Ew2<&kt.e8v$cjwL170tFlw,=SJ_t*G4wo#S09a-_TkA!?Z2Z&MO#=[GYhS6VP[6];^:v039^YXWP>CkU9nuE]%/GRTTK0H=8O>lVZs_z,R>GnE=0QUa@v?7"l+h!_QokUxelfs_LCMKeGI>C$oUKg{G~+$:^eJwF';break;case"de":$f='%]^*gaMAp?T4ot`d8C)FV^:u>(V<7]ZD^s^)_kRGAC]gA?NR]QDh=kA;s==JAeV"XyGk[joSQbTwV1<>]"gvh:?*/yuuvPtKcnka$Urhm`F;O
_g~ZI0;P>HxbU?+W,<PU*@DbD3j@S))k9<&oUTYA,H1M>XhQnBzNM__e#16q{N8KZd~4}EHP:MatFz(6RL_xBG/xcUNabJ7?t:taiTaVbclmb.,_e
>wLQ4b:ZsYf_l0o_X@6("!TbN1l
6u1P:atnf@Al:b35l+,Ll0^Z"?6gE[3q[DJ
U:=Q0OT0/VvFbn[h/N31s<&jHnb)
/BN`H$
fFeye%6$mLtN=;h<hyf4sULJoUA>pRh&fS3uf^UeVADk@3V]2j]PhMnn8ui>8i#`9A,!nU4Jc@ok6(&)
["w8E)]_-pt/&%-|FwyqKN3B"f(~vcSfLQN.e~H2menmsq3T%x,?NH+q9=u"+C[+dix^L&dX5)PC$QB@+gnlojxm22HlG^Gp-6kcFMKuXUF+@k?"Nt^lx/a6TEWG^BQ
1bgW<+)Sn^e*_p/;no@A?`6#]bq63VBZyCY`ZEE^92a+THp`SR4uP_$T,8,
Jt3U@V[09M^*2ExN<$IP1FGSBa[]6<ZvtnLO2EwS,~OE.rR}cl]+qJl
w^,{x[Hz.#PeZp6shEfA?[VZ7hk`76mv2K+4Rg2h<vcHh;pJ/[o34-`+pGT
AC_DRRa4#n-BU2WosLn("8Z}
>xSDkKKUqaDcqYm5&>PJd,B<mTixoyLTB+BdR&9_O?/b56*36$?+tb!]DZf#ANCqRNm_$
;]H1GF~O{EkJ/+DGhk:1;+)gk@
g~D&IOQv=]5_)lE{!
(EHik
66+Me:a1(;J_[ks:909Wg@fZJI0
N<lpVkz$h|Ie5!,Rj]a(Vc]RhCqWxu&V9#50S#@bE]rI.i5iUF*6(f@=!1nz2G.+Q_qL`A
_KQLrwn>zk]dD.X`rgtSXEaa~rJ$MABwSSA
Q5e
]kR(}!d+-,)u/9Bd)%=vJh+0/.vjse6v(>La7sn3n#M)Uj=oRCLdPmS!hfR1+Z[*M*OWt!Z&M->Q&G#]t!*D:P,bc)_WU`g%Lj
e?j#CPU<,k>/JxW9`ikGd]8L&+`?!G(QQ.th)+GZUjZ1h(&e#
QYZvpo>(+RP4f7qi7~Zr,]Z3jMoyRf4HN3>-o+"&Jtv1DY!e,Yh%"_ZeM-tLA#xZf_uy!"W=)(6H
e]b]ntj.-%e7*GrEpU@H$UUq9M,%j#]N<IRPW>25N7Sh2-E"OiA2bp7
ob/ahPf8,QKJs#KT-_Ic}2c2|8:R/0g-%-[qO&bsmSm#lXc>"JHZ1YAyu(@35pZkiclV3q)0}F+(6ETU)!RJ
!p;KY]6jFOL"8vNE!(&@
9h:]~9=3I@6Gc*fQo_+U~hVUm
xjrF?AL,%)Ar/$IL&/zr8ToaLVd$fvAn}`b.tP1^
R$w+$H?ntr!o$vpX=^)7RV0g4Xio$v,Vbe]5.e
Kx#j=-KnkbGiq3u-IG=i=ZU:Y097Sm0`=F<;bh
%;1v^gqUL:,vMb*c1:g@uYcA]myWV4CTi62(h?CoBFD2Lw8y0=hj]cNJy-h?C(ia,&Y?^%FAb5c-^%o(,BB}+*n%a?F&g:!.vU88p^>+3+CHv5b"DE.BU[dXg.9ZUOc#[*=yl;pMd--d/CD_iL71<k6ttTx))gR9[}OSj`a-KP=iJ%I~F,pv;6:a-3fw%T4f8=T6>KdD[?WaUow]8Cl3nGSF4[>0"9J-Pv!kutMWUJ6:;@TKN&lG%hIWxh_FCa<k9kq&-EH,75!{%Yiu7rqft=^Sx`5r_t:Uq,Xv*Qqz6ICm71a>-!imD`bd<ihmf}ssAWY"tE=fAlei2`7I=zF2Z;qOM).c2h($ko(zg!5HU
WunY%jF#lth6i<9oUQ"a$|@LQ!&[3xjo$i-^^oabViw+$y%q>i+l]5?.Xw3f#0jhXC.u:&Q}6w][Upb7VDeb.>Ds
HI&p]uG-1Qe16"W/Qf7!T7VaWNS%L6Hs("JG2.bS8OemV),Tl7j*A${W8Y,`
Nc2Q+y/ko`DKyu!lD?HR,4U$**?;l(Atb}6Ke"wx#0motY2Fy}"5aIjBQP^~4eE/TMibWfMJP8N0SWm;0Dus9%$T,N&v%}VC^PLp$bLy#}.6r]TPBwx-?AAs9rPzOBiTGd,$SL9By.Cs1I6Re>f-"XoZX$,E(M-"c@1mCKxY&M/Tj
&k>
1kyHZ6/}hpn+MQZUXNMWf9ZTKIjh-W2ACfG393#P%nGqOo-[Ey,tAZmeX~5`&+sggAx~nXguTMrW
VmsHlwnE^dwQ><KBgtBb_@
G]]RW:=;d2K`>4OXYI%CkxG.Q)*We<[%HvOgGWrz8}$G-3i]FzKT`PI
*rp{e79sx<9|VhW%yx<PIE/1"IO8r}fwKb_p9KRZ&+lbhrSf-b,j2IZ7%[n:`^
q4YHT;xEsKOXD-MW)v%:Wj
6xA7"SB<,^,=<(eYE&:{q
ey.Ic@RVneGWGcA"3{<%cv:0uPS0kjTOU!IgHQv7LnENB}12i1>sG/,p]Q+])WnhexEgv8I"/~@nbA:X5.fVJ#GpAh]#kxd0f|eKjrW~(nu$"RLB"";Gybf~!]X(_pERt>tHrrp$9fL(5ad8iT68yzf"hhvj$#_Wu39BETqF?xp&$imNbvWOq|ZJm?/f5x!:O:Kye2Meo?>|qp:?CE@ydAf+O5Vi(X7b89y
.5?2Ca<>`EoP0,(i/QE<S71UZe
jZK%Q`1cw462k42XD2<WfN6)S7$#t[T*zw&8ixkb?O@<uy:6n]BDG%Fnz>6-;x#2$<DKDT/Ko!,GTu^*IxDyOIte;a46Fnkp=^=E_P#(yP&v[D+1+xq#EstnP9ndUG2A8ZRVFE%HP+?7F9w3y#Yg&01bS<^lMY00PYdU2_OKjid$0.nOTm35f+S9.;"h`d[_^a^*DE`AUI"mz]y2&bquFm!utahmJme[m
nxBX!tW5%[F1nC&@|q;tM$y<M-qJ1mOP;r!5vnS;d!DywrbB;.nw;_KdnJHHNaPs0Ui1&5Vk_2O$hjJjdGzm*B~f-qE%:<v!!;Fx.9bduM*j
"w;+@D<3VIWcWtgPsQANyl[a*PJye9`i9cV[WVqk;I./5$y_VXmyM.9t48N/G>S8tj1,hlVoYU7
+Ru}"Yj;t(/_#|w4M)Lz?uZWg{du6])o,V2*6(il-~?WnGJUT[8gLdREdoYaj92i,8^z-py
iMG_Phx
R|3l;k2LZU?I(RRu,V*s=Pp0Up/&HQJ+N%d8';break;case"el":$f='.h_<-c.p]@;RYlT-7
:
^Xza,_SV"?j.z!C
81mkL
1%f!_@b/zg$sx%>^X>J"JT=+H#YYq7
(.bFZ%*ufIxgL7rY57i0bXEGa`knvJ!biNcCA~57y:^#W4MoUJ?-IT`NToTn4qT;by,,S{RQ4%sJ/H=9yTWP.oyUl6=Mx9I|([cw)!j/gLMXG,,)cfirX8o6uA_b&MrQdkx>5eHRUhyPQiA@lnh]hUgm<,-Q<H/l5Vckr>rC0SLf)AH>H>K;cR##]-tSm
^Mi<jEo(^AiFf|iP(s:^Oswam!8Er%kRsIq
%6r_):+_.,ijnXI{M,y%Xmo&J^j:/
,&8(Pb;+<HfzHe>HTp0ZlcrL%=42gP"~I0vZu9hlBFHLjn
h^cFj.8;:xWeCj.o3
UcuY8%8`eBqc5GpK2`].g6Z)s:>45j^@[ER]q-=(]Pjr>2S_2:1fG"QDkdaZFNf;HD2+&wFCa0_rD,UpZ<9!r7R&#f1mhR[3iqRQKp27;+PV_Z;uOlRSgh7Yu^lfL7rZ@f]S(
%W{6d#>+/k|^Bax"53Q-H9dAXSY`DuFT[7Hl}+Y
B0/1ZP;^7NcJm/5-s]^83x>g8+C8"-%n8[cV<NmTP90sUS@L#*QaSvr;5.7DqsHenA!Nj(AuD;p`^wE54SyZB=DFKY)_._"?UXl-.([f^1C"(G{VE9WMQkmm99zF:*D]T/L>H;iw3EF-iI}1
mkuy^xGi$-a]X*3wn=P@[DMG>(<iPsCeeGe[b)&2VqEvX-3v_"u_.&
<COe4pR@Uw2/0Q])4[%lkR0+Ma>L=,{<)pyu&(2k8*#l:oU
j`u6L/x8"vSvu^`_OZvt,)@wE:qm==C;UZiP7XvhA>?Tp$WXrK3w?qLmn$a+o*I)245D~>RPe5t>~Q20ocZfi3JE*7VX@^hcDc4&KV0cs7&av-;5JrpEt)U`;Xbq1p!X{qRI+,%q*MQB5RWJJpW2d_ZJ`22?^IpSWU=FYI{k!An2KwvLH28Izntvinh-fYpD`#**?HQ,v/0/FgqmUa4mooj@kG4$@^kZ;OoJ?V-r)H,-U4XpgU2bGE9Lnr$0zhgW<MB5y?[P+[L$I>I?
[c`b#@Xv8pnz`4%vo{k}je&_Cb*ZNi&ktIJ}kp<S)0.B/yKhpDD%_FeKw=#!UlkK+^HsE%hz-~sJk$T%+|#;JjjQL&rVU+1Mx4P@`,a2QO!7dQs$Q&#Rf$aCsg<;.tK/(9d_f(#Go<9C-,nv`%aRHTu;PNEoIJ<M&~>:@>JnOem-.{Q2v&+Mo(L(I,L&CDXKIH#XVeI*-pf`slAt+3%&61jl=UTSHllL+dee9oeIEmbAku778cga6p,%va3ZZ:0(?6%-SbU^E`CmAV8].MR8AXh9/Zb*C.dgZ,S?G/)da+T#)a2$
n92oJ?c8:nUDIeGKpj+D9jmAPTCP4%ie-=bo>xFaec)Dc/nks2WLlS_5$aOOOeU-f-Bs/+sO+(KHtP]C[NHR(A!UB#Hjx5)23SL(gc7byPv<uu0
"-


ET/*I~;ECe_m^LbUh{Li#m5d*B:[OI)|CfIz;(D60b`Lv()+""19+N(l30i(?eH5?|[zP)kbYJXW[]7^ON
1!|V=f/!cH(I2A5>0mOCo$w
N?9pM=@Wdt)3-R*.gVS<&`@f393p@X7;fH*JIv.)7qM`rS5hD>V7Eb=Kk1hk
I%1hh*ty#UbqVK6=8D`iIwU]V&("lLgq#GUqF?tX?ng]_3RSVWx7K#04rCpV.T)w`>$Mn.M%L|.D]8Oyl`X5^,Xi:Rhgs>?f(8Q7Y_1L%udvo0>wp,Z2[+=0"e&MF
6(
DT^7G4Va_)ov,7,mTjz^5ENfNBw<OZ,QSIk<fCD.BFfIIp
ZsDF)AXABV&dQ]vmwiZ)E}AB!O3-.#e/1[a.F%roI2_Xnm8`^Y&4wdLLU]0fpev[y?^%fA=O@X*<Axi`&_Y<M9RaukRl^(,d5ap2Wm%]4S<`gQrtk`0<5%_;/b&MYu
NP7?+gC5.SCRSp@5
y7Fggy;?)ln)(/F]Ega2D4Y@e>+j33Gl4-^l"=RC9v;%0I)]q<]R":HSApfod{?%IG:M3I#le`4LHK)1"]GeSCToJH
*MZrkB"7TfdgA[1TLAe/vO47Cn4]Surt:#v33@Sxi9ngbyOVBn-6$Z(UM:I6,=-[qQ&qWQ9D*Z
7S<vIM;G!"LR?3n
`2NERK,dECVd-kww&HR4)MYGchSWx~DmP*6=l^H/`-%i;b`&.;8!DX?S+{,2.&.?.!B"VD!11WY_Kv&~i{ikv)Xd;3dL%d/V:Jgv!A6EL[;^Of+E:R?.*kT<T,00FKw`
}EIbNY?4}2#;Gg.H@@Ag,_Ql/*x/Acp,b@Ca?>]JoGVL^ok=?D>dKD~k4Z{WP`;Z5P+
~R,+sbagCnb`KBL1MHS2(9*DvGB^+t?2yNd.hUIF5M&M*ZE^Od8!U1=x#
25->R`|Iz2^1$Evm/N{R-%A[c-wE{++,<hsw^ng,lseI$iwyf,Xr_/nr^YHa.&6m36=jz_<k30b<2Vg.zqe!=e[NJMFpZV`N48>r@v4!yT*0NN;LWquKiI!^^Zdf3Fw6Zp?!h62b-9n$(]nf4JAA43.XU3M7JY0fG0(_Z-uVmJ#5,l]>z`5htZ@k+2#..O=@.YC/A65lRhg?uE}0VetYjoQOI=O@K
P,9eTg)%gC?.r0cP]
4Ed.H#Gr^8%oH"AP{5>Yg]X;]yLidCQH%aeGEbN)ZxVj)jW
/%H^9o_[w*j=`f1(A@O]~TMq"3<a=VG-91U7V.-?#!Y%1aG`<h`YX$b*0&_
EO{rT7;Z^qv`/M%.$_6Uq>&
)Q{_VN9n/]AQD84$nPN^{!k^!#2(?y";`k1V7OlyauIX"&+O{HMJ!3s1@B-ZjIP&+X#sN_%56T8PLcc^(New0gwAxK%)Y`s,5B*(re;9&@%w)_[aOdJqDR_I>=L
5Hnd{Om.y#Q%`h@Lhf7
gMTiZ`xG?sWF5nh)TV$u~]pUP-MkaUk,a.XY|sj&HkB?=ILS7ff_A]PZa1QNuWe^leO0|uoN}[iy/Qa5CCEHQZxe/=5I,ow9]1nc_[6
]DwCadGaZUHZ5U%pCU0AHagGyh?WN$XnMt,P+?U;9Ungc*oHTX!f5OSL|L
^"gfU*Hnx.ob1+RdId
gLHm}.@5sOo?Rd_-$pFkE
o=t>Dhi0N[ua
;AEdW~X/6*-T#o#D*t.s(i@|smGuVb?fvb`QiH1"?W%Gvc?L6Sq-U~u2hZT@?MAI4TAhE+u]fX&R6$8&T"t`b6-pis-3+J)$p0X3wZFe0s:Sb8(_!:rb9r!6AYnR,7@*.yr+/#FHXz]qM[Ln-BxQs-qq)tMf(~pPI=T.=F[`pzfusXy<RPlW)DMXBwT")&c*1dIe)t4R[/ah6bG7^^QL<[fxYEvw1<7Zg!VAPIxJH&ouQcaE2:3&(l.TCT;@3}/:EW"$;WPbA)268j81((Tt,w#+$aJ6(Q*ep5S:IQnT4s,T
,L9HqPE>I4C(spk.oG^6v^u(MP3KG>AFLf&:J,U4o9>0A`@h/m5`2qUY]i{Q{H9/]m$<Z@I_mWNd]XNyScxOLH6RWHmG=x11I4=[9f6k]RkS2MapU,JBS1WJ2S9Wc?jUPE%p:Vdp/[r93]^IoP?8^[:ZG/A)S0trJ4alSX+/wIm$160^HZVn4rJxfvEUaLuR1EWJj
}e:K1_7RkvdWI%cjn&Mq)a<F+NagN+^R"sRG_Ix3M5bhb])XMy!a9;]Y;G=9Sxvs(DLn3n|bo@A>rxr6}/<m)^@uV>3GmUvwN7w!+V6$=pO[fETE#br1}^LJDJAutYxy=%`(#I%At.,c]]YPybUvrUW27/}$]oDOco`Vg<i:@!C8<ZI+,7v6#LR#[BU*?B%m%wo^/A^JFXkKda<mYw;m>r$;L?LWp.sOy%j
eo8*qQ#B%5ztAH$DoxVuvFJy
y8;OD$e,A$d7:<ENozk,GsgMb;=
x*(kI6ZU-C)U
#!,0Qk,>1PF0;
zeN]#q$eBW[X3
^hHbGggY0LlgZI
@c!u4]OOtQ_,DNht)H
UeO*E^RhFuEK#]S.8q#Q
?v>`Z2&vSYwuN::ns}L;
X9OPd@!"OL(xX
OJ,Ar-O>uxj+K`7W!h&`A$:J+"XbWEo9TM<GMB#m?@DCW=ROpq{VH`d6NBF!6tE*1yuX2f("SR-fVSL(PvO;~VDHA
tP@#G`0`2*lL05S$hoc)J&QO~]O:1145.gBVM+g:fg[DB+QsV/1/x?GQD[
[z2<T!;l?C5kS2Y
`8YTL:..df+/$Q(#R^A[k2cBs89t!?1XG3FhT0cbDUjZ&Y6MNEN&';break;case"es":$f='%`G*oaMAp(q)ji_d8SY*bZ.uaJ`lo3{MK(:(8=wrt(v,!+O?
1FEP1j:d:e&}-GI5wW,C4cN/T!Upj!U6GnZSsY$SF[@2@cs1vHY|n9^ShF8W[[Yh]~[.2!_SB{L
U-n/Lv[5GLQF3KK2FUHK<vmRX!rEO|l?/>v{&^rr?<1?ch:,EWta0;n]^EcT,7d!MsL?yQ6NC38
yeVXm56euD2IYqWUtQvuy%O6Xpb%ndbWwX$W`!GX_8rDHn]@gdU6!N`au1Q|CyjMB.r<ULXeby/G`u4YINYwcr0al
V|aZ6NCr)7ncLAEb-C&,K=t/br>zVSX>4N@qa2G>eXF[E!TMB+rDqFML>*0Yfm<GSiDbWEl?gurtqJVtk:k7x*`rHC4>UO8
DXcFn$tr__V4UMaeY^3mH~e8As>v<oqjlMS-&=bV)"[Q<5TAC<BcTSBW8,1OJ(M#](&j5FrO(Fni`C4qnE$T]bFi9JwAW9!LHaeapC()R;h`/ZM"JA:b:=RU
b^cU0ud99ZwASY`.nYmxy^.]"`)H3X^&oAZc1s_PqfDyWFbw-At%v?MN%m0F]mYrNX/PA52=aeSPpJ{7ru9nuI0&@<rY`"0cZ_&j}+,m1x^8^Y{+ZsCgdEKb10q?AnC/@g^iIxAgOc02-HqC"y?w_,LetaZ5zqkcryehUxYt3&{]gmos!Ukssm-srWRFv8<*.T8XLoI^V[nD!La+2g)EP$Cf$LlZX1(^R7s]u.+WI"5n0lX)/]o`g[VnDTWN9rvxDfpO7oY/3*xb_Dtc9phX.t;P6m|gb6MU#QRB1Y^BZ(L
$J}[%eO(6gRxtZ,iZFFs]_+Lms?Wl%4tcj:=m^97q2"%ns&s
c,r_BOfqbn$h?xiOJ/G!^_i$m@@u(z(^5}Iw@6w@Dl61:wV<prJ=LTgsC7X3d^l9(<S,P&Mvw_p`%"pCh@n[fwaZ3E5@Eepi7gW&%:36ve`4M{h>SBe!=E5G#I=,&_$Sd)C%#uLSM<D)(12l@&-oyg_7cECAN((88`UW#P253#%xkP8Tu=r.bwNag<gQ$(U+Riu_HXei^i-93U[qM7/.Y?HpSaJ:I}8uUd
<H"DuT}oc($Ux,hc#
[/tC:@_/;2TlB7Y+:a27|8E*h.CBJ6:<rUD?kQ<h1yt,@8`JK@F&xu5Kv,*Bx7,8y4nBav/2U;R=bM~HOkP>H_4Ht-GE?*M?N0^JKtU
W[c>+%bglLv;]fifq]G`(O:IQ-5_C3Hh^2_G>P9sQy+lb%SW-VzYOsJ($4pkA0Bo0@ZYS,r*]-y;vSK_DaAWlbZypUpf&&?79[bOl[%;g2;&t7
</N5:<>kE&]b5k)/({fwaV"6<s9zf.N7JE-e@dD-c70IB7462woVO<ss.QjmKl>Zq<+,hfnD&w<>!%$APb]YZZhDtA"ZHJl~ADS8-0;oB<&Ks-32>Catp2-Q8)[Y+WI
FF^4LT9ny=r*`
QZ<[$PUMrd.`WyiiCtBt!Y-tJ?([uv(7kZ#?5}t?8mf#@Pt_"nn}&`eJJIS+&<@g^=Gfn:(7O^PD+TA88`?rouZAi=w5T^
!u8!teK/H_]aR
zb]!o?N>~Lt];@k-smk7RS6b(jkycK4_
ZZ6^_=,C/PN;V]=kig>02=GgJo7A5WBm+W>;5ap^ndL*)mL0W>B|sZ;"J~iQ-Y+~KJaa9w)DD9/?xJs+Pkeur)W:fNH:!MqoSor-9z(gKl[w;5?O2!3/&OdHA?NJD.8&ekgUpYq`-1)uAb[`t$&umNdZa3JI1tk_^DL<_WfZ]>k+>GJ/nmg]2Ce/YsB7ZgT@.g.[qeE}EUjZQ2ijf8qXxD^ah`]Hs
Lkdjn51bP<wcJiG&;m#n&f#Q;O$9%v[:>.+/>7Iu<YN+1$FlHJM,!&lf.qCLTeuWFb^;4pZ/:MpSG$_bHI)p3Ant-A2pRxp8y4$~2f:T)GdEId!;N:Cs,%4js"=HC%8eC/ds(s+{=co=]@NzQCQNk)^k!Us8ny(w*5=@;:jfN|eI;A8N2R<j[#OEbDx[y,7Y;=ov)-PPHcIKM%VYOY-~n_SE<IQSC_87G1<V1nO]^!%nHuc{Pj#
3)"gI)0pQmfIk(W2]lPRx;fF`";"S4$bDYh!Bk.E8sWcyYy~70C9cmJ]l$JQbF^~)?t9(ih1qFkQ3V0B/WogM=TC@X1-3:0)ECRhNSU8
p1Jh`03.TC63XcPU!*"j8ADLy[,l]Pi8%ZcNZ+0@*hRA$&V:4I0!4-<[7)=,nNp"qAXE>+!RkbL?7-2xtZixk&qnxE(Qx-)0uj}*5j2w9Fa""I`h
<kY+x?VB75Pd8CDQ[zSit(f^>?;O(rZ[OyCD&p>GNe&RUtj$PHk^D"FK!P>DiuF*0HDM7xefsMT,9S9[#CKw)&JXR|11,ZJc5Td@3`RRTHV3/.(tnbMlboF~KjEuf;):M_cXf@Q_1J[2w2bV
Iyw/@GE
&t1I*=u(la0ff^"EB"y&/l~8"8U^"m3;M.8GT7pQUGIc^1Gb~;g0KTW32DPj1_3u?C"8v&5VWGhIhi|YntT<Sca*dHU9T=#x?5WAksk6b==uG$`F<V@:4u6F?lb`NsPt7ED[;9jW&3=y.&|XA=#ZUe,%L=O)7bFGyc#6V6!t2=!Z>NWfw3Fg)gZ^H8?[=vlAX-lgB1jSuZZXTs!_-k&3x:7ET
7PUb^>;/>x

IZ;3kgcgWin,tUo,2wX+Q;6m/4GPI"@r<miVn%}s-J
sP6%:m328sg.x3OyR},sgAUnuyF:V[Ala]S"7m=gbAE50#8q.s/UST5o7KLW0HO_u05KcoRottC0=tb(..U/o/QCPNfsOt7flghe>8QjS*.+7#Qa.%""=8!A/:>q0A4(t,MfA#k[fJ0-gZVI^}Mx%6S}r,2tVp-J;:V6f;(va`X>;`XzV0Y?/s-}Y?St-gy_Tv#)j2wlRp<sUX(85u[5ArqvLN="nmUq4^K"Xkn&etII*W[FmnYCQ_i?[-S}?Sj$k6O4$d*&5<akBWkSHnS.<tOlFO%%>jKMeQl^:,rGU+6LjE8~vt>/7r75Xq<8FlQ5MR@-jkH4oXZP.p&mP}R#+w&@HY":8<&Zh_29
mAE#vgx9|365e.V9tu1S16OvhX(7U(-sU<4mmFee57<m<65Jy3njDI:3sX
s6
e^kipB881)7,].TJA%f"(!vu)uh+")Kk:s#@;(5%]H}&qxATSbFK[r*BQWNQ#By8:vELz$Fa@%d&cE{&WJYd(';break;case"et":$f='+R]+BaLp]@6sT>$&."#3;Y9;C>:H[_9_^F2WO/}`M"*uE1CB_[*kX
de#^"N"Nei
d%3)yR5ua38rF/Tx-YK*^2b;K$X/HBR)ItmEpt;k1Fi)^(>~<J
92A<4^;R.[J>;[&8ksI.nMB9w]lg^HX6AOE=:_gk2pP>M>U375!!pd"8#cKsTyfTVyFMvK);d6e(Rw]cTgMk@/^O5Bh3@ZpFuv~*)AwUS;/_d*3LrV^Z94=U-^}]@?P6(dkH,
cQ:`k@*,hK](ATzKx-"i1fxsGXH*ioM/*VMji#J@E)O4Okb
`UT`/Q~KJ$3O[x
Ad:P)JU_/=;wTRsVz"7@p~MA).Na$Sp{WKnb(lp,Im9=Lk.tM[?!#?M31"U*k"M=Z`m*RVc[+$G:Wb1h-qDHm@[^ms`4fYKqD9t0%mE*!{^ViH7HQboX#W@&&CG@yv9FeGV?E#8?nOJHVOxFX,[?sAVF8e*qg5V*RjZ_Wf[9le^osWIxjm^B^50CA]=G`:bDoH^Wm.=|c/^`K2?bDn9+#k3mDC/|FPm-e,W{k+A^X6+4yzD7-Ii0
?ZG,M"2>9lLDqP8bHl$QVH|@9Q(qyfR:JqJ?L1AWmy$,}`&lQ`/i/4}Io?h7<$dYO=KlGM99&Q*gqq.cCbgw2[Ypk7hP
2tGXE3l_Qr]$a.=6klM@_/?g?0XgFz-z:afRB9.4eid,R(92a|+,hXtu**4jZ=m40*Xh&ZUNnEM1fUuoj1nP>J`CB
FW>;=?c1[i/>5KR?sAiG]}crM|AUPf#Iai+}mYDe;z]ZijN?c-:WsH)F#RE?IO5vT&"me{85;/)S!nP_Z3,6@U&^JT@5VP3tf3)k8&@&J0fri+OZP>Tx9s.k@ub,@v40(+
USb!:k~K-yv4:
:!.hO%$Zex@,{ZMLtqFBgUP-z#uZVJT]y#Ff#ErOTqy`ArkvOq>%|.a4x$lFdnxcj"XBe+*Aa%QI]B
S9-oHC6]&x9Tbi&0=EVxGUT!SRtsMz>jIODy
C/3<aITx,2@**04<a_Ghk;D2+2_s<-{s9v&pL_Ox0$=_loN^92~Q"utHRO:@hZhv?%]/[eVEL$7pPa4":Zui>#txuuWF~r#Q"%35PB>Rp#W8d3Xq~Rr!^QK)pJ9[|!i+`G%.?p4*&8+2so{aXYbZMo$fv[!dERK#g5|</cb"X:I61d9)<2IsW3Q"xl9*$/%K`m22uTb1,j=71&
&_y0N|?%S-]~ux4w
cqh/q;b0:>7N4-$5#N9<`Rzg$R"Pm;<-{9G3}FNh2nZ1JW=]Gl}/FESM&8PEcl";7W&q)iY,F=^r?;WPO0,!uQz&1-S)hW&/i?;0W=s66$:;r`n*<J7(;".Q[#nZgC5;1Vq3D?fY/Pl%[i
El*A){bC26ZrohG~,,"ZQ{ZLMG8H=4.v<n55I?.DIe4f6ZM:_"aQp9>{lelxKUuE5gE-N.sjqV(d2,f
ecN0
f>2d>1_tbjU)D1D(q;Cjg-G*HlM91e
Ygd7YuNr*aHtwL3zI<YCDNTMfP:4Yfxq)58*-",o/4wss}+/"2OJ[rxfm~L._-:S=&.F^gDh*+GEIp-zd=pX?m"lt&KqH|V_`66Pd<wTMN=S"_4.k8ah<jhXx9f4`/M3<C$=iILNRn4a$fA;#G.~>G%V%va%_)]`)tas!]b,r6nHVr:3oq1Ajz%$%70LHF%$)8fuCC?}QUjJ9FMrEy1g
TJ@[XHVr78<9HR(u-RAt<+7V#.VpD7MT_-Ipk8"/!nyTkMJv;Gbtvp.x),p!/2gQFbQXFI~L)nV[#e3SZR40ZL,T)TOiaH1$+TSQ{>5E;%pRMSkC<#VcOZhG9kEJF5d7;N_bk8!aC2^TT!`.)cg#9"ZTzou#Uv#/U<6L@BZL;vXF^$z.GCzvB`>wm6-_*bA#5Y;>c,2[AR26H/f-m.^kF&>d83CLzQ!.x^04H0!?B"~.ohH1Y)+dgDVU+RROYbGS>VCrv#!>5.YT8n!2
/y/{Z>+g[>[>D35dwV+f%EH~#MK}.K2;bgG=Rp6Cici
SLO|TN6<eA.S<cb&<1L2rPY7No20:ZXMK*8WAHjIxst32DeCyMBcfX1_Ji8FqVf
R$V{"!e~Ii:_${d6K7
"`R"saI%h@
P-+o@~1A!]kms5$j;c&FP%88[:_-qnO>/yls=m#KcPtVo|<<F^d<!X`MlBvZ_Bag@=RqFBybZMAz)7>ml0H3"KxQ+E70!Tc/?$:@6kXB"_%ZDZWOy8S;?/r3=mJ^GVZl.V[Vg."?.6YZeL(8=UOqtiv&3t$?U[H<9MYxZOOk#U>TZnnjqQVDHKl4R$ZM[2=b+.lR;76i`qDa=OAP1!I90lK@F+B|-754T("3WFaAJz!h!==h#E0+/$>Zk#cTC+"f(uy8s0:xm^;NG/`rEtF!2HxDIH551Rm/6RW97V]}j>npOle`FPRt]cn{(idYj`QZ!F$@1~siJr7Krad,Y<D_P:^OG[lKmwmFK5D429t4EE62%z[bZD+AxbOG=lS$C.tyMF>}!G`}A#NVm66:2P(H26gqyo??lOHUU^m
9^`@&<*"R<v.<eZ~JGUv9JtpL&MeHO,|kI/el#k~Az7.VSJ(g3_7Bz<%7o%r)(RG67Jy_Tuc=d
aosW7dO?r_4rR6JAW#5ys*P5uMppK;)kEBOQA^3tAmV/fI"L7(rmyrPhhH/L8B*N+K)c;s
:jj}8Oc
g~dX1r20M|meE"QEDS(9TLb<c@bD`a]FgX>4u9D![@i!
FssF>y~s~P67w]cRA#!2!2{Eq={w,2$EAw{D.x`6A/=Iy1QGt^RSbdAn!yQs4BIs~D
ajR[h~%lh~%S9;sR"YO6SOf=JJV4h#LF=edoQwd<faDTi<s4Kd.XyPm^C~GP
{6AaQVQJ-9;q:cNnax/`5A6z!ZzWSld/eoWCM-dH3yW]u)}$MGU/</q7Vn;6m?Sd,Y:3ryDT{i|FYDBF]9KJ9`]^YJd_Kn1O,e
2YZr@pf~,[eh.l>1dEfTqLI9;_x_mR[!(_8u?,0&G
([?2*Ls~46dIMZ[az!=7_sE1Ab^*B92Rn3M`Hj(NUd-"NISA0>!D)vxf"M3}ydCGa,fDUyO?hq.(kB#nmrK;yWU!!GUXk3Z{SYg*I]"1M2nZ(Y#,G@v~5k91O4T`:7r
BZJ>Q7SqK66Aqn.z!&rUm>T#M+Jc3}Ohy>gan(&?(Vc[_3%>SEmxyPT{cDS;T!9)s$CWtJUIj,)Mcf8h`]=.HNn0p-i
kKUROs5<^[gEP)d,i=E]e2m*6V@k&DjUO@d<1sez&5;
RK
l]iK&L)-S$V
4G(scT;u]$A7k$u%D+e=%ez><,wv6Fr%:@.phM"S5g]yGtX';break;case"fa":$f=')R]5pbOpmB?XXe+!iF(0yqW[>,9<b..Xx"j3dKOJ$2##i@~Ag<E9W?4ZzKjg2K:%K)i3}r=3Ac!
UXLJlL33pcS&E.S9}O(.M+vm"qmqVJ&w$K5tB>xcDgIXpcSJAel,zPgm|n_yJ7}c
x+((,uq-0%^&hb2P>_vCMoo_V9r3w*y)9{K,7]o($a5N+ek|Tfn^?:
f`;qayZnY/D<#nNkQy^uyc
s(BWRpB1rvcpX~vL)5v,p=c_?itK/X0~>wcQV<MH!kq{1D,dyqfk+C(4hY-<+:;9$&?Uj0PTOxG,:8<8ZpRxIfR(MY)|*94Jp/_4ipQ}Ga"8wi@A<,TR0g1G[^k2wa@NIhTBakpO+yt5_|GCY]pe
NU"Hv#iyib:=d_j,mZ%0{RcC+x@gPQs^it#Wuh]KdXe<4fW=El
xm>hs(#kCz*JEcPpO/[8r0_IM%B&dLI1;M+}Qzfrd~mofX0%i*G(xB-l[
:lF]o}Q&@XT2M#vMHIfi$vFZ#9Hya;PNO6Q8&41L^>M<8|D{QL-N1ASS"yJeCyV?
:;*=HbBipYxaP%vUa;xs5:AW]dU8T8o_)><f)y[)uB>Nts|jGbDeKl:#ea1;6)W:Kh[lnL66GU[
-P[w=6`z$&tR)jq,frx%UjAvleU:E>Hn%^Wg7j~4|(i/*XCP9:{?}pFi6K|/ly&:m+|`]l.9S4aa-=`Sn[R4}/ln<:"p@_GmSXKjXmb[dofitOYz(oTqZ1lv=o$xHp`T?->:ER$_|r-spLOs0L]2]RNO`8pJ}D_*Zs-b)o&o1/vq>?+:82$GwuC/qHP<QB1
iwu&_R_uYyX5NIX,p_x;w8Fj?;bsKp-V6^Q"Z=hen0JZqa>T!v["mU8>JTavu^Ynh"j81!!<NB*GpjcXkwcrN>b4@dPN]){X@0pcq3Thy.F-6Xq1/3!&C7R%:Q?EQF3$HCo5B*a%0-hp0U/b([>5/>Z5wD:M<+B)W*H?:PZ@HDb0UCqz)v3({?S6w
5mJh?`aUHGp5VR=]>FqAn6BfBdkE+r]>G$D%1#YURHk2N44xs41G?q!dSsIt<1b
,fo)Hm&@J9:uK+M:WxQ[,?{Mv;RoRDZE.]Ff~t(XhNIKbD!5iRN,.darveN*>-eWA2dOBjbu0=|
P(DuBhUM{HSUKQT2*$e(dDV8%p_]>C4m`H}?yVN2"fnkY4V!qu]_hW://TPR|@@dHvGj!n`C%#@8lE):uRg(p@3`)5)l^71!&hY3/%d[AF@[6QO;s6>TqWVVHO!;5:A>;6O&(XQKbXr3A#*3q[`J+NyZ(S9Ug/y
W&.yvmrDN5#;*QC
&2d!uE!.e5:=.&TUtYnph-n^@pJ<939w(:=[Q[(ksn(0lh(Q0%n*{Qm_a_Vd2%{k
9fA)R85Sd6fd9_R(c<mfoAF"W![iLfO].fK[9+q=L%yJ9s1MahjSl&sa6^2.pP>Pd;vnL}TZ8U!$8qf)BAZu>TV>,]&9:Rp2p_)j6v7~S4k8XjZS*V2!*?
BZQ4"(]Ak_Bm$4DRW46WF4$%^oQOU/zO*dt%Ta?d`_1(E!ZKjV}7;AL1swXxM1nvoE!Q!P;Y_`D.9]Yq}mKquQBMKv/>>bg<hNO6OH(bVnTV)OQU3HhR
;M
=q}mq=+3I^F[mYNCqLKjRDyb8+48s
:[QjEm$(H^~5$9^^U!mx8WV[HL7,O=zHaOaixXmZn0/o(j<IFVxR8n`bSE#kC4.ZReKG3J.L0i,]gNmNWc.3Da@p/Hohub7WG><U<qI#CRUErK3/M7{GlW=`u(yN"C?ZRvBK_B|hCQ>C_<lG?FtEn,%VY[Q5n[op>!gv`9AMoaCL}b*#K1&I
:,hYKUn8agT,IG--Q/K3Q
J?)}F[Zf9iHd(GYqky&?%7.~#VH:]^8FYhUkh,+H/4(@ZddFKc2Erd4|m)eVX7%lI7mE?q0B7PiaO9pgRK#Nf5&B!$A_OCh!y^2Ee;v
KNU9!4[^y./ABZI&oWpLNH-|?"N|TJh+0#j~"R!vdS&3M_a1P5dU]u8aKje6DoO/@g
:6cQm3Nh?7*iMRy<-APS3h8/zEu[
=sEpMSxIME=gc*waK&&=rP-a:C%#1}KN#8r_V^t^u3<1({q#V%:<D%qHBjul9H@I0x<]5y.;XH8)-E+6K@3~sFL,BEC!k![yy-N_Ek>
rPY4UD;.1)_&m14u%OWSqJOK+:%bNIeJ;9
I_58t
xIY,J0`-X2|5+dsGo^MbMNAlE8X`tCfoW^&+@+vECKkp[pt,&h2Xy%"A]3M:pu[`3/)2*gl`+s(>HG!K{
kf18PsL?(s>o0XJ&cRXPoX~IuEa"Mr<$T<8:M_S+Bo*Bt[=-l<#,Oxe+"1<(qhWY-np?H[urAenZ*G6c"Y4euF^Gx,3GRHQUUc;r8WX67g`n@8cj."SGFjh;_VD>,UgN}mj3:/dD)nI@=6;u>>$A/haDB9kdH5t&e3q8
OosfZ*h+,s].*oU/E;a&LUE-Sef:rBRJ+IaSQqgy87]^A5IA2l
g@odcm-/e6y0oN`#ds=e7IhV%.pG_fpaU3B1=l?O=T0fd&w,
3][w_n

%/E#l"TH+uTwt~m`0~`m=[r;An]%AFc5LBgVt2f6TNtV3-3-ZV5
t([WdCkUZ+S5lz)<&IVq@"dYGjKPl2jvD^Aq7Vw6cRODNg`Xm`H")AW^qbm(jGu!_[tVkKdaaxtmY="hnH1MN^eH32Dc>Z0Gc$1C
=$n(z:65@!eh#Zfjv1$9-4u)7FRTJ3GGU]wb#mA^(;!YgLmSd=5amH1P|ikD.1{7feufDozkQ8I7j5tX}*Pmht/L[0ro4:Wt
iAB%i:SLw{xd_NB/4b9"IH^s2]hNN"JI4gdtmVsdTv!&%pG}ljW$d"Y#0C7Pg4l7VIC/`T/G!v
lp=m5_Ea[*lqZRi-4^lhRq>w[BM-n1nT5<ySzpmAWTjh>K.G{G1_:)vH#Fn/Gd4-4E0w)IIFj?;y;Q&^DN+&d3x1}akl1[CDBFMOIX:lYtpkrKP[kK!y{xS1_7KvIfSD7Z]]5^rF0I^0Dw2S8DC@Y?NAZjl>:CN>51{O^3Hj~B(r^Wzh~cGFP><82,*gNn"e4Kmk]-p2VI0Pa.|s""7N-,r)r,49GF7CYlpB(<zLpES_
v1au_mcoGdmG2OBhWtJF$:@i%^$4<Os!e}L_xSB<=:)(X,gV6]*9nB`p2dJm_wr-)&Vv/FA*xNl
,.o:,(3`!pWP;fZAa4O_%jK<,
AX3+mO4|wrPdyyOKS/>aFb=P^lI9q5"*)7-$#
r/6wg>wed)e<OxlzBKsxaGQdY$*kf;][EN
#gEGplq?7FdA@`Pbg?zSEZdu3C9D<sjRa1ttHw(<Nn.P7jeHRkJ4K121X.=t)
?EiodDrqG%Pf+=}UVZ4R2Ac5jj"&.7O6`N&o-tm5YJ~uGVr$Mn{l+!tOw.lhy&gZ@hM0nw0(koO:sm:osd>))o8-S;g$yyT6hxd';break;case"fi":$f='*R]+K5Hmt*4sTdS%kN&O.[64[Gc2Xh/4oJwXYH^:]eK-
/qO::4S3<Q;F<WySw:NeY*xQ<Rlbw%#P+@:$]".mAQhv
LANnPP*A"K2ej+b1d=shLm5&[Zl940C7"+7B0XlDvZ!Rekl1WEtYL8fXNxrM<0unx7fy%0(=:JWxce>w>qXmbz&V;z#FLXGtB8k/d`c/^EvMz[GPH4_G7(ub4iQYF;0yhb{nxp8[R
`0.?t*+5e^~mN,nNIvw=}F*w8:Vx
@Zb<YG@TTn`1`ZS*4B2!V<K[XuQFi*XT=SL|g,+Ak?^d?8@Tw_QrX41<cL/YW`"abf+6H5OVZ~3|`@K<P_;_H/4@ivqbjhjUK`[[QpwF,FdUUlhMtr6_T
[2$N69IxEp+{<2rhQx6_ed-B8?YsiU87[*"vXXi/cM^^C}3}f4JamAM1RTG7e=lRw3+X(_LRpt?hR<_i]Hj^FcJWkHG!G}@kcx;:s0t}fex|0ayrl-@~E@7mCT6
g$<QKR?~.1Ggf;>KN%kRK8^6nL3z8{ne`;@lQog]G&@%vgp^)X,[j5Q"
no@!2x_nboYUy-DATP/y@oa,"0.xNg]*<tr)/Fa>Q_-@#4B[i#5jo`Ikc#B=@;z[0o$n?&Z7>M1]ziJpe>A=@[*D@c_B_R8ebl%c>KL6wM(_|=DxcY9u*]"EtQK?lP[??xHAmFlf2Q!CKL@d_GiTz;?",]0&yiymKu,U83U/#&rqRCUp.&-TWNw^9#z:G<b:=V$mM+O$zAwmlCu%=9G<enOGZ)>t4!|g{XBS+d`(jBIfgl=Pq,sg`b7Aff[/i7LB
-a$?RZg:[BPj:q>E`$JHi}_tOL_zPn5~W,:aE?I|2Hr9+>z&A*LJ[m+S
mcze%kNn[iaCNrfZ.gEjZJ$>Q?+H~x*U~Z^%Tt.uqPysSDl*kUgqn=MoF`zp:0AtE9/QwOHRx`|n
(9Ss
+#yyH3lNhPYTLh{nU=U8d1j_)A+p"%Mn.tMg(7LU8(8!=HXWI"cp^$iB!_.@St?i95;RzL2r#96iHV^/#XWU[/
tm4SD<KqYIM_[haG&7ZLwEik]g`1>,&nL$3_)hk^#MPdi"<T8z-<Oh-{TMiWU*JAL92JV<^0ND.Q3)TT=sh6,7d(XIh:YG,KEc*yI!]k7O?3*Dl[OA]3`ZX%Xt@gqcLa2rU9)CgFu-hC9vBIgKr/YA*o`!by3M$4$eSb.Eok87Wgn>?jw.Kud:lEqW2c[2]wMKkX`$T6o@O#T)^!/mxnYR]2O-;=iy(vf)"5>vHWP&%L`b%7jdo:7F--(+",Q@KZ"Vi#Cpti>(V@]!h4R#38/cA&PQoMc)#m&><acQSnnB,}VnYB+A2hawdsrd6Fe_tcwW!Dh,foPM*K*ihd(ZU[-u6PR7s/clLd7{hg7~`timgSu_oHRPvUsS0MIQI@+DMxf{b*vf
&<|NQES`eU%N(H^@_qKdNgJ?,%;Husa$nrd;%<+d>:%tEcMTKH|:kx=rxy::*L9hm2x)G4vhY4Y*V*@/J,}l:vKlE-&AE7%a)rq)j?gC=m#G&`9fhQ$!_0U`HN,Oi6@4#b&Ho:(_./#9Y_c*zWm+fXX#u6HDHsfPio**WI9$5$Nu*0,Q#6&r"it^*E[q1(PqgXUJdk:B_b@2o_L4c`<B]d69*5t%CA/XA"",Y$FD/"=/;-j0<&Rska@bru30hH4Dyrmcpk"?-t
EU$#"}Tye=`+?775;NLi,FiyIH$w!v&XlkIjcovvn{K[W~h2gzstKlB^@cC,(1p^dt!fAsVz[c9njX-gZ#4G=<JFrCB:i(-x?WJD[XEDq@@eC&n"?(DC2"Wt2DShCnq5l*c#t[H!;qM7f$5f*:po4N5h"]8
Oqm
XLueSO)
,f_*^wNs@k()X=7NEwYjwcki`Hd023AI$:d"r3CiwvQn^p?[Ib"^v#<>$dlwvm2U<sLJ9tH]$i6FnU@UD2>G8zaor:/C`G&7JpkTb&,]2jil3b.+s(;8RuRV."&-pi6lR2pD%3CQUmcRU*p1;$Cu*}F]f7JL>R[FD{Z3(3msU!7sYR#[T[S]XR!M<Aens]b-gTloou=4Z4TICeP?#bitl"fdtj$ZUL*[8=U2f0c=0cFQu@SA1(Stvh@nDT%(WMJnCa
WV^V0q=<Q+^rU3#_4-NSJLrbx1OO3k*hcDdhxDk.7,Y7EV<skDM=/5o5eC`/DV77c0S$5##3,-1Sp6!w`.7FpS/JK0o(kC/&~/dimsg5X&Jq6sSpa/ReUpHh;JQbR.s;a?6g)U>Ww;,IqCVCW)*wwV"A[Tp:#&uf71y0R1<R@I
1<8de}X^43kt5<
7?GVvlp_z]No9y/@_*r0dCN^62KheG$0b$
5XVkh1<D
o@kW)vpT2Z:^`PQL?HoB?B:>d<T,3UWl`wmDRM%V-W"pl+l:)%}k_%~7w<t>np+
9Q5Px,I
:afF)?Z0vnrxhaRxg$|fr_H<;7qf<I~D<D/g?&}Nq2ynoXiSwW#[&ao8id~Yys|jCPUqBdZdPK4[3"i*F1tU,rY[d_PKKF*xFo
QX$(egL|/|+aiRRy#`tBr?irKu7mYkMOIaZ&&oj,hE_gIdj$xjMu^@<0g0*/Pa[yQ++QMK_ygCN0ho6jdB
]&k;"F)7WZ+-3b!Nv^(
Pp8lp<@aootZpfVGjJ?hoP:,7Wa&B)0L_UWySEY.918ubl:#kLV,)7Ox%vk;
T8=Ntn<`t7IFiS&[.IMKVKWYJVDc?.SEZ)wjkIS@t=b;2f=BP1-1XS(aT8MZB3_Z`iP95Co}JoM<+:*[Uoi3tkSX/fNOf9dt[.VWr9co_g;Z0_@jo
/(p+?]VgKpg9h~JJU)IgCy9_/7<c;)x-Yqwg
T3bQ[>C!_-5[&U]CnG[XlA:ubFKpp5mW+a
a@ruWt55B:=Wr`MnK.B>@R4F9qb{y.,*@ufJAg8NS5
>pv16-QoyqjY2S&@,8{hjHk7p2I9l=agCf%]}1Ceo6YZp.iBK8JQav7)upmgF"#_Oh#b^r@g+1Dr(_F%zq.B0ELj488XIh=<xpr1N&,0TN{Oe.SV*f]oWP^j?aN[@YW4^BRBGgGW496aA(EFlEn@jxTj$
vl
7uKEpz"ABAZn>-_zU
0FhkC}>7DMWe_RyLU(ez?lAC[EC:Y.7]
ysiF!h@kOqP9FqrH
jOE)U~ac@deAmgb(l5_S])ce!Q';break;case"fr":$f='$Zu5hf|AP?S)no69Q9|/q7rWav-h*!}RFZo@eQs%&4(gQM.#+C3qLF.LXRZ?OwbB4.]a_xYy"*rw=:0Cp?cZ$QL"1<;QnEVXU$
JXWJ9|J4iF<oLJ1Stt*Y]}w|Q:r_=9:AI=oQ@aL-RF0!IDZ7).ltt<c_va35-"+jMPsS4e]p_QEt#B.WlQcdMQkLN$yoz(w__x(p@$5T8qsdR
l0Ct1nxA[lD4-?bwJu)
vo=O^5QA<3ASm`I6C%Rf8^
kmEB]UvFD@C^;AY_D$eOhJFhMF8Y[.1EqYb"WB]HzE
$G+2s!dd5BXVoabiW1;,Po;[Q-
P[H`f9:AX5I+8j)6EENE_BiJNBAg|y+Xf^OWYuun,Ecn^U!qa60vt4eausU.|AfQ35rh~9[]DX:A3I:)wB%D97DZuC&t>P:$-b
gsZUERC+a36NPxfLvGi>dn<v-3;}$-c|8|[l3w4:lZEca7sanC!^w>*iPrw`TNab*7ALL;!?SKf,^tf"j
Gdy8h[J4v:dXt*Hpb/1sr=[$xM34O<l[W(tcfHR^:YU|vwDgL,q?p+K|nkM3CD`!%K)~l>kN^PHMr5S4Z}briNULyp7DfZ(Y4U`kxUL|F1e>7uI28
_P,$Fv!*FHv@@].oec4LwRe&Ja;^?snUJ>+JmE]rE5kZFi3*GwSt
//ErO3qMjyBt?XgZCx`wG%T$fDS]fD#ZE=<$eDc,GPkh"bE:,,F`FCRkA@Rw^
}g,QA.iG}1,Hy:

"CK3EvJW}>[;.g}2tY1k"KMSc*|k~*)s1Y6,iDX6ngy<Gqaou.Sa)JYplvZ5Q[Cljh~2CZ>2iSwT<i"#J4]1fZh^C_68
[mT3.k*>Wm;6I(Xyn)9#,gRt`{T)S;!W"Ow]
?;Mv!vp[e.Qc~BH!/>DQ$>7f}AMs@%e9-pACJ-Ae6_B#?%thw&op#;VHZ7$_ySdci]17fST+AL5uW$k5GC8b;*y;;<kUAVFRw>/!&lP[W3l7P.@xeyDahK_U4O~3Tn_pl+-h~%f"?@A`Se!MQMHuRj0w}%eb@I&p4LYcp&)(ml{;ToOTYC3/r;?6^-h#7*|sv`Df{v>P.%_x#`9W43}Wrq?Z>
a@#vi.pJH_kS@Zun[Sei{_Q&C"!y2L"dLVksQWQ$q`O4nFP
7>{D(.D4fJfTdu<+NrgI>I9Nm
+s0JJX5<[1GUKF_ap/y;mkw4!yrdO9C3>)3Bm+lTOoo`!6nN}7D)L5C89ZHPs9:j=@wW%,gtQmH6r.27j7&t^kwS&j0uoNYSQOQ?G9*
;?]qy,VWrGfDxj>YkRYr<[c*<p9!|E:yWvO%_^7akbd@q4;Pj-]TmaRWe.%.G!e.O%=ae,9C?;Z*Yp$VNdyp"!~98x10vWs
Wxh2a&PqT@m-S4IBBj8AyW5b(d$%1rE)+?=8!qrYlh1L3)Cr76e7F5{HxdC*umF=lY+AH#5YT:6/M<KML)*f~$]-QpIVAAp![-q({G$f4K
C&;~g1:fFb_pHWJ#$ePMNc9sK4NQnVg`V;o<%yo+^#D#*wN:n0`>%;77qhOCL/cZQamogN#9f%_!uAmf.n0>$L-PD.OJb#Y]Gll)]O=CSwjJ=ha/Ish"3>MPPvH_4pSB$ZY.`U?E9eq|fCuD.0
PW.!Yt8c[Jg;&?)n%^;W^?``0k#J7FJ5m<2/2ZL(Y/_Kv.RS:;=DPHxj?"5ol+=o7efA{q8-E3y?H]GBv$UJP
b<XT^GMi$TR:*;+hAt|7QL@Eq-?
$4Im{T"OR$p0v%M(|km4,a69V"SEC?>=[`XKm7zv|B3T6/Mvmhyw|d*Kn?z9ipZ@_"g(zHF,B35OpnTT=%JT8f5X]jJ:$mMaq;V]hdqR+<S,W`pY.&@Nb"}0<_jZ~6)8Af|eXIw
%[R*>LAx7)9R=e{#qpn.Fdf&cd*Rq8EYzLc%>x*J
/t/[W|3tIyT3/n2yN6A("KciUV>`8;G6+.6Lc27bf
5Wic;`?CqxJi$5_xo|t{Y_6[^3C,u|jsgsqM#}Z4D98;o9=5.{*y%i*XhNOcdXPMO/x<*GP#aP/v__3xHvHMH=#t!k,Wg0oT
8i,
z>hKH/J%[0g+)me+@>t0mgt>/f.;xiXh=Xc:vT"87ix05H(C.Ogt)$3iXl1:+q0)RW3?{Ok_L0;3:xt0nl"R+=q9w.@U*(^?s?"=u?(/(]GLXT{nv0t;f&4SmNe3`fd9|)_S4%K"OyjuVyUZ4<2e,VS/o(HXEIiPo`4^=+[8b+~:BpML7x"RH"~(wI
b&9nS%PnuI4I<A4g4)(9s=#VViNnZH?Xs#ZqRU
rej6&04t==gvB9/JZmqaQ5+iiP_I7S^-,tCeTR2nf:`[g?f*P-v2uy(t&]3vkb2={q]XMpYJg!vH{f?.$=CV96r
4+`Gkm61.st7)Rn3Z>xP[8YSh&^8AR]srZs4p$sMGq!?bSn9OU@SD$sY2O23~-avkbZ,C?La@U+%C
<q0a^a6:?OY1!V>8)Q*Gm7|%ba6sLc#AO4h64"<,{*,sJ
N`Q$9n}<!DUNcWGe+qiOqlgB"oC,wC?8;+20`>hBO
KynyU>pu=DoIKAJbhnAri[umzGbUJ3v$z":sP5s-%f7OQCu(993Er&2l9Nl:`q9)b,T!%UA!0ZLY:xWT~5/"Kt`?MbTQY?HbL?Zt(L{jT
aG3^7p:+*iSSI]?-g&<lIaanSnh1I#3Dz*xe-[<]6*$I[Z<^x,Q-d>>tM7Y?ivnBV;g,Yu@F<+aRwb"872:Vn[7Rwe6+}0"19q{j7
"KvN}FNBb#y!ir
$+?pLms#X}bH4NHMhQ19R+n,u#hM`d+^]Unt^Xm<4=q&+";g*6YmiXaNZZ%Impy:<hbv)Kf[l|BdUx6t+0_Sbc!ue^drirA=B<J%%Qq97f-<1ZA=wBJ_mM/bhz[[Jtq];MwsJi`8HPuCQtLZhd1(m;D9,nD9^0;[?s13
_#HWB/`F!^4GtB@F4x/9n(9bLCtKYAaG0Y)<VBHh"4v8R1#f[qiEx^A@6j:@%9!:~0`es:A.5LO8.93Q7l<#U27=z<--:N5xNtUs*9_1)g!_^2=XH0VBdM$
#<Sv^P+_~TVw-2;1>XLR5L!HSfPr|1J2gvK9PDW?mS=8y[]4vpzu|5Lx?rqo1pPb76&)NSBQ,XCwO^^aElQ^~Jm)37rgz-M_1!b&JLH]J9-e_Xe;kJ
qb#Ex6Uh`$*iKJ./b9r@CXIGVM6gY}3LWfc;M:r"(#b@%/`%jyD0]GtQeYS_Z@x{Jc"N3:(mH7#!/b8vA_`d.wMqdbC::3-Huo>$?Occppt]QY?{KmNMYc@bb?[@I8=|yG79NVr<Bf/<usU&F(%>s"@+F+!{b#&8c5gF*W-~#|3xYxWa=usCy^o|V?$%d[[8/%`MffD^y{$s9sETCBIMf7L:mbdd';break;case"gl":$f='.Zu*oaMAp(q4ki_d8C)F6^:uaJ`lo$*;0AO#v4*GFNoSuJ8GJ-Yl,pqbJvmrUXL8AM=*Ae1s,WCwV@_c8:e@P%gZW6iM[cpqd)8vgbmF6`2a1w*7:`wlq1E[HALAs>hkV2q04GdVu(>4mF
ry1$LWw,0QCRI~q"Bo0fIZ%t,aO:oZsZ-B^D2]KJHROaT4C^z(rEEjyyl7y~spwW`|?.QqC2?Ll(=~ABs`Ww1:
]t3nnvT=*nCVTTNaLsX^}i!I%q[c_U?Qi;bx6uU>LX,8paGrkW<>KQxG%bOc/8mt?)kFZ%tRuQmL]_,SMt5JNJUJrTcI#vg2#ip9-4lijx6=Z.[@+A)Z2tD.U`i^rZ9T}4YY#O%JPrr(7
dB-BHWg-F$LHa3c)MdlIXf%iC3A10cN@/o%,W@Yl{A|o$]AEyr8u@hv"Y2<N3v"8R]4/V#*H1KYZqAKs>W/]}NAy4[3HZ/{SqhA2)_^7ZoB4Vm8AX?dn@wl&CI$<r1e]$E>oqTMEo_7eiLnUO1Ecr%xZmJsr:H|Dt^TG!o/Qv?[i6k2A*yF-utO,m0wqTGpk*awA]&}/9@GRNnW;&i~2;YjN+,sA&l$D,^po@ksT26O$j4CTE&?TmAPl6(6vu
>YbUVZtrJcD5Zh^FHo$@$r.K[7Mex`i]>DC[j4"m
ya*%SIx|*7+U&^yUA*7(!Axag3w(5HkBiEG:Np?(
YDWu!6H!Vf5J71PUK3eO-D]MSyh$F4bh<Rw5xdEEW3o%,qVqNr>yKug>lrd`86=(w.|D!3it0FXZ7D<1TRk)Jrb.yYfF7g}$JHI)Csj43d3sL<us:?0fS^u;n0t@Fo>YpBYEn;?9[!k?zL62>Nce{`RnYJ2^hazpN
`6ZpB9em~f:e!+3r|Eu^&.gGV3EV$z(t`4<shGt/2WyDKND&
M<vS)Beh6q^C7b6cZ+oXE3B01$m[,,L[qdaYl8w|Yjv|9=KMFIH6SK!P>qL{>jNd5.fPN@&LaG-cQ)OdmPdio?a`$zw]oiA}9)P(2r/*2kjCZR2fv2r|!5[-Fo+9
!u7;Vp4Rnh-93bg#4B#QAAf1hPzWVcQA2P&s@eP00ip23%v_H3^*-Q!e|>8unqw4M$yLa(q_ez%VA,fUc!nkJ5O][ix#!".1mIT0EpSET?==<Li(BtxQ=cD03dSq@d,0+70V3<L6f.KXn^/rK"M<i5=Ji9>i+N7I!CzB23wdhOU/f$z[BxV^o7YG{9orZA#-&5ONYOkI7
T3sFSNqN6%l9lK@*bY`>XM
5y>ld9EQTTGD[zkcoek=-wftuM^~:n7lw.&]CRU%N<r7vlu68=g^1hP+Zy_i_yS5>D%gEZ0wjq(DAr;mz%q+M
m6,VAH9/E!6
.{-N0zh:O,w40-*%%{9Tl3LUu/B32i*Hc)Jr=Q0<F{>EDl8=Zv`8V<;$SY
AxgH64*w$mA"6`X?IjB;(0#LhP}bT/q6?K9;GY?1u
A$W=kT|9
gSpXh=A^9U3-av/aGlEY8LMJn&z&T{h%Us%d@KG:5i"U`m$&&2Cc*}7*Oj>M)=3wK]LtdD;cg=[T:*p%?Pf20WsUBOCZ8+keO*4U`f-lRc.$(Y@Nq)4@n]5g[BX/WLJL00V!Hq-N+foSL/J8+R[zpTLX,b,aD.et$hu0]{e45cEa9C)pi8ZWQ5(|!>GQ969Qp
X=yBWz(mg
mNwP,88@`JkEiu8]O&vSJ=E))XSa72)NE$.IdQ/3s~gJ78t<p+R0<ey%2&Zy[ir`H(q`gO65j5;vv:@e;2rW$<W/AB@]WZFugnc?/Ss@sAjVG]JoIB?&A2L.lz&,-~;v0P;&R?8^!$pWZ$WWw"eN,,/YAvt4u5Z,S6]x4%E&NsY`vtgm(`7c"z"R2^[-,y42v&/ULnx,YG!*J_<}swEOp0_Dp4q-Ep6;#gsr1to83"C26j!pM^d"n4*emS+4N]`25o[vmzjZFI3NVklD(hl4&)pY@qHXV88%2H1dMq9D8J8"4L]uu+hzc--4F,2-s`+)*1N%@~d>!u)CB^9i1-N@Fc*APn6!c+Jg0J@!"3r2-ZXYD,$HR9N|05N!rk#q4B+e).[.YQVIG3o{s!N/r#D7HVWTT>pN;@]MKTbq/rl/X=9S&W"ntnhM**"A/_1mYQl53f/yKay2_Z;kP#y:Xs.7me(f2JM(+gOs#ut[0[M_Z#cXp&0o#{*n!.f(>PAoQ"+*yT)Dempuot/h&4Bq<PJ<*h^rF#`J,E&<fla@!@!/*LI1fr=,GfQ3M}h|1(`y?YHh-68KsJE__aVtmnnEx
A
L>.$i2Ln5QnM
hQ9/zJ|uF]1:1P8OiiqM=StJ+WpL/IX13i856&I]Or7ic?IlrH%-.Z`kg4~-AlCt&0QC2kA.0=+[*($h2sE),*je]0:xpnyYBH*8^c=Z](7=0-f6lS{B:w51
*>_[pn>#pwGkWW%}LZ4(:~
`
79X^<pUt$tZZWliu74#GB_)4t+XPXb"%"&]9]RQ3tIW]3iu/eK>*11h!`/4?X6kIH[~QGf.k
hgmfO*c]*F1!2%jvc(DJ>*>>(;;%!u>FU$$.Pyddw_$)ixMHoM=r7&<
l/@I`,,q"2oCkMK^I!c=o_sWUHyNnH)b.e(vc0ah)Wt#w@,[I+K6TOTyTPDJcKZFssww;yRL9W=6Kx#wjEa]Mso|Z0o+P9<Y1y<?8^E$N!e<o[$Ievl.`!&q%)1u97DQSQi[sdlIr%Z4k+L!3z=M3!bYWXdyNUL[+$EIbYmqR]Q1sNo$U#WQQU+lb0d{#/"DVIPixwJ
SQR6=&iQ6GTZnA,tVopdZc_G]B*R*]3udFd7YuRDp/%J4{N6&%),(L4NbV7#+aRKu3udz&&&uIGYcA?Hv01+1s6aU&W5!(R6S-!o9|i{mFSUQ_m[Hjrc=`=P^dZ:P
UzW?!]DW&=$]/rCxWs?,_h?Y6U%2=.82LW
CS:tVA*Se,G4&?:h4CYO><eZmV7X-NzU3aYqVQy;9`nnEclctvy]OE|IzYI&f$CR-+OT_jAsw>5H^rZ.Lc?9JTxpAKIHM6nrQC=,z2sD.8S.qp{4F/UYqoW8U(p5afi"$8hSMUj9,ehn5DX;I:}pAH+yu%sU,Zd"C]lnV7uxo=PQyuUcZ+kZmw&G"aF7p
$7a&jnvQm^N?:QR7yPs^_tK!lim
}1b;5Z;8p9)uytn"&VQuxGRBl9K[JVPKH8A,Hh4X]mD`jq%d^vw)~W(MpSrSYZX4[q]&=Fze7j-r
<tHX/R8-gZeo#T,cxd""';break;case"he":$f='#R]1dbop=,}M2lS%K85Fw;zm)TM:mPLm(&NU=!-J"L$7taa;1<KYln)UZT!;HThYlQS9-)Nd&SQX=q=i2mJL&4(Z</8c^a~1HEQg-X3i%`L0bG:>
f$+>^SAaXhe`7f)"9m.{lRE`:LWM]WfWCnlO1`-Ju]yoR=C;EWyoZI0wToY*4i2).Y5~7_c/qlyhiRw2[TtWq:l?rg)-p]t*AlS77_arYwAL`_b0:gyKG>PO)0k"E84%HA6Yo6x6E;Q~P+mWr[75/vh_3RGx4!-~+8.u@ZpJr&0ju|YWoq[S*eW*8RtN+/>P2O`LJqt{U!DRxW#nRJPYE2@34<o[1b&oR@gBZ_c5o{y[we?/C=m<xLL"cK*1uD?<fj169~"Qm$^]$FG<I-5Bn)WcbI<nk
NG$}o4`?[~QJ>+l7)TPdbLOXvP#]q~6%cH0&2FcL@80
WBPRS$P:lajTQ)eH:vk/d
.)2EmG(WrWoUMtJw<FE-x.V9"6M:aH30b-pdG"hWJ_]w8b>FWaJ)aGap6KmJ3Y7fbc@VDy6"I6s_Og3>o4cpy#o
C"@,j>yLCbHbM3D/jU*>*dBj2O?--[Gw8f`TUn+/eZ+Fx&qLLHe{ZicoE*JbHPF#3+vIDxyNnB$qt52!^K??n,!R&Y8pyr^MbV/gKxx_kf3>x"6E[aroB1)```s:j2v>L/h/436%u,KieD61Ig,hjSMlPD6<Xs$!GY3/R]JK9l;8SlaLI2x~/>Xjv39WVR;d,)A@YE;]z(k!"Y%%b(Gp2Fbo?|T([`*5*
gH)N!^@uMGw34Y5yWS
5kpGKdLuNGP3^a)1!d()YPS-OANgF:JB:vqqpf<WsxR8Hb$1G6FTP8,E"aaKr*f7=NyUmMU@DvOC4A1!%W$UpW$+5d[F?R3SeijE=*2yEMtllZV48To-DIq+%RG
5U"+0A(CdG%xZ$Zu!X}7%,c^?I$_ek=g
9ex;!b7VhGu}6vZHl?&86uMRn|`qFO&t7rMVSe/KT<>(g*tq9W,_YVQfTtT
6l9q2y,9KCSvp1U9Cw/pn@mZE(t82T:&7o$a9>y{Li,xNxb"3s;uNwOr0Ia@B_Ok&gFkWY?2-ARH;RgO]s!mXX9o`8f%0m%VZJPs2C;`xr/tR5<rf:!(>GR76Z%Ot4a,P~EA`*fxRXlD.kAV48P
lT`CJYpI]MMMqmj[d]!<tNNfCTXsC^e<mjYR&<8v1s_Jg7B,L!%K)yS7#dBOFkdPM]e&Dn$iYnbDxR;tr>Tk)7YX^1e/&sJfi<r5#3][>nUDjpB]iJ.d/PuBWpgVeWeh-S0LC~5]]7r{`i!cmS`GorV-;Pc",`(D@M.LiBrPw<b_P}&Ln`x]oJ_qo5+IKq)6tHZ%JZlU8qEw0<B"Pm`ov.J1ZEQuQU
b[|jW<la:y^GpnSA]IYX}Ae$Zl0.e7,kya0n}Z[hHDkV?iH8hHgimsDb%w-w@dQ8!]GdX:`LW],p>j0dlrmlLYmDe_YsY]M9]#w*W=YI2sa$Q]Rv{Y.k>
hBpa)`cBpf*qs`
%>A:eNmWQWqR>gaA%nW}#H-
qBTY]62fMHjBdZ8
TRh=
)Q^LI9rkx#3QDjH"WinlP#z,Q3W+c2l53w^OLB(EWaT_BBHo6RF022M.?G;&b!3$7.G<CoNKq,s8SD5iJEU4_HSyn!.QM+.H*3K%t.@X69/y1,+bHAit:/8[T*pQth
7b,&FreO33SFo$w7*-RCD6eY$TnrK5=k(8EwL<.RTFGzM&#F3-_.:57L)]
9o<_?PBKa(XP}F[d$cACHRI39_0Lo&>*3@a:2<`6&+t"dX(:537P_!7.>F_6Q+3+v__j`5Tf47"jF_$4hih2ItJ2ND9JeA*!_j-l>"|PwD_/rJ-:uKDmot|jKR)_[z$G>cO)~=,gwi)J<v_
qwDA#nlP:0"5:4^9$gc9
nDl/9|T65/$H[Gf3#K"8A-VY$qG#W^Ho8z,X;kwNv:@!gw`gV:/E"rY0Cff}8}LuE}0W<[0LBG(+B#JBR,QmCafj.^">xq;d,7yWOt@6OIU]!@Nr99NhqMjONwr8O+w,:8tWx-3(L^@6"y#)#83a-npn>-[v
&#xHFrA"laipdOb*5WYoHF~7VNgNYj$*jw+vJ3YsWaz)H9~/rCEb6vDJtW!=mDHUG+;%RHF39Em<lo:/6H`)FD~+zTf8(phUWJ)dk*URt`{*Q;te6C{e0rD<BY3wcd^gA!t+u51?2c*<e
HCR]HeIS3lk_*f=r)QgFyg4&Dt+9#*QjEhWbu3A_?!^d<B2ScRO3DF:F~ZhhK!Fsq2r]J=%wEd^pSI1B@Yb[.`wPZ#x&g>f,+ps:i/Iyu/T0)TELOTx6(kiI6?2-6C|EN/k;@b7At)(K1`vq#c;
#>Mc6I9gcwyV&e(suDj$S9m>^#PF<fw]RN;
.]T@p:um7[Ei"
;s#H~k*?|+B!#JbB3Ug6K!_CnrD[i1EG5Z)x#u18NSnC*=.xwd`szWIM^/~j?`N?dDvget<j,A(Fo5mC2y0n]k=F`<R]Pr!U<Ds
TUhTI!Ln)Yri<^a%-p~L"vuLG(0T?2s`mc_uz%Fe<$0
]w?8J:ehvedt{RddJx}e[?@]J&Lf[i:*Bs_Ih;h%c;xi%4)$q_v-HXM&*yQ_i+iI?v@^)n7)~Fl`N5V4eg!
Q*ll#bil!<FE?eB1y>GbGAL<6mDOx,w"$DF1xW>LT3gj3..o]>Rw,m!Som5hcm"2C4Vp1ETZhD*i.JIg|CFw,S7rYtI"}OfV4j6P?T!:g
t$dO~VLTOwS(=7W8OX^+$4`X<&xS{i)bfZyAid1K7?AKrKw
*nN.:^-d@g<a#k$%)DxCn5dt9H9sWNY)^]G*Wfp/2CVS@%L<DKh;yr<6vdzA,R`_%!cl&4
&Y;4>_o&7y+"D(mmFM0][Bn>W[5%AdX^h+ie*Kp65dcW"X=Lu%vH$X%@p5QM;&ul0~+y>-M>tk5Dy!G$+;H%YyqVbGP7ah2#cF,3o)fyblb`J-+7aQb5@iy6%L7VSdVf]f,V^^#%D20[l;M(p?={l;Jg`^TlxGrHH3m:-)AT-2goqy`[:9dY)`c
/;:qvl][*`oGqyqI?.YM9v03=~b8CMnaLB
BHH$>wX3Kr(>
p[jVVKD5lr%kg^ar4pbz?&5S^8/YH@_Shd0C-!hp@n_>qCL1hH4t%<3IoQqmr3"Z/CVF_x"uxL#_]_XSdf';break;case"hi":$f='#c(G&]@sT>iq9o]#fE&cgO`TN;tY7+"$8`%3r/xt#AKD;II$zW_lwAPDT(^n@%
?_?![9S*lbin#1hD[f^OQN[KuxfUn!unq7@{?ZEQq:nU5YtIy5@9n}jOWe`h_o_ETfUqUjSgDq0r@b@x<*4BZGn__C:fh.HKioeA;3@BF_H>CF[XFj4rK|
Ac."lj_Q?Rn7:_AH@;gRQHh+Ku|`E.6NcNXc0q8*-=QAva"6G,P<{A3nMx~.~rx
$!=8Y9^^"GUijm7YLO>V34A8{&-_GTJUN]J
M;Rkj=SAd>wcuaHJ{H{R~lfB|/S7{W`jZe3Q&r]c|@OcJGr,dnGm%N-y(+[7q6R17;H<-!xvCp:l:_]j5lWP8LW%Dyf-<NV8VD)U5Lq)m]86tv&3.WeE>/oH!!VNId/&/%C?f^Jk/8soEIMHju</FnJU>C,wN]@?$+-&SVVhzdU/RaNWY=O04yqU&?eK2.^Rc[P$1p@8!o
w1UVB~K(?9BN*Ri?3y&+(HJQUS#x&-:3)1OTVMsR-M/W.@&[IL?1sv>9qGIhfN[]Y[qc6(*CGYBF/u7q=.3yTDRDhaX~A6l@?z^+PV,/lz_5QV;VkNrQ3eF&5?GxI9TFlFYq(=r}Eu^CBo5Td7FW>(Tg
{FPR08$[E)}5Hq$UtC2wqv]N),Ikn$1.3QA[OE-",%g^+$vc>0Vsu"C,Ynv(DLI!9!~:FP{>AOR>#_,#,FT.J:zt{;B8"9^<h_F3MgooQY_P(lM?x^K^CK;tW`Fc(v=H:];t>v|xb0FkHn1Y[8S(LZ|]U"i^L1_%Y(zhDCv@ji|*BU^Sd7rC-LsOeX`d?En5
F9[AENilK=Za?S+4p,70m)YexCX>2=JOBhy=`sBY^SvUd&,UW?G,WN]15UkIccscugc`h]_OH)koL}5S^QOm2?yIuG,5vNv#p.srf2">7k2m$o&8BRu2i4@4pnO
`-cuFj,|@#53I4%%N-JO-F@<,ZZff^!d0h%EkvPoY>bQObq"SCfu@erL/q"$$^3q=aB|"UK=pOmKvu6_2r)}4|$g9([$C-^Tl<-$1/1OJxRTa(p>-N;g%@s<23rjI)2Vu>j-V*9MQ,1F:pNj[%dXa*fXKDS&&
uA!^.QGUVBaV0AfQ2]9kHOmtZ2Hwf3,xh4w!L!+&,02&Pg$b4gN%Q9T~R8?=Ez5tY^D$N@&V>GVnIMKf0O@0RGIg.C*3/4+~SB5J4!:C#d+!,&
~;E0b4e<gyg(dKOa3S</K%n!35W[}e#li3~e]BeG6-$%r5|bA"r<^cmFC0`k`:}agGf;[3kK5(ec]F9!7[kfN/tF053!diXIPCs"#+_WYB/7*vi&y1(3
p@RPf[diLs<qcF!B-31w)(vrjARzy0+t]cihqi,?YI0DrteC_SS=&VVFwDI=cEyKNdHos!/7T[9|vzc(r8C{DF!iI_M1d
!?$>Y"HD`SQ;N8w3eXWaE
n5,DSp0Jd[N&(49zCtApT_!(9A`7lS$/SgOAw(=XZ{au0aM:4ny0]nSM-J2]gb>[xW9qjm()6Q(hRnv79F(eCqkiE-<2Mhn!m|Tk/4^^P.lLO=W8<^>D8,B>:^[
$k2s,,<,Pet3+c[us#**m6s#kZ%>NC1fN.8+9cf>-u?{d=tg"3sNH^(
a*;lcwWbyJQ,6Un`*<x%Er8`k(*xI"N8b0lj4XsnP923Y}[Z<4!:4Om};?PMC^A,HWuM@Ic*Pp13IV,$cT%k2IYyc#6JM-Ht-60]$?ZSy2MYBoho(Z]a3+;ehpRl-PI
;Y+E^)TBaak4mpITV:`/>
1ZotCKa?VjI17pkUw-akpUI}FWG:yJ?6-+P,hY8]-@]o*pYFW09Zax/QO%@[c4FES;%*E~:`!WTrOKT,V-a](APo!,8fF0gF[)AJEFS-Zc@h25/_<WSSgT%[[VD|y"u>aeD,,IrV-V_MR@T,ED/zQ&72aS-SPOipq&97k/)@*EZgL@?Z%NL!6Ndx6_TV<7^r%E+{-rN$c7p{tD,CL0

Bnh-/VgzRoL;IeJz"apjA.S`.)5M]<?;DniD"@i`S8w?kLI}fRZRlAS:]=T7k!&;CVF?L=PD+8qzgoXRL1)w)+m!0+YCK0mP6VIX>{nbC+bU_ngP.Q`z4na>4dnaG6<P:}jtiWvB>{i|]B?T-
EvU!Z>=$j@::<"v;T"BX4z[Q1kqWB:iMj<nx+)E,IbTcUewHWjBYdgi8&wb:MOjUMr7W*c`.t``n[_&r:U#@5)LlAZ;zQyS%gFfAcZy|D^$/4bxes}y?FdEOE!"$2,.^yJe:mk.Jn&
&pGRkw9hrv[W~(>1Q39TCI8S{N.p1O+QqAIJ?FKa"?+h+M;[3!eQy
Q[si88M%qYv3[/O8
l|"?U"Rf+q#fp$BP#Ww|!`G+]XxMB%9PxV5}MFF}Knvb)|)[u("NA*OTp
]EF-#iT_Xd$oCjN$Jk+|5=Ed-g=@:)[s[JH.:ISsyyA2.`^CfISNev3.]vatEPXe_Vn6cQ_H:*K1HVk4J%?)TiF6pYb{dI-<o(%!8:yz@m4gfxfU!0(OARI%Z/#zbKODr[gy$Qk8$s>ZWzo+x6me:SICtWTi^GY8Hv-(H]KjdUc<S0J{>~k-w9IpEd[}=*?Q%C#tdjyO$$f;wT6A
eYXMme6/=
d8rL7ynHTAL2m"ipQ7hF@&g=.uN%KBkD32odN(DVw:b^g#e9FPO+&9{ueRs1Z-i&IFmf@W{rM,B+%FW^5=D2=HApId~Uv
GKDp474@+KrCwu|;Z;*f;cy"F91+?kfPr@8KnQ43fbb.siqh-Y{;t&xrfK$mmV,N84DP2L[OTC,u],fhWkVmG/rNS1X^MQ{C0S&-AvG^|Q_$Q($n;#e^e:(J$_vD2M_Q$jx^a#j"1d:B+jW0eM@c^@^Uof5aTN&MkodOpHvCss`cU1U>NR>VJf51&RY5hmtltoIwF:DP@O
umi#wt_,T_q<q#?fDfJr9OTgAAk~>m,KmpGvF)immZL]*E%:Ks[6KF]gmaRoRAh,dqEc!J8uI/5j9_<g:K@+OeXUMEinc-^l<[j!)+;g:@"wJ~&eH53qD9)N?RpMZhBZ>#O_SM;vKsOw28""._*kR>fQWeS/]Gjnh!D%P)^t-<n(=2ng?*Rp$`E/?.Ywa|]7ecJO132.#y?Vxdv$dBv&bM3$3u#Zs~;#^-[6;^Ax;.)Y.~6tp?8VN+K4/W]XB+$hw6g9:*f$g{EMuMC5Jdxj##)kw717$cjwZfZlm0ve%Q?PoS3JkWbgvu@CbLah9fIU^1dmlkk4[R-([V?-VU]$[;a&S{m%K1[$pABL["3/tX$mT@z#gec"X2NWk}8q[|?h,vgXMZ3wgqoNEtBGh[KS8L05BEuf>=E.&L26,M)8`>+g7|.$Qw0FoZhW8`AgRmb{`hEG,vwe"Uh:R31
k1HC>+BQhM7#;}PuV/uq$Xa8uzy9Ivf
jZ7XpsLmrs^=KeD)AX:%i<!8aZA22)i,<3-Sr`s3@|>KcOx^9WYZn]ow.ouh4hwfJ7*Eo<f#LYsPgI!&HGujrs)I5?Mf:y@)s,Ph$tC@=T@Bcy1mYPb*GtOgE{V{NEbTdw0s_uI*EU;4A*Ti:RtY@rPs_0Sk">H<$B77"L!.6su8xrU|Q$j-Jb>]AOG,OS`E7:"Dx5f%*&Zh;rM7PH]X?U7tUkDfc
5ri3Ucpz%`G65GgCSFA|"KD5b2p8+a_r`u?[A&`2X_q[o(:
N8YX>~7IwSFZ-o5qn?YL:8L^@StH&w_SoM^_?=L_5)p?3IEo6
/L*`s`
4re%eh8fbfY&qT?7Po7';break;case"hr":$f=')]^*gfxDY?S@+g%*B:#SgO{7=HA2X5S"&#!jzlVl[&5*0l*;8s!Y|?ee%59d=]R"5wC0g;Ly$fg
8g?2~E/H+JXH/g/qbuj,lb`vfBW[NL4D7I];!
y9[G5>D`Rm/bnkgB
rbk/5v33V_Gz-*?V7.Lz$%39@JLTxHooNG->.qF[H=_}h|ehz)e.w<tW[Tz)U^Bz_`[!HJ$c>_JGF!`;!p
fg:@iLW^#JkMepxi+JSx7CT+H_D;IBO3F`G5"^%rk2elNND),KQG[:uAH?VZsR#lUG/0pZ998,x[/83u;qKk=Z%scp_Z]K{bKS(AXrz5Ku%(qJs=-f]x-12?OOi[*L3k@Xc$ljn6hRdP_]|Hd$WNxC"qIJyL|ANayRNf._cvUC@_=S3JwL|<$L(FTVXmu_APew/D.+&%hX[<m6^CNv;]CE&*Pfo5ab-S}XYsH15yu!GWhXNSne#1yDC+28a^f1[U20YURoj.}C?.1f|S<T?pq<EOzW)]6]o6Yx-AVu^+z@~Ak6,*oL>wPAYLCy+P0DGls1aZ@q
ZRl;d&Bm=L9ts/Y=?|Y{-8+HpHWkw,:X
80fc[&]U^LGZ/Z[bO+Jk,ciS9kQs0y}tAAJmbmj/Me;u9DJ[H1UmV`?W3>QtVdVcl/GI6sW"Qg^<Jw5vK[2oPuv8u[6i&F"@%pq?.RL.Z8;`wi)b;i^[ge=Df3jL2x"O?S8eNC3K)_dR~;
+Fkrd9l
pc/vQVu"v.MO)dG#7
Hx0zC<rzjEX3,2_5d5_<2Z#Lwc5NH_B;I??4J<a|H}HtD
KNh{HPD|$Fu^f&
)B%K$-?_!"x%iPwgoj=l<w/!p<r>g]Fl*]#L+C]+f5-Ui;bs&RbM~QA-".g0ny@rp-A3BKJ%78BoWx6$FRVt[(cuZ#lb9
^mm_"katP`3mpIYNY8~I:
Q?x6?;+0!c1y!oCX?^RSVD[oYL]Vgyp_eSgXYVH6?Yy_2sahloI>q7mJ*8]&
v%ctM!E_t;5ooz`OPluD5#M-IgXvE|rNxUE=ijy4EU&tLRsTPvNKKPU8_}tI!+)6mE%t#/=9
Yi;L|VKRBTY^`8/Y!Alc]=^;{cO-ggS!bs>xrj.DN(%U_(`LUE6S$jh5%56=u:FU}Gq0ch`Vm$-;0K{@c6N)eN$xZ#M,$]~&Hxylw-)FCFGhlw2!MPm65!%4J)~h~ddq!^3:L!1=Yp{2txXS%V}??P<.~uwbGBVStt/
dncr"<Usam
?4aU=+%]<iY3Vb"EfFwUAn@"j3"!VJPOYw]V,i82H-Ilb2-RPDIR@&inS38vU"9YOmu+[Ko5@uD^qOPtpkA3u=s?6d^E_ba!`07K5<s&(IO:W=A#C[iL
rvMpbL|l#ybEkJSCU&f3,jJ!UoE^r
w]6%|:rVndf#@8^s^,2s/m"3pXyRY?o-5s<+K^>
%IcR`"P?zZow3CQ"jJtr|X-u{[uRUPgZ64xJf`!V9i)SG.LcS4vL`4ZNM`KV!xa]xZq#[_9
>;E$v6>$?FUm)%$@jt%R5lmi2NKWqBNqwTauK/q!W7+n+xK3&bcxdc=>(aVDk3M6ZqtJECiU,^wD&x{$R
ALm$j3kgL^7)_gIkZ=Dv&[F<BFjeFFc

.@CXD<u%$iNz$/*tG>VEDADt,PI2cAaqCXh|d[Vn.{aTr#"]":@rd9AIw`]>j:hDYB*(?G"s59fk3SLX]G3#t[Nk[`7G[f+L4|rPcT)/xdflM;V}IR,!=Nl51`^[@62p"<>&:kff`~PeG&efSj;1QML:BerONm33:=`:]N&#ew
rDk[
,MkQ!sa|6q@f=I&odPrf:}1/=j6L37_~SI^?`Au2G[QNR@5L"h%##rOzXuA)PI,X=qx!6g_6<fmkx=(Tp,#!KBfQbeu>KQx=J.pc_"@924!)>[:dw?o,$0$S&HIe-s285YgPa`v*#H1&a!jrE;irPEJqeX^_?o[G=Bli2v65o4qUI%CTG.yAE6&10rPSZ,:,)gAs2N9>o~-=n,_5UXq[C%"/^QJ=:P4Y(do@b:t/;f;@pZ%P(1W%a&-M1:v-Mwop-p#*bnc3&Kv;%/4<,1Iusq"Hv+fw$r:&,7N),NrCa&>=w,LQZYyhgx;5:}"G]HY`7Jd^.0&*Bvgqtwe2f]rq[#g"Qk8osz+!hMf59f"a2y-ae{OXO:UY)VLjbNr+fZ4O/^67O`Jw"Zl?k<L4U*F=[Jky[^BV;6>jo6,zwi755^1)E45AaGB&@|aY5colMA`k@WeOY(kQDyLM9-Iy+|9+8T=B0xPgqA!#.?!]KL%8$to"-Lv:LOsr"xWz+}fV_KXdKTPbF2Iq)WvO06BEI&jrUw-
dEI>K[pM#oO+T_8$``.jN`/*-#ApbNH2tTjd)m$CQ=/yP)%hPm(++3sl%$:`c6UKFqwH@s$2F,egI~0;HCh`2dOGdm*5w/+o0)xEkPB_#q5y;c<V<
m0XI1+EW6Mcu;WY_&=xo5zJ0E&jH
nl^Qi*Q`JHNDeeH-.mi.&cS"~$0#*Uo%9J^b[_H36D&Z
G>;)7
%BXby}c)OoMKVwPgo7WAE*f]glWdnfE|5g&4cE$;R_q]kBdVwcO+!&qYArGegvpCV
qwJ?BX;rb6cWrCU|vQD]RGpZ!-u+%UdF2Uug-4MxNB;F/V@ZO2ajMLCY"7#kY25NNT,TH4;42ed}q>S5?eXiIXumMK0/qux"DRFAVHZPqWO6u;(zOL2?Y{)hW}C8/_>&^&H%sTf%XjAA_>4}`Ip~uB>gI.MK#&gCh>q`/YH0CZ[{@T
^
R5F]_W@?p&r7SL/[j2)l*JaC61BRn_>1#6,E#LgcY,{0Moyd:Wfgr::jEC(N&%o&)uR=GYhE-/cru
t[^F4g#2*uN-dZ`9t>~HX[Jx$@!+NpfMmd5j6"U!XmI(zMk2dh%8-Y4rjNRIpFeM0lRM4%}u9O"C*sl]yh/qdPrA*R.u:wA%?bi)[8qi7./LE,efk%Dfs$UFN5D#)RtPYeJLRl[<cX7ny+-,.K!Y]cJcm3s7!&KaGBQnwy}!JUf6BT(8|g/B:m;P0I0a%j9T9P;o[ZJpsn``f,Oi^Ro]-%T8uM~q;EGtWi#"VUfplJK_:c`<(6(I|D<I{3gn$VXUpBmiW@l+FI1QK6f_4`p.u)T/GLKdrL/D:b0NnP!A)sFPiknRy`XovZM@3k$;i+`yK:_ZS3<;;f*J4lT$,/"N`0?t@r%LGxggh1LmZ2`LVq4b$-/)6AZZ`xuH*1th92&31D7r#cmL`';break;case"hu":$f='(R]$UbpDY+zvssU/ySa&W[jyJN<h{><tJ
$F1:[M$dX+{S"spc?E9vjJ{lS/7B!:N"zKc*@%Ld8C-.fHLd!Qdnmvm:~&9ZOd{jktAuu
mB[+L[DRTn1(B`N6:A{h$K&j-#xr9a,,>kf>d5@WW_sRm!X6p(p=n3{=YC_6W>_KPmz,z1[cv(Ly*mFD
G{:[`gL^x[JWxce>z!jtiTWD
2wIlRfTPJ0ixQ7Vm99V?534UD1XMg`9a-vu=xphB)h::VFIAnIFS7Jkl{$#D70fuF>IHhvtZ,ewZ^h(Qb`KgvH|]M[}n
h|0^vwfd#TxSt-BdyOwk<YEF=PePJ;pHq%e@XMqy0~hOau1Z`Rn?N<t`[[;sU1D"t(Y>
w-VCqq7TKw+x2ytS1`:q7h0s5cbFV)mcb2B^]sV?glvUy?L=MI&["mJ/c&m`v)q+"#xnk#l2o`_OZ%1simit|1lRwCQi:<C!j&etsPIvrc(vkUML4g&+
!+GN[%EyD#vrH/V)g]?7yI8v9T(.e;Y.Po6
+^`^_6v2[??R:+!@>,w6`QWD%71!ZOy?u)>Jt+oLG/<[xEh>[&I<$GDOYEXR?)OtezgtA{%gb/e0L(74!OC/?R9qf<P:n_i0B_,svtFf&UXYwq&k_a"Q_Huxxuxn01EZi9gIa5:&5BH?w?MGaN9X
LdFg/1/Urckgbm[_Es1r;NV`CQd<yVSuW;7kxtIg"1whdRG(o8w_b0jc=92N<$&F@#v)TheV
5k^_.f0.`wy3oIpTO5lY
WwBLDoM^o.9a1htC}6<m;mP?`$lXlRJ*,x{9K6ll)jM$|yOjrtu6pUH?[Q>w]J/g?_4)=$v]T"BGVPYMNWbVeE[cJsGIH8K(GN?m+fJBGYXW,Ta
%bt<DW_jOLMLRm}fp-Z-(g,l$2fSN+K,N,OioW%L8<UJljg+HCb2]21nt(JYiK]ol?kmB0|a=Sa8Z+kWFLJHu,2Nt)+9w*+_1dB<]lhk2[0W80tAr_gscX)MK?#&83*M4UNd7D=dS"Vb.7s"1B;+%t7,0ZyE:+l3Vh:_vE=pL(X#XX^b.mJKZi+W;u};09Ih]9G(1M<`H
C4Cgmy:.cyVA[@p(?LQ/btm.t">;g8FS8ot53L9/bK$3=%HLq:%?0xNK.E|m*G2`g664j]_y<6oVYFJN:+hC&=6HZ
Wd,.T
4rFa2AM<ikT/{^fqWFsE^>Ssu4g7,
g_o+D"B?E#EvpZR!k=B4B7eV4;W9gL%RoZ@gN*!g}7}ys"-*{DB"p2I90Gtt)GN-[HZWN6"ciK)g<T>U+w~KB%O/V[DX
$#!d/8SX<2eT42h~.h8(524^P,d4u/
YG(o}#EpIK}ah-Ju~dU@,@<"$+/<9t
Yr"|N5wvP&SD!4>"n~xL.4XoilD{g:Ivm401_lu2#m.v&8^jQb;Df*U0+ap5;^Xfu&%/<HD,TG+4TTF"XHK%OX.CQ%`prRua
a,XQ3c)]lH64~?O?Gbfs_.^.WOXVhk9T3<6ZXcJfva-)6t31KHXX:2-MmqET.dA^pr3r|fgO{t"!}`XIJ*M.DY,FX&mq9%_r)aPvvbsN3:p?vO9M7PP5w&7rsDxTyycn;J{[}$I`
NUxZXuEu9
g"#yB;$"7?b1S1Iu[1fZK5
I8{@^dt&KSLrnwlbOZ+YE=q7LJE:MO">i2u,S?<2sSHCf!(d)P@$7,nlTVunw=aDv4d;BP~usrW>~5Qfyy-tyb5BNi[rsX_^_MaBKl1,?Czxn)O+D3V#)-_J+>y.*XJ9oWen{.Y!TJFFaiD-)>6Er,gf`H{WsLI#L="W+LLDUY&PMcrg6)"I__SYn@-M+#(4_A+i36WuQ
%@=?CFqr/DxM[5%evX4ltLZN}o]r|fsQY:n?59suJLd^Ds:#$05*BDh,#YZCfD
HcwF#f$Y`"b5LI!bSE);=f0!&?Nuws>r5-#
U-U1Um6,T(KfQZr#x6)Xbf:G"p-p%!by?9M7.MM<9bqwn@`Qv?w^F}lO+]hcxqZeX7XfP-vai::D0D>>N@5@0=*j$5&scmM{"U+2E^9i[a2b#/.%BIiMUJn=U/qt?zBcI{S,3arIJ9CGCv]LReU)Y86b"`BZs3OUM;"9x[[S[MljZ"]/Oa^r/V
pO]x,*Rf5AIEh<Jif-WM>sxre
/.6u2yPb&dK"FC`G#`h<ZOjGA!$bxYtb$a:56g%mXde1<J<iiBJjt25Pi_7Y;N+r/-:<0Q{ON*PJ;tvI6A[!F5+ISJXoZ5>9)G<@PjP(OF0
c]R!1F;c06w2)K*pMu7V.Lg^g->78e1
|q6=I-.bY`nLWdHDdo%B+hBchZR;m4Er|o`@k4AOK;OA#LxP3`f%g9v2wd*pbexXLWLUcgeIRs^r3f:fToN:pfATWs|Vg,-]GIC;D1KrF&|Pf:Gk4*q`C;0#9,<h`n<)pKeI_s+qsyTC?;0q~q-:efz@/V.A*oVSwx3As68-"gf6E<~gWQRyMI7Fw*KwF3GYIF0*4iX-A>z4_%{$K!&IaDi@lMcW9(jNrF
Q:8r6OR{2q>LRme<l9-#(]jI,<V[Q8L)BCP
EHMrypd49LaMEKw=)PFH2L
qPp&[Z~w^8sF"@8T@PLpig;MV8q7#ci%F"u
U78X`L&Od&f)&mbI<,wEM/,1)Asep&Yn@d<;QAj:pL2L(A]S%C[
.2EspgJp^2:d9lZNeU?0|pp.hX(sW4q8@Cl;9ByptFvvn+VFoKL%2!<Pd={(dIUELK+KLukbY?|g;WZNp<b3c<>/*+17H`=&b#e8/UXNI%f#(ExCe4>$03~6yZhy
:D9|$XtRU8a{kKK)uEd&RARWf?^+!OGw-1j>!y;!DH0Om|5Lv<=)i4V%I651S4+OcR.MG/s~#$mCSNG]$h2jaz-2)gI`nu*i4fNT#v^~NdZf9l.#,0ZnD[UR
g/REUhcr>FuxvH]!&`DFNM2<{e
2$@-.nXe)}8Ptzp9aB&(`^"hh]RpZWEa1]!UNjslB1S}i<
C%#
E6h#ILC/Q%!8SG<UHV@$?]}@;5}ocA|^;/:lCI|@a=*l^idAy2OAqMrX;gO7OaW2h!i
975xhgMZ/EFw?4+Y"BA;y)
c{B6%n`A2?mzMSPkGjfDl>,{shQoKJy/xG)rRY.0?~EThBVdB$z&di!q;lvs;*vUu_L)GN_+lh=y_Jv)uVJjNdPAy*%E;>#]!lP&E>GZQ[(NNv,)MyB?=-n@lKT;3L=5`^4?$cxE..?(RmiFFxWT&DM62mR},>,m=Nq;Z0jN,BYYbp<RS5iytfhuXM:AQ0&-xp+}NV$R(cJhn60HX8*`IA,"Wb9p&@qow%18^ubrtULKuX6|`LH8v2_cr@x0C#$(';break;case"id":$f='!UF+Jh%md*5S*qt4b?P/JjCH(jf[SvkUavm*WR_RIVc!&$]"C<H.W#P"7S7yFEbHZ/$>G<}R*U$$GL^VK+_baIlieq!jTV*k{9b
yLr^K?f:_n;8q0&VF*Su>M}g006BiMQl8lo<m./^tOi`PSCr%VA-M!fs&iVtQWNw@t=^Qz)59W&qzb"tT-;JG;;&e+46]>|w
?{JjRW1=dUOYO{kUl(^jL"VX)y^n-qP=^CQU
:w^2DT#*%T5vgS+__I#*eRTA,F}B^G_Soby-hJOASKAOakxH[Lr>ie6qRcgt3#:Mv$Qt;J&Ml,2b5i5dbC~&X9F@0y)MIB.Dee!W0ikjz8<+.Xp"Q;I#qqK^o`%Tl`J^pVTf1N)l7%jMNk5F$q{2F.8V*f0vu8m)cGo.0=.6&X2&_o!H%$}-9E<5y
ea)=%)eH?7?`p3*0`I[=;BhoPMV:R&Q=MdV`P(8=$v{?.,#n<NA2*RoFKa:M~H%-"9o++WP9EksnNddRTc)FfTSkSYI[82@<9YmmXrM1ZL{`4*gB+N!T#Xs%GH<SPSSYd*qO0d!t%qGfitvmtTUt)DT^[K!Of@Kx.G9ALk>70&v@+WxyCN.fTX]`7ApDG5A7?8c.Nl[>43@F^!U-[.u&K;;FU$"H/6[OHMK!o]lP6po5Dvt?gNu,"^A`<IQ^-J/ZZyV2g3^$f_GbepxpmeXX8^58?^Zg)GRa8X&rRAw,S[W_|]i%ivqfw9dPCj1aHK~On</8)T-oXY.OiUq!q0&Su?9*,7mjSou5n^90;PbYuHhfC7hkBk>.&9Y[ZWhLSK^vs`b]U:N*Is,9>b/[SoLs2P-],oNjJEYfnQ],r1!Mp>6R!BBypRAI#%r%w(}t3LbQQDiOiO"#VC(/D`I.9S;VGNu(9)4KwN#vFiw,lOQNR
+d`pyqY=u6-Mle4#v-hBvx&X7udsz
A!]NIlRBuDZ9mwCk89]9>Jg%=<`,b],]]<jKCY[3fW/?Yd}ks-"H*$10dpr`)Up:k
sU,Qq9jN32%6e#S"9@p0N
tC;gh0Bl",&EpI@O]!?8Qg&10H/uH,2Rs/#=&w4q2`^.5dY/VAz$j0hb0"Uu018gAPRP&U
62"$N5nS+(@BC6<.UF7jM>VZORZ.8ZGJxpA3#[^,O;&3H*Es$y-4&.N/YyTZHaNQK.4Oo|TR=wPT9uM0:Gu!Jl38rcKapl!7Hf"*^kU-_A)txO?W`3R(7?U{7%n)tsM)R;kae",R4DUT>E4(@}l{;Of=`8DHXsJ:".Hpll$^KA%=]wy8Y;e&+y+C]4H8.mqN8g?j8IgAKAW;G#LVGKwb,|jn2qZEkYu)/bc[=teyR]Y`oU,)Ht=$:_#}5GgkuFol8{s[##l4n_*+V9:R6-x2oH!zXz_`y/[7Ys"m,0!LYx(tAlf8p_&=];0m:yYQ7I!Bh/L0HiSVI(*B>~pQt/(*f.`E@rFqgN->1[Skb]9S)LCu])C
OX5CF(%9BmQFDbla0Ut<!x:&K=en1x8#k*4]+$kh[{Ye7;6
@ojqMQrO74udWzqLHh$/qh_)w?99J#NY5pAKL/tAVlo>)+aE#my,46&/:&*:/R+pk(_c@p1>P0m;O[O0^ia/20I~t+-AL4wrS%26=k+[&f,;H9bnZt:;lmP@I7spY1pwRf>,Y!%]r.E#pmmJwUU9E?Z{MCu[hj&!3"WCV#xikkP>9gf@L3k_L`@Y/%=4l0l9(,X-yb>=qYsGR&Zh1QJW8URATAXx@~BlNAV0J8@12i1/3}Pcn"lXfX;:TV"6//wD4$M`M"1?,"x7KX4Uc8V"`x4Fid*~!>lqxA+w;N>8q@r4EZ*
mJZWHflRKj,@$s"u[ns9<iK7Um/,9x6x:+NtD!S$1q^yNS=rCfm&J$g:WS6|^GZYjA^Xn6${x?7],Z58VQhG3Yr=v6Tzo`FyDnh|0)a-gFpeK^OHHe%*$FyO,a:2kt"M0s9)m!TRa~eBQNoX03k~&!t(o9T_WiRMU3Gbv,wT-5B)eY7abt!At85&FK^;E8Xh4P;z/cE%&U:KMR3X,Bd3K6(*!SA&I@))B%b[nzSWyolSx9d.IOakYfGf<ie#m:S^m/xDNeFWhG[le4+cQ7!
Y!yahv<LnJU3MV#_tKo0"nr?R!Fth,GF/<%mql7Nbx9L%$Mp
bVJ,`#O^@*OQ$on!vLC<L^W&1Sg)I5`gvK;=FNF@R7mEM3gw`yOV@1{whI}vV*C6-9MSj2ogC:0Hu+io6.3#>0}Ww@kttk1JN<ND.-WsXvG&yp~20g{]:-c4vX-NQ7P;G>4?U^}&-dg6E*3)4W]c62Eg5g@%1-olmEg]N]<Xbt"0=_wo
h&NbdtSy#A[*Rjs!HZ7e>0-1[EbK3i_>K!j}SVQcagRv<o5xARru!UT|h|p@bJHa)!vDpO$Y3D[&[
X4R4thK:R0c#IKwytS3
d&1FV]R2INSMp`4
u2h!%T*J&]]B2AuS2+$.xdseZ^v:Yxre3xIbk$yU$6770:W-mBhhC|/Wu|TwMfivV7+Iq.i6IOD(b6VJ6:tlw/qW$hV_tx/0%+OS2Pp)yC,mQ*(HkHe{.}]VQrftD@Vv0/fZwa8Sq"?NvANw[8:
L=meqd%TBL3tPA)9:K7sqz4Qv4[dQ;EfQie8s&O3[AEz964%EN`obCD<M=$_<`ynDxJj#:MBwuuPl
EQW"4e%8i1pomEqtM;bNd.=0M2R|Oiw0e]mY.CY2&/BU3~p[<o8OX>Tq/AfB$qe~8A5?kaV>M8,-DfMa+^X)DdB35>b.93UQ0F7Y3H@3$~RHU"tJ`?RJC77*KJmB""';break;case"it":$f='-]^*gg#+n?S`sq~8,$J(Tg),@G@Y+mXl|pD)g1zt*d81YTZ]Hds4=!z0z7}4N2[M3sXxsILZD^.Cqe$_N
EL??Wh{b+fd:%Bke{]}VfXAie?ow/<erHX5`3i(V8fN[Y;(.qH`:YG6sL6Za6E?47,Nyy@Sui/^vI/VRSt@VqI%L_u4:!z$vKtStJw=<*380AF[H4:c>ay]N?^l.#0u:6w=ART*W&C
bD"SBXqDL6[3KA9pFoVYjoFH2M
pFyZaCdtVEvJi*T5Xl7m&#6$FG.w^LPXE_dPd*-J/S}dc6T@Zd4c{TE^/*WH?UuMPb2L=-fAAg[=(s?d"@i+XCD<w;9,I5tJdBW#qs>BrTDAYDVx%96<glF_|@(B<IYXepb_l$G;E2]j&Z_uU2Ux2#+_:RR6ywu2%b)>ZO?Um>"6b8B_&O~_w4!O;D/o%&qd{Vx.+k]eU@|v4&oS:_Tbr;H[JF9,|GgbSYbj#_Bo%G!xA5q?iuua{/"XVq$x/0%a8`*6O!p[H-h5XGyK,"cs%">wi@TT.)`pX#<]/p3VTkm*.7h?"Y3X0U-FDtoB~ieyk:g<)4O=HtSsf&:MPXWjkpDxK0QfHhk5q]7jAXsl&lWpC3hz&#3l"r|;$uu`Ar/Q@wY7V@uuxp#
CK8C=j=*f)+Hvaoqe
C#eX5].
~ZgqL"uWa_qt&L;an=|r&MU7{@enae*^{u@D:sP#8[wqQj[9D?<Po(e6Rd9R7py0<TO.+sp(p_g7i<FM5(/O`6T6|t}B;J?Y7CNjW*3U@tJ!.irg4yZwu"[`*jsyvjo"U,]I}U=ZGFz]~7
YI(~%$x)M):kjbTW1L1?am*#toxzu0K/0U5)sF,1$I4NN@,bySv`9rX@o2CrhBy^Q~ASwfkQYe*V
rRybC^8"yi/ouOc5=(>8`re=M6MI4^ubM_i1(-f_U*
Hm;}?7Sw6#@Ve1&6f,/?Sa5d6>P4Hi&j-j:v#?&)O,iZFKeBVJZZV?Y]PD>5&s7.[IJ
NXX-%JDI,i6q3eJcpm!6+.24Vz+`ZIm<8g^p5}ZDc?j[7)Er!.Qv/E;|+a;6+e-p1FYgl;1yj
D3^|Z|(y_5tC<Xx^D#wElMS(5(y-=D)r`c(;1s54:`R?87
6<"oe@%p1)ajlI]e(53f/i{^=nU+|_|"*7}v:f_!SCjRJ_/ge5{#ATD&L:#3=)%_Qt.
Q)]OOob%)^xr"+E-(d3sQ97oA#(LjNJS2Ejxl-R:8=E]VZ}))y;i4.#vbDDN(DNN~;3dyp0Kl9j@A@]5O#UK4X(@"9%oHxoGSo>/*yjpKra/p8CiwXwk3o

n2?@wYyvt*jr+_WQc?M!b^u/MQPPzU9&;;F1cg6RI,"2kf/sI*&0:.bMf&RW$HE:[_1c0B!^x$.h
T2w?m*n?I&V,
jm:KqrHw
9gEo/D93^<@UfG:,C1h~$akz@xY<.4<yW}alo0@+WI)/S1C,<)6^=s_QqaIZ#|AMho#`j}-x;SlRCO+o8uLOU9rU7
ia6I({]UX$Y@S41LlN>2lL9m0U.%N|xpaHtncK"R!!_l-1+"bWMm(^VD9QV3U^(D$q]{`Jlc8:Cu>}&/^G^mtir?xc1rp*BuxK2CK$5)HFvqlFvBjr_.#uRVnO:o92N`UR<8OchAdA1Yw]t1-N0@[kOG#n$vv.tZZ4@~WBC8$&`Xjy^buu%m${FTJM$tO6
U=eW86qn?elqSNx=mF7teRQ*C)YIf3gedr5b5QEhCZ
57HK<pM?joGI-o[D&PH5GkT&:Hs9?7Q0C[B=>9^Dc
NEPr^VXeQaDt__."0u=G=UrD`^%X`"OmL2=<]ccE^khBn[oY,H=/Uso+J^FDW,fm
#=-lLsCki?Em7`5(^h`d4lk_a>>SgSv]s=6scQJ#;1XD>G-8fohuD6E4JM/+bqs>1.P4)h6:+2oW-_uFf8(Iu-2i+^J;ZXt[ldPn#KX_5g#s;QzN%HXA.D,0<Py-aj8w|MXJF.n(J-rQOsQm9.u!,Z+f1R,8aSa%GL;k[LjqrVT/`jJ6XMR2Yf!@$ZIkrMg>/S2($^88@`
&y%|
+!8dD_{lT0hU<+%Yz9#)uek:bp*I;j"0UY>(+(M>7x73NMP>I%~-wen-
PqE~)KWIV<kBV""xp3+v3j`ON`ROQDUA-:
t={<Mc}d?$jQC!TCrh^FO[(*r^(`eXl"MON]A@
FyGgV@^.lHa4#0#~hU)|;0FitX
+?u#"4XcG7N.zY
-$N!8Z
r<"1IUNXLJ:4E<eTY[t<
;$Llx6w
veWCbu0VPf^xm<y]uXVlG_!5#g.J(B>+tuVQYv*L)+P2x,C/1>-3^"DU,&-
*9Y9d{LlWL!K
&&pk8y1Zn!3CIf63-b,?m)f)eV/9$gkWAD-sq//kM4&TQ/*<yE7t~1J,{rJ67T|[A<yU&_l;5avgm1~]0mmM9-8B21gn01R`|wRsV,r6fo;xF-]l)1DA3bZ:{>TK(_4
,11JXZ`t.kN5Go3m6qBa^vyh2$92}m*]A9yku_:]p=#l&AZf^Ij%uJrLz4OMC`@6
M=-P&qFvL,l9L>q!:dp57b8Xe&[2vsvG`<lY-tc/jTv<.H]KZEJ?e@[q[F)Cc,Qat*.Yj}PTExvsyLF}h/^?"`SHS[o$QuhyI*DnA%+k/C!}LS-N54(:+hRwxg(i3P$k791"*qVE$](P[.nKguF~5,;`<-3(.9v^/r=5:e9u+R7NqR;+[r>13NxngYDR_@P`"zu@&I170lh*Cdn1Xs[Q<2
b/u=&/IR&@+%4XD<5gZ4m^JA-1s?ZP~;QJbs302Il_=F<k2),N{65f1FH<_n8>t`X=q[2-="{[,=q"~E?v(fd_<t]l="&j2*Eo8v]A-UpvUMmENC"st_)MgK,,0)O6.^sT[upE,=da<yk:,^@wq3Z]xQ7>fy*$=uW04h~bl0NC`Cwu1tK&`K:o9&&nBoZ0e?H6y%/B0*J;Sg;rs0!ng05^*S&YW`yreoH)w1td}*4f%C(=W%+H*->cwa4vud(';break;case"ja":$f='(Zu0y6kZ[EhBYlJ0M;cV,dAsQ`u0/<TWl.#]SXapjhJk$v$#1:1HX-/3Fsom._)dt:p+<D6@PmdC)5N#HMlV$s+jyfxLYkD]Xm>^q?=$~UJ7kS(
>o(0EkHx^ndfkbRqRQ>1iaxaw_Hsc&|7N&ag4e-"Fy`q@./5aau5i4La$fNfOEHLYmoW:
>4fnZEbw]+Vf?]}_.xn_*W7Sh%Xh9(#v@lU]tRR]j)FlmqntVF|w>yhiRw2/
)]&[hnMc]z%qlW9y3bR#!^vVXRegc=33`B@o^23XY=WBD8IiW
`T(05UFi_
WD`+d&!)"
H/Z!DWl(r7VV;%54hpi1:]D4I=J.[#cwQw]d[9]aR(1d+B8|U~f;LWA>i*Uh@c?gdjm|jlh9CrGUl~5e7}1:0Cv1$^QMBxFD>ar<D{=)i?]
3~oC5b0z^3m|VGUqA:1:2rnkWvD9BXx`>">)/CARWf,DhT;I={W:xr<b7t]Q@P=q7U1m-MLi3IJkvfXi%u1.=m6KJ#F~E.R)VQ&td<xzU:B$vyevW.eb3U"|2fG~;t_SlK+D#3A:T:LKyQ,0bz4N,6`<V<fwwE_A1G7zCr=1/y-b[F6[/;n+Wmd`Vr1J.ygsWlTI[AK*@%e3]op/*U=:T%y3Vz,C.&K47~y~X{R*3{:)CyQCL1yvH5dEz);,j.H1m0"rdWDKtrNZ!:6{Re!&G2L]RFe9=BMHV-wrtev?lFAQWGC`8m^aixXYI~T+mY#]aC#VS0G7nAj]iGnpz)w|?g:2h03dw?V/uwlk`Kn<i@fbtKo#$7&)mjP7dd7{L5i+5*`mF-mGtql}c3srqr_4Qm>be)D_KVYvHN3YqGW1a?60s)%rChW0JVPDRUaq6|3/H7vF%+C/_X_pe`Cx^K9zUWX4X7lTduF@s0<?fc*ektQ
LWd8PE"5aPt]W9g&0~]Aa5#)8C$e1YL&k>sb^@XqU
+7`Dkjd.A}irkh(]b8PG5]K^?a
v-$opHTU&-c$.E/l/Wfvi"k$#*?fPTgZ*Toy~4E3QR(*;;r>dG})gDE[D@AL]Kn/eVCxQ3gW`<@-CY]F-TEZ+[q"ZCyREDEYlT-8<$,O6n*G6*H6qt:[c8<[0197or2y"h@.[X0c_yp6CLL<K;[yoP*1U4>-O14+6ygF24Pj@[4W(Hl5~;[kXH?Of:.b)l=6.$Za7s<=gNrNpKLez
pN5eHg8-E-;Y[xtCyO#=9Kf.1JT>Z>%1C[6%T7
QsPn3p3>Y$)Sso`<k8uKJC3gPC963h(OFFUV$Rh!)1g*FD)l2T57DBx9[_<?Q`:=R"Lw;tI/UA*JX:RbIU2.)~O#oJ"!*Gg#h8>R+=DS8rJ|3.j0^W$.cC*N:]Fc*31e@MYtswNauCLc#,W<c.v^3F6s9J%a(%P/GluVW:[|=x(<=?(J-pn+8SmH.c9)q4)n
F.OR^^!JNZf2|HnqT%*[k7{$XhZ3=(WK]w<#6]a/6mkq`$lfR2)i:F7^h6`$pe=FIrj]reA<(F=2SMkcNUJLs4IamQlF}jBVpb84(Emq:n`x5-c#$dxB&ce4o:pL?c&dxZqx:;;obvril
9uco+9j8./Fexwe?v#S.ux{ipC>tP!W5_({BV5f4y;)Q8Bn1b_qSL&d2<9j3lcXUrEMVu^h+hlwbSCSdpl/"$u#!MBLBeF43AAt4PNQ<R-a/*2]cAw=y+-g/;&%qj(&9Lg[]G0;+0]j+#Y~pGP$pc>Zgmjx:1__sU-#vrT*a2)2O$j=x:AX^iMld52rf~b{8;Wp3K#W+e4JJ^GS;/,qki[UB,B-UGs9Q,Tusmx`u7vK>LPx4aWI-?dNp2NLPe2z@eT&1{CpqT<udx/A<?]mO[
gb{o1tw7P]iy.s[r/p!$uZh@*Pu@)Z$w+YUlzk%O>R
;Dn`5@>)@rz&4Vy>SR2Eqj"uy7x`xd(mI>Hy#Lwm</G29<ce7YN?2^h^man@>z"{"BAU)+z$GjTz!LO;`@&r%k1P-y@VmrnCf"0jVh_9$vG?R;K3qHDq%%"Kp^Y7Fd-+#I(/7"<fRNGuR5&/6.OsYKR6UF)G
Gi%P%,,htz(^
qWCp.r1SM9(vCHj520GArAt>:#`DSyx>.UE%?|2,`deka:Y5$.+~gXgjRmyWpu>:;o]H$pIxq1&1V}wgSm+D<Zh[XNHkLb!,M[ZVAM:9y`jn5<MS.ey
F_=TMwNq2#@G^Ej*HAwi6;HClB3:6gW>k/^EPPxoY-1ilxe6
&1oAkZbWH"*0>I.eP]?cj1rsF+So:Em-8/&6Deh2]X["X^1"Uj
wCy1J1%efr+s.[92fZ&6obOR$`wPH6,G?uNOt-0eTAuw%/Q+<9sgt^iB;zE?>>Q#LA)3l$N(%;HnN`x+N"![pd0vo#+X:Sco
lCf,mrut@bKjCQb#xSzGZw><zRZ"~@~(K
e<kRmYGe[(67XcWm
%-`iQb#4*
;&Ls^f-tr!1=$~32w?>0
u4-umr&dWCU@}dfi^<zZA)Vah!oJQ
K[%0;>iE
$KX^)`LPmYfYTr`p$fvknVwXh)c//`vajZ*%7(f*Un=mC)p@
sgnG.Vny}"0?49#;-LEU0dh6g>|[mqkkt<T?XN~PWx#i[C4is2~*|@!.m%f/U+]buh,h8[r:b8;_H7DtXQ%=tQ$tx*Iy6Y|%l2Z1lk[lJQyC:1p`{av9$uibK2E^[#04)x>jGJ?J,Rt@7N1nnvo,P/K-jyV-h8L&wGSAt&v4@1QTsjH0EL<O^d|vg@w.tegDFtFgI+Irkpo?g;N5d5GsqJH,>Tr5Cu
7LOl%L<U,p-Z*8nB4j[dhuYY>eKZ]&G1TE?h^$;M;Z3ur=Z{>MB}]#<z#}0.G^F%oQgH7;:mH+6gwf+&$FHq0/u|_FlvSD.cjc.d6N<^O0.[,,aHkc1aJ*WImH$sekRf-HXa1DNzGkmNU8MhgBHr#Z
aoVMvC+Q*$G!":[[{yhE*iNs
@+R`&Br^?%h%yXF@@u"DNfo/MLs#v
X%d)#4ElAmdK]KlHTAF$sBI5)^;ia|"|/Yn_6$6=5dZ,>{_*K#0i0|wyV)p)OxR.mUnmiNq<){)Txj#zd8Jc<}EDSIj/5nkdiqs$N.*445B:B"by6#l;5#UU]eBr*]LX;Ot?,D@q;8t_I<gDWl^~B|2LMC2$Ry4rl6U{w<4YnOT(@2L[4EB=EG.#6lGiIHqaZ(6iOR(CcY1*QZ
7R*)zGmDj:vq
=QdSwLs`$yyd:nM23cga1C4hZ}RF15@qSze6IPW(F+]i0*=8>5(FI[E8y}SPn/qkv}pae6p&pX]b3G.8n?@lh,@GY}CV2/6$YZ?/SluD0EImA`KGaS`V@@k13Ep]vyMNA&]QSgN=W?:~g6?!aKMeC#&n';break;case"ka":$f='$]VLMbOp[@7Lx]7#F)hc+mPq"GahX:::$d(;CHN?7Ps]KVQ+Jg5(ITssHu|)kSwm5-.=.Qs?67pM>Ejdw;fmgq(_
OODjdPCfW:I[iJcfUy%riSX5aFK#tuZhpiDvpkXf>k9C]w_*K+=!y21$K#9s+"eji3g9XvMth1Li1_-UYS1Qw|@$;jajd[VYkI5-w]?f<#(7Gj)Vpb(>2
WG^nj9Pq1(o}CV@tt`0;n|HCcts,d!wML?xm.iC]CGj?CUQwknAhbT[qN/8L`am8[ET|9>6HZY
;tv]3bgc,#veFG~k7>&4u*%(}$U@uVq?|AA"HO[u;VAe,t4TnH|MCZJ[m>hY=TO>ck$QkmCr
Eqr=Lfh]DAmiSL;+PSyeo+3DPwOcTA+ut}eJVV4{?bY.:?v)8j4;%Gn4CgTd!0<4F@8w8.4^[wTi1An+kKLfKIHif4ha72E{IfR^"~_F5AvFMKXuAR?"8C:cBc
f0wP+Y2Us>9[O@EAG=/hNyy9[Kp%4?$z#%iTEV1#OZ{Nz#(k,J1Fj[
(P0PVP8=`{Y4-;4Q1q+R78.4e<[n-J".)KquK(qB+F4e1[[i)q+44d!ykdo?kfQFx/-WbZA12rCk^T+niS,TDnC:l9HdGu@~D:`C9L@gx?lfvnyLZ2,0^Ts4nFeXyL^t:H!AyvLbj8G7;IG7i:^Y^harZxh5,Y0)
UGy.OWo
M/S$H
b1}*|>RS5R-E$<.5K[
>i/4pdN%9!!YmQ#,X`Wq`t[&<<2$0*">VAxj$ULRE{f#TC2ic<.D)>yvhgyA6~p+B}7hkRFk"):JlOZF[PRbIr_(R]C_W`q%)NrRoOg,l9V%K1,@]eV$0,GYU0%y<5SX>Ze]X2JoLpj_07?ZLCU4D>q0im/>+S?0AumOdFNp>oFq@Q(*L8WHddO71xObq]KUy
Q`+?F;&7NtEo;o#JK1Z6P9ML9I4?O^(>oW`=On8)67.m<.<z7Nd`08)G=pWOO/3xhC(2[-;ja|oAAv(vGRbs5C)7
a"4CK:~.#o-azf:OKFPh4W;mGU+U*09Y0vN(:nj-hjL%**HR_Vj?r(rAnh>3<7oN&2T;#CB!!.f;Hz)E6HZ$)Q3cBR|%<gbh1Yf//Lj>l^L(pP,,.^Yc>!!<O`l8dT&a-Y8/$88D
*-fP,[)/]j)9w[n{Cu,MgrYqrM!<+SS9?T;&4s(]b=ON+/6A6?,oGKL-VUh(-vd|@V*B]VHrOQFr2A("Q~:h"L
c6UP
GM,f2&?]Hi1zZB2gD>qzB4PLcxpOx^i+C.ZsckVR6^Lk9O5^g,"&Qc&j@2(E%Qp@]M!Yl1JKdC^4Hm/!9&TKfhT6V2G!Nz=Mi6:`<^yJ
-_SU#bjF.j.%3)?yCu&8kWN%%<k9w>l&(:to{8tU0Y/#Q>Si8Zh$I<8%$EX`"RS"_E<60:vZ(m0nJEEV$918LT~z!bu#Boe,^q{$KDDv^+A"|6^${
Va;=PK~h{;0%H6,+H0C^N;9Ld7s-2<[DyVeUma(,#GOL1#Y5*!}3VkX9#<9BTX&0h4]+6<*3w=-Y]xsdp4K-wu%+*SlgZrdF~eP4C({#X(y?m"fI8?X?j+{
aWemWi&>a.>mk`Uok@v/=$9TTxBp_=0MQT=QCW]*TD,hEQLW#h@.a3mV2(nJSI@cwm)+
Stp4)iS~,MYsf]ZT_/kb7h]k:P<tdY!hSlA]/%!IxB$3o%/jMf2a;t--j<e"eXn
Q@gg`69aH-`8<7-m6h"{kk0P
""e:#"x))FPjq_1b=8z5(_-CqmH#l"Bo/pP[#8s"S=m#fpr2au%)qW};1As@=9R>q1rF`vBbTw:/eKsu:)f0&"HUg
%8s6F/r<M+Ojm1kaNHJ4aBO%?&8<g-<b,+3DFFi7dAp=j$S(R4/Eo@x+<3`)O%Q-4*3"9mpleA_Q;*eglben3+}2k4[R)66aytF;in9Bp*?=!aW6Mp^eQNU,pnYq`^}dLaY5C(PAf0VZOeL9Tj]Quq7-y"~.WO`sV%_Hn2]q2?K-|7EumN0y!5I;XE:
5Gp??o>$7p`J87
pj
[av6:m-nBO0hclvSnNMJHn9Lc8pP4Ud._/~b$qORIU-R2[V?RR&IGpE@f(VD%?M8PL,xn<IYd_J:l.klwRaj"<4jKl-<$m?Z?MO;egul6DAC(bFE1X,..DPGN"=v=^u?}U77/3>#=!Vgjua=j1$C6%l/}(JgOXxi!6}h`[6Uk?;c4J3`.X"gDPnp0R#W@Ja4+XXQ6TNFS)U[Gs1
ehIQaGjD+=f7sL[Lfc4mEBee=w}7D*JSD9s-hK4$
J5.^%05u3l10rEy76r9SU$KklE1w::vfM&Np.|M%o[/jt#@^f%[USL5j7I$&VC$BO]GbhwK>x@mFD(bQQ9nciUqj1ql-:V&f?~C$%5eHL1RE<kkIyY*kn0(9^F>=N%!XeMKPw"TCH0n&X>uh7J[~+L(v3mK+Zs_1u2&BV|-yc"^z+wJ-xG)oRX]?^pZ?n&$-X0b?g3Z)Q6u`d^Zkac2^tNoYb&rRoaG)=Yn%9WX.,#K)1n0oJ;6WD5X`[pF/D+]&AN*O:2D^8r^(4vsQ<k%HM5kzn16%_u4IjR
~r$$?&(H[D$%mEBV:51[Nef-!iX8GU?5=Pi<#PX6sg*V2l0L#0a(!k)>-KZQvYoc3x!F,LCV+nDt4m.+3elbBrfG,^J9>^vp7+~A5mO9=+_0{L)D0LsWU7^;j=Eg;nv@6Sw"+pnA9XJ;0:-r(6<Wo4zD~fB#3Qq[p@-gyIPE$%*,GeG@{4Wv/lCZDw]&Z=/NT-Zw/Hn$dYLf!u4-?Zr4"NNPu
<fe#@#}V0Wt6bG4gbunORGN(Vq?y6&pBAoaP?5!y[>I
|h6*/?.)^x>HIFiRNZOJuqEliji560:RBqgrjuX,J.UGMJds5;:R2
iHjZ$bKT`B9J
WXp$3;Z9BAT[o3&[vHXCL?MF>C<PdlI
<;95M^Z#yB/!P*ksu
v/g`@W/2c*lA_5,MFi/4:;wfl^Ed<[AjPPE0c:#T
3lV@i7Hk~b}4eLGT_OT[IE].OWZ_lyfegj0e)YJ;`e6Lvn"2):I,"k|fF:E`U@G)>O2Q*>e`{S(nFxbyX"y`BO;95q0m-9Zx52:/OQo>eH
y9]jE]!gy5aLK._fv@K(]F8LCC:h0S#$mg/&c&n
>OPBJ=4}MHuVMFHX,o:bLcS-!NXKLP(|j5ei
mIJR9p|@VrYC
P1c@*y3@L:G[KrF263A9g{r{Fc,5bu,!>]Ks`/w8T-=ROfZeK<9}v)lMQR0ZH-DiHjW@mLU/8Y%R%IO;XI;{_#on;axEW8)7BHkZ/RC|yJr[-rj2/s.Vs_2&`kSiKkoyK<#g_#fmRiYTLPH1@Js"P$E#U.aLc2Byx]v87[BB^a(Z]"_L;ob7TVoXa)?B#?x/jGr>6$IUcmC4X3B13*Q}#c^Xiic
/:*F?84k6NctL[M16*XX9E(o&S?#3MxSr
yrf-gb/Uxp>
)~/i=~W=VPcL<-6cj$^}1(9v@sGf_8?[M}F{N]),27Fn7!&eCo>4TU03*
[+!HUMPSds%b`V+B>LrrU4L07,P*Jx.P<iQ]m{A|T_2W=jW/g@JgkahN`re)2]^wc[TN?1B+DkyKsfYM"Jf:Z.@rYAg*X49kf)f8pS=r+0<P`QEi<}1R`Zw:3<4-A-^3?l>zt6nIy"sT_8TcS"x`Ro^{+4dZR]_MaTt!PUsH&ikjrA;W16K&XBvC#dOE';break;case"ko":$f=')Zu1$bop=@77Xh=Nhd0h*[1y@()B$gE1@PL=(^Qk;PrY1B0Nj3=N-aPU5i_R[+J;3Z|
@](haEyPUA;?+[wh_ynq]fmT&B=_oEc`0:z*9EOsRVuJWqbiFb6+$,V[W8][~4{@%i.,9s^5-x6
kc2*ho3ZOnlD4
"bq?P`7
~eb8qRUv{>GT&4lAeY
TLyl2:oqy4>wnC5Wc3vcFXn1hu:I)>tGyH]Fo(a2BqXe2"R)a4vn6[Cn,6S8?T$w_T9Aw,fQ;v-R>c
#u
cVl|FmQy;r+MY%W9kR?Vl}sVcZmLa(o[-DJ]h{@)z(^A7LkOqR[oy5
DI}-nw]>v+Cnm)SVwtqrIS1LWY5uS(;*m[uS<#qEUXTykINPhV1Yy%&M7%RdX]pu_nj6i.*Kmw:6*]ZjGQ<S6VAtZd"Tj+Ldr.c4d;xg<J,rKqC8OM%4ht9NnAdH*]coSJG4lyaqdf^f1mmpa&(Z:H0pMB__D!;h>G6*4`W(r
+wGGn%^QcD+bl`&&~&qN,QaQzjvQLrP:Gop#&p/P/N}7qt{2i!4>U#%=
$vc)2=&l05aFpX@2+]l0ankBe6"o(;A_JpEcx*hh14InOgmM]*e_K$grJg;<EJiJtPt!h8cn6tcM,vwnhsyfbzOJSVku20h|H|@GN!GY`9!?&>c_^>aStf]*=I7)hOnwW^:&vjiPW)mZ5kd-HlB$[{Fd.@JigBce_n*-+"RPN%k:0K1PxWFCvXw.16P$LoG|gugCHz[Fa;<iwxrI6D/LrN?>qmE8=<s-]}w:/s6v4e39>^tds~
GJyH^/o9@8[W2e
TtR6^>D.c`*<,b5t2#kH:)T$_7r:,-9%X]$=Bj@/Y0dK"3lb`1
eC?9Y+-Af5HMR`LvA`2?7M:Zen:8xKN!u/c;{C~^rPe"8+_SrC<S~L]0FWNw;Sv$0T,2n({b"nV,6t3]DN6l`Sb(%qt${<>,SM!sQT4yzv7pD9Dv1roUc0sJ1#xhy@E?J)HnKR]vk?%&Rc&Eck|%SCR%)^>y^FKX8p5=i9i9EYNY(HR`
S_>R6/QoMcK<r2xsiAE&z%>,l7kJk7eB1)o/SbKioTOt^rOE"|CXvZq!vT#|=%4n,C/i82(h=&^4Vi$yVbF6Msl^4P&9nR=JnF=mto7UvD(<doF1yhNqf_3Zx]
Ew6m

Y5NinNhSuQX?e`6sNvt]3,~`DRQ2KOWy$KZ4?PrioavhG:@uyaiU1Rd<;Ic3e^<kGY`EFLRf42h/C^}l~4-+1.+kQR:vDnqa[hobxqMXSK_ZFMf&@kF`S,482ZJq+`6pbepIX5Ic3(r,hTlL-i4^Fl{X7TRn?8$<uApSBNBQT$Sw*%D/(V=`5:j!XBHq,Az4=yX3Dek"HPNP#7:Q2Qiw/3Nv#%LfVQ`#pS%eG23GPx<VA4Nh8ouA94P(Z3g3x9M%1=^T87IX)WNfebEnW_7ehHX=r,}!ER?_Eh6K]O?iXy1<KA/yW5_*6cNW.3R(`0l%lb&s*U)#~;!SM;P]6bw^DI<.%n%m|yHuY
[pOBfF%5yKk+j"Dw#:C`.866P"P>vJ^e,Q?aZZ
m*=RIw(B&RB%hZ,*,21GdHm*u|uRGC(]0MtcIfF6$C]%"_QnOfXs`8++8{)Q;7_b17#1X2P1UL-IuG[
K1u+K<KFw]
0^&j^v2PuW[($:2=f`<xFZtXmDs/4DEYNvz8TH>=}7ga?N77X(3O8itF%y$?65BGWsxoqx-0Pih+0h@[C1LSa)4ulf_q-&Jy
::Z(a~PG9xd_N%s8PW6#lT(^q,;6`rbk,
m0n$wg6s#&SEt9ro)$
$?)e~63.Ua]nZqFPvYQM@lYH*a=4u$/+)eu,zbvDm`"Y)S|rZ0hh,Y<Fz48`79AFq[?7!SXLJ$}`f6koUVtF$?/g-CS<XZpV
HN.z*fl).T;`kK>J2gHyFlLprEIaUs=}w,:&Z_=
tyb(Rb0S*O,Q;g^<ZpW)l8468rm0VjPMwTO.uI/&q
_aW,vI8&*ETw`IpFM-`b.f9Yy8I~@9`dJOa,o;v;k7Qkw7w=bS_i.^]QYDs^7we2^)
99d@=Agd-fiO;Qq5
41NwHmfsN>W2p^Rs,.0GtgvDll`5#B(Yxk@gCEr_>.OR22f9j=YJf("0+En:,C8*e8PGH%xf;,>RarEK:)NZ
fye
<1-Q5GW(].h7ba2<
_``>/(c}pgH
wS)i<4/[.Rh)b/ZV#aV=-v.W1SVn]eLxuX*i^@0^jUPAsyQ>.6Wps5FDuHpY#hsiAFk:b]8y2Haq-.mTmFcM^GU]+vk_^RuTNVXv-a$SA_p^<VLDVYanv,l``+]tF!V)SJ4]Y2#IH_-8!%l:uEl[J*v7jATgK)GaS>=Zwgv0IE[gW<M`7NHi^A<,K%;N@5%,TcuUdE3g2
`@m0r[vlb4gWXQfp"JaWteh$7Q_Q
LZo
8v&jh#w-I;4.%
jZLY+DVtMb:)[IFS"-rdkKOi%#pVqk%Eia8P[W}A52@+cE8.(D~Ua,&Pj#qu3Y:%[C]>0_4Z+muXK#83n?GhP[U?RvIqNS1Fp^92j++9jOjpkj3F@+w:GIai1DK2e-lc`Z.>Y0[0-A^=59(PN4S
5S,a?];G)rST2YhEvZM_A6*/%jk$Tsq/ihKf"%s46Q/vZM;0G)^65mQALD;UkTGDt&-`YU5-u:r8&IyujKz#+Yog`F285>m&TrMDQHp5+bBl;SKT"RPC7@2?EAXUb<m8
#9l}6uoge6PB-j2x)#_At(Px0wGeJi`TEB=@+<GbmrXw`u([wV^)[Rb^G=ROr*)`3#mOf!O}j2HAdjk"_=t~KgX26#.,j|9"aa_$uEeuWww:S_*Q^15p=HG
(Torepj"5/5;cT[6>5W44w@kjx;8d,c&^LV%xV+PA66tYangHd`j/*ZC;Ib8cw%:wrBrN^s~XuLQjWuD?-:hKU)i&,*da[XirCz)(/Q$/!*|q9DI
|MRH;ch!5b9]xj`Yd;F67T_0P*qLS;sx:IL_".Shq+ZP.+vlP&3GQPUBgIwJ}i$sMSb6{e&L>`o/T_^9rZ`Y=Oq56P>C8g}q*!_JsP_RTBmV
c8!h+#/}vV`{,:%PNa]!N9@D0*RHb]xwJCw_2.30[>v^DZNE#+4Ejx]>d6V6W0IAvX/OuFpjBj9GEVRvxG26@zDuqui/2$%5bAwaoPP`.uVx!KZSfhsAdpP<u,i%LLOLjRrj2WRXeG?ExMf_UMi?+-Lp1.[lZ4j~A$&O.kNmd~#],x@<';break;case"lt":$f='#R]%96lAP(q*)o:OyN6K_vBh|I=HWc+8^+V7J(M
q"*IS0EgD`W[zm_<<nWAwukB_Y}C,^FB6p3yQl<S"t+h+)2!]l,^Rk*E2@!yMTu5}W[u&S2^34BnALzn&jC24Umml^@Wn[>scQuQD^2kYxlTsoLgdPrSsA,Z(c)9EQm
9@]ePtWqD[dz%4Od!M6nw>U11&lli0vr,B9cL5.,q87ZSekfC7iS1AO_G1$vcVmKl#@@(HO<a_kt)ofQkjN=r1[IMDJPD@#xWJ7TM[J"}6-R0.Qn+FdiWoxs,<sb]bZ;MM^d$=/M|bS]}`w1PY}Jkkx@1;
D._?2,lE1GD6VCJU7*0Z!Nqc0at?*20%5adgu:,Hthsb1|ye`P$$YYNf4ZcFkd0"CmBI$)Eb?OTQ1M
{,O;|h@Gakes`XZ?U=z&%4`hhOU@X,t_6JJ2+0Iq-`qkXg;?sh}2?J_xK(M4WIf"e3VQg(,e9s(24RfyhwHgo#cc7?3VD=^n5(UA}GOY}6##y&:<HGLwjGiit,+Zne..}aDMymP[0VtcX$<:Ixp#Zxhvq6=5BGSj&7As`<;L4*4bhtzHlTF.8P3<(
;y8bDP8Zkq:omiIdUdmZx%&7xQ?nX+$b9B_:/8sCcsZ(R`aFhd{@Wu)/,B@y"Vbl)q*z"En[xWph}q+c
kV>%AJ4tr|uf;%MBL&.E_/0E1H/!_e?=&Zy&
UpweS0o"<wW
IXd2Wsh47LL+g<72E^Fu}!bgfv#@6;?G>jyeJidPi)#!typ[S%Dbi)<OTdJcbgzpy*80/V6B{Py^sO<_m&lon4D:43!4#%!3F*PQ3tBZ{&h#K58Epd`R&gx8np+Q:[7s`#tXaKLGt"Y)-Lnbn!k;V4j$MxGJIF:<CD]G#S6*GrtlO)|J?J:gZFD4KX}mnGdE4,}8g/0y|VoStnJ=yQ:"IL;0DZw0<
xm2>_@SNk6xaW2EQeW|UhD*LWTvWiPe19e@4,it2bhgR-[y[i!7aLMax`$X+l]QGx!KPe=DcCMh$P5R6m#
X@
UA7tPa`55N4$r.b!+.,[eE^WLU_D]u7`hg7^J+)a`(v00ZZ=L#dRR8GhVhpY9z!tL(),V2p:cyUNN3~4o"3DMKSQ>U`OWAP5OVp)qai6vWraZ+!PX]dUPdA,}Lc+N5<=n(q?m(D.B&mG@x=/(i"p7/&>T%B"#"h0{
9d-QasbU(-&oQ*$I"kIbguX8,`J:1Xv;ck7U3)3N$P}x~?Om4I4xM/">[bD]5K^i3orU@Tx8l:L+x8[k.EmL=g2_%)a7AoF9eZc&1P6Hd[oGZ>IN83"snY>NwR`d=HiI>u~-Z[G-~[X)Wmy4sdGDdbiH6/8spYNR(^p^^U9*B!bjVFYipemG&-}_wvyuEP|`f!!";.Zg-./r[`G#~BYP:f7vsr+<qc^`>M-@]`lHRy"D"#LfgOliH`
"WJ+7M]sU&=G"uaDXRZp"|I;9H@Uos
}G&q@Al&w$~3H))]iLwnEh|&@iwWUX??ZaR0E!$f$1J/^W3n3($4AkM?H*J%k=UJQNPZI5ji+%i!GKF@5:}2<@}o7.F*<AA;R<0&1$Gg1jOW`n!.%TTIE06WS4fjGJF51Ze$fyJ/Le::p^nKp?CF>p4WuL}2.YbZM2
p5_nE+QJxy`J=P[#>d:o7QT>2=M,p8r,YVXPaId/O;JhcxQO+A]O:Rm4x=NDvO/h=,/a.pvO:7Tb!bd:g?"hL4:t+kqquNUC"&N+F{4M%?D
`PTI`}2.QM%Nh*2rET?";:PON/l*A{"!t[1{Y),i?)I_bj.YbjfY^"%^&vNTj|(%SXug9h"&S0:uDf6fC:Pq5EeEXY@Khc4rg0@gR{eF;MP8Ul9eV?J!OV*k)(dW%1b2MgJs9Nbzex"9V^.A@.=
"PbQQ9Gxd6%>n/9m*KGf-R
!Pto*!tSu#?lar,Y5*>3D./SM1WV}(7%L%M!x>nr>$fK1G7,*hb1eplm].p2xH&#IF~F0-era<^-V5M^$gWf<<4$-8&uf+Qef06fd!tHT^
#g4<KIl$&(R@g"qo#wU-+YHUbl`?O>GXuM(<[)6]
fnV(L5WfnS+S@d8IU$j%Y,7$4f[K2Z(6^d],v*)NATsY~]MhEKaj9s,8!M(t4w8T2pMX9Yw+KQzSa0?ec%^OOX?+zndnV;Jo
6nW2lD6:/-o[9Gv`XECzN>Rc@/;4A3uHxiM~Z8Kq7QGrvGu{`%d+Pomm3)G6lA<yTPZAM`&_3x04y%0XVP#n8;Oi#c6rDF#c7E&s^!bsAFtI"o/4x,,*jZQ>jZGG${i2ns>UG5VlRIb,&1U@,>af033a)5y5S|*W(a5thF<d$Wl`VZdX[K,57"!}S8%,3x72v.rC#9hMx;kL15Sg4=?G-@NQGt1D9.jqP.e=8LEWjcO=/bvfW27OTOo:cI--ZzV-o-%I6a`/cuKyNmC_pgVdF[?L,=XU+w2P:cd@rLSNXB4ttfogLQkA0~0U
_>;4VW.%WbRB5&k"VkneLo5RZwNUcLUciecW<fu8,Z_K,frd&8,N"*{S$W{_%J37$rxs@PC5I8}>j<sN]DEV"(AjGc4c@+`/WntfFei-MgcYV[&8C@a:h#@tup)x"lXOi],`y.,$pWYdy
Io{ar6~<OV3#SX_wYhzUaM[B?1U3VbZ1]?0:=.fu2V|O~bxO;.8+hYr>WXm#@&k/|8uLYGhdw*6qg,BxL[=pI(}`MBDiy#S9:V1TfharFGs;:sP9#F>S|S~3zB.B=hQ5M%CQT;4UtrgLflcQ[N0;x;1dpgSo2$O+V-fh>s,]|LS[^^`f.e_Ow&Ayee<?+0A,>eLox+G8>J"Ryn_B%@B+v=R1z9#W."i4<Orhs[lHaR^_F/>]RRcZhiP]m^Bq"=;mKQDN+eYs2[#p]2%^uSZor1oME!oHmO&bw+1[y!W@gbV1MR?9"#^yOvISHg8V(F(j,nPY_DaYUq8Wn/T=<!`GZh#ib#?HZa7dd&5%830O@@(A8g8>yD=5cUwh136=5:.8X&:q8RX^|2CX%:%[~B.3YW`$[7sC!MQ#%E-_7&cd#q?(7SmX/u<
Y
U`pmy6
Yi?5I(uAa`)|6UtKI%g8Xm1c@H2wG
0"c3cNVpdZ#3HG)E[YR^C)f)a<!D`q()URIS"hBQTOi_*1EzH+!7su=&s#nek1,CgY2lX2Ytq7jMEQ]$F{=B,dqA-In,G(qh/O*1hvJ
ft#bYgfS:LE3cD.Tk(=*T#8>[DR+Mf4fbvP]7~wwVt!pIoS%Zbm>-S4ZnIh!<@G}MebFIoc
/y]cB"FcqQ/L)+!F%4Xj,Uo&3*w(^Z&I.-/7A/bHG%Yy!|u=h3#u-5&V`
!MT$f+Q=#OxK&
<."7Fl;dmDo`ms-{YpI^*1[TY[7!!*a`a0iOs&aF$iF;qU,@/KYr).l~SFtyRXG.Di
`A~_7';break;case"lv":$f='.]^5hf|AP?S)no3Sjgz/}E~@U3e?*s%Q$5mOkFvVKgZDx(X*}<7x$)g.EFfKcyg$[#.>Qh4sPR+k[DSori/`(GR
"]*T~mrl"4f&sMvt%GTgEm>JsaiTe%bM=nPU0cra!H7a;A4JAQ~d}[B
DC}<)"36`k2@6XvlI$&
GK,R^d!tOHSe
M%i!_0jB;1s4LL.7v{L_uvFJw>tViRqm:Xk7Tal-x@$swf
zHf+f68epijQZi0JGova;kgg1_QnmMoU84YDV)aWg+b<gAvy5F~In;F=fGQb0Y0
}?8pIrglnh&o`H:xRx/LZ-=bX1k]*CJsF#sRr^sgg`z*Hu8TI<`63?D]mw^x]>He)QF2+uz[Mu2Vo#W!i4wmlJ{^,JNnQhr*C$I9oLCil:~_|rqmZYi71pRA/q,=p$u)2!co``HO~tEd#n>0nSjebOztvFSD[bd^nB7-GtFrV.0v?GpRx`y!3S-s:E0yjRh*/U0V2GRi#CvW3[wqncC8C"&lAN(AjH.UAGERI75"
3>K8,92Nmbs$
=,*4E#xMd3*Mb%
:5H*S+4,ITx#FD]zywG`"p]>jQ<v)-,2&$;{5u-!gvUDAH$vE+wNFRZ%)mZtT4mf/s=[sTgZ`~vx:iNU#|f9iT[]fM68x`XgpBspHz.=[X9z6plue`kdm9W=MjP47LYTU#$BrFkxDNS`9m6
yPpsl"@cZ
,Wy4Y|4,^`F}37Ve79JNezJY3p^&tcgv&sBZv<8>JdBR4"Q{,RI%).[(Z"Y5JdcEq-`}xl6xyM$79WdIILG,.rp)dEKUQP<pGD;qF4(iFdB,_?4cKvh:`WMip$,SlQJV[kIDV&j3&DsIc7e[=tyqh}Kx9.DH%IQzmhZ=N_]5
8@9P4)E+/Jk5,#K;y-c
T!BX{:Uk?[uttqO:a
witNmBq]?e%_dP)S2>&/<Uy=?ipF3PN[-=}K:-Xg&Wf*B&zFBCrTALR=)-+;%c7"5P}7R`Z,]qe<#1b=gUfWf@cqBW?A-gph!HL"Xr7@0!h<O7m?bdhpmfc%>6KChgu(&4:x!G#C*_5;{9$Mi?"H)m9g*g7;]J{3_cdIcaUuL9+F89-xD!Pg^ul_OF6m-smpf4IgT7Zgpo[
,R(Uv%P]Nb.4Bq?C".0
4Nw..s16<Pmt6=^9PdR)Hhn.eD-yvH&vHOpF-LL):qY)4sCgPH8davn@*LK7]1*ZIe_`yi411x((IBl2_)fl{!dO##z!|)%Sf:rYOWp8-c#dm,N3ItbZ~?#WOs}y[5
AS-f=deGx&nv`61q/utY_y;p";?yh9:LZ3a?Kjr!.IoE.qT0*=7@X(,.`eub)gd/X<>*c`
Y34;Q>}7?*n3I^%Q.Y^OY$aRZ=b@~-WpF:"wH37j9ul*TKp^@;G^+;%^PBE?L4Ht7X<,q8~pSh6m2P<8AdsQRf&t*;yfp)
s8[`6{gw``w1u}T8+!Pci[JWwzC6o>i?y]19SrHJ32Z#,{grU@]UM^9z)iOuRa<E#Ge,1i7.>xZQEb8wb/M@1?!5QHo.Bi(Qd(4q;UQ"9g#Qhvx3NJf;-oRv1nI6#:wB)x7EZ0Y/`L%2SlJ_7wmCSnFMVu^=$c,v$G0Y=I^lA1W{)5i+pZl/>d4`%
=ieQKN[aT&%]"e]VEr:SazY$"~eOlcs?/{Nck)]+/y(]lGGCj)(wXJ]<6ee5[N9O&@2JsjCaI-Bv2T
nNtjmu9c5gC9b:ybI-~`As%DRL=6)`Plb6N-@I3t)8.2>CB3e/(E)8}t$DQx?a$#iH0qC3ZxF`Z&`JU<yryyU:uT[%,Ws^fLJolgY%d);:kmhTV>COQ7.fYXe4Eaf=.p#OOMLDso@OFn&mSq!G{qrik$*fsmepnV-N#7-n8";Pl+`WsD36eDWA9tF2cim*C;aK`&|-er$S_N:5j8>&H62$#QCG&/0!%/YOq.NroJ
CB?a$V99^vlm#u_J$IBK4QhbuW$T#^
#s-s%G]!|I^J^E$vnYYCBb6P=ssDJe_KNc?K%o*c:"p%/T/i7<<[_<D.O;:J{!9]zLp*U*&m@.36`[zF&;W<(%IWVqBo*#DN"
-`B9iOh3v+Rgbu5K+DH@M]5F>CLwq>qCw
$ax3$Kr!uW1?H4wY~
PW<JY%=HTfQ_
/Yo:0$R+pyJ)e6/*+h;=+n5NQm(y?sV(Mp"2bcL3x46B&O#(3)tW[!$xvB,fn}
tKge_fTdXUCpN;<du19U*k@xAA+C$]Dw0xaA+
eC1PrkNtsNiU}N`GV"1%lk0
&?yz&I&eF?IQ^EXwaHLAyL=!Ig)>*`N:J::[9HAf+rSqHw4^s4,s7r;(Woy/r1y;0LBC5%k(%(4l,Qd8(I?15L^Eb
1YJZ&ra;
D*%K-u-y04Q&Zt<Dh8Nt*>g@HnQSUq:ZW}E-06/-&1eWh(`@R~j1sxex&`o]P*#lO(,wNZrT@~.<lOf)mR`G`M0C>Cq94Jtz8n6-
TYDq*
K2xb?&Xj@+ca}+CoC^jQ(;ymjbkp4uwH`tl"h^Avl>ruOsJj*13-/,YfB_B)GaZ@vO6
p?X[TEY8JBCU,o|RUgovKe^j}tg,8q]vyg>yL72H_AFXVW"Wo+p.SkCQO9O,P6+_V9oNxN+n^ORdKx/_"JYGQ(-M=Ljh[QE@p
|e@E4j"%:3ErLP~Gww1V[`uR:I$>3<`xPCfTUug/B<q2tFfGYlv,dP984E(q;i|!sA`KpSPeM6wVG&HB:2RgIPw!X
XEN;%!#MBp(ixn.SOd]0MTE5pJ#Ja$.P$;@iPcZ?ZfdVdYa]C15Erp}T,+ac[NWx?fmK2^wQ63oqhpNu^H&HpZJD!*UUug]t1;#)SvOtKOQiV-v>=&>"~Z^Vc=#gFq>keO1*sj8&Fy^>ShHM%Z6d8%IBP6@-[WHCm^,MBy[!:w^2o5,(Y/Ri73{Y7M5Z{jG!f;SZA&).u0uOF_YOV)0Cex9qFKx[V3kx42MjzX#UdKWRq"pw&%BflCnVSyi]pSw&ChVwCECa~<aw8X;gsu7xgoe!AN^g=kgFA8d!x
PV**JS/:WPdNK!*il4arNZ6CYlvBF2J<0Lfb<(XC1"Itxg&MoW"swH_pfL_QOD!,)pYL|QAk^N=&~ec:L`fm=]%lw8{+F(G*W[GK}N
4(;pG%Q]AOLDop(<Ux6<)64&XXf-[{?Hp^*AueP9d:RSHS?Hd4,dwS.?21Zh$gfYYD7h-L7jeMlRD{)N;M7jwv*-n#gz(Dd8UyMvHr18k.^$B*WaAdOAsYZx;6!own`$A>*h.<0T,nTMi;>>&GlO2QstN&';break;case"ms":$f='$UF,=hAmT,za~#mf=F"jn
:Gk:Ek/EWQsh*<@q5)1I5JY8+T8,NS3o.cm9rz(^LszS}ueL3*uGA$D2U*1spJvuHc`n2Yv@`X850m(^G]^j
5/uq[/a^wb"UhbR!ay@{*qb0;<]Y`$hc<<
}=H@sTbZW]
USgW^DF]ar?>iQe>z!jtmbw=V5tSsPb8L[)u]6vQgLk>1^RElq3,7@?6Bb]aQqXo4^`fUZ*Bcx.j<]jkod,5(q4bDd46Uorj5NIW<;0zF>@HmABwRY_T_@vw5V
r+^X?_dC4M_Z3jGsfX5I2e"vxXj2?B(s6=OqpB~SIgzXrY$61/%0|hUYpPGU_>3@CrEsK"?:8X/0v(e^?1Zz(8[c`tE^wv*41L-_BETw+]mSP7^3W,PPdX</Vns:2VXhWf{f0$vS9xw83&rl>fkf,3trIGAMm()hW
xZ42~>D2LQf!+1~[~nSYW&rw?k[_l*FecsIsOm=eN;bw!29=?d#oqqn
?n&BziR@(>9rCX?->hC1,+7jFw5c<Gl/D/=xSeW6K7u3&C5*$`9uaiHwwlu]e2jFW`X$OGP]
H*J3n5+rJY3l8]maxUK!U+nih%_4]lX!AHnpe!lOsza^Aj)CcRBmNn^-@zI{l!K|bX)TWV4}]a)dL}VF2^H|ppmv#MoR"URiME"bZEwB:lAIo%e+of
aWk^Aowvdxxi,M>sP6&$fwB4F]o/V+k#*=*Xn"z,!5sp$YTj;8(9FOul`V,#m^;kDH^NeLYu]cz:/R}4G^b"]qMW"93&d/aGt->#c
5>@l7^F,HdhZh@{gv"%*/L^Lep&qGk=ZjUnDA(;pB/o$|?UZauI[ryNh1pjp^ntE4-G13K)Y"K@haN]_IOc_eWZ(f)zFHc1^B
pi2!}rWl
(@>,pN9l*:m_&&/
1[6lD=tRso<qjM,H#-_WiGm+`i_=[}Qyogcu&-sluJk%N2&B%g:9qN[1)!9}YyhcBwg}"VDCPDAK.*1aN0(2e
p-a/F9!Q5l].]9Ewg1S?aP_Km=NH&hHg@*jl.S#E)+bHbWJ14_OPc86&fu$.eg&yf.=9*ver0!CmeLwh#A,HT{^x;uciem^E*yp(c42oxx9NHy5F+@bc&8FLCh=/Yb`.b))O)5[R/%:
&1cwm@QlECe{1~hJs}q6I!^w8r(U8?;%JNW
)fb.i>()Sk7I$|
C<^<
_9y=Y=,(M_%@m%iQU=g`;zZcO5HZkC*X_2[$K$7;=|7=$r?mG#k(.BIkd9"t?ghF2++j2/w^R)SSs`7qJ@9MhddkBi6]N]pwC27m,*>bqjaZ4.($ClWRX+=B2OM53n<Edz:.JAq4Cs;/qu"[V`jFG]J]xcKU>Cscn[8?9b6P#"Z,Dv86Y6yCE_xSMFd[lji%DHWS9Kf5u@>>XRo
N2wl=~&h;O6(eRLOF`kNkZ@_NP)p(@N((G>_;aJf$lTq>J,vW/9k"$:LAs=]I7bzHDV##]Ip=_Vdq{T,={,_vaok-=>tm0*C3dsn>=[y!
=OiAF<;3_[NRpDR1n
op=rqpU]VmeZL-T0dE3d+ys*An%8PDvBI;:`g@Wwm4)A?Gy=Wnn0+dy47zs.KUo#v}@ssPxpF9FF=eR<Fftre0<;&"/k.Wh4!LX|_asGV[IgfY?;F1S:Cg>rO<799Ia-%;?"W7.Y>n9dgH?<^~>gqs,]"4d;xFt|s7x96y!U6}e]jQ4i:h.GynHx8TQ=dKVxA0n:n~6
(*s$M"&KTyCoXyH4>|lJ;<+kt(+R37XEy<*i.7=uV6/2klZwTmo*E&]$.n!r0.&O,<:j3LZBnMI5>/U9[Xiei9
dD?/Ys1nrN`!X,61L>y$w??C,$#`a?Kx!t
hDRPU+kA^lAqeDCH(s2&gq8/lhA1kq(Y-3aLWoaLrU5u&7k"*kxJ+@g8q@jjR<W)7t$6eMP-ySr{!>IK0s$07cp+1QYNb<Iw!i/f1wwW>-EbD[ln4(9wSoeEx=j*o(x|["9IuN_L3M^Y%&N=HiJU9d8~,U"HD^"c*mH
X&WPub;emMCs7v(2%IR>v~<hglo*i
;PqtYVW9t`,"u3dxO|b8i2O%&I^e3>l8aX_.u[?_!%Q{:LIGt!P>sx(ZAa+n;U#p>`
Shq0SKI/XH|v>%"7u;fB4A(x85Go&-pQRNe5+91m$x0a.ZJot
VVq$PUFVh"o`a#Zxw<oqJ++22&`9@IzRJ27ojXB2W2,AyN$hUPHJi97<Kk<43d(vu^hM&iK.e9dT7u(erEG`1;&_*D4,T%U05ZhhIF"`RM@YvWeS-%U8gPJKq.Xg^;n3QI+fLhiG;_0aTW4_zC`*`B6ME[_AZieY^.vYUkUHe[~s+DT7#jy#@7ejNa`-xmA_+X3Mygm5y)dfZ]6
Fb&k.99LoV^`$ql.iWAKmm#4]W3O~_#-O`"
S6Xq>nj80anGt_0`R,qQ6]b[gChCz8iH&FD]lSwE
f4<vS0YM4^rjRy+vam!4=y3W7(jNGvsPXpP.=M61#AI:2lPb!fxWVNF@/y7QRJ@92m&/]!Gt<A9kwZB0!4*6T:jNg-]/Q4!_/Al@HZSK"e
F1bl7J2*6>,<mE^>?0JM?Wl>mqK)]JV4N4q?Mf3)i-:wcuFOs-6>-,]IOe.O|.@:AY3n(:Bm4t`D`:&Zr[@Y"A5OgT-g^[,BxY_bToxJR?JWV=vZu!Ie@"1+?E2GwMmQ1qgw07PB
VQGsIc(k0:Bx-kl
MiCru#ev`nZ!EE?_e]>=r/]?.9;m=fWkPw
-/I46o|RYZW$3dP?qSRgWUo1A:G!ePqSxnE+way5@Yzeuk^vTB)E/87Y&
+=I9;A
,S
A9.B-
1nYhzlJl1Il6gca9sx/(.`[V1T_TJQtfJirqys7)1qsvm0<GaLi>=3G9LJ6:.-wFrAsP^%?7"IVL(F(>T(m@c>]uk7?`rp!JG+!muAsJ
V-l>=bUs##!n0L:xvmo-';break;case"nl":$f='*Zu+JaMAp*4]RdS%Kl@Ow7ZB=Us*ke)<jlV&;^(lQDY-$unYt!8bY3|DeDyvGBpeZtixy>>vfc1(9Ng#-b3GCew<%5IxR7DJ=L~54`R-~BuHhgpT9a3YQTu@!G&;*U*p)Mi;DMW2RX*r:&dMvUQEDO"K[]T7LY}X8cKYx=ub]CO+?wQMbM"LTN%x2L^x#v]))?nfJsnBl00GZR^xc/3uC1*S4XH=C`.uhu:t
e@eI09at`l>1&1K?(*!OyB4l.PxSvOn/g9]9IL[1`Jd3(d<)9ulqm2EtsnAu)img_/RyMO:-n|#nm5%@d"7"`4
Z`y9Y,E&W9tA]gIX"uvB`K4ioZIUAR)fZh{:L]`$aT-`hYu5~35>ffEck-efpmNB.q!Oe)NV@1JA?wXe^2jPY;C1]I~r^4dsj[]H2A
J%mn]K7uRiL.=1u|-*j=MN60PDiz
`S*,Rtt4!CXngv#VUCPkcTFPhA1jgAg-R-[QPA=>(%(L)4rO9P,f=v<[7;ZH
8b5OA
Ey]@y5LGX2bcLE58>
n{S-?+`I)hcJ=KGu*hp$Uw4Y$*`9-nEGHZ"b
5et+=O95)F6UseD_[*)ic^//GZMhG)z`AXqJkkwy$acm%ENuqM:baaJ,:[!_NfXTsh^6WSPwZ3zyoPo;=sMl-+`Ycw`qqn8l4Q-Fa;*Cl)L`fPfq.!@XB1
YN
|KfOU)3j_K3wZrpwi(%&$P{;HcB4}>}/{9>"Sm+c
t=RgGb9]
c6dVt&`C}1t;0vO
MnIb:?tRwk-V-M|,bRf<-I14s^6P`
&Cuy8wn/T1385IToCeSrFuhG,DI]{TAdR,al;%K)9(&Z;j4qCB%[I
o.8<iyE?OewK:mQ&Y@IlohDb~H9cp1l;AP(SQe5LmyY5NKxk.)qo;Uc^IR!=?X:flPkxY;jpI.85BnmRlrHMjW0eGLcW3Lc:D
K7ADOBHZ"l:1q6?5H`mh1S@8Fl{UmaPe0Llc;n9"LGz_+W5!k:o]!(V2rU;(8t5$z@ZSF*VUdVfnI>4LGrJI%e<xY_.IDd-Lst%u?:2-9BaoC3-#Mq
F22CgdXz9p7#s`;3MM`**#%Z!Xa6"S^ey0-i+0K74ONXCMc&3K,0F,[Z^&%{^_fpYLh@5L.`b|98@9Sy
riVjRr!`tadE&LlVUt~0cBEXb]HPOD/ga0e4}8ov#l9?4,f*"qvhmM{KX<`=%o%@q0:hd6/:i;b(Ng}5ZSnB!&^`[*Jn6Bt#z4/Atp%!jfRoQ/)u.&_k>-td)"P32*;u]dk4tDS;4]Srm+087*Fx!$10ta#MTP|*
t=sk]";V;S8+<g)h-ql*I:KMm~KN3b<[@&uG("aQ3`J_K?*7t2,|Kcl,jaLH7E)R)=?+>h89@l_MK{De
E/1T^nQ4PvR[Z1R%Z6^AH[N@9TlW~6@0x94w$tvHY58sv*v$LU8X5VVvXn}CC_4s<,:NUH9f,dCe?$"q)d(-.0dhjL
Vt:cT4wB+-!|.NKkinhOB4+q&4W{U>eo:(.Fg47?3
1Guu]J#9##U%uOg;%r8X
yv*F2;|_-obc*h/MY=J0"eplN"J)TV(^:pTWO]mXJ@b)3lY.?%}g&jh(jdli3F&het|*}hm8vOE`2E[$G@Q*iUexWQ{V4EkXJ;[6~Bm$JQDFft4xPGd
=4C@-yZXigL6)3ti@sTX8q>>94*5*v.K*,_Ar`Rv_i5K7:OcD[5EL`_[M(%7E[~QnI8DEq7"&*r_L`bRVypjg5]7wT7LybcF|`BLPH0L0:J688VORA.(L0I
r%+Choq9oI|[?0bgc:o1Tv!VRA@n4vd(5Uljc3OuM_:ef7h#W%2-@,,KQtx^2w1DHGQa[sAFw,?DNWwEQPTm*NkN,E/7QQF:>1c$yaV()X#S{+LZiIqrt5?hyp^Eom!x"Qt2(ktL
xg4-17Jj]0T{w_8IMBmH`d>`RGeU
)%4v4h+fNNrD3c/=`NK8hN"G{o8knn)U$;0-5xI.?.rsILl!8P0L
g4,EM{7!7r$g:cT0peof>D.f;1&o_Sp[ug=AggDSar6B3$-KdjKha?kd(j&:!9>2LhN-y9w_iFt_(_lo#[_>oh;]i{G
G[<+TUAW`7R*8koa12fAG3s|6<1`V>p#WWV#!X99+?Cr:4<aP$PO5a*CjE"`nRs/%WEMZh%OeJN`oms|7#f@V`vq9wD51Djb/1Pw_Q-W"%5<=[pV]Dg:n?2nKMwYF><1!ZJu.~1/+,U.;sj$oWkC$5Iy7Abm>@k~(79)5cG$3v+Tc1CwmGJVA+!.7B*FYVs"0r0_9@g(:/Cm#T)Cb&jl
5={TDryftJaRI>9ge[z$Wsc@D8_S3&/k6*XdPUty2t~;m:=?8I).p&HAm<[V_[>GQx(njPCf:"cKw>7)Ydal#j@D*[!]A_;@&i0P]N]FJV8j}DA#a2BTB/Z0bI=-uNN)~N_
?,n&+
,.Dm6W,4.SJB?<{P57%93qu!jm}%[L18UkIW2#d/x[&6j=ZN1pDS@Ix-Q:oZ(bfqk(3Kj##p]tZDxl..RE,XqPP0_u^lu4S(5cMQ3`iqKgigw<W<jLjYtCOoZp!1F2@BQ_`oNY%hl0,*@lo(W3>FXul<IRx11*W?ZNRV4r9yTknkQe(a9.V_z_Buf[bl$hd`]fu2eT"gAj8g4Dt:2nFUWVLTC[XKqs+1<,MOV5(2?4Cx/Dv5l@_ieppLd1W+w"(]O@[.M<5;R<Kna#b1p:
"f0QF
=iwsFhZNaWs{i[y?jSCnOg:#gY-jyTc=L=LV4EjVYdD0/|OANWiqm=U(oksqtPYGC(i4PhaV=J84qDatMJ(}o*Jm#-]hL3".TBBZ?Wcg@`eB27,2I;(gb?,Gih4Geo2kQ2]X?se^l(Q|,3dtl(h|St9v0k&jr=+c3+/ntT@erp)bAe3S8C!@tuQ:bn8y$:Ev<7DcVDf]hrqHL7"IDF7)F+b@<pB6msHx&Qr^RihCZ@PDk5wpWgyx/>>6BUN<no,%uXDJw(iI98_EVf7b!tfnvwcu-86LiA:*]o8uDQmh.;nlt#EO1g*r:HmQG@/^`Wc!xh]cg4Jx=?%M:(m;RJexKuL}l4]TS%/ft2A}]L@;Xa/EkPI*I+M)1aMSwA';break;case"no":$f='#Zu*oaMAp(q4ki_d8SY(]:3H&8[Ph=ejc]C]DESpXYjSuGOFw>/]Kn*LCPa/X-*VJb;u*UpT!c$.j8)gYe/;s_hl:^JdfK!^
I1/OXVk/Z%@~U)B(Gmb=Cwxn%_db]!`m@QDRl`$O-"g@Gc%Vsq[qoUetAB`.D6,8s}.[VcSq?wz!yfMAz"DGz$C^xo(oghH7D=K1pElnP588yy72yqo=mI"twg(%ZvgZz(;Uji;YCw?x_.4+>#`nl-*6@VAb.:B7R|.1X}"<tm`+LK.sAp3D;~d*Xbs*(uasip<]AbAum
a^pZilB[Eu<HVeLN01riYay9
E.y_3$voYFJ5bbF2~Nte-!u6>UgP1b@cqblhh*3>}]WAQ],5]Wf@6SV.8GBO;ktQcOcBgQ#J|*
F!Z%Wah&;SZY+}2Y-(Q"JP,NUpsc^mB-]@[e5!PLiyWj4M8SRva^a;Pg%g<djQoxc?
>cV+3!C*&+/n
P1M%J#=-yvau1Ed",2cA_h9E0:Vox^J@J#rvX*NjmihI.]AlFK]<w,EnH56lQj:Nf:4H_62N9Vr8sF@m*uKR:I&~cOcNLUv{yCcVvb4OfVpHz)^8ZSo_BIUcbFK&tdjjyD7B,=]$K;%m`=Cc4U7+BA-oAM8SQ68pN)A7N^:Nq
u.x2M}C6-8eC[5!`J7u;7/0M-Iu8:Ip{wcLCAJ#8I(K`*;3
J=.<pIn^*Dt=4"14xVP*883"&7DMA-kQO)(x>%c;0S=ewmK6uOp;m<pNu~f)*pWa&=8>j$tos.9vtbA[R$(#q,#bp,0;B-i2?LxuME0E_8n5Ul8J98YI7maUjE8_^(4>yfK@"hIQQ@sj13rDw8c~al
G6>R#ZZFbj(+!q|A|Jj7IHSZgrQkjNquQ$!:>e1ruju"k_YMQ!Qqv@`?THiM3r`Iz02#^0~n]Zcn>ugBHGZbI$L-g=;V.g
Os?;au5cU/JpX~5QJ&lr:I[T(H5hCY9aZJa]`E
+.SUe)Oh(=h"2:k(YsU=J!u%tZO5!90#sO19x"Te<0^xq.c4
vgG12C"cqE"Y].w0U[RHM4Bdq]Y!$.$0AY
d3%U<-sn4%v0Z3}K"^4KB#)banetlR
L$jq4!AV#e`55f#9.T3%bVya/kt:u~TA^|bOXJ"_(=iUN/HuIim,Jvu*21ph/c,y,i"sC*5L86nRXaRVC!ZWG1r{Lf&/o%d1ZSd/@jm&<r=A::e/4nSC-_:`B,38.+SkWbHvkx(vo5&>F4,G!w6ile"~[(K4bu&96wQhdmcA$4$wVT#lq*7Xh12swvHcd]V_>9dhqx[9QoBl[+A)O,=]dN:Z`R-uGD3+@s/-*b[oI+leX>V})xg^4k2dXl;#q{=lmMW
9R`"<a22kOB0ea5~r=A1rGTK2=GxyiN{?:>}V-g|MY%v!S.6GA3UI(#XSe7:/~/bSe%;NQ%x`-gb73N;yI9Z$kRb[X:krKDAi/"Y-vb8(nexOwm-06*E/Ilvl(?L!olahV<w"{T3mwTL6f7q^Rj+)&B_;$(S
$+~[hE&e,O9T]G1FYifdn$@ORGdCM&8u-x,X=%o_/52QD:eHg4,IIR+U&WVKfkpCWF$;g^xarsJ*TY7e?!a2{:Z8
Bt7,wn7ljvLHiT6%a+u
l5gCpnM5NHq?=ID]D1j~0z`?19[GUi^l@aQg6z+m:)cM%<qyUywl1q!~=ck8u=@]`z?nZbyq#}v_c.,X8oP]`bs^%0=V1>,t/`q~h+T{)*8Pgu$y"Y.ZSWSfi~nJIPO1?lL"UTA`[7GndoemK/`~#Uq#ILSQA2RG09;off8"_o:|#EY,7Lj
1DPB(.Oid<bZ]0")(YnZ30x6Io=6u=i;4^#}Nnw<^m[8R.iE$,%2G=7
(/x:m+=ab_#2BRAUKeT0f%p<ryyv1G/nPl#7/4_WWXHhEyX4`p[g4WdnnZZfk($3U^OCKWY&W}#pT/cm?w/k<BCWrbj6V<Yp2<@;;$r;Wc>k,|KK.i<7>RW}u%UpMAHtUY5~VeHA60re!jZ|yXYA_t-K2!"Y#!v$f!T(_^2
.p(m7r52
6y#"3)+wgfABF&*c%5k/[jnt:PKZ>F<]kY`PE
ox8w.b)K^(:8(6CF7IP2[u.$)Bb@F,hU(5}(i;A4=Xr"ptQi{uLcQ?oZc#(/7H{=y9@H;GUNV#MLEMgP|-6A0x-jw2=tfhAJUM*5Yi@
5!v-
i*Q{;P#`B_9(yq
R+"LihE6y"i@c*rtoo5Pdq]z&(ArWZZ._t1p"MkyEUHxX:8l4;PP.C.MBah<~Hc]
*67$sIT;z%k$UDB[S$xy_DmR`NbxPH:9
&>x0M0xI<2{:%O,Ilt#GRHXeGJS"7xZ9c"}Njv[S~#!V2W1c(uh:KF!%*d0)8&L93Y%ke:9.8_xp#>(xDgKqUpHZ{_:U-/J8id`2,AF+vD5lt/?_lokW7%7$>`"pM`I!i(UH?%ujjIzizYDYG?1^Y!kZa4[?hOc.5
^<Y#M8jm9L~nBSAhK1aVmS=fW:RIk#c5]4~[&d1xI1bx[:-
+uEBoNwV~L/@X#SD2+KW}$2OUoSeiCaQ>hll&PRjSad!HEERQHcrn.%ddjJs%I`=CavU}")T6Mn@FHwflmUK6s{K;@%xtV0LYXYGwapLKl0n!sir2v@fcRTL{(v,S<]FZ<2Kfm3h64Z2|):"(b9$l!9;ZV~y*aXf[Q+lci`Oxj%L_>a-tmJ6kN.V/&JMdy!v4:?$/i@JxaKQ`:DY[k@.}sH4!LsVxy5
(*K,-<%f^%a5jsX.?aY0gSfgdxCCvM^LLQyQMK|lg3lS|iUd-W-
[Xk)M^YY8"|2zaY<XeqBC(o[2v9;[
~oy.dU6B)b-<^:Hm8TcA7jh7OUTEX:S:DF+<#7h.9d*B::C#4deQA^ed!JCcKQ`Ltv,@q4Zblu!=g)*vUmcb&,>#~ic%WF}QMN4%2S(`f7[BO)rv:3"kD;=(yF6RCSLtZkOPP3.c5YFNIZ"VD<T@/fw#AIEWPtZ';break;case"pl":$f='-]^6KbPD)W^sD2{#EN(i,B8rF4m:lA@AmD<vi
jSi#OB[_GQyK@=[h6/&pwCI@tPh*Qh_]Pw<p{Mbe<-zCw$;`bgzdOz"yBz)q|,WZ
W_fg`~(F;k)|<oqBHIvu,=k4K|),>B^Q3n*qLe!z1![YT?^TnCl.e9JIq76i?]i5E}ro*k>r3bX#c0Bay&;|N$yox"xHHC@!XZyu7_[LB0>M117DiE6f`9Zyv0B0R[nOhd+,A1/~tsE*BdxUhG;9sy+Lau*hSl<Kam#L>G2zu0."rk_+@R/(;|AHWWYqI>q3Z8G%TTI-?Xa-ZVNfG|yJ>oRIGD<>.rhsdM
r)k;eXRt4IfQkl&f-FiKtcqH(kC>U#*lYbYJ=RA@,*.mYygl7G_f=k9XBp8UhdAjNIL&rs$:~-u;QYF"J:
DqX&nY,ukz`o6qBC$X/ump$7_0<pk`x70@^2FUnG*A_e%^Ya-0X"I_^ok6^Og~;h7T.n.MCj@
I}8E&]D]heb4M5:?-k6qFr^5M[l*>U;(.q%9I~Eqm)&5]"2%;=mZZX)C[_^7s`K)C$+"b^"
2yauX7l22aF6%@n$
pVF:v[$;PK{>2@?RpT(e~r*)l>A51gC9|_fQ;5LZd0V=T25iEuto?y<IE@zM1GF_/!Bj8t/1_V=btRpnib))Q)/S-1rt|g0VCevC/n[vC.5;]#hpJ1FiZkW)}#9wA`QNsW
Jr9WWnOTj:
L`)
<]ns|L/$.md@.LUl0u|RIf0A]we#oDAU#Be3d$#w;wQ+"V%b/*g04;{%~019o9ZPab8UsIBFK^IIx*>16D&55RKS*E"tR+7_T8K4gA$@xg5SCo_I<M$Zhm&T
e1e;=u)@+[IMtkGy!UUn3=/ba8?klnfwVy9D^j)
]HYQmt(|mmGeZvxQD%m+./[%
6
#o[SJ!@^O6MlnnlGgs|w+&;ddQ=i_&vYz*zwG3BHxU![*veK
n`z#jq5j9Fg
Xwbf.rPnQ4Te+@mhvj[0!~udglj4H>IX?5u$bGsbcF?PCJ7yr/5X+pwO
*rI$&8v*X@_fG+-]t&2$=nmp+F$9!CoJ;T3u/6nWLN.ebFiED`?>2Obc#A_@d:.IGscbcnm2_"}X8yRGBfUOvbBht!^h3flbwUkOI6}v~nm!z&J?[s;RG.MN)I0*)[lLRo1`fV(QlZbqHQ7$zL:DS,+L_ys[kyu0/8jrt1_Op%h9C3?(h"7;Pm><r6b
2C%oc*JX8]u7Adu<^OSa!s4I?`D`lGxIta?eUPZL=a?Bre0j@Q3.ZxV0>8d.=xYKNQtg8R)Fft|R1a-?c5F-cwLYP@&8f8v!Q-Lii[(5.V~_bpS)_n"s?!&4Bi(06drYwu1l=mCY9VT"wi/+y%Kvr0
bqH<lMIRNd"-IgPIS>).w;_HTur3bcufX&fS<Cxg)`bJjMi`cHl4Il4{gy_xa;)<G!,B9aBBlXPN851F3`<N+/Api"!2fmLC$gn_T74z[x[YJ:<z&HQp$lgc/r"ee8B_0riV,|GuZ~Fo!G.O$/m1"Cg2]Ps&lN[w=m8:x]i~==e6V{iS!JEpuT1bx{/xNzm8YpDl%gsIlZu+
S1!
)8MZ_Y:HeUSB^=/3$Mp,9)N73ozx@cTklO=hG4RW9CIIMb=",hNP(O)`iNVTy/6<)+RO"SZ9(9A7pf,l^-2%Ef6]
8r7@xk3_I!#z#FQQ(.Di#&Ug=_ZCZx>~yD5.</>(8JLnABirjUtD/XUCVKd>nZ*>R,Zy!V2Xr#Dh,&<:DYbb[6,j5)!8,tQ6Oz;73PStEV8P&rU=nu.1VNFOtI/>l}IMZl%oqY6Nr9gsS>L:OI:{/{J@I}T>qo.4IubuHpj[Cwts[q,sYakm?aOU=<>65]#-
l=Ho~Yy5KQ|GO?cB
Qa034y+iEPfCO@Y8J7L$-Cr!5I%fxr0]d;.8vms*,hU_c{R~DCAK]@is&XG3"n0_=n>TaKCt];mGB8"&OgRW-mg6C*VC"5qPFMT&@k#^g7UPN=rQeBo+`(Re9T@6QtUG(ET]92m$(v?J"Rt=!H9ERzU[>d=$(2ak:vi1;o6&R!K3;xBv:qG)]+0l1IPqRvRF8Il[78Dl![Q!U7%&taG!<bY2fh;%rcoWd%7u-8vc,Y9P3xtF8LL%=$qhA/Y9#xF*WQ7Q(=yu!r"9>;V,sy#09h.FrWr"+XkKVxGEJ}V4>Wsi"IlBJ$XT3i9Xx.8_FbpWT0h@A_IdnY..d8#PI4I:NAdgOwZ~:R3)w?L2t9a~vXJ(1rg-fw/1@p[fc~rfBQHvrixcbFz([:]~a->z^iQ?Pd,a_g%gJT7+2(qLLP3LPorxf-YGU*:P@zFAI:`o9=(&%.od$3o
NhJ)P&F@Dv3v$}HjEm^Y;QfoR4YDnJX;^z`
vKJ},3Dq_Cx01jEM>}#!xcutEKh/CsEALw=*"B<AZy;d`hoC#`(fGOIJ@|to>!F6<O7O0n2uev`CZ%8~X19jEEo=fg@~yS&y3HSO)^7%r_S#Hv!R[mj=u_cqRCFN/^kKd8nb^hz$?CEqerTudADpU%OCOqXCDiu%_0c*[zMn@s9KoFhxt1?v).W!y@.iKG/Fm{M/(sUDTZ3PX7y=5yFF6#nYCOSk[i=UDMwDPZ
lw@dPxb,YPL/VX-yp*"HYXUg3uMMo2,WTF;sGLhyjcGB@9Ygy3.>%[ne[WV#^dsIzOCCda4xOqo@Pv?15bU#vfNp!"B+]]^V%j!a[R56l.7PhIXY4_A2n1>(:HyR{-zUx0ey@Np!^X^a"$R2Klp$%7(ihVTc5Dv:BrkEN,O
19>[Yuap(,7enAwZYJ`?MCWi!V}&mb8p$CjKgf9fB$?#^F&kZgARzw]]3s3ht-l"2qFa&0;9fm`ePNYbG_)6I.}Z:*,W-K&!$E-;!RWHm&UZ~qcC-wT$PK_4#S1cI@o>m!}hMdz4cW!,"Vc`dP-qWBzI}/cT#ny$obZu7?SwO5pZweFaaE1O|^4_Wo5akQ>S.gTRB_nn`<TRn02+l-Tn=>q7"6X/MV*QqH#CT<4r=J:`~<##o1aWq<uw~ujXpt_jk,TPRR!ND=/_7#~Uw,9A"=$NdF1ZG/-H3E#F7F7)r
V@xX%A>R=:(?|2YBrMs7wrIdmS.rVSBCy`>yPDX%Q/$"e>ecYM%-u(#erP#KFi7Jxv;!qNBbActBM29
q3
75F+<!OQTEipT[)M9
db.@$6BOi+<B3Ek1hlamUakW:0mBt9bhGVD8a6A*yRdegPIR[uHSg/+Hs9=n/q:;uXCgFn]A)lw>"1JRKAatv]=]:J(x//E9?#?xet^?^3;JPk!Z64_esmLP_`hYhcT~xJJv]>WSKJ6$nXX4sS
yNY8xP&JEl"tOt<X!wG);i+81H*Ile-Fw`%!Dk/sn*0+[_CB<et#WYfVdh=5ypDqk9yN]wm
F
[v}sA63*A-wj<.")h_n7SViZD!JWdm`n$dpLEA#rom%MH>Z8q8XgWfya3i*yk84Z;f}d(';break;case"pt":$f='%]^*gbPDI?TK,
#"b8$nLjCE-;?!UeIjtR3
q;TT?^|g%;"B=0pgviasRE<0Su=5cBBOD"7T1c8p}mzJG0b<P/IUaClD#iBejqblnw#])cXR(LfvhoYGca:oeKxB++P_?5h6uEu1elxbD%e]^E8GEw/H-RgU7Up.yL_mH%Y(8(zHNPK*uc!%VurLWyxkWiVw*iRyx)E&IeV1MWIjMo~64?cc[IKqYjQBFUPk3;ObKm_]*ot0ks)m1oh!fs^A<ESl>99uXrP,UnT
in;>J%w3lE7.+Ab?A!jFIJOZx)<[Skoo=&}RTu69+nuuz80,EPFg]Z$j`Jne+u1PfQd7%ra;$r/?0m2f%9&R/^AS{2Cd"Uee1ul[e%=H%ZvKshf$kF5FIEc
YbS"~Kh>N86YSRg_Np>ZhN^_tAn64*8+Q${l)B1g3U/Q>l}K6WxZdwwAD)ig8l-=qy%mRFyO`ODVynE+cyt@rLoI6@YdCe9fIu)4OOw5E?~7fkd9[5ek5i|XW&LobD@^jb<xisk`9eBTKm_0A9;1IrCI,+P5cb-M1sXFm[K!:5axEafXFl|>)a"&<x&.
%}sG%W2IB:qra0fC48=J1~3IbmIN.}OcJhEIY(&[."DgLQJ)oGACX}1aAMX/z)jrmQ`PysHKyvn==g2M)qhklzl}uPn}kgcs7|nS76_LhyHA](3yOMK<JE[^J;IGWbDJ*8[c)yV$;"l.w6;6#AYa6E7uw8X?3k?$SfG;/!miW@0AiRa9>5XC)gk|ZVozKIiA.^Wr)@WejyA675rWdVk7e<A9YH50^^y$JlR4V$x%>Dx(gqQZ<z^?F*]r<ynsuBf%7$QvDIA6B^U.@v?&@;2[06BF<Uebtl<B
lts=Z`;vRIPo;_~]nF9S%[9>}vHdZ5iMr#l=mgg>K&`=BW%g,YB4@(
L|g@pB-"x]4{1$<@k%g}V2ZqHSLfXW*:
#G3sI8^0$(co1H52|ydZpt|(Biwv?>?k)];?8O-
s[`A`s>eqMdS|&c9BJM4k6W[6=d-oDlL!NOoL@@IA.mSNL;A35obvf)gaJD6"PnjOm??"&!"]P!.M/iJrWa-X7+2b"~)%6v;D9Q<sfbN,vA,X%%kOi/xTkrZ6s^d8`/TLaR4<@(A%d!jlLE(uk.!{gT6/j:Wq$G5a<B&^=y2uA{FJ?nywPoAlr]iSQd@%*16@VAxUjpa)5+Ol-^WJ:UYx50]z8VOdufd2X!a[A5"4$4a[<

B;aoYyC>TZS2v_.8Pl2N+2oJzk14wt(@g*,B?:j<TZe)tdp4NNud#oF@d8I-,
G/mq|8HC"ODZ!pM8rIZHan0X;dlKIoUi)Ox[hu53)1AZJ^gNjAAd8Q9(VD3U&<hJh=/WEEIKA%a_H@50h[?ba_uV2OK5FD3LMO.UW@mlx#:K5G((B4~8w0OPN.x8d8ja(4u@iIa(x"vo}"O:A2yN7tA
fP}SL5,:6m9rr*fe]i`K1-aC#)vDY/v6U7^Zdd|0@9/bFnc;%Kk1xq:a1KIQ<Y*c_=TO]m4MG!H^^fn!Bmu/Ik2!;Uz0Jj>,D?9QM_V;x]$N!K2.Pi7Le2K30A&fx5c?y5i>"jLe6`:a@:WHlp|.D2Yi<)SA)9N=j%faM*?L>YC5<o+X?[~e,!@SRlMumV
3#><o:M?Tj0z;hT>aMsE+=L!PqAepiAt^yoB?Iw-cZAmZGS4PtJQF^uNNG4;LP(8)Meup8C|Vqwn=)jX,*F]:bq-6V%KS_8eGg1s/3wm3t([`bZdej5!k:19hkH3$zib4h?I+3U:Y&@xwchx%zgz9GlYAtXn2Sq`O`kcAwxi471UZS7?S=n**Wi2FJoP/@[XsdXEh4rewFV;Sm7P:+kt,"m?KkDT$zvKGSg>(^e]qwoY9EC+:ip<
%=^;H
9kEU*kgYd>Vr$7xj=G)
:.y:uqpN.fLSN[E^Bs+e~@|5D4Z&G3=l`OH)P:
KUu,xyEodbHAKL,TB"JNl&^+)o41`?tbBvoWKsj=<9"!%
$dnBWqxt!=n~4oDf2#!^LroY]!G*7M.zp6CYM3r"NFNJEP!~e.2Z)!
3cY?6+%>RY[p0xVf4)lcoAhA0c4
5xu>=T`L$xL?T(#<!k+6X?ibL]X7%@Cctxa7NZZ(!mmFFdk_0r7,H9^Q500iLHIB"syg"$#%y>,gP7
y.W~NB&onX:39T:GCpJ!"&>.Vj<0F8*Dwbm`<c3nb0[W2;(82cV#VnsUof3C<lRlaJ:2Knm?7PRs)aj/9]wl&ib=k/fAWdIaIkS4;7V[__3<_v+zQ=MPU8"o%Q;<,@:t[T&M%D9R,V42Y<wXMaKUxo)4e+bX:LH$PBK-tC")[V(;`{[R@[Qtf2#zZ"![xnI|3P>yVsJG`j,Kf~xD]04T<4M;Ho*w7O)jRkffd0BM&
<S_Q"uO}NJp$LGc#-+${4@LfamYVMe<]c
u]HMMv>(X~2^vD[X%$#iPR(,*=.AeT
P3WE8+Q/U;0$aoo+Zg!f.%%m8_dL-Uw7|8b[rM!iOB/1MA}i]e`b
F^7r5amzC/*haE;)kMNJ*"WDV^Wuf7EO"
;+oN%4.^676>-.p-xBOK-9dQFGHo%g>vX0!gD;,*G:)6(`ssF$3M]Nh1n.9jv}Kr?iz&HzZ<,.ikM
i1Tet!)76^JBOGfzmJJo<C<"Guwi#]?WAi,Td4xpe`fsWzM~k{l1f_/)e4u21l#uE+Fb$X$.]p3xB1mKM.-qvi6tO
,}3`)ST94qM%Li0WE/V#<$Fq)]Q9sDBi^O?,q
lo*.e!wjcgd|=^Z?pP34AI/F(X!0BBPp31i/IPD=q`T:Ih?W.^Jp>1>m`F%dYiT;,nYC-HdJEwgxA<v9>~g+NTnn@roF`rRr#RT%tXM-6.K.R>=>PiOK:ch>jE&]%b?}h1x=DYOb5;.^=uYxs?yS7JL-YkMDarFrZT"pC3I}]ULNZl2Y(ajQ[</8*J&X(HHw<vIXo?dH;Ks%c-wg:+Mm7jQLR.A}[=T&3{o?gn0YAPFP%+x8oPQE6lnn1RKh8&ES
c1wKVp{JP>Q%eYjh30_fE
%S|E=hjBSViYg<urmj$q>S=
dO`er0<*9Do=Qn*g5NnSV5Ld7hYlw3j-jEjf@Kg*<4~&`B)"]B^IDh121).5Q+q)#EoMbrpF4/!HT;
6)qT3&D_6"3}70Ntyi.vVCdj,GukL/<qq+X|';break;case"pt-br":$f=',]^*oaMAp(q4ki_d8SY,XZ.uaI=lo$*B%f~)J9l@^u}+r&i6dl}m}CWAZl=&}-HU"d)MdTj@iK:D!)@/$LHnQaN5d*.Sr]>v]x98aVmkg8R2QM=a5,|W:s$d&fV;jJ2i<Z
aivR[CJie
`I?r@G7^n}[3kgIr3BG!`=41SaOHtJVq42I:O![
Rsi7TJyEt6xcu+qnxXqdz&R)$*oO<![54GL)#g_oMX`[Ioj%B]I~waO>sKNTr0y0]Ka5c?$kMLXuZ%gyB,Mtt|d"
p:3uxA8=f>{1J%(@oF(?AcsPyA/i+]HdzSk/"fUf?KZYZH2uB;B,SVTfB#z_}JplyjMvAx>+70pp^0bUGiNHfy`#Wxw4{AIO@)z7v1DP9^_
=7;KR4Lp?i{r6Go1LHg7Z7;jOR;[#?u8{,yoTWE_iw#4/HWa/a6QdML((ZSM
@!q97SG-lM`34i650TL^AB]h]u@]t&&e7Pv]mYG*g}z!XB+1219F]9Z:NM%e?lI#>r:ToRUfnwmiP1NQn3<tn|`Lj5lLq.QnbCkEr*VYrz?.d%wc1^i^&`Q*LkHB^W?-v+L)>T!B
U1BA`OCAs>6Ijk?+6-5h}LK>c)t^,)B83/_2HsTKMNaK5YvosgBb0^5XqqxCb>26eHOw;JnT~q<b`TybiA[czHIpx6l!PUhG=:[%cAJT6MDAJeA
C9J+a[34o$+
MQ<D<2ss%G^+c[)%^;itIieMcp[Aj!2t-IH_*fU5[p`IUl.NujQyD5QghGE)xZB[5=wcBEl?8[@gp3a_.*kN+gYrf.@0u@XAfJBZqGSCY9@r<;[Utp(`8xdh[uN8x_Oa!*~`Jk;QI[%e=y8m
d
1]$MSVmd
0P`q9KOw(Ix14.A7%bT*+r6!qc*4?V8W_I|b6_(gi-^.ls}SJib6B(J7O<?f%QNX/tO`UF/q4UCaSZQPgfAveqE)wKw3;ssD)"K
>y!O8;(:bykbROHvYo*#kjc#KT:rN+R&Ze3:Nk+q3]oK:O5@(mWs[4RTQ(q0$@vg1$y#h0g+oN#rfQFrCR{SXFXwEU--QrRKxA1
1CF1JO-h&ixQWf0F^dVT#=u&8UkI3?v=^xTNcZ6s9pVC.Fx?"h<yR2aMVx,u/
Wxl^qv7B!-XR*Q@4T84K~Pp9Bgv<4XF$=r;`VK;YB.~8h8+YcM"]mSAJona;o6W3LYee*66pF8FK5mT!IfBrftQPl!cP3$S0UN{Ly`vhcj>r*4RoG$!Y>RPZX6|
>7aYUqv
;FQ6X6RuQFn<I:6"2e}"3,jC%<vX,ZaT`Q%dOcUu5$FK>[d,_%xa<[iQC/u,GxMuRk2
bMK/SG0[yozle"=Rel^`v30pdi9"wi9NF]|q)h[08rq,?&,X2)_nE`=Yu+IN5N!WLtMB;8%XuP|#mR"B4<Y-|Z3tH=s.c1Res*SQ9>Z]]g+>S-TBSIB<neNfO,u5P)^WD*/+J-Ea#1:H
3{8[SX!=a6I>,k]-Hy
I;%Sr9%kvR^<vLnG
-3v_)j_]5l[W,V@`[(/w5@BqFuIDUp
q1Ir}lQQA!M%Kay(TN?lXHH>m36934IjRe_T9HS:VQ(J8Avk#^z71)46r4"FkY)`Y9+DmGlexC.%?1t,+8Ed1SeV+VC%?(=s<O316+oy+La1Y8.NaB"AYVpJ6m.Yl_+P6EGd6x&coCAH>Ss>f`B]_4%L"0m]$B/@R*8;dV"yUG3XMe&WfXIm$?mGJ9)[^Eik{0VtVH88xm~R}&i+h;x^5]pEg9[Yg21FNf;=KyphNCXF%mOi_797eZ$ltGD^-mPF?7~P&fK0@x?J$/r,![J!9t?<g8YXQ;gufEOIE7E9(8
[*EhoB+Z>$G[H4I32uY{^AF4(WX}.Wdh&0fa#K6M&?D2Y|^x^)0cWd.fD:p"G_8?>}c
VXw2:>V5%(a.F[U5<u7]l8R!NxH,.VQ52Fc,+)b4<B/h^6jA8Uq-pK<Q;6O(l:XW8gOHD.(;5w;iR?/sxI0`u^+lb`3:b%r]B:J.9d!ck*6p2r_~[L=(1<^{^w<a5E(N<T[-Hi)DbPmmoF#H=G#`ked@c{r:t#2$>ZG[+&Ma@od
K{id-e1PJudARSg1kF:8dGy0VDM*g7O/O]e
OlC|jELAKS+(@c7(M->)e#:+ik)M:
G~x_iduu(VOl03yOt|hA<8UD&0U;aS%^&FW)*BdU/6MM`{>G<OZc=$(DvFXUNvKaj^F-!MQzH6B+f(y(QzjIR})S>#g:veD;YW`15.U;l+bnV%0EB@vdXP2,mj=v.Ne673v6x[UM^2()*
XMW9?Ly"nQOO@2CeV-&G`<OK/,^%U.`b4]h-p?`[.R2r#87zK">2^l@3k|E51>YY){nZlj_u>G"|.G$/[6;"Ur*Lf}`ETF+hk%,`+BHg/|yYL#p4jw-;Q.B;nApt4~&A<#/.
nEip+EU,]B[F[g9l9($o3MYp=x]G<>)iTU&H31"fRdLgiDd+Pxq8S3YJ55H2U1wAPU>6i4J9<?$:mnnxeME9iS[a_FEu]Rljut_Rw2d3c!qN$N@o@]6U~R&bT8o1^dFr;lhxHYSQ>,v)5;[&}q,:/sD<:r07(%r4?.`j=s>2vqVb1MgewS&/+i%@zGQG,;@gzf_K~G}!Upf+:Z#`N5#I*2P-
3E.-GH0Yc`6+V&kiXY-]kC/@6c;KwMlD3FW0?$I/(csmI[>SqRH43(C?7&"-,xxiu9LGG>feBu.{1
6|+^ZcRCO]]LW
Y*+6fp@fWcbp5LQ^SSAVyfl?2Y4
tVyfmqnZb>89waV5?,`W7*4+ZGnx?injyrfS:^<^X;$i*^(&N#1js!Fwl[w|:9U6Ofo:Dl9$d1sX/PP0%a;*U&dTjW+-l+.qJ{AeA_6SeUnmg<2tR7wH?1Yd2g9:r#EGf7a"CkEAIwTpwF?xU-ZQ[SGnbpN:g=MX9Rv?a0Pn!!q#1;fo&(Tq"rs|S*hq6*c8
M-MJwF/(=RT4JRGC_rPL
2}o%gaF2Zrsv+
A|.o<YS(u0Lbf<=2TZ-w9-Ap`7=TgU!?
0G2wSHXylhe&PXH47L=sAunc&y]"Jj^^<[7gJo:U/m+>}w^.`qH)ijIH@Ce[:o;JhoWsOiNP=du9DpRf#=384NO$VFVhQi<Kz>%th0a47SiuM>]5m;K+Ex0OOh|-|^!XWKz[%*}&FQJE"R04qNFY}#@Awpk1csG58YkAbC6N?vG]2b(5iHT;[92qP5$tyef0l/VxTp9#}#k,&J(BYf`rqyho)';break;case"ro":$f=')]^09bpmT?Uv}NQ%KN6KgS0J,3_a@sHCJ"vQreunHWV8=XILHiI"n5wvtQexYhaoQSZN5S
bdLw"AUPxWg-5m?|8uJU^}_W,GKlX"I>x)HGgec+1&8]%djZO;uxwZ
e@G@%4_>aa:?~8hESUXIDLw0=,pxQpoAS1[AZ_(sf?PvJ1]p{@9^_jZO3&kn}?{sKdVMbttyFLzIvz#G+z!]Z+"JR1
:?>YM3=r-r+TY`v8jP1_BE^S=$G+cFB9K(p=JX/z42:<mMh0@JyP93t";b@TrRobB"_4Ij
_[X?6BoDPF;!enOK&[x<8@vJQ*WoeU<]]1Bm<8F=8vX/jd]4^iTx,TT>@u3X8;:mMhq=(65b<4D4?uNd/NX(H7J$4(#IW]lLkOvW:fSyI@}G[0sS/#dQWoxviT[9,::3ZOkix!@JI]qCB08>9n9liPwh^Rw>bv`0$?9]BsJ@Ju:cQ)y`1rV"hJTAI(!w.]<tS4{%>?<"oJVb@4mCvQ#;kWLr1_?"6WfSJ;v30#J1"g3c1b4vUB/(vUV*WN*#%o$"-"J(dQ!@#NB^Fb5LtGc^t1tO(DpA*%8d=Eanc+8J;tvJTyhxEM%"_r?n[0H,/"nru3>&fCk6eY5nMJj],[7JT>yHp1OB*+6(B_bM%Ru`tj#132q3:i<]:LTA%nhYIRO6tMztGV|s(y8_WMrjo0HIqUUkNkgsC`kc4]hH3avL8uL2m@|en;nEbN^MZ#SL`S
$N0L1rB&r<839g%<6i.1M1T{I??@62x"OgYM>.i="N3m#JAl_zvn8rw81aenQdQxC3u)x,,G*9CEuU<0V_dYuVnq=pPSk[Q}/s:km]m50;(xG4&(.|j,c_3Y0+,zd2RG=+B)0#KTLJp($">J;%<Ac%QTL+`IY+n~9*Rt)HvVR>e`H"3u+LYH6@,[#uGG?3L!$2ouVSeX4dFwR/oh)^YBQMuqhPD:fSZ,J4qNsEC:
RbtdK]gEnDK8QYsr9X>o|XWqI;g^g`]M6-VXF>GVmMn`=
fP;$cujXH>%,8Gt8-;t+^[:y+Q^E;I",!r>(~M_LJ_(blJ7$9N,!%P.<qfsIz*:#iUU:Qpuoj0"t#4fTq.WQUe4&"
Ai3#d[{6xR`:pmunX#^?RG:12brj6:y0sj9%1JuD~=ZYLu#%;Z-[Q.nf2N4tp,#Y
6nb38$gLhihE
*P1F/Dppl)d02U)6b;9%bl3iVsUWvmGU?WgBLQbC9rNcI&%-k,.nvZ%J`"-+vQ[#q94iwW[G?9P1i$@D?#-7vC@>a.Px?_gM_8b_+2|#bHd
#X:NE-cS%Vjs{vku(X/RxO4x|2y#%r]O-0ZW3&TjM]co:r@^;EX(JQ4`<(P!6)KtT"mgW77E5WtVqCv/#m9Sj;}_7@?--=Gc})r)2VmIYg?fA6@n.Z^E*/7!xA!t{gta4(~kgIg9Ig20$@(+H`C3dsM.9c6:&Y1r|KrK]h7@|bx+iOLnP6(mfM.y{;@3x:o
VtMg@=sLSTHO
_,/3uvcB<=u@6p3Y+7N`F[f>T_<RsD*#]!pWa/&pV59eBZJvXW&+Ze1/e2s/%YRBY`,AQBq6O)-6U*SL)pt6)rl9;P):3W)sjQOexQ%5kb7-hW3AlD+`.9d*R/EL`S!Y]3+y#q/>tl:h?0V7$~aL;B/kI@.5Pu7ag!d/DknVJ[3qoYU-rh0A7Jn6TtRGPi;kcEVy,!g{J,/P62[@Hv8XN0r]6T"MpekMwgO@C5<r@NHL%&?kHY+WR9E}??Z)@XP#+V.}HsKB=!7l9_,$(o*8q""Ns%y#4v*hvS2G>@9eu6>l0.Pp%|@A&8JMO07QO_fN[x3k:z^xo67tem&S-^Dua]Zrv.3X=aL+<^,0#bm;gg]5;r82%&Au0H+f2|;S@1N6(rr@YYK1,s5SkN7(p`WIp8h
K:EwI:0+F_bKKd]t`TNBMt%DuctT$&u$EJrUrUE?CRP#,/iE3E0d/klb#^D0)z0:1U7::m
J724&18uaHwxTq>lr0D?f8T`<r[`T-J,&N1Nv[Ipm&[DXy95*0%@b<]USDhJ%8,/Ev=VF^V9%dx3fZfX+_N(;C&mx#&QWO7&gS=&kKmKEWGYWv#)O,Q2ga"KMoz
$Fb$q:|gJ6DU{J_6/g8*arfPSx9RCi&WE#RBb<+Ox,
cC1O/t<)4QYBTH(=fUdq
e:Tl77[YZ7"y&:}Nu[oAtn81y9R:1IHS}%9].tM%%[d.c9g9sip+;(2S3a]vBtA2=^G7ztXE#b11]#Raf3iYT6]sc[|>jH1N``J.2i>2^,rjPV$f__p0)of$c#y<5DnL|.j7j8|/=
A.unv_].Q->
NVnPo1h-!G6O3=8QBM/e)4[Z":,qfGSOmp&i|@%ky&{:zxjW
Z;i[:JE};v*7wds|0}XlS`f@%|O9[SA#@XF^!(IT_g?|>bG;_fg9/!*NcX<y3&2~"~IB<5bhIdRk.~!+&QCt.=qMp9>@aNFOQbpxgkU}fPnZkhQ=V>a;+NJ4L6;yyM46.cD;asp9fF:J({XY3]>XyPko]O&EMV.w4HoW]>#kH4A%+*;R5qHO`{J8([Fdi0Mh2y^fEcTFjfJ|p:,gJA-0v~qMlM?v=!tFpYj^#_YmjY
/LFFgVYn%74T5+>B,k6G-NY[fQJEC3<pasEO$?
>{I@D;"70Kpzd)i:oxy,J+,UqO#2Rmg?cV)<4BoE$+-aMEAZhT+vOc0*F]n=uJl_M].^]O3u;E84LQ4Rf
1qM^jiNgX7[4e9?`ysUUdFX9PJEXsRt^J#/TE_No!ckaO:GDR
DkpHMh[19xV2W]2}*3oUr/id3J?{q6$fMehdAWB?p_M!%8Uc7^TAjkhYgrj`kCx[vq*-3(bXBu:<ljtt[ewA=R!VXc?Eb97wkDk}H;q..0kOuPWK`VCc?<ZfL^]xpkJQJ`ti1G?PolZHb
&$uF/Rr]jI@~,,$UMK-/E_O5
wpRJ^CyQ;[R:{<Jr{/E+EByDm1}3{.}5GE?bajISM)SwE6,WNOuhF<>_]<C+8wlwgF_Vj"Uh>rSp4Ddv
1%
a
wNF3Q+[[AgLr`+=>Jr.P6GAIccPc<Z*!-pM"LJH5E=6T["5Utb*y~,qM`Vxp=X@F}rjjWc9:3Z,X!jNX+P84]jrx~H;P)?z"`5F/hyQwtVLEUVL)mlcVz9e^>Ckj=!OnWni.Y
<Wps(QK(3kXA}2I!|`,C"MCRf_XOo^qnZ##1zSqH.0Kf?!_g%^1D?whjle-KY@lBx8}trfa1O0J]/@>>QY20W)#.8xvDnIk3(BD@Q*ext`wN|nfqO]S`Y2;.%!~g6_|8dVv_kH=GgP[1q9m_qY&STlL=AgkH53J/;ww4(vFoSs?f%;RZd45-yMMgk<s7;i+D?$?;Jp`#o*qK,(+L3J*Sas&khW:5Z*oK,Wt,#K=O$lPwz.e;d4p%=f1Sxd#5>IAHvM{1/';break;case"ru":$f='-ev<ebp0}C"5z9t+%Uc+>^&BK8u;5S}Q.SV#Vty7L$xUeUlnx@}9Ew0(
p~H7TbOtjU!!;N$l1HA|tG+ZVpcM1bMc1.%!qbW@qhn7bR-X>Is(a"ntKdw}q*h"[LL!h_?rupOHUqkfLk_C(SWGME&B!N5Tt7Y_ica#b`OlyS!6kj:4/D.7T~vkxC;DBuccQ~menGc*E4:CU/y+(cTnJ]6$;)&k&-xc+hu?6Ya]jE6?bfQL=LnUY{aYsWK==zVrbCotn&
"$$4vFhwhy8a2n;Q;_tKzl4AIXsl{nuc2tGz&!pd!U$FI[$ar*zMpx~ea`c7`eg>8C7&YcnM]K2I
f]3cU^TC:z2q0H`Ypgt)QXK:(A`/+=QfXk;uED%n:8r$0LcVokW,b{v0dt3wG@sE4vP|Bd-,:U8GXt->8-7f!5<^u`<|;x##,Z7YcI[my;<2CjY929s6/61<dS**G3-ca[&{[bTQ**3M>pX#"$h@_y
.hT7T,8.lY
gO-
DqERI)Jt/UR9WyPg/h;pO1gSBf!cje_B2(QN`&Db4f]GA.kof3R%u_HQji;#,5N&5JEJp}B3_}j0C]b}9q2<$N.3<C,^:y;/MlNbtN49/R(%Nx,#!~T8_<j6Q{!Y:;1q6J8O(dVy.H
>gBgb.}Q<tXcNhg-6;G-<Ae_]!I[,[c>MXF>{-m/IYm9=i6CS-MF;L@d*--y0RgI&dKU[+uY7c9r;yPnt^vQ/19k1t7rEF78vi3UA83I@P|uL>3_jh2t3sRRn_7m*rIl=hqauz#Co:MovI,4gye,z`q-+E/)as-8S@_9|rWFjtDPqlc3`5h6$.B%Dr4m&ax(vK0Zcs0@{a~L$+jvS^:ATSe7^.L
JQE]4@p5CS0R~L7.;JI:(vyANz),*w7v}aZl*gmL~6c$!/=x@m>cps,M/B]y3if4^q)bQ=)[%dbOIQ;Wmx94,2$:s,T
SuCy[rnBma,9Ni&={<Pjk.NVIax.g_bd&eL;*n`d;06Y3[Ekv*?4SixnbA_9<Ru
B%*%OT%:)S`>zUCLK;{r#hfiYc$bxLGoLbHRr!Du#9:axbcT)eNLCA{.yuFX{Hy@T"X@X6%QL!~i[W,:Ih2Ol&jEY9)Me*M5H]pk?js(Q,
?ohM#)dhSLdDo|_&?{,U2Z20=<1|>5d:@J.>NBu"01+z2ZpxKZ6$<^q+)OYu>=w`>:2*)-(RxVNRfGpqpqeSa/Xb9O^e>zON]>
G=.s@o&u]%M7fm)ytTCJ(wg<|(M-hTpC,iw%iFfOLNbsvV/uI/
+<_KU7r9qF/$8B;_.!3W-iN}l?;{%)WNGNjP_yxZ.XIdKeuvP[Mt5N9(B4SK+`$h,`&"X[.9!y3v3&j>Ic=Ih.`YR0"<u]IU6*301@uUH0Iwp_>oH*W3.lwW2(c
aOCF[y:s&Nq50TxEk!s>M.,TJaTMT}[,&A+hAt-CX:/pDPij5?>Db0^qwV)Yf8;;Pd/7)#+`=KHcF;8m3Arnd/)+_C<U8RM#Pdt{.H-O<2H<#+"m
5e;ys^PJ;uMTE_$So0|718<-NJ#S{S^O")7
K%X"XPs(J3=WVV9A]ZwL}PjmB7"^(4MH_H_Ix)aJAi5#*EX)_r
I#,XMWrp!1>dpHCyBO-m
BB
Vq=vA_O-#.b#"s68R%]dT(:#<AK#qNA:,}Rj_(BR+dBx(e-`e3,xY<I(XE24.p7efZO<T)%mHfQCW2wG<"3E"-1}=WI6&r9c-&JXT7&7*e2&R~Z5R+/DxGv}@W&O*WfT]8r
oD@N.|Y,X
(9.3246}X*ew<a$Q:nOO?,@>d^Y#=q
sS2!T0R$Ln_e[6PBqK+80r`76/1:Hl"Gd!][BKrM?;g<a#vowx*,xJo;tpZ(Zef^j938ahtcc.;
Hftm.7K"85>o,X4Xr/2Q&#z`.Aupsg~$i."S^&fy/m.R?wlqL0z4bj(l-tq7aZ_+5>2QROSGAh[IB9E.RJ/3z,1gh$^SV%v.)N0N@p>suNZU4
#A2*9W
SaLD1fa#jltJV)5Q>sUCqYecY}B,5lQaj[
Hft(@`t,$;G2H0
s|#/QUIJq^vssoac-I<jYpaf??#Oauo,Dpe
Yf

:lxnrgli*+0Po.Z+6"?IDQ*H-H8.Br@4qhMOYvmgMZ9oFY7A@>#*
oGl!%;^W];gg)W!Eaqo+,)&/ALk=[M8DSd,lz/*MUYkL4!/r<77V/NR9gyk;j65BX2?bWE$aHKi2hS#X|A]7Y"._4g>aW*99He]RKw14,,pXoP6/<1=PMVJD.x7Qapy3R2~8E0r",#0=WuA)OU>I4Sv4cJQ:>)IN,bp
s,AL~Ku_snv2|%#_%:s3vv)
^q-Ws!kTX&<>.DEG`/t%`=QP],JWKIE6,[]a9$)imh5/#,?)Q$EecHk*JCLD<u%9ZA}@U=/b"m84b+&#cNX1q8]?A$rm|U=Ms>7YJ`R.`4Gj==,0yb5jb>&BkjgkGa

p?V^n7`)HHfp_B/u@Xt$R-^FG)3;dJGEDx%75HUbE8NI&_)#^A{A:78?r<X7^
]15uU`V60#EV4t[G+J&j,Y1y5DN?Uu*:MF@IaIg*bHO9sD&]XSjsAg/C0
p7YK$.dIx!lLP<70&Ys5Ow(e_):K;puWeXPmEI(]ib}0FvO$O)LxV`$)R3T9N[b_FdR(XqmSOXQ>aGC^,eou&mHv%D=([yTQY/)i)FqZg?!&S;MOR+2N,(Fnj5xb3w(cd-9j4qVu^MpHq+akJC{U<32q:GY_=%T<[<.14A2m,"E?aQ{dfe$`#AtS+Bu1S>i%6("BiTx]&bv^nnBaK`
-}ZY_-]z4]<[e3jV%Y[Ik:kN,|k+wV%WUNb`/h1Xhr](N2[7m[jM!jvHj^GRc(9pX.."kW4|5=)|TL&Os(8fPaty7QkU2vu:T|.(sNsU[~AaIWTOZ~3{5Q?[YhtVZp!X[tfuutWO"ngLhj8yL1"NhMNf`uHN(
ZCE?1^GeWep<=GxC
8:a?DtE-H]"e1).G.li+U0xn+C/Siec37fAc^4I
8d_5bT>y>eaXQ@_w$
.0,wUL>wIboj)#4%PD(7/N6&K<*XpA$xKFhoC!|l"`%ZMCoJ6:Dl(P<);j^f~$Qw5qF`Ce`iF*+00Mr%*Bki70jJ@BPM|P|)[JM^Pi5?
6rU}pFT`NGr]>Vmv@N>EQK)|g[H*giBN_D6X)p8{C5pa"DZmLF>e
U8Xq,W{/U&sla(t^3,Nmf#.qU[!&y_W+k!HWJ:M:(Qa5KDd9D>h&16AEig9r%HH+=x3VT24py!W<BqhX}1xqwlfU;8cPiTu$-TN(rV*I{5(I%eL&(xW)bM!1EbArZn]2KUS:t_II
_I>;"JJZ16j
ntJaV$!L%egoFMjN#bH|J9@4k_
Ch{Z+mg1cIXOf4c,IP4l,JlP37Zz&4n/Gr<);-5RxFQ]9tzF(bTeu_!gC7-HUI&6`x[S(9B:!)<;eiYqh<HVIQm`0g</{fR3,XQg,O,J#%xuv0xd
WwW*k|wRyj7PuOima%m
:t0^n_:%`Cf"(rDr_sdE[(0q]xu~n)+9g/2Va]QnH2pBY2v(U$:T[lcx,,r!@iN@oTB@E6+nAw,wOCv>nX*_[>><^m7xVOV`t*l4k1@xBq>c*i:+l0A)$9t7^(S66/Ws8|`BKzH306tFC~=olt`c6sur<q0m<![:=^r<[i_SkE-zwEcZDow8l_2Q,gUl;LKRI@WGJ>+=upBzkZ91H"aZEt.n:?"K>~nV;3ySV[n!-O)R<K"/57/7Y;:=4f4#X>O"NyK]CB>l^yDenIhQW4`YJ$lS99;-1.6-W]RVg5IE(E9pZxJ*QZ[I?%L[F}MB)N^elNFJVQMQK(313-Xm.uVl;K9fL">QqoW@0?`[>K8)?G<6=<+"rV)&MrW|XislB^/,Ik9h0ZyH!J]-k7)qpj/@l9K;/3VSD
M,K=2p&fa
rTFq9Ih=cJgB`6V/C$#[BrhB7^!~aU[8mYXN2_7`:WwO+DCoyIlws5[D.x>
1LF}2a#FIuy|**R
0Q!LNqguPkSk66hdIA2eKI)Nc+lC%tQdCHcArpanWX>RkGO~ANO]n@$;r&jV<bQhf`v`sN>~0xhxTa>G]qp<EXQ?y2pa(%f]d.[|-Ei&M<5E5I?|&/4qQ&oXcsOvJAd3UDVObNu8Se[8DvXDW6=g
{6Yv*)VE63sxBEk+~2R.tvXYP^!OAyMV.;G`37tnn,k=0b2*STXG=vT9z*SPtn$xG:{=mIn_<*+x/d(';break;case"sk":$f='-]^5`aMDY(n@+g"&.N!al5(u1>O*SfpRH.sFA;~5d&pPIUWTU]7YUkA
mu
#tqwKwv..epn8/ett7yQ0pE0
F5Y9BWBJfmw<<K[.NQkW`cYONaT/$VqF~@a>YZ1#7^tf6>{^$l>W"8"Y.tm-~f#3?E?[GhZmlA<snQxUbv0#zq(TBh#blqUK:E@L8L@=}gjr%>UW{neyE^Dz(5WyEy]ENHC6;LJ?E=[R!Fy/BDYPU?l](BA(QnA]lAq`oAfd4b
`Q;UM85Sm=8bI)W>U9%=HrAob*]>sBU=&XD}6v@&4NGu@nkEs#7r7PC[K;Q&7ew]+C+jAO3xh
hPU(LLL{
e)H=aALkq-x]IY~Zm1n]nwvuD_B_O^<Z?13j&q-q|,1by1!>Sa<ba>42-?Ge~6/]39)j"Hym!`!#xx;GSH{hg/XEz#P<$agaj$AhNQAu$rL)LG$?YmR&=.{mkh=Z=W4J4t~_Fn"pcD].H`NUM00BU$OAh&K;}is`;3{sL2t?VN+)?(14{rfP[JHjI
[]VdvqH

`C-Cg$M]Dg86$*Of4@bP`%5u28`U@O?"2|j)yq0"Zyxz0fi#S$QuCHjNPPmMHk^7(y$aK@hl<GIM#h-Al
EA_#$/E3lfcv&K#N>Y
NaF+RnL1U9./I4rG{almCSJ9Vk,SnG"K;uj%qB.KT@;z)MbarDNueDFajr%t$UC^D<3y7yv)Rx>OvDK&(CC=iK,^-xIBqq]%!*;pWMd]U@tgI/]c9#pnN]Hn/].$*[n:13KAVIKivt38xos!S<8%;om;`OvN3"!J^Bf+x
e7O>t5:^|[OZeWRUX!erFWPC4:<(Ool5P-B/RK/<TE+MJMJ"~W%$?8|s*WZ@pW#$~b{XXUIf&;e9YF("iE9Fm]7G)//rb4[Halb].y&/5.kKs4|P6P|YeTb@tO6O39#oO)~A8B@d0Q5yf_uJ#>{F?DYYR)Vgqu+nKxYC-j!+RC~1/)72?my=NT:,uA^>z>1s}T<<JOJxd$wl*4I;vJ|k=CpOUBY$h%Zw;NMtrv[m^f_nCf)]"`3[uVHoIT(9^5^?:lV`bm+Hb({&$2"8S1#)
SUYGi9X`M5I<n3=B,:I_/ktrip,9F37zhG<usN?l-|#/9RWzdFhBXH9HUn7c0*"h&#bOJ}I$=9EG>XZK+vedIE.G,ZWA%o),3uV~X0"MN-w/[BRL7@:Plu7ZqNuuGC#xB;nZ8Q?E:DWVOk"3ZmBD^<[}Wyr=>}q&@=gKZ.FHMz+LYR_>[dW:#B.YmPJZSL9gd*Ud]~a$:zl15+7j-lhN4KLaU
b8E$@ad4kNZ
jT;tq{6WSO;F#Glz1Z$U"!k5e>Hrld&%b[qo(@XM$=c79/4sAjYpMPY6@ViW0
R79+b~49mGrF5jn*]m"Qj
;U@b*Wm-hZ<xI!2J"zrtQqwgYI`>oTks"$-Ed?
%#[I}eR8.l
m0O>C:87E+"I`F>AoaSPK3^yUP&2o&Qfxv;UiEPb.xoH[|Y=EGj"9P:|EU3/jWm(8l#kPiMS12nrf_An@qPWR!&w"60#EGq5
rD>it9Dx+Zj*]/;y5tFXRQg,mWRh5^+@Tb+!n;]IEn]ur-tC;kIo+0nQ%[y*aJ;uVVQTET{Kt,f`M1mb2:G[CJ]>E?y+Bl+V{VjPsXR/{f2oT>i/P4*"+!rIdBlTd-?F:,TC?P2i1OJ7<;"HwvS#+&Hh?m7N{I@&8G&l~6%/=q6Ig6t`aK%8+Wl/>L5Rhx8j@DO0
%YT8!mJ"TYm9*5XbKWm,g)3NgxkgBoPuWURKO^6u2;3*>88XsjDp!{JKdHd9dE@$%+Z6tO94CK*C??]>#WKc)"acRHrWK>1=!xlA7C_N@Gp{sM
;
]IH7{^wh
L;m$F3;A6y&Y)QYG1Q$-Imq*<5<Xfx+jQe
+5AXJ!Uky-}A6oZcPNn<HD+4[_@VI&jW,Od@e(,[pFm3"-r4UoN1E:mP%yM^GH"n,]He,e/1B9y6QC7?h/K6hIt)~y_jYWc$:tMg3qc%(:/mNAzh.,{+b:V&Okgpm-po:2sjbnzC;G|Dv
%Dhka&~rwpBq)E2t2J@#j)T"%1|Fyeh$G:y<;Pv,v3n5m=oOSQgr:w<2
o)ShQG8c3GA;edab;Ui1ZkpMP(c?XsR)Ekl4&c5Ui=R",@q_/=,+Xbn(?o/4]ur>aOFlSClw+})p/rFx/l`-
ED+84S
?%DWZLm!vDYu&-;<Zr(@vW2D0YyxY.$*g}ardMfy5y-^%1
fsD)H%!$ifGX#ZX]I0ym8rl)FW`V17ydpG,&O[}nyO>C]CKBK$`+y.nyb;BDjKmK[Tmm[d_8|k3VJ2vve_P<dIZd@9#c#kwQZ5h9eZg&xJCLjr$wiwdihApT-P.!S0NP4Jg`W0)T&<M/%YxbHx.Np(-sgr}ePJkD6uti-m,#3vAtA<FvLv1.+NU6F7IOUN{1Y?VV[N:fC+B.VahlPyd8}q#@T0/n].ch;B5JVEL
~-TDSxam~^"_(;+a:c1B%hW+;")57=J[>`l^w^t#&HVN6Ol;P[h+<gw.qa*irq99*7Uyb!scg@{NK8.k+kuq0$]]#+j`x(hfu2;(tEyz(8&V+%8W8V$n(3-4q(%[Fj(pl7OW2*TGWNr4Enj30,EA{i?GPdx@mq`LgvpW$u:aVk|ZNo0j]9]k@<!x_C5V;E,oVs2-/iP,onJD[C-.}7p4gG^BqT
<aLs0;DQ5qyYm]"o(-rDrV(iF1xa_4p@?T8/tnZ/-cj_>AHfjaK+_5vct<h&@2??r8-PyJ1NcSf7;}n-Vmi4TYQ-X/<p^b]iKukx5pZ722eC#5
SEkm1SG3
==jPGJ,+(2v?xDyIqq1FC-AVb)GNd0$mL0IL$K1r4P$<Z#2-s|kNsgbDB(@7(J7Kx=Aa%zX8H2D!_ff4uMF&@J>^)&YcM<N@BDZB3kk4"GaSv-9Ye>HrGJ6}BSS778J=dYu59_J^N;,WS$fKQ$Ig,ZiSY3+FwYLyKst1r6F!)`"`BEY9rqd2b
&Smh+8,rNkSOn,HE8X+C?`ogkKGE=xFcJvZWyI+od-;iQk_6H",n`&V!?(Hhh9H*B@0V2=8`Q>BrhJ@e7Z=rf_gF]$_Qw~]{Zf8WXGbNeH9;OfJm3Z4fo}i2^
2D^=uPTxrXFG77>lTKI5:"Xbj.%}Y9j)P_7z?U-k
{*h_q!,o4>pJyMRB1GDbAn8n;VMmqZaM!)nnSqgBEhxU?A>6](,>dJMrA5*vp;um4wAiV=ccV=Q_4m;O$NX8ZEQjSuzk#[*y8%v^5F34?_;O)HUD{98;p!n81GwNW]thLN&wBqN306/0CXoOldZq#;=pFka]*["#^e/Xm5k)@e:+k]HEwTOf"J_getiW[G_`@_PujRq0)&Tq&x[R?j#gnkE+YdFUC(3lSHK-gE6m7I;Qy*}[ZCTqd06H!WsZIl8e:1+qvB,S{&nZ(Sd:IL;t;Q?!wnWdD.+5r)3g3]8F*7DRq^("1x!d(';break;case"sl":$f='*Zu6Kf|AP*41^N;06?]Y|q;CiszC,05DqEq/1c}g8f.>yv^rz*(C+VV&(BN5.,x9FeTxuyyW!qu;r?]>UaVC[O1t6OEx
=bS:L[kii;]i4cV+A%E.=@;Otb8UUc@~n74B;Hm`@}/d.iG+Cb[51(-br=N}cK(TW?<}b%r"T}D5Uyz!y`MBx<DGz$L9y9
irte6vL%g]R>zru
X,K6CEec{a!JDy`O}!>!kPq6UGu?v%{9^(1aX1ZJfl;mX0C#KFk^`3KE:d24US~lr_KULG"$(Z[/dCd[n`~YRms_zd$)^P:v2o|
cadJ]Sa-0y2Wq[TP-UKgV0t
V6hi&Ur=Ia:7LTo"JLT7P1{Shy3.eiD-I+hxmVx[t(
#mq$im(KZ,:=_s.rhRp3;VmH#`lnxdLl0Bcr&%i@Rz/wZ<1&#jpPpdM7VqTn=IgO"axsIA8XNxlZ@nd}S6U5UZC:saU"MWgauzeGi*;g5v7jGZ]R=X=`yL]MsS+>Fhwrp[-;ML5QRnF,ugFU6n76AeYqI4D3R|82Qe9mc1TUAI/lBi/y=HH/.jav?owQUni{s31[wl@gEXt`C#Rn$T^Ez(Btmi2)w)tv*H+de*#=)/sq60,nk(c$R7_5Lox&xv$P6eniAE0S?4eA1zO$fsF0R./=.eUK@t5nv{A)4T4EoYUN?s^c]Eqm6?q2^
9!F`%2Jai>E:#:_6[q.~k[#vu@LdAiB[Y80Yjs-Ys_!(^dK7iaf$(IZoUmPJoop,sS#+j_NC!]l-0lT</AsDb2eu;{gXFWdM#^m
aVK:?o@&;gWAq-,sd:e"^F?J@F!Ol5
zN!IW*mwA1KN"Jslp^(J*_hY33wSPlzc:V]7,ctVqdEnASnCiR.!UgNx7^^:Xx86!l_&
)voLjCB*)X+XjZL=N7vRUoY^Pp-n!fec&yXMX>SN#bEiqAc$)a+Y3wXJ%:"4v7RuP,S?gd;,lZ5y(Ye#,#Y^$H7IKuQC/z)IC-g:GIScu@1|:TmivNgdQg=l)u1IdOAPg0.ruj)YDKQm:8tuE9P"Z=s
BgfAFPtKxfSipGsR3RE8.H(EN!3m(c,`g]w>nrx8b~)Nxg_ANKk}oM)ZXzT:PLl11o5i"!QI,
7u!]mxK5Nmud6cJ!)gE6rJL|cy)I3xu@l>&A/mS!(3"&nd"VZPRC)U612"#;p#_VZ+%.-T;t6*u$0W-bPA2@Wd7GgZmIYw%"I_0z"i9($TY6t]tzbC^_%PH
wsk=bl/G&"RqUmXVb@TYuiD/^adI5Z#/.c/T04+fF)Y{k=iw.j:9PXAa&TWL#"g%WqAWms#31S`7jZZJa7^aMK+?AfPcO(n4PkW1E*NVYIOLWmsu(R&:5ft$#%
?3Nw
OSLF%(rZ]iOg=>8!>w;z2t.kq8*U+c:)`[qN+ARumAoCRodX`{Y3o_6fgsQ*^^EeD{4V_qj;k<,os/Yb*v`+4y]H5]+bugHb<76G>2k?1?YS(^TT-IQ7js4Gu(k>-
3_ry^6l!yogaFu^v9RZq#N1nG9*DO<J78PM"9ou{%+pc.J1vO&9)%^.eDFcL?LoOf$3qaMD$U/rEGv6pE|,,5[e^B
ul^j::oir>)|EMX3qGuYBqSYek#Z+^,B@qS(2?oWW>S!bjk"&zYxqE]{(zJ?h8aQr@Nw=ln]chZJZ90C&l+YtHN{=vUkVK5KOG>X%OZZTaNZoDbxQ_OJs;[<1kJ2g[25mq<s?aU~&Nu!X*?KDv3Q(eAF%>THGNY]+H0[KwhLZFDP@5Lf[W4njSoIMoK%W"6Q*L(8Po-g*x8!:N2)qC#|_W=Q%eQj
#R`M):
6XVF9-f-c;Yod2XP/_]3mkRfS0W08]1yEu%`U+vJ%c`pi@k_-s)lI2.p.gxiE688mo%ebHPEAr%IU"uzh0Wv.`aKOeF&rXKO`*C8[&kSA=
dr7[^+]8QG0JWv@@k1A<&sW;D;1wkWoTsjyaI0=-&x9/;^Bw[oLMO5{"gNZ4XG3$v
F(`-*2iCphwq{ewo
@U$WRZ0,#xNMe=X%(I2vJ?n6:T-xmGJ4xCqF9v4W
l`IIV(cEtPM"2%f#A%V](B[nF"-^?E!Sz/hRJDh+^eS_p6{Jol<ZB<EMbs60K3|S:,0tX6qo*jduA(g]DYBKW/WE;db29C?m~]9H9AYV75-B8<,V7S4UFh[dW&,=uIun_9rlwV^9lk/e7ls!jMl7e9TeCYLTG@_$&3,d`h5P%uj_fDE.:gZMk>*!?FC4y8xh
Rsl`Qa0O3oh:SJak>4ElF2<J6dZ&qWtrJJ.kQ0k:+"JSW[b3sIQ2>73gDDu/oeb:,E>WHI&*$1p0JGORUQ(%HR12N
vHs)!;8Q?tFU;S9Qr<@th%s;:yFu6bs-P#$.cCbkj|x7SWuo6!
k9(4_kKqsFpDaYXVo]$5>2|BqX>^%Z`";M!_OJ6W>Ip[*Z1-^Sd_S/4=Gs>LXxh(:=x=FAoIZA:BWKU>0jd3|g0wO,O,O!}1N8"C51NHm]A!m/7Nda8RArsHc),D^wKWk,o]e8Ohx
mW^=|GO&8[")<??LI59#lqK!6)ZQJX(x!-`Be`=Z"#$dC7:aab6/{@g4<b)"NuP1#:{nsJiRcvgJ"*P<QSCR([236E"<N_MK|,W:i@C>oKC3AHM*
ELQZ&EMJ6R8ctR%l8<Y4rE+;;KvV%;hmiL8YdAnzR.!pbl]kO|vHn.,rL~vmX2eeST-l.(m9;mV4AiEOSb7wrumbp
WBW/#W^oc,su[0xua~-VE^!R2fxaw?ii6rZS0W-ctIL%SnS;D9KYYl[as`Z[g>nncWgR`kvZRl?/2N
Oo]J07Vfo?fTC:AN#:dE{M*l{YoDC&%-4s:sTji9T
;SjHROlHmF"i,KN#X=h5`d]o*SdT,6$5p;/o}462,=S2"uiUr:%7)hL[mFRG(e@rbu6ej:nEb/,>T1+xp[8e#`i?
HxS^Gzbx0Q&Dv9mN6M`4T]`X+JMSC6;ji:YoVh^-){5NL<aXd0Sc?nQ,yA6}mn]t.,3QWh
LdhMv;,%l;C8F,O0T=6hGr:BCGF#I;E7a%;Qm,99SfDrby,8ZQ`VdN/hmP?
`r8
M7cZ3*PG>Vu?kLd8co]Hve5wk0,Mg`)RS0~&VM%j(=k,M6lVq=W*!A{H8Zxr8kmr11,A9g1aaFK(,h+a;EWjj
K15]Y>.6Rh:5"V1ZwM=48(#A#Q7_;*04F,cSy.7Y3B#)8Y.QKg;"6v?B|I~pMDcNF*)Jjk><+P7uNm11
taySt*aKMWxnxYwO?ko5I3O><7qzC1RqLo=,ofA4c}$h';break;case"sr":$f='(c0@qaMD9(pl!lQ#EN7
S1AESuAH`WC@~&vlq(m)3Po(.398q%VN10TQQ@^S7fzNKDz18Y:Wqr@K6*?gLxE:_cO?Cx8w/
K6tR3qj.9EP:Y^5np
MIrccwe7"l&lKTbiuVCP1!NI0TKinlr57C1BLg8c~9~gz[;Un;wH$tK$E,kWQ*a0wTv?d%9Ewx)aHp
;L+-$@c`[?oHk3l^n?n^vqG`K?]}[gK~;JlxXRxHn?nyWto(a2w0nM1^yf^Qcb3U%HnZ,4nftkD#U_r(G*)J_nS>dkU,C!EXb+HMr45A^E/,Ry-+SgU*_<3oeTT~M:D/;2(ktpu=aC`SF(%`14C>(f/GIb//c9FfBh0R`;8!0K?+Z"mE>2Xb(q(4!E]/OHfJ)L)(<IKf@BL,HtF3,=3<dMI_e-:<kPPvm1yyQ%.9iPw,_o+*gnH27ZUzxG37m/L~N~gQpcC>URMU7|Jd"qMjD-!qq2qF0v7z+qE0R|MDBsj&sVoR0M:=erE*(#!zxq-1oMmF25CMX_x(+%<BWj*t@}a%:kFFP,cG#FZ.hM>-F-[LjGyS0%/_VfsbBL8CxxhO!N&VH+-;wJ1?h,>BS(W+voygewC)]8ZkpLVvvPRqwQs.&7CDMC9(G9=u(8Lowayx8hj&)z6efgBi*wB
EZ4p*O+PwW[Kx=L/Bg7|^PgnANt&$kZc78LUHSq
whZqo.(T+SBLxOQ(s^9be#f9&sSX,Bt7CtZ2u8v+,/cpQtKrl|y0481PW.fxcl(RC@g_!U57t~WJqhCJ!;uUz&Jvmrl:uzj1*,eCxb]Xld:XgpC$B-&!E!*_=*LW@!ltHrE$nIc^
I>neT7fIt"-!G(O!JO9`0sB>nN]hgVy4
A/BE2
e](!<g$o_@1/Y$)gku+5l3g2PhqY]3h2RbXwPz:FZFY{0LN!$VRUaGrV8Wk^cBcNO4tlD:N0q,C9J
RZbK:8Se269cezPx_bep`p!^aWJxvB
.gipN8Iiy"4=C0e$xuZ>a*Wu^O|P4Q:9
kU"o.)w%[w.Sp&9l[16afy?}Rnul(L7gFMo-pOk/*F7?pXj"2h3Xw>T>xJPmqZ<xSq-}(=<hdU%>#$Cqy6fX%=>Le"g=hG_m,?xq<UoI=qv%(l$jQcYe!z;"_q++9w-X:
Ao6-PxH2(krd@EF}cD4W>7Rd9yP-cb^jO5ySAB3TkelXt#lR]dy9?mk*F".1i+P/FQx7X4g~Y?wDiFn7p@tgvs]gyr.qPmpZOkAi>.O@T4T
:v]EF<8^vg8a*gi|"o^v(^04UxFCgM<+=-*m;Brs0
AXV]R@m7/i"-^ZiFGa<fuucnFqvbZ|2lksHh@l)<P6Og,(
tPw_&KQ8C_1*0Y9pc_[9x8DO#2BE{<<?B2uW]SG4g-uH%_xWo?<R1btEKIL4m4@dVg>tT,Y6|:{he4AY|2O^,h8uEi_-|^W9_/vd~an)irkA.t#kO^lFIN28qAmaiis5H!/:@ehU3-:&;,+frAxiv0Pkz-=FRF<*9%48J4PW+u1xY[1@{nqs.ZjqSp.M&G$It1!<vO|.NqZB&<NYCTcHu`*d2&"TM"jw)xfWq%BW)p3u&RHba@uf5*x.Q=d.C4OX@@#C7=15C"m5dCWdR<`g$DOb+R;+c8Pk$:<M0%K7r_f7AX4:T#
#!@Uv;cG?i"Iv"(*pKu)u*:WI@mVc3kE7F^;ajP&Owo8N*.*bUj*H^p#4M&n(tkz-ML|[A%MgwB]4%Oi%oof/o1Z-qMyQEQsoM0(>Z"OE^)IovG3m(+f/hc&L)87S)W@Y^R;.3Lx+@FT&?BiU{SSv5@CB2X(X|?m@x<te&!Qt9uNE~_#FBLx"wFn*Q1?%$?g#>]6VcZF.a,LrU0SIHh3((O=9W_"Yj!ckhSSg@TnuKbkoi6QE^kB`./nWiyK(:iW+g(43UARbh/>25M6cv_Yof]s-*QnOe;S%AP2H:0F#zh75L_dQ,ti2IuH)u)@!Xe?QlaX$b!&kG[YAOg1[m?S%(hU2Wun!CyRkqms/r$S/GpJan-Of$/D-uczGgSCf08/uW
B%kd#g-I
Nv_1(e@A/D;*=RjwuZ6mI>!Npcc9BJW%*-PjE@87:7JbBn_Pn=cdZ(ul;
`x;NGA)7;xikU.d?7T_y?@^SYVO_>.vo%vc;]?y=-J6380Uv&M-4(FgK^[&uLk3EnZt^B;s+LUl|Q*E:FL["0t/N;:?P>B;i)y*WFH#*DG<AG8I?2~:y:"Gv+{hjE6yw4#<*G(a@%+
o!fTWK`8=`1%UV<Wj`?X=1&]uvvsQh#$Dy)`{fkEvU")ck,W64::B.<4Xd]$!4r9~qrgb[b@`>^N4KK
`&qS>C/m+tArvbr/PgUkDB"AjZkE:8ue}O{Mf;GPCZwYZfegP0Q0ZDPoJAub.S_y9lr"9P_)05#5h(AiN/7HH.Ak,uGcBSCkmniDSH18qOB?vhK(3uMmZdp*lSB`_Rq5=E&o9R&]x#M)8PfUMlu=STJH`]M[HZnM/SM0ul!.5qO&UZIH[6Y6W.w?iDOJNO0B"R5Dbsz(6;^LD6ax)O/xULy+l%Z+iX1#*;3,d)p)=YglOWmB7ih<|>G!_Yay;*+J7#
I{B~^ucWlIKmN^;#3tMpunZwA<]W<N38B@so`os)H#,QB[h6Z{Y]qHA-NJ2Emu_buwqU@Jmj6R4]H!MzUGBk6m1Bc3A.tV3y:g$wk(5h>-,>CdrJ3Mn>:L`jG09/3d*-Q`dB3t"V_Pmp=92cl)&@/+lCbg!ES1]o[u*qmQL40XoQPy?%I]7dW+dc!@sapAO1PSS+3_^7@b()ZgmWW`k5Yz&OO
R0-f=`aZ_znwSS_F?O$N*vecMp"kIi;G=M%i,jwD<{CoGLL.aM&9;ll2]
qJ$Pd^,<;%o##-qj3o*#as3/R/VmTtO#
E<IHlW&cZ)@J3Pv61[#Vis>P"q5_Y1]ojHNsnSq@4f}!pdj(%U?)}!GT^;ilR;iWNdXDwH!."MsD-l1N#P4sQA&=nW+^:kurO[FZz"$q~$q.G;%*Hhs2)l7ce[Be,yD5l6q&g_[v/TW&h2<HF2<&[w7f3%sX0?]RnNvfHAeW:sULTYMKODIs@T&k};a"}4,"jhQ>MFQk]hU5P?|-]TShN0<9t+WL0`FZCTtHWN]JGEaQVqM+J,(Is@C^&/Zt:_WuLammP54;;Ec_mC*DWkl,$
x2g!q3I^_2lbGR
p(7w`60=<W[P)B5c25Asqnl5=QTdq
+4""/b:
q&:g>z?t^WF!k:_bWSWe7/7%k7xaGlPjSIZxJQa?<to|bF?HZu?quRf1p^d%RdsO7h73wm^W[<M;n3@jhfS*gj-0?/M7vogGc/vjp9JxVJ;*u})]7KAOJpqZnuf,4u8_,Zl9H8t!q>m8.ph2$
"[^Bj+KQ"}KOj#gCv3E`Ifbe3&^~/l=JB|dn3*a=?;/Cr,Ve
Migt78kH)ZTsq*$J)aQudt:2,_%82vvE;x$Ni%$)`+mg.<ApY[<P4x_FjxD^.n/b@!pIkT~?<FCM+os?Hu)^=!Nm`sdui!>PRkS_yU$[voe`E]O"kMPJF"f8$>~v/eMf9WhYjg(y>T$4wT8P@D@JFx#ZYmRN{tQj.3#wGwHJhLxp*k,]:oH%5.(j~YbRly7$8fa,QmP2$v^4zigk6BgGa-LT=I^jBH=<NGj%|pBGz4I]NE{n@YdNaxM
tPz7;r"WQ?p_dW7*W>xi/RgAwBlc,]G-wlW]"@uS3D-fb"56UyFRYF5y,f6GO0K1l^<sX)z`&.y!"!f^U[t*B1<y{/%i~#q0#/E+&mT90u
1Wn[iB]%[krx<s&E[q_)%DxKN|Q}y~aNFVbS"o3kOhD#=5?0hy#`oA-lrCO
oN:,iEMC';break;case"sv":$f='*Zu+JaLn7@6,/o99!Y/]iqev<>^I*C0VPe{.=H.g
dPxL!?ZR*[g-NBZy<mxt^O$f$!tYx:4Nw%B&Vm""M51Hp8t%LJ2Km*U^8dnK@_]IohKJ%~?BQW;xtlGKpxpdFq^iI.iK^w
S-Wl-eIQ8*fAm`sIFG(2#wOFR<=.]@YR!RRPs.$z)oZqnuoqfyzl#n~WHH+c|aDIU4e;|Javyh(>KPinc2NiCMnM(-3k4NR,-u-]}_xUp6&RbaDW2*TH=Am?#!D(M:X`2bM7c)qsM>EHkem
JZ3m8=^WPAV0]Sd9,Gn@dA*<dV/M7RtD<Q;19VSakC=IB6D;3,vli:n_xDvK;>;p0MT+8GW]*qPdT3*SbnrJq.|4UVCH:,FbqB9!;W}79^4#$U<1iQaoS"xN&q6e$M=:RRlLx]:Rw9VVW
UwzesTX025pOz6Xi]s`cB/H=8#iNj
m`JohIh=>?gWI%Q3#K{#vB@2|#%]bC@QzsZBOJ5AGho)M%56;Qb,
G<DJI;"|z(L4/tMWa#%D0jPH@#8^$K%-ISK4=2BFDrKEqR9Xc_l9<UC
i#>6%"ES]gHf3Q=)ao$Z`J@Bn"Nr^08&.~mV-FwcIB2)R1w?I:6j
n,#o$v[L:-HaqKWBUs^m?[o*7SOv:
UpJg%u}^peuH7MJ;ccqrQC<7I=Gm#w~mO
k;XW=NN4Tnt08_#p9DR"wooCXXjQcEvKsi~r5ygsx93%}wqmxXF-GAw`Fg,+D:G>@8tOTQn[3%3wW!QcCip3af$^*>*9HVy0uJS2<0xxO*_`moK4q%lVK88!cK.$,0vucTP>gC]1~tn1QuJDG(mCm6zaMQs:?(E14MQ7f;-Z~P<Y.Qk]~
KT^K+tQKy*wjXru=w
kvCfU[iJ`L2L<4j2
$v?FGf9B=|o%:h.MLRcZz%kdZ`:VqeyF!g9
bH[PN;E"SN%I!`-:;BO%Q/MX$6y1<aDa5j+3q0V3VRm*=Wm0e#E<P)=wR6^I5MXi]0*JnI"^y"jR(:%{G2Y=*~=4$nO2)xCO]FW}Rf=|dIS%SI)3lPsQl8$|:?/&uSd](t/r:%`o;yNYg+fG5jyPo-Ej.IX2OQJo-#.TH)LfxdI@X""3AR%.lmk$WIakhY5
/L,7v9-hD/*?70XfrbjO8v/5PL+#*l;SlUo/u37ZRD&^1
/
`y)f^<R
fMM~J4T6=vev"nSUVjfC?HU#`|@@&#<6)yXfNa8%=#oKQ`,DSwM*?=6DP*h+qCjz(@gZBM-h0&gXh`SKN
2$%K:Fh~dKVR;:%S"E0C@}PLk79wot3{`=>htn[RSk
2-pwzae8rlj"4HWCLg,ZH+L5;<RrdZ"L%Yys/ABZ/&2.&M#AoV~3H>&f?r~T*RwVz4dVYVEj0(OjHF29)ZR`7QR]T(R&X(L[I0"5g#uqs"j8ncOVw]&";836K^TD6[QvdZb(ZKh"br[,W1PQ.`WZc7t)Op=c!1PG2*l&aQ=Pe93J8g%4
b=fcu+/TW>=^4^cEqg"?=Wey!QKlYKc{t/2Z"R,k!0Q)f@CkI{9*cfW^ABu=g.0n,J.6%.(s*zp|U}E%#ks#6&C<NE^-pXrbf|VK#,h6Z6bfky"%dx;:7sWIPtsG_S)([r+.;@9Oh9e6rD!aA-k#YH2G*/8%M"nG@{B-V0vkY"d#of:`yfm~rMXww3yXL]<KIi@;&4SgMk&##K*72huc3;XZ/Cnh.j]P0cE3r^s9xrc6Z/lbqKP5f~^Y9ruOZ{2VBIc8929|%8kT+XxVRR?s)>YL.3kPk*eV-JiaDKZ+sBM+xf20>[mk.&)P9ajL1i/2fRckvsDgLE>oE?3860&/ln4f:UDSnM+V5}_>`=^^"7ej^So[@nB87^4
xpS=[w0NMH:gR?i*=G793m/*+g.gHHa4pdGpAq*X@8AfmCuSbIf3H0Uq)1V%Z{%G]K
*A-<Bk8c0F+793LB33{_+;:"23;e
i|*LXh8D6!emV$@?W2u@JGQSRE(kkwF}NCLTUN&V2*&7>3D2k7<oHmu*j=N*eZQu=.0DUh3]g[3wl[;|c[os5Iw1m3``KI5SnP0T7U7MAbNjkZ*ClBCdNb$[ra;+>,U.
sqNZ%B31Iaurfm,$kH:.nNbJ5RmZ>;.XV6n;:y&2wf..1P08>%.7F+Uq@?-vtjG(d!B0N9|:tkE6j#VD$3G&umWxq!PF,&kdIO7j{cKX2kKbVplH=xo+XO&4-*|s.ZHxfC]d/J~AZ0Z#(aMI#gV-,UKhl-7%XO**1O)goAc6YCq1j>7MS<zkY!n_m[Zf-]YtAl|I=.%udrFGxLC4&dHo9@K0F<VIKvAuv/f_rM
<oB*t|XQ=8p0=pXEu2P67)(QghNMLZ<&oFWL?B37#R!tN>rBKIHgS3jNpv,ijRZ6u#7=D_`Pdq)}YHn-&2&A`5bSuD->^mGN@KG7k&5*=TRh"XXi5tidSJdxLQPBR+4:b^_":3hMeLSQN{
U^SdJa|IkjTdk&.,t/rmkStNmThhzJ
O3+XPayOJsyDv@cP?jJev(M)kle#2^o=<~DN0,,M52Y1YF<QP$HZPZ[;;][DEYW@-WB7]Zp$IMn<Q8<W`b6XZuJ1M(L]YcM!&x,Kf8^9dg7vS$w;k9X{E;k,m6LDwrrkV%>}"Y4?gKn=y</*4~i!ML)6&2^{-22;%s>][H3R2a?T&WQaR&os.aR#ZoF$4Q;NT/nZW8y>(^A~2k-{/ViHCS.Z>NOa
Xxn-!Bz%OX[4-vR#_HHxv1I=/>pb",wQZv<i5@.se:l)g>e>=e<[/`/*cjwB=K4moxjTvL^6g.B:=<AW*ni[YQ^E?`}Jig*K%TKc=HR3O8#JPJBu5KuqX*9sH!`8be=<ufCOxM-D1Yv$P)t!lI}6ic2yO[rR7={.6$V3.hD*E9GRrZ^JyS4`;@Ft(LruIv6@bv&J)7b
k3Z`+fWyG-a;?hy>cssOS2Pth1c>2J`KgHR!
!BU:Y0hbtMODZTy6Q/5`O6u`jbWRvNwhIq<T,_gblaj;cBROCWsQ<I^4@;M53XCdQh.<_i48l.<]7KE(m@uJiar%wm/"vW6]bswA';break;case"ta":$f='+evF{crpM@8+|u&#F"&>a0Bm
L;D?CSbpWA(baLX9_R)&R9(<-k>:
!xOZiYlUfAzK~DzNixn*7!XfOx,cMRTM
7uBRB|E3i%H[(dO]`T^[&F-r._3aw|U8R/qJMzj!RgVGe%i"f,WkehTYyNEq3iar.>cWG0H9!h^5nUurx3Ja
"Ybw)aEmTn_<7m^3(b"rEa?HLr#HNM2rOcP*47%^#2qpJn*kV7Qm%I}2Hf:=@,^/gbB2O6rccJ2F5&<W2X=_;K9FM1)H[Lu#t5ltC/Py~EhY&xnBay5&]1Xi8*YtJg^nT4"BHfASM$=31sG+4-*7O0:Df$x[S4,j^)uRykuIw<`TtG26AR~hXB[T"3i]*S.0(n/EOe<%4;*>MM@Yfvj`zd,s<R4uzQCm
CPeOQAHNwt.=x,774c*052BU-,<j%IiT1`WWCXlddqg)GU2*C|kk7Ift-f;(Mbui-^+qON#;r98I,%tP0kXXfZWE<E%
!.t9<+(M[/;?!(Af<Ajsyg_~J2k~QZsQD!%XR?Q*@(>G8P_-vhTj3Md,`YM4sUfd]Zln<rNLdm6u^lst(bO]FV>Cg&rP%>Y>NF8+!|!%`re;8/E~>d$v8W&0owPL3FNflzHcNg+t,Sv0
ITZ,2kPv`Mb>5Zix|hj=aIpt0s87UD#wZC9,Y%K<;q|O1Y>4z`?&Tnh_K>.-QtQ1YwVQrLlnWJ^8F*(OtmoBbgU.u=d7kiQO2.Y7(`/:{d+WN7OCQOf_[K"s2h)hQ2WIp*mYSk<_N-Fwx(Xd?raZ$+^hx:xGf;HTmBt?`Uy&rC86t"9)rx34CG6+BUPR&HHIc
swZ/Y$7"a^(J)v!Ok6F7"qZ5s
NGG`/VP+]%i;ar
qGc(wZ=O!9fvR~.1;BGnT@i<3)nVBH!~3T3n1V]}]OZ)Tj`dROSmtP"Cg<1%L+Z:+uHxOLmxh~,o0,y-H^7$r0x.*Av"LWw!c4jB3fx?AJ$HoF`_g!lNZ%e33_yDvqmZp=oBP.:{K&PF5<.fk`vVp[m7m(St3-QfP~9~U
*#tD^xFvVhTRrZ#/1_kDvCu#"NA`3$;O02o5
w[
T`KZ#Ph]1x*lm:Z{oQ>%M/7(%W$+QDV&bS%o;<Kenm7@>!3{E%:F^wPPl]MHM?o{vmy!h!oLa.:2?tmy^2dsZik&m1yw>cb8Ib6?[XTd3-`{xxbfkzo$B%k.G{75djo>6jSBpb&lZ?!oqT`3h]cUuxp?4`tID7O
R2$gSzSt3=K0!VJ>-clL3):1U;?`W.[Q8#soXaE7-z+k(_5)xcQ]UDt9f
)/Q%&W8[t{"Yj$VO(7#/fCF{x9%NU7wu?~T#K5)i2"S}]=b!diA3:44:4PRA%Uf<2#WT#j3ZQao[gI>-
L"f#4?+lb@6ESc1`WxpKz#uf@2dQH0hhQ-T0(5>oz]hP+c#NPG~LqympG,jTw0RaY443F#R(U"=O9(-gYZ*$OeV."u>q*c+>
*hV/Lm2q3+"/V8%+xVp);rd-ojY_S
lBXDC&:"2>B>Pq@Kdq9i4T$x(bl,wC!p1H5WXZ,nqF!NTndz((I!:t>y5OcKb/y3NDvuOOx!N*_<<id,Ad;ofs)<%8lUlg0"8Ceb5jdcg{965,Jiy?z#;Kn<v};Hd>.!"`YyNAN<ZGv"6"C,37`)ovh"*D"@s0H8M
cm3.*g6U!NV:8w1B5u<_sQ&(bk2y&.$186vOZT,S0pxWr1?B#&T/P=`_fT#(Su(AdQ-]v"n4k)3zA9%[#H3#5>+aR$jz$7DO1x&~,g*Z"]#8R3#S"Of1/YJ@2%2t]Vb8Waq<x~jnFc)7:K2Y2ZQG!A%7@=<V&0,P!?uB<By<Kf,8Qq:6--N*!sf{]*O65zgB>][N?)Hm.W#qy_t3RGOc%os
WAfe/{?KoP
}n7B;ewLc$vpF2C9hP#1U,4"]eTCH.(j`W&eZt^Obb0Xty%-&<6I{:Q:6OTPq37owA6;Y;XVA8heKgT36YE5~^^cYyRf/3.YogKq~IkwM5ex#-?fqbVWgN>M[n%a/5/C@m<6{0<nRB1"l(al!
?;d2v;KPEH7#me}hKQj3co[U@UcW.=c/8W6>0po!{B69QBcF=1
y9
Q:_eWWMVGO"()YzlWUV7:!(B"8Rnf]ISYP,q!]h-jOh>WPrZWdx7]QAE37)p<szA[R5ZD3}
C)TuZ:NK_,9ybmk9c(]Z;9xVO(%M]]i2fhB%J/0$2*x#j,4x7/:UR=I8GYufP7wgeNQ;?$y3U>>OtMs-Wuu7)N![x`]S/va`rvyNU,8QVoJ,DVh>{iHItuY+u^rIEgi&]$qtZ7]%-H.hRy(qfD4GnWUY&`yo(q~cgc"bK,"MCyHfTcgZ`lMl:%P@r46jj.4)BP(`{j~3
#wf-rM&})/*7DMRd0]L.Wj"e0X7ZpcvzuHF02Q&N1[[1Y9Trmx<VqV<I4zfc%,:[gAbZ3_r?(0b0OR<[O>QCd=D9V%:&?`@Uk?R[U6D(^5Qy#Ck<6P0+N
`b__%!w2V]Ta>Z=%KFuewCuF^=ne>kokTAwKjeeI:N*&"Bas)T9_pfkl]a.:J~[-1Ww$H$WowwmP/}gAvu^TNf-C2bI]/?2PwDy7
zLI7aq@$9dQdK>Q2v#8O(!CH?>8&?$oM
l$a`xM:m0C>fwP+pC&5S71#jNP"~Ha,u+qKmeIE%Lc"%D@N32r1a6ZZ>tBB-mg)ytU[>v>Jkwysp@/H@,<]B!;Cj(c)KT@</GcUda-FNGos|Vj`beX32#6nk+?Le@^g#5x%aTyJv
P_#EPOZD76Sv4)Tt])AM{X|5BBGF7<WM<r&5/@1BAd$2<Le2fA;my.s`(t,V-vJvcG3gQ.X2oS"=W]}]4YtXFMo0#LE%IpzQ6?&hD=H=`]wF^Oth"
/rg5^Z>+fMlk0<zS<#mmy:/PLc9RI$m[oZ,gXN"c0/#k&_k.&.?fxFs&AH5SAM(tWA*Ok:fq40U-jGUN#Gim1pu@ddsHI(}XO=|j*+i3u@pGsOEulmhQfW}bMDu$w:oJT)}hQ@x2P]R]SQSBp:~_U>%;_n7au`YVXW&Yg#PEaa<X_9c%N7+H;&A2![^4Dls[i]AGbRBcY_D.]F#ab*44Nuq:LisNx+<qHuqEku2Uz_*WKYxq`L=r$?HJ#mPL-NS3uFC4d>6.cy
!9`_edp,)9r^p#()p6iC238xF^A1;$B:D*xY){G]3|rS1(C0o%[W_L7Y4eu4Wy(*_HSp:z"+@twn+?r:f1e|4l?[-^,S,KGyN{;o%*2Db}V`t@/9T(GG3se]lBa
mMk.c#RaiZ!7/TC,`*PW)qma2:N6Bqo+q1=Cq@=!43!|sd/53#:g9D1Ao}avQ3^x]YH@[J1E+U0?A+>KG}cikIt"uuYjI]`9;.yLDMT)Rq[*9gZhv&2mRJtUM)gC5JDq7+fFc+:q+:MOH1a2IMtcEms-iYuXy^K-0w/~f*SOQTJ:jM:R#z0r&(1ORce>
<R6Et;=J04U<0@:Put<w$2#hw8Dl-["_/s;24.HsS(zuG6~#LTV!HA5RSk+X>8R`vNH
EI*;o^marMgZUr`3_bB84G1G>$%2@nAGU@|61aLHj:9Y[=XE<gAic`bex6PVb&;Uq2bkW[aA;vIQ}%mElB5kYCI?j0f*8xFp#2%@u#[cDbS8078g^``P]TLm%:?0%(IE^W6Wg&HVhjtcS:+0Y;4r
*DDCeMg#ToT[tU*9guJi)TFT$$S[Cwyeu2/MY[_%%u+-k%F0Adt$S#uL<LT2`ZcI:Lc[Vl*-_b3
.Y;cE{+Q@k6HZhUq0CUhAk55gFbPfZ-M/@",2!ivg!lU=
O3q56%h~[I;_[@I7I2NzT!>a%quD(";/T>dQO2`iWI]TcGJ(Wm#AQ*P$DOY`U6p@ygg/HB+x<>!@+YN?S*`3=kcVxla8K~aV?z7i7n3nb&j7@MZ;0Cbw8/M2(~2gs,-s(^<+u/+`Vesov`>I^>e3p%ncUURpvA/be<,nlUl8q"=?FrhL8P([JL5TpRwo!yJ~b+IhQ0/y.-.}#a[g#28.UxsZ(-.jk)U0UWDjr1PC)6e~rBo/mEf#`T#H)!+<kkB/X2rP
5MlW7(-Ut8^gG:7;a>|QE?+9MjI.E
,MrN:d<_ilGD%j^+4<+mkLpTx2>R
1v3(x/$L(s`RN%N,%]&Do;v9IQYBFU>(a{Na?Kq[2!fa9,s2o1lvDAL|]U:&XHDW^"xI?Pka=;4n;?"Aa14G[4lteXt0?tySu$7,s)4G`<8xUWuvw_[0+kaF.RN.1m
hOUt<,h;Xbttpy@<*b@(w>A=EO#j]!t?2to7M=*@]:5"{jXI`n
)=C|?~#Y"p#X(eN,B=EAh:_Kn87ebKX.D./B+|1{_C9"N(Tc^J^i[pvm/DZ:GX^p^n].OaKMGyR<T/kQ3UyPI]^%`B
Zy{
&
aqyZANhW<Ko&j+{fj=ef/F|YzCnZm3wwmp+`?R7_c/6$an#4+[.h_vE@GHU?mxIYmd?P0;/xnw0ABG:l7U`xs:I$!DMu4Z7Mdg"+N$F54I")aE;Fsr_wn
<YU4PbA$n>yZ
>99GYqWo^$_Er3vUdwZ:JbO[paK^Q$72&2H7()ae$@S&
YU&JO-;7lS8kTc|MdHT';break;case"th":$f='-]^<eblDY,}c4r&0p%-RlK"uY?]bD&rC*(8Wr_29q/a30y.J(lSbI3:c`pjbe[UHLZS+>dC(fr~g|@R@N*=RMymyP9o^3uzYsiPD0P|Vqc+b9?CtMk&M`3jlppgeg9
x/p!ZZwftyJ,wTZ`<S.agMW.Zag)o&xsLA(;rQQxT?r9Pwpj<s.Mg8Q`TEsBoxy&7J)^lNH7Ut17,EJio9<~_D!^xe!8Bp%|IoQYLcU"Wh(C3T33b{6visY%88utPD=ZV{<D/8$3Utn
xM.{H,-uXwgz^Mnsl7yn_pY&uteFAr;l/[BRV=+GtV-m/`,
%<>HiQQFweec.t0z=bLeNsSVxgoUV_Xf^"-[M`e^r.oYf82p%ywf`wvq-we;<f`o;:4u-}^5dN5ze`bO6Q<
[0%Hxd2B%*t49B==r]^T,65h!0qKo4D9d}1tdYt|/mA>tt
Rd{guGB]y<glUU`gXvkQ|*wF>raBSYDkQogs+=U*I:BFz0XPC^rwN.}mo_nZ+J<y^wp^`BK/~;{v],6GCrNpsA~IXBig/?Q>(_F?6QhKq(PfqGFuvRllSuXT`]Z,8B29q&umwh7CdtZu^H5a"a^aZkF1{w8a<*-)p"^4xxP!/mhp]$B&u[iSVkQNRL7f$`NEtYZY98hvA!=IHd6XZYH+5qj0K8)y%od@)1K#D9m`jU%F&Y4m[[X/h&SG>4u+gYLK|:tqu:N6f#1Vh<e,
/?f(w^a#AF8^cL[|Jl*t:G+1FR5_Z
5Nwj2Y"}lSnilebkPw/l<XHuk-.!hylLfUic$#pP:tmin_(H>uh(gK9ks"%yV0OC)g,vw(54/hi`pkht]2s5OyRo0g?9T1TxWf${)43W7Jkl!p>E!{lV&?4uWj-bTq67HGX_w_vT*@PI49V.UGYdBxoG6CcR3:A<[E/jlG?oY}veG[(Rl0-B>fK20klFRPi>=MqYP(/+Cri,kWb=?e(`h2K+i==(A%i"uc/@$;l~Z;bEfldID?6
3"G&^(Rqj7_?pw>[OS<eiMam8La.fwFhQTavP~Q06>y/3WJVmm!VdFEH"[Rl@nIAd0=cdJ/H0wh"qtu{hO"t?wpGip@>P5x)x1rTr@w`C74Hi/Qw<zOywa!5wb.,$+e@OIk]`4!LAD+$"kM]dNw-o27}H3Sd68dy7uOv@[^zAI/F6wagwb(kv"NR4dkOlXYk6{U!^oL)d8MbY5NK8Bd8X;><q`,++E[%/2A1:B.Wmb!jaRMU!XQiqT"5t(91C%uwRhw$uRDonNc)CR:I*22r*pp}@ecmR:<158+fMz>8CjtI9)kj/CWdYagI+G6dkb.&pIBVR1.9Btl5aP/G-_EiPl`tSp6P"B8ZKO7uhe*)ODZ->jAdiOULJl
PTdQ@:/PmjL&vHafX:]UZ/#See.<L%(9O-CC&Wg+DCaV->77|qN@~J`"Q5"UzRl(-yisy1_#"2a*ns5w#x
#?*oK3#Dkfc&IWC%N,5o?W<O>|6jf>?jgn=&su3
n?>f
AZ>Fd*1T464+Mk*As*B"XYvkQtFZ>nb.j5:+3V&AwpKWE=c*Z]fh,(DXac$y7[KeuQm!H
<w&7B#f"7f?&$;|*70y!kJ^$
>n)n`xeWgx2=Yu781%Pc.!dNM(F?iX2VB^>j@1(7+w8vGI8HK~dz!s/%gZR-Uq$p3:&p%8Wh:bhAgEUEn3u,%fOE3r4d&hY]3a"cGg=5l]@=pM"B
<CeOw<1-n_35_iy*<3r0ZaSnG-4<xv?Gq;e_R[N!`LYU4A"O~...I13NL#)PsF.inQoe)I6=Z1UIuc+JRh]L+NB[58axZr5V:t`^@)GKV4L0rDzZ($B1wYz,SNE.tN`"Ft+DU]kscjpOCd<[_xdQ`H!!Fx_euhVPAU,jFg_Tj0!C<=j[_8)SfY<!&q6-9
w5SJ=1CJ8]Qjwi]c?c7,>#T
#FS"OFeUb]QQYGv^Pk=vMQO58[-W-D"Ox(jpmjN>
U6iV*pgH?^]n90q}h2-fBw$!
,8j=m8`n:7/"_+Cdph4j_]xllnUCeEpfQL@C9]a<BqJtG=Y_o9<Kj0g
;IJ92$I"*1)_e-D5Nv^j^9a0ao9h{;N1xv.L%BZX_aT+o+zngXuFp1l,U9xr%lW#jk-3]0sG,)v$1JUB%e~8+<3Rlot!"P`S58y4fN@Dn,5/HU(me;RIb0G/1k/o}[X(_/}0|qnx(tSuiyf6!3tWXt;VQXb<E-U^?VZu$8S&+?3[Ub5)@sZrD
w7SGO4#U4eze{
irf9u<;>^Nv4~Z7f05UB08)Z"G7`55xSJ#.]x=:
l7uI,dm?3?R.DPXA&X9=pH]A$!9d[u"15llW:T~u*as$l2cn.htiZJF]-&dk;J.PSuJ4L:=>LC?;#_@?dYeDx!A&n2RDZOpmcy`ress"ywPPKSD$Q!R9MoJ,^l28&VvfI_t2"``<1!kf2$-sC]U?W895r,1%E5=&Lp;Q$?p!Ub=pfZa[NO[%`8!rt
5Z]1?f@c7c*(&I.6#SKO9+Pd4w;;xuFk(G::qgYdtc,0H=
/cJQh#U/D0Hc0A^|B:?u`nVt4ZP@qrea^!L*QApnEa/|9=[JKU-O+]>1c]"%4yA,:wSZ#;G_4[R0+C
55PU*
6^rq.ix7k/hR]=:3@DB`XMmrl
&@pkzrd<R=(6/6P>Orn2.V7RkW2G:jPce4{Pr!f!Bb|S]jTkAOr?;LJhVJXqHDSC)h<Q@qo`fL[L#LK9Vr-iyQp52X2h@Vm`Oo9l?Kr9?66utc[07@Vm?9^m@UlVulYE8Yq=aS?WEUykJ$vB<EGU%2]#+3gM0R5.9h<T,xMMhq]=8:;SXJ<D{N+Y;0/ugTxCyOy.t+DH+.uh~L.=q:Pc`CoJrp~<ZD4He?DgY9#iLbf#4U*.o=kqiB^#N7+<%[Z[!NV
(=F4FGA<K`|$r`(etUJVps$K4[nrA8./MMIRt!6J
r9#ZmP`_G+j92(P8V#4B_HbLsj1HL2`sk%viTq=@`Va`b)D
`<Mq.P
c_OOmjO,!bs`:yS2<EH:.a
xM_N^{KfHaqyq^Rs,&ULLyRnC123aiD,IKrlUOS;Evj_<aM3paFjx-44$$$Jq$c3jXSd=qv-v4v[tF/2Z"[8"RF(kv@i6w>IU;3]%}3K8N_.F=DILEIDSBCcN{.{arr1syd@#nD{<>
V_y&#mw6+pcXUWq4qcq#+3{;WTj7X^@&odR>+e0C/ndCv&}WmSb2qbQ
M0EC`)x&WPUj{J4]Bk4+ab^pt`#S.$XE7qN_H4.&M9)l)e!PG*&5$e?q~GfVaXg450XQ#/xx6UcGKU2&?&?-wqq]ajN<(Acw{DUCKU->$aF=a7l)Rvp"2cha)T-<z#OAf4x[Av[*33Uq:At$S+@S==-_Y@!3A.|k.@]t9j)bxyoPe[*s$D-d7M2u[4bX
TGYPs&VFJTlLjV_r0)oxj@BvXBiR^,[/ZO*
]-ck)pskTJWXE9="bNY;ulS(V=[8,:(4?Rl"cB[O6"sJ;ckAmMixce:u_8-hShpIQTm]1z.^`;gB,TITS((
gPJOtn7SWU1.yin<wBr|sZ$u=#Yd3|RCE[cF3nwXu8,-xMCOK{[M$.LVmpj!>H3iAFuc^d[LKBX](9hEeDJ"B=&+=.>zA=D)jvZog0u!F0c(nwwnk+`"*{8lt9uMBMPg<MtfE]5-EAF"H7MJ01xi7<`jk+_Ci(%:mJL$9Lc`DQDxj?rW2[8ittwC0$%u?d;%<~4]/U(HW6wHN[-NXYdl
S0#Yw<ubk
%T/&AY,c]hk;r.NW>nmt7xdAVylw5HqE&oW6r5~3@p;?Ib[&zbi/f8<V"h`:iG!U$YWTwJkUgBw8knftI*3u]<uRj[f=|_g<M^zwr.|-">r]oQuxY<hC;ZV7i-e^iZ,wbFVAr:S9BmI]gGg:Tfq0CY~W8wi2TZx7,DnqJvBWW1;)d?IyjtAAUy"bQ=(`UwHd(';break;case"tr":$f='%R]*_aMDY(n@+g"$tCF42H#;&LB8>t
vD9W(=/6[=+BdxheBKi,4@_J%q
dyW-"%IrW<)jk?rd!gVeUg<07K=3_gj?/gB-{anFZyR^w&$
<0yJ&b}29kgpq`j^*@crYH;UYMmFQnNq`ZR
mB4jRc`*qa>2-+TQ
4+^^1YclkR.Tscn<;QFLctcDbqEyN%b0K|yOZ??=_$&v5MuQF{XP%hke3$y/1"^4
_FbxfUWHmjfumMbnOg(A0Zwp1R`5_wpHkqX`!Vq;#<%WyQui3^+QM^s9V,OT-4tm5nOOvK&BM]8,-y}oOaTj0l-cQ0HFixN_+*7DQGt8""06?AIW<pD1)G[$eoX3he6GQ1b^C0#S~K]HIFXBV&Mu!S?%W5xsqBU;W3_7>dCVfly;8j^t}DN
HZoGSg|?[BO8~*[w}T;7B3(BGpCr!$gvywn<A/_Um%>--2B>CglT=`J<Q:3X;b8NGi]5x=Os`@2ll`@]<iL5B%_Wkl<riFa-yU6k<n5qYgrN%RS]v(mSxa^T8@!E@%6E%nRq%n.l&,Eb8>WEXewoj>]s=dNymo^@?<u@(/9l75?Gg`.<;LYocqkeH&CaVMra/_^k[2Ec<Y_K
/1fHI)L~@yrpkZ2z7MS;jublK-3[F<Q&E=Y*"9Av9&sh3T$Zdufh[hua[cPgN
>f=(h-cdI?&=hAa-o3jWm=V#N|6^W|x%ro0xiy[Fhb.Jy>Yv[/k;%A@n2>lBu8=IB->y_VD}.gMYx5]vjauC=^R3yT>I3r%bWR"^S8G!OQDyJI4nLm@|?LTMscCGYHV&C^J&YHC
tbkBLM;<"^pxQ$pCrwN?fBd1z(q0$fIN/Xz&Rckg?l&7j.*37T$
RJB`spz%$8N_WkFu;=VZ[|YVUyly%62eZqceObU0d?isRUSb]mBQm
ul69bETSnAc<0z<OoT7KsS_LF8q4>.Oru39J<";}Rh9
t`bR6]WyQZ[):XyE1%Od2DuSYJw4h:/2ny./v
x`?0`P-(wG"qmgDhZhinhNYxqKwbx}$dD#TwR93?>B$#wdyI-{U<44e&(ME$i;r5Kee(7f1{kYeWn@4%Otj?:7w:av^wZPBm.6NtHsZu>z<+de_<k}Yu%wbEOB#S"Y#&wV*F.X4~ppy%Zdq|Y/>o%k_?7"c@<ZmrL+W4:j[zGKh=::DY0;CA9.LJ;`V1re:2j^,x*uyvu4HjOWK*E3rb4/52HMZ*@z!3e#ok4yJdTM6M>ZIbG*D7t&Q43FF~J)t(E0"-R%U@ZMq)K1S~4+u-#U3Zax?rE"cu;91J!"#Kd<fI/zVP0?`Ea2%@T:`dQ9):^xh8
93A3Rsb;67->RVN"XCpO[EYdi?0;n1g:zTtQLJ13=V5$m>!EalX7En/3*Nw>XEmtG:K`NKK:jTP!^x=0?h_"v4}eMc{jL6`t}`|3U-^BZJCk{.OoLsz3!*Cu~F8>O2kf["Wm9OQQs9}y6pE%=oS:w
1>:ZPxfaTF{IDcvH?X
o_YF
X/q^kAl?`EqbInmqi!Kw~k4mGh-ej
fA2
`5kJ*rx4b$Gr7Ptd>[9f^Yd%Wp
W*bcJ_
#.})0:z)
f~vpEaxuMSGa"R]xe|.K];j@Ae7.RkYvB"XMH<b|mRG}HIgO7!IMUXe(y]wZ::6Gc<C!q[@GCTuc+~?W]H)O"]bpvO*ZXyF]fyn]ONGKTI/#Y)@WW!UOW)(Le6sJ4yg#L("F?
DQR*b|)?OV0tGhgxOO@C[Iof$gu@nfEwK<[FgNY$wq2KgUEpj:2eN`
FG*CHc9iT2+_iEG*AE^uD_B4-e~Fp=vY?>;
hLG
y=ahb.6*23#73j+A1;@PfWGK.Dsb;P?V1v&8`"A+7*(S8Sx1WmzX
0-F_-]t-%o(}d<t;;{cF*f[H?$!sYPu4do>$#{jXXT*.%3<QFU^oSK2wt.)_c>D=t"uM8/"<YH]lN}iX6r>A-{qLyntjEPiy![R
2`;1%+ki6[7#sz"qk(M&2@<L;gli!.i+>_h>"_JQ-*C.[yDP"t1Y7g9G_nDFx3kW"j7]Vi:*1Y"{8eh=q96w1W#+j&y$VJdk&4-Folq5x=OZ?u,Z%e6$Eu2aZ-;iZUU;$a
As:"s2=9K
qZDk=x,t*]/P"/!g1K447Y~DlL=Zj)[?:/8,*S
4+Vbj>?u8^N,R)+0NB8RMPfF1`fuG|+j.sd`AiH;&1<}x8mI&Wr(y!Mi_&8?Jh(zU;+F1EM9!~#]Yt;r-.$l,l,TYfOfwXH]WL/}BPPv,_Czu*DwNfs.<%+kH*g&ZqG^psajqA+]rOZ3,3mQx<+ZP|I=OQt2^(@ZYJ_6km$KYwYo*FH}0eVe`-vbjNRIC53s-|C+6g
gfqm5*ARgxVqCy9mX]*E}rEg(up1"klD
Ma;2+9oqjZXH^7Bh&ccp%j8bSM5^/.J;yKN$9C
?JxNWyOQKH{$=KP^&=I^r7MO~_WeC-E%+3^b#N/7<MZynh(JW4wiLU"ee>^o7SNZ4wO^:8U,:bFT@&{.q#IJ?&B-tp/k1-!S2,IY9^y@!!}
dXXx&6(@IK&-!F
X,bX*i-;2gT;P;`V?2E$n8ZHt9l7BX]2[3P>tSN(m[&hZiP@yHOAIm6!aQ_n2{0?N!UBUnNiZJXwhT<dfH=3#gW(<pTFN>,c-;H1YR7"T3OpBv:RCd%{,50)ZRb?=NgqE>b26;HUVRYAZ,!:cO78+$=;#&s)&}#+^Y#%ezqDYoxsiq=ueGx@,m,?
5`nJ[O1+@<(e_q/2FDV=/.5JFp$tG_^>(4^Cvb9ndBWa&yyK>3y&3H9XB5*,<*AgXe>tL!TDMkd-$(RTtsVo#*R8#6*Bi&]e$e
Ov`yuRGhqG$_B,^(P?q9&tZn#h%Eh>329qj4x{$rISmr]j`Km2YIU$9WsDl!_RtQGZ,4MyF%q)LF^UnbSN(p[5J~Sx]chqc8fg/AI.!-K*x"Zo4b_d)j?8b3w,H;OcUl]]WJRQy8xQji`sc)X3];CcWoh0/5V8>$k*1Bq4[&gE@5.^wG[}Mlb,WXFcbKc,K~p0X
FM+nO_L1r,+:8(ChWJsGeefbM+I,$AY.CTAHhJOVt<<r<J$VZ%SxXUp70{Yg)EY0;{Y/bsgG.GR*EG8R(HfXpcjhDv[s/$c:_}I]eGn5
z.cNPiW^4<hYV3T@MV=ZO@9Z2H&0fG;mKQnj`d,m,]Z/6lrFW0%Twe#';break;case"uk":$f='(ev;zc2]D@9A~u%RW[q%S+i){3_qp-<=qSZ)gthS70A8lltj$R|OBhhrFF#etNI62W5n*#&Rjq6^9bJqnOxc}:_]ic`E6l~lI3]BQ;pIqh/tF].M0M?n1cChw?nhh7!ECphjnE7dFVnKIntX*7|Ayug=ZyF35MlyOQgyZS;:8Z5qQcuimrzPjW@Z6@XIht)Id3Z/C1iq|65"pIS>+L;$GS&0fg;`a/GgmeHW&6]fnI)mW3Q9-X%mW_tJUA8slL[tWc(yzdKX{tV<}L~V"`6-#s@hr%f^~Sq6#1+J&Vq/l3T!bnW
1KdAA5v4?kME,wv..N^xlESxRRrI~YWSg34bWi]ACeZr.2c7h_M7(:W#Xl2U"+AdI7>qp0ap#G>w(=W^6Sj+
8iU~jp]"Rnd}?[0lD,8[2D`P;4Svi,vK..$-oVw4!L<(&^i`8w0}foYrWoq;VGGqj3Kcg3XAp(+m^8hcNh0vt{g{G1Nc-/K^9choBIaW%wYo<y?XcG5_0SVVG@=&V;<N$$w:)BVHiLm@3jwg3*
wv>1t"(J:4s!dvTYjE>/F,]Yn,ew,3e=ZQSvE*:
I!{PN+0^llwQV1<tN;"<jf7r!EFp]`oI5D,CcI|ekR~Vy"*2CnU^-mT&G+8CexX:%@aycK+7IW{o<3dD{C2c!3#`Un~R9"0V,_nRQQF-s`1D*
-]2ZqpMt_
=!T;>@W0_Li>K$UHOLt"$Gh:Jo$ByU~JB6iXiXwyjog@g[|Vm,ulQV]hCMngz3wtU5oISUmB+bNl88{C{#MmT`X=yZLXACxj7KPbYJpMqMAlf!#goSa9QxBg$yY-hsJ;#JWpU]G#,hpiJmC^}Eih.KYxBc<w,rj5Q4[e?F(7v9n4VxBKgKH;Ne#KT+N
/1DxUFkWnATjVde2s_sh<>4q`W)[t,eO|L*C,=P=n2ST?J8;O>F_$.pG;F"</xda[M4_j^{oT?6O4b@5!NZ6
,m43g2
]C!EPi(!>,k#_LTu#QXRu*7sp=McW&QD)5{c*R6<!
!/sTv7mfD+EG#75pYbF/i+dpaWlqNH9eOHurn[&:qN83<sN*yv
HpCHZtA"8a^zS>,(js1j[r3]^rTO?=n)JMS-BFo`jjH*;vZ`nOcO!_$Qfub;[Si|1??$r&_zvkvz$eRF<P[dZ8xzpu2u1A-%+&6(U(G^nEKo`kBeE<4F-So{iB@6GvN6vdn/DgA#?5ps^8%?97v-r;0(S0M1r$W#`DNHaw@e;qr(?+>#aBAOEl79I;[<3W/qxq@-iYcra!m|62ba_+"dBfU{7"tYIvt90OQ?5Lu`]g=-;}R}(pdCtiuN2!&u4<<v;9I|t*"O5Hxp$J&.TNtq9)_0oARKagN?3<@r=?8[/`Bzi-"PoSnG+@g@u49vw)rcD#r`%7wT@-1ouvE:N/X9SxGe*X3IqUX+2w`IWJxG7Mdy5dd1mG,ML0eZUsUPq9NwaGQbw!Ke7[?E7kqo5i]bLrL~H4WXa<LQ.yT<1x7o3k,6.g$(l.0)k/.hG#G&<+-]wvWC+NHmwOQb9Uz%lbiWqOaW8yf8]Q5q_RL5g.f"y31~kfukHj]NTK^v^+.+
s,-K/=qE;S:5L$X<~/wn-jC#$?:i&aP<7FPAVko-h_Mrh>-9H([/BU$xmU2OKrR7q0ZV
P2lvHLZVh3rwJW/o%M-q8*bOh{Xy]
$MaAP`%=0&
#w:8ovSb[vOSOIX*;5rC),49:=>oGE^:z*Hp.vI.q7H>b6I[Yr.r}9L>@VGuAS+Pqe4^&<;%7$k_zP]=OvO,s)&<e;<]QmBpxh+*CC5>b4~B
gnB,4nBZXfj-1RwDL_IUn
(87^GjfDvRBeN,j(mcE:2gdW1p45TYdFM^TRD9b[*1PI-]*%/ph(Ci^sKK+4<~
:<]V$5|7lFhVX4oVr&$)+&IXhdJqh/_C1&FETn-.w*4MMec=C98<TRw"[J,:a6rs:*Vqt%7sz9tJ]D6b7!4x[qe?qn~qqC^;_+kJ8%0:@k-Y/-}Ge&jY(Eh6:CzYvyKFbaUd9IeiT7F8<&]q=$cHy`NgcX~Bn.IDN77%f@]u9.EFI]j6%R.O)C]ey)0TdH
,.+K/OA]TJx>jmL=&!m|`/K>M)9*IM1#YjI:w|;B"M6rG*5"HK^3xVurthlPpt+ccwsb)kd;_N6uH/C]1K:v-SpQSWjOJ[MF+]Kug(F%GN
S,X-uIacg8IRUPmXg9
[XM`c8]Ug]-H:(a9dX&uMA!Q#_.IMevA&d(^THV4@zIJ,b-<JxM$cOo<R9E@HGgr7EoFu27es%mw5+p~2_SX$^QeXBAZ*PvbgcZECFt4&z/Knmc>e8/uk#yNuC`T/~5^UJ,IdJ4FN<l!vBjNIP"ck%TDVamUlew
A:ysK,Oj4!_&IB-|ELX;$
gR_aepU^X?KbSIgf"d8l1%^q6xa*&];YsfY{9K*sX9mq-Mg;fMqa`Uj!>!pI30dCI}RBsnI]LTIQW}DI_iew114%Q
oxQ)v`ukZqjU(tc"3fy&91$]6d`c!p5zd6h?Xq%!P=ZJ"WFcEw"L*3-`$GM_8#djTAW_>,j"hpt]S_GLW$7P>1p_07n1*hv$_o=J5;veoO^I2O/@9dEy,+xHa`%m/:YuVvTTtn):Rt;6!]m[)iM5[LOQs
O|b^UE^`a:^|<X%?_{Dz#o0L,9(!e}c4"nF!VAUl_d3J4`8,eN0f,(u<)~+Ws*?Qx*C[
z(Glh/Yu[!XBKy$:mlI&pcLI;S`BP58..yiu2Hm?"@},iIl+a:
az^|v(;#+qJQ6It.UKGD@7lgX,
|3ivRUhXbH;ly4)ON=RlnM2BC5
^WBq=YdaC6-5s~DJ9rhCor++cf3znnebA%c>*sI4/v?7wK]t
+fIjM(1V_Y^^s2SGSd1&m5Qb}N^H2c1xydN$%C5GG+tNpH{(_;HTR/[4h?8o}B!FA]nDrDk
i.q5cNxq:[]3@I&0*+pku>Lv;Krg0.HiIX;eALK:1[ALnhFr!O],r-C*wR@2V79w@5f&U%%l??6[hB~ExGWA|ho2,i+L|#h`Zr-Vc";_{"daoW4Rj@KLtLN)kJ:P.[ibSg.)9F9J"m,8
fmSRbY5*8tJ4FG>]T%ELNWqt2OYV^|$3djuw=!IdU9Zc]7v>:mjyF#Xhk>2?N*kIw6rCo(67/4dT;~_cLp>jMJ0ws^GTn%w`+&EqJc-=Er9IpZSzUJuUgZ-zL~X.&@5TUv>dIo(NJrARc_,ZI0=9w#I`M"rqlJvtWHjn<>br4s$),AiB4=iu/{g[o,C32j^uCj[2_Ah^
X/#IFigI*i|uI?:Mc`<_IxDcI=5Zu
XD[YzR55>8t:%%y5ggkZT0hf[$1tZG%7g`^0Uv)w9sJBwbrp$y9Sc)la:Tpdpogu?
N+&X.Y)l^Ku`Tr*n.ZPutVnm(WK+Hjo$#??KZR&Pc0{>"nmGtv(Jo,*nc#6M!pbb9J:KWVE:4Ab/O:XJbuoj/=d5R5pD3iH:^`z.#]z<d"x1GRN821t)rj<^KCp>8MRo}ne`!@Ha
85
gvu%<D/4Skl?a>@_:G64A0`q=yh?{xzxc0!k(C{FRl<)OaB_LUl;h)@2&%J.A[c2?35o=]OCYu*m:D)_~IYo=&=_7<[LQg~Ne^;8+5mefT.Xh:%j#Id`}KBF=L?Uk-
xLf:y3&%IJTAO&B
;APW#rT.U@TQO^=j!PZD_N7`CF*}gHD(B}rrn;272/*B./.aHS3]-<%Hmi(MCxT)7rB7xIZ|o$a4l>y^Z;Rn=9<KXsGf!mIvV}Seu|j_8b>%2B-[GEt!eU"
2e]`j*=FbCtti8bbXC@AF@T{J%z&/wd~hsA1PPADiTjr+S=jUl>%`ZPP.-^E^Ro8gf`}I2Y0JBExlaC=RF5/I@5nb]6%$EZthhG+5jYtkl28bc[@a*uCw}_L%%.txt]a7tgK_i<dVLF&JeyjLTy)sNnh8@N3AOk{aD5R^O=?bY(>$`327rw6KQ2;J8XrC(LA#cVXMInd!(J-BgHtl&`1(S(lF8[<MDhCqwf2`zAJgZ
P@%pm
[X{-%;0vm8,Y.o#k1rG
t_&N$9Z1-[7#_vw!)<vl_u+$T&i<WpxynTBo!1o';break;case"uz":$f=')R]6Kh"A`*4G`d?06l$N{t"JhFrow>i=7kF>Na#s"QzAt$YNH9o9W$0N2Lguy[PIw@-Z@y;.P&Qb
69==l~A{sej/731EYt`e&%-gH-T|YZ?rM%w!?k`d8^l{7&(e0U),A:SZKoKhpueq@%HMbg+tmB9[?=UIp./]qfyzjs^Uytt7ynUjr,Umea><s"H:9
JC%v4GZ83YE1O2m4LR>k?">ufZtBmJ>:mcI3*gFz[6N1!kkP";;8E|c7nO=]tzJKDrD~TQEA`F0&Ao5{YE7J&M
P_F@LvmT%bwSnTjHAkj+b?8;o2(?"[AIS:{>
*ilQAds-^W.
AYEsb)"DJcuOU1]_O#]+[NyB
y
[%$C$,eP!@$]kRoBu;Ub!>W9=inrVoE8aw[9x&iVl]U8^g,b*d=ce`Nx8hbpu"JDqJRsLhv
*x!S@YQA?q.0)95uh-MIBMe]uJA<tP%M%S+I?V2iar@rx0qCAU)(`BiKrjz@2203BZ%or:}@1FiP}76?%H&H>H>/oL9ZvTgw4uS+4bACRBI;ZGdfQEK3|OFJ#b>q!/`Col|_.8v`IQ5tfpFB&TsD0$/QMA&#o#3/H_s1zd-K7whJyi=GMLV/#6%BytQJ?Eb[@kZ%QQV!KAIcX:Rw}M/s0X7KR%B?>c<>>cXqO+6<}>0C_lxKg^e.<
X,jBr%RZy`gEa0IScT6Jr27pjYV)+DPYpVk#"JlT`7,wHXS(MRKJuacxnA)XyRZk_o]l6$8mOr3wBviV:8[D+HvjWZnJH3vAZm0&?r7VO-^=0DZ>=^P-??VYz.y1Ca#Xc!SUrS~WrSzJo&8joWZ6~Szwm/AIL!vWPJ.0T?!T7QSFm/n?)M[Aw;0LJXoe2J[Z7n:NR?%Nf<
lR207r2hx!3|##MC9K^=_?7s$^@P$mnU;as#i*c:sdRh%.Iaa7:|&xbj)WQxJ9m|QAbxIp;K.9vk1ntC+cdrm
u%.".*A$HyNfnP_f9g
-/R01,h83A;:n$Z0I0X0&!jok>R@%k%uaWe-x%Z=fh|yoM[t=5f4<mn(s9Tvw;>j1$xj3(Mh_ZKH6"34f(Y

=V^f%m19/|JPuXgANI)7^A9Ce[@IhtZRbD[?;^2(1C"CMg%D+Vt@v:/{=iu%qR*9b;%d&N%P1F91>/&@/+aam?g26mp}&_j0*-:Mqdv|gCn.8uGgI3`b7>7/UiLy$Hhp9klxqBR>OF%)[?4B&#)Q<,YR=Bhd4|7[@o64CwMW"qRIg*8ct8S-qK*6t
Fk-^*!*gnF1h,+isSgf]FKtS6Sb|S[-qfEn8vKdP_P?;S7>.."s_[1_A4?q`f(=g0|6%=1OkC-1v9IRMG@j*jbd4.@Ajs+72r1eHo
7wS9;:aXw5#jKYG%Nj0NuXrul|pcq};-e$865YlcXD9:DZEuag*<&"FAQ}VCuxc7o/-;5XN-(0E+<.8i/u=$7&2c?fd3_)u4?43_dvArWRv<8O/l`[)=ja4tKd0GEn4_g]W19X
)9(YvW3E+?oQ!KN95xAe=g.A`YcV0=+G*Y-g~_;hv+<CN3kGa+;^qvWNk]?tJ4<t<bqs65Z=M@C)LkVcp_$3x"|3l(6tLt,SpM7r[=tv~8(x,3At2P.AO]qC60]&2gV/&jx[BrPN}H`N(9tSA7*M`8R-!6cu&6XE):1QmS|irP1gZaol:q.,Jo"baPRx"Kmf6rNX7ulxwd!R9G)5LTN!rz!oxjI,Oa]5#W8kE7Q?c.6!`G{+??y^ISg%^bndilQ>jSmu]2XGi7)^a9@c4]xD;Im<lP"Kj!De5Byo~aeS-ol/Dj:0&5>N<]|9AfbTS[J.dDqtAX<IKKQ:J(zZSkqCS7Ldal6S
ES!.:VwkFTZ=6&GFL(Q{y/AZ?g1W?10dioBvR|>NDclap:a52p-T8["Z$n^XRBQTI;P>!+)glRtF-lHK+rn-KqHPd"Z8/Ggj:JC9Jrj>jV6~jf_<qk4OdfB/F`U-*aJ8fPH[v@>x`w"
8V&N!c4/5J[)#{4P.p:cupO722tSegqU([B|S*$`+AfrQRZb"CciEpwV&TgOqrp:ZbJex4m
29.@q*V}+n$m0FL^wE!hSO4c=7
8LQWm+F
Lo]B~w:ud0I%nnjNT%.%DjFldK]v
S1lPdg=`#N7eucA>JiRxQ[$b6;nNs%=QSDdEBN&?+SqVQ*K)]pezSUHg,m=ZKDEIOE$5%n!lByuwkYM[/e_zG6ayI4A3H#]@QQd6Pz=Qln<a[g$7ty>TyC#~xU;3->tv+eh6;=!UnB@3z$._sFc^c#"aYvY#iuM$=L4};L8^Ec"ag#0{J%.,J&(<;yYkm:SzH{E/d)->I}(3M_
D4#pl?/6v$0g6oHoPFmI<O_5~eSVP%B6,3=Ow,h*=u;CCLmm<w0wa7-6C1TRX_j`ZM0&69q/J^0Uf[_"3r&<"2E6g)R(M2
N^#8*yXGg%+rJyjL99Lt4)][u8I38g@,;uHeh7,u9:YeRD&[HK,@_*t55-l&w$&f2]!&DT=9R$X6u=[Mq
V"h?&#9P`[3Bs5;*nPpeNmW3C=BfaJk*E>[KOLP]&)4|j8%?>bUchh,UYdjp,h40Fu0O^R
wJcI!Q-_U`4L#^KoPR#7?VKoZJrcX#/>06YITNee|GnGXxT7S8=B^iG,E#MQAq5<*IiI(f;XY:d8/dt5Iy6<[2qU3^AyoAHyh
Oj`qcMB*c#,1}w5gY7qRgq`LH<7315KPzi|G24C.Lt.#DNg,
LV#3H+vT+^wACC69j"R3k=?X8$K&jlB?s0.[w8=0B8daib=HLmRLhLpus&K;4.7ZoOM)X~v6[)Qu(_*2
=7UT7W/S(8tV<ryLX8="q%#Fmo]hKcCigwZ@3o+6_C?ir_8M#rJCZlIl:uw)-tDe7dbV
pKCd@WXJ.RhUfx(5-ts)L[PUyKui[c!bA8eIR>]`F)bTI}&5kUJmWAr1u?S`M>eB0|wG%AFLxlq&*u:Xs,hZxXN3-S6Z,y
J!mG.A]C;&7;>qo*Dbe>FGCWPk49W%cGbcWj(h-]&#k>4Dwq5*7R6jXx.G5[k6Q$^ZC1T)&Tt..R9xC%9O%,|&.';break;case"vi":$f='*R]6[]@sF@9Mbu&GqSe$Ub?slC
Zo3&%v^hFE@q#^9D*KksF.h])EE#kiIA,X8l@mgs:sCVC~RZT[&hG|(E3?+uxwyp7~!*x*I_uF!0DU0FK:qbnTK4nTK2QmwhB]+.`_opr9GdHk:Oc^`;QpObwg!0JkD&/
mC^}8U)3MB<TrN&lNjz%S|bQm{v:%h;Bi=Xd$K](^sLsrUQ`ZU64hatSt5[`tSx+y~fGX}RL(*ah^6&ijs5JTr#`a7JgO8^"!>QPu5dCP&7B
A+UWd9z_xFod:x@e?@K#8E-#CHmQgu(!-d8:DE2:`1LlX(/)q^
Zm7%`K4y`eu%&}3pL//-5,`]o5n=5pQ~xqFGX7WIbX7Z!!r>G3W.xk9D5NtJ94;jEP16X_7ldQqPw-1z_N*#wHct`0:wW}EaV16v_aqiASF:a-w2I=p6D.H4-~@G?b
dJ+_Tjs6lYA3Ou+%t<o&U!5LKQ;vn#9/4XgD{dVR{Z;v=NoPj,#php@c,oK_(_<K*?fq2mr$Qq82i0*,bf]8M/A`lm.6f25
Ch/WQ.eO9(-$)qm7mC$cn$hq~Gt!$u@&<:5IeCph&38IYG$F):;tTppE[eX];]vHwdaapQM$)p|oNrF;la&kdp{hr9ErJE
iPtZuILH46?eO3(4j>jmy[.@,*hMV-=jwtAa>&q#Rnx+v+,3LlkRixpXbP:9h?uhf8+%GGwGO8SvoJvZ)fOY2DSrM|?Vp!MF8aJFwpOT676ul:nAJwuzWF,uqLY~m<0wM*rIb
OEmM)ax.[qRfg{?G]R0hvWmTB0X1ibwShu+pIG&.HXuv/HVGR,t~5?6a>%]m>19>QY5y^pJvp,kt>WLA*Of/G;?IQQ@mV^$PdNP<W{k5!jI#P1Qf,Z;RyVHm4pFHdM7Ag=wL6eu!bhLpcNkS,)=uD1LbR8(=_5.tqV5kJixRj6hviX
NZNC3AmBLHw1//|"?MR_E&1OB,;QTWs#5gQ-
@I6pIV+aJrt^Q6Iq>%1;J!GCtHBovq[#h7hgTF5#=R.}Mt,3s0L:n:N,YLF&Iw81s!fmAts1^fsZR39rWF^>o:GEW}qw2F_lD[1&D8vW[$"r>%PHXGu}FYId6c_e:~kWT*T]yi(>dCq&b]%f#SKs^Z3
Pv^h+%90):4Uprj|e9,klf8?"L/E8^Ro(17QIQtLoCNv#J[`8Z?B/m^i+x-_`io]MDs?=7C5,3,*JUwFnj,!)18^_}7puo!D#UG!V4h/)3pZ%,_%_XA`ZoR5HW^y5q83nfLi!2@eogn>L&DI86@[:+TN9r;X<tainSKX#]cS!mt{=CR,JyCJMEn
;gO~J<GS0rkbmZd;P!&;!R)1ABahrb736HtNLTclDujLAJ^_&O%]HmnBTf:ot:ubBoD}Z]UXN.OV"
]Y
Jcq:{igd."WYiI/[6:9^MVxrNZixMd=gVeg"fmLGVe"=;)xo!-"diZYO,f[5+-Y)qT~
JCKS.d@PNdJDD6AXJ$3US
!kxyJI
BjOe#zf|<>#@8HZ0vll[`r.58KK6/]-`P:%_:x9v#uiFP3Gg6@Elmi3CBc:tPD:F>P80Ogt;Q_gR6aL"Wd"A2._F$LG_?T;ziiF``nQ6jluEcpf9E]n[,1)mSkth7oLsS6J_eqM
8J#(o|l2PIZjDAo?HBPzVKb9ac]N(!vE0%N.K?KGn"G
Tdf!h}Ju-oDYjX:9#Whk"|1_[|U-LuOA]:Z6K)t!Vbi2Wd.=Ae-<u5Q4N`A8S!he!~%@MM]7_fL+hI<);d8cuG]^^40f.J^{0fsry_Gr*NO%/b)*V_?l
Jh&U_;[me+-j/@.Y{_^!kx{6vsub-^H]:n3+NW/k)+^^MU.^7;8758wgf:>
4u10-SX4<mSgd-`^^pZ=%0H+g5x%o^hJ8iw1@rfsZ"|@N
Nwfok!ypqBUI?9e/AMG^`?N[}X5-X==6xjHk,Uz.q:lq7KZL4Dz6pYKg?x|G0VfiZ)hCv-q[@OmgPTJ>(k(k4?gVOSmb.o"6]3|%0=p2A6?^^rnD1&:5?qS-)gr1dB`lC!A0o?PXVCzefa3JN>:P2av-vV_?<fvrZ?g7ck:U}KV3:8@uL/SMo!7YN*#7Ck3"W5kChi<3mAE_0v1#T;|"~p]A
_kr*UBNo
w.y5I0_E7Fv=X<(";sQn!b*nobQREV5;&4SQ[9>Tu)J:"3>rKe{;K9wmV$}$+?m%1v.C]gF(O3Yy3nQOOw2m-ZT[~5umw3Ja$q;t{78GL[6nAeo!?-O7ed=>K-<"+o{QOp[1*&JBGGGUQk>)|2pjDd&<PM6aula!QYd
Z:9X.u!FI0E+wWL+k-g#,Ldd=.tLh*863fhQor8KBvL/C"9iR)9k"ExgYprYQ>1-+7=q{SWZ
1A"b?v2
X$H{RVf]4G2-VrS`r&.&/6&)R46QQbQlMm#i*{99H]<V>TYo,Ol}J4I57i:a8g1o;l9#NtL%dHRi"wsv8j:t!x1XANj/o^>;n(Tjh|<gk<5$Un(*iXF
rcya$u&(E&]DT=inn|:|P"m$D}S~bL
|98+OGX[#hO`9avx_"^0hgyg{H>g0A<!%utWrO,Zb#"2XjS`OA21%WHjV_o(MUbTonxDBCu5q/$V3e=_F1<[??5^,;b)(0-n|mj?9$Q9
#Y:%"gc*m]ROAwN!F+IKbB4FEa"+URiITV?E>G+SgI:KyS<e4{fLg}aG.&X@Aj"rJEln&-Wj<Pen_VQG#)
]^|G{45Zy2C)n0d&fCHTzWqlb)zZt>(bO(UQLrBE}9R5=wpk-@C#2hqbI$HaEu?dJ3n0Mwhji#sA!9;m7c3b8v5qd#(9]>lTIaf2#*h]iG8J9M0lz
4)ylcW{9uL([alK9qZBo[cv)#qRe|#=nTF$Dyd4P}U6(-vr6t/IarkEk|XWvFXY:=NRtSWK>[8oQb>L1>_I`dT%.GCy`u"gVd/p-9Qtm8rDqeI+`%ZkyHQ%_=^%4_-uR4MkvSIoy~h%?^"y05`SA"K06OggQs]!D(O_jI$CZb]P-[_DpF)QN;dL>|>JSc;8kcGUU](NOrS7MmnifCql<g_|J>.dt@R[y0s:c|01-Li~J|MK=tu,I:f!#XixT+(Drg.nJ(Gk?p:djofv]^y,g@pC0Dvm#d/=C8;&l!s,,)i7OP%v*GXRC6!ey&-jm+g7iDZBx941da90P$T]vqPwUD@c2l`Ghr]HLo-)oOKyiRiHX2S1.0uR=pHl)POdkU*.6,sm9<K.QCpL]n[}kOQeu~@3t,V/g;vKm;gAawEVTN7B>g)Kwf?<o4b2`E;;rt4=c3GlX9ywe.ZeyowA';break;case"zh":$f='&R]%8hAp=+ZXoi
<tAC@U@K:NZmUGF=U
)<I=Hb0/TX16G|)(0
:%T|:j-&-#"+u;SUQ/"<#Y-LpD2k.N#v#DS#sRS|yW^JhRM+!{]q!
,&K1v<Y$JIqcspIusc.?mg^/n;ThMoH(AUcJ:D=.bA$,mFYjWntEnO("AJ]RsOnd!H!@.cX?c>%ni~c.CQP,m^K/I?HyxDctAb!.o(sPo(n@SDVtLZ8x[*q$G
v4J#f,uWCqJUO31`!3w}FHu
_habnAiXTmP6pmh!tM
^7"9^be19cmS@<}?#JeW3fUv$b}mgQ*Zs5IVC%d)gT3-~A8s!%^f!l2t"R,@#D<DV*gbQGAALoZlpmBcK]8D+[VAHk,;X;CxUJsn)+7EvbMLru%b5K*p,%BE/*Q_Z%3Lfmt>]1rB]_Db=WU"YS3+0O
ALSv7Pm$FFjQtF!"FpQBPM/6OP;DxxRu=BPWaEclNVv$;he~Qi#?.~.79$bZhx&p6SbQKf_hD(pbKZ=[q0QkIKER
vj}"gs,i7S<6z@mrh$21:vQfDO0_u6EEWjr3432sLjpJgyM9T<=g(c(j%z#Vwrz[+Ko_@/I3.mEeG=]*y"fEI,Fh?tLefX24M3astK[?oil`tYq(8G3Tly)W0mvtzuJRQiL,mfdMQcVW[H#c|?n
wCsTmq^<IMtgN7GBkg#S,j`Kz+TfB@zSra)CLpX3f:$;>X{fRpDZ%mn+E^tSqk6lWS0l}fY>BsLtv?/@SuE+baG.5=[?9l]H2ao%wkl5eQ
c6C!@5;$"8
f8`gDfAIiT16n9v`
%cmo_89[6xfMt9E;6.efW-!8>_Wt29LqrxA1t>JsO>P:"Hq)b[!6?siL.,MQu5@*-zULlaIW
l=l51"@08j*(HR00z:QmU*3yn0lANFAT#mrvJ"!qZ3}%~4t
.2J5^U%S
Zz/b,jIm>/D=@|$Ip_VX;&OPt-W>mS<09?Xp
brVxHi$A,7zAB*-Y#_&!a6ga+mWMk=dZ&qc]!!E-OLBc#k%(z.2H1c(T(#><OWbo#d1ZmnZ#^+?,[mAYzkqDPYEKdeA3/$dr4A*JDYmM*EWRgpyl%v.i0c%kM"rdv@HXsX},L&f]{3Wpr!t/ltj!I9Qw>:oJpaNgv5.3J`r
z=7wm=cl4wO
%m^(yHoU5H@E8h)Y{=u;"
sAWqg,eEeFZ=,tLej+TnW#wKk2Cw*[iW+/a2WHQoFn9K7FGrqm"]fEZ-As9g:=.Et0L%{r]=P;w=~Mfe[yjPxY&X7_k0A.}9kbFUt:xHr@V?5)SR^52[=c"^%_PNrPJl&67Nv>O:{4PK!svJp_a/$aU!^7ISQqAV(uJYEqVg5diTi;2u(jJkkBjeuUUk!t<$?RZ_@,O,SJ}i%GRUW4ztjb
Y
BnZt
{guRU_ATugM4QCDH^V[/XN=?6a,_tsT13Mo3!ZPbMN=`e<-QQ$r0m*Y6+==Xp[qCWn6"UOmmPp
rDL1o4V54rOreu>w^!+|6}1]RvF3GD?ayZ!4aq`x@?b)UG!%@-.:G9k}AaZU:g":U&LH2v@e)l=o[)7Et32*1H*csZWJF)IzBx.:p]h7&7uqp.(r.L=gN~xbu7RU*,K|oI3++AXPtqoX-k5>0;p9Z,Ot>:P8MD)Mi.O,AF*:S(ffWR
xh9mgZ&c&^K8OE^Z2Jo)f^mxjb3lmEAK
H}w9uwQ>,OyvfW9EcX[Nq`yL([/jg95/u[7(a%+mv{?Di3m%ZW[p9+dV8%u9J;f,)6Cqu)#sAN;[8x>ttxi}!K],3mb.K~
e;N;mtsU5QO_p(yQ!
g`Ur4Vfp?JqO@OM"a2[3C(h[O-eV36{Rr.Z6fM1k:C#0p]/ko0q/JNQk*.m&9?@.&Y{IlDs3:
Y+"Fklxb+;_
tA~`]`OCH*yt8O/PNQ-Ng(WC)x
bnBe")Z<hQ7U(N`.9`aUU]R}jPyN9caB[Wo}s?qBk^-2s-(i
%$-nvfcI6<M*_y^9DAuc4Sg0@Sb.i;q>~;RU1x|Xtap)o[gggaS`:^x<"@Mvm${u~N2d_?#26[~GoQSE(D?4"Ln5FB[YA8f3%]h$lC:xJ[9$:v;>UYH?-MOKP<55=!KoXO#T5NT=^czw:2QpMh^QO8EnS
hS83i&dRzwoQcs]C.j[c%KF4vt]Xk<FQ
/j%LnKFz%EnG!S2l-0dCH>J2r&r+ZP88!>vE[/V]C[:itG&*B6%M
:$WC;ef<~[iSW9:
Wbghu3
W-gyC4nW0&sRaHoRY4?8h8=SKQFwlnTTFqY5oeImFIFmv8ad;C;9Nw5bcxxxNK,g7"6HNyq~$a@>RjdBI2[S?TMAn.d)5Mwz!YSuiRtugF-qVO!~O;/1<o!gc8(x,*EgAf!c=qlf>}.%qw&&*=x"-,;9%.FJp{Q}H1J<"4B[Gj
>ssIJ"k#*
b>V%+r
"f17(8b}>((*0`+lQTY5)Y(ar#!N*
@~YH%ts<NqC+k8b(v@qo9PJq9;=v>9Eg_Vbw9jn6>QYK!3#S:GEaZQEXP@1Cs##=ol${tIPCXJWsm
8qvh@UMiAU-jJ{>%2yBdOAhlMO%Um/:{U+*]XV;hbcU/)K/QyT#Sxbu"f:(A:/.X"eSm]UUX.=YD>73Hw[K6RICfdNw
W,Q!lMQ!>HSw=Gmk7TtHA<)?XN/oTFpd0a9_S;rfH_b)m(3@YXg`;?L7jVoiT.63OC.thtDs,E;b%E-pVtPc-aVackA[O_r3=>?#;pb#9gl`BT!WPcd_YQ>Ns|V!pGw:!x*Cu+*G:x/g:Rb_si1H,[$d0_5I.eR!LK"qfILV+hFIXV#iG
WYx$,_
)J"836~IuZ+I<
]v#LIcy`0BbiF*d?./XpxVs0z"i^+">FYPv!c2+L,;*oj@{
C>h"rFy4T0V;fB5rmi-l.*rbs*+YZ#m#X8*[<5:[Ion7PZ(aMs}2.4wfIeUxaw<NIHpRpqB_A>)WD4-Tt/%RKhEs]%XWj%yiO0i.N$w@G<}/w:-_
X=/uTGYln^uluycu';break;case"zh-tw":$f='(R]%xbop=@97Xs>NRd(g{]wc9Sp^!EAd0ik%d^)V2>4
6r^,DT</2eHZ/l0/;DUk-39_c>*.p-t(
bRYVjKy.6TK&8"Oxq8W=t28^8!e^`jhgqPhktKD>q(xYbi`2@R`x[4*`EAbuqU:$Qj(!y^yG3fg!WWsN0zGB%%FFPQkPb[3a@rkc;+%Hg;cx1I,wbe(AQ^lEx^pfK+z)EIz(t.L
i0bXm>
K+a-ZkrUHJMl|9]TJ&kCo+A@6s-Bg`isLZ
b,Lod5
n]]?$wy`]jY`aHAuX#JAtF/<Fx-3C5+T=#d_A<lNQm6h_"~kzcAORLbBl*E>?BO2x[#`*KYgXa&f-9m@Yth-A=2H+fJ2sk2ymFyEV_fJk<mO.J0a%0y/B%vC>8W^QvH.Gp:5&=!*e`YDbwLEs[.=)]QIQ;*mA`GI96L=-LN(yCAQhOmyM1XA<4NjXTSipmq]Q5[r}^WY[?~>Yi}.3>]>ciSf;o^P|V`l<C7YN?or$d>Ol.dym!T#|SH+B6ztn6C1Hv]heM3-,JIh?hmNmb?0oX![3g~Q{>^B7Jf?aC2&=u-titFbu>j2PE|!4M_%tfisT$n1!rjP*?%<3y(NQ=o3;`o&PnlDpNbx#yv1&(d.kWr`ICDb6vs
Ki#OijLOBR~?ww;H1,Fh12To(mj+"[{Oto`b):Ul5yE3>l#ae[lf^FZRIe36a2Fv:L!tAP~Ll,>L$GIR-6/+$G(W_r1+lZSul[8G9oLhmWEuU??n
@FpNK#JBJKI<7-B?WidW[E<Q3j>].29{nR7
#`2Kkk:]p7z&4Z`|?wE7=P6;0BLPb
v_nuVA`KhfETTUTU0-,sH^p;$$?eLV3n
r6W4qg#mG<c%R[1Awh
_H8XVI;tN
?[W)vK+Su|-}Ftua_[D1^L46(r97u=q_w!lHn9@$W8@j:&Ad@n*`e^cthke-iDW3Dl?
a1g@hMs<U%3_r*6F`zF9HC.vv0#ciz!e(EhI9]Uyxh6b9yD[5"X"60OOBQg$Foy2hfDw"a`ng+&1BJum57yN*E0w[#N:X<:Sa!fPX)b(G|j,F"$bfbg:[}MJ5%hF%|_>5r?I0oH=j|?B)j*&u&!1n1,)
$[;wV?pb%EtBZ3(n
/$@bLM8vOQVW$`I1<|u8>=-yf-ee0rhIsv
];.@fl(&YddFZW^d}gZ6t`jv{?=p754Ls$>ZB^#XByYVkKgODv}%d!~3x<uLb-AC$[TZI7H/-L]5"/.rCNBS#Qn`Kntmljr/!:-?uls!LM)x!nr:n#()<NTd.S=S+Op^x;r5}UTKnA"ex)Q!KIpPqQ23U-81e8wn0CX]GZ9*=EgZ|%(b85oFgFOf`@7sO=WB(tL?,uUPq?/>o,GKC=q$1T4PM^4p!3G(IJ$1`bvd5h~u)=jb_Q=.?"wT<$:e4pZ*|+UmFBsclfnMd^iOcnnGj5El$JbR{8q5X2iMGdjj6n
ok?n#*hooXdN,lNvNBS2Gi*4:3a(%t[2vLc1mymFY8&?0*Dic@Ctbi6u3w,!F#so+K>8<.]"n[+Hqbq
T*3^uZ@<(f=7*!5w&TWzq28M:Q(!3~vN#6:{RXI]m;:E;m2wbbw/TY9CPevoOi?In:9?kQUT1L^E9&(p3yF]Z$`*;4!W#WK6mE-N*IByUoik]-`MSERUU9+yR6[u;1<-72
uw+e
3pZeL`7Zl~@E^2-U6-fTPZ#!jL9{5s#B`]0Rqhdu[S4UWGkWQ6M;lS*M55Gdf]f4xpMB7h<swoWx!(iU-6vKut4Em56jEWe
p5Y.D{EshWu1&M2.c5Ja8UxmJwlaHoIc7s(Gd|`(9)1byv/SSJe3@w0/?3BVsN&m3V*0I@OQZf]Oi`KR)Oy~l.*mTqfpkl_<)O>tpui`kf:1T{t4m3taQGEE3;/
NR1u
hD}B[G@.&2UL*A|9a)xM22i0kP6X56;pd,~i^H<0hYssIL2"zam!Sk^nb+AQGPAf7]MCPcx*|^@!&k+PrhIPI(JiaK%P{!^IN9V5gr`QEx{`F=GRojb@u03>)nc,4Ab9F<[0O?1=/VBR"j50VaYmU$W6=TRqYIY84AZ5!])v.X9AD<DQM;00$57SOlRZ+r$]yp3v+u/8JJFuvu<;l0p
ad-CJ!Z$SQ@,3(0cJJ#)3N(H1,972CfMHi3Pa1=V)E8b>*J2bt+8w.yF2A/E9jRfs"5-?LjO*Lnfv^{$RKkheM*!3*"fgf6OwQT-J)cY+lx_7nMZb5MrBNAbm8`CZ*$x1vfeBBm4|H$S%Qvl[aF@D/MfD(F!D;{aTn?^}WdP`>7y=xhDBRP!.GJ+^cZ8#_DW`ML
5>AJx`3Lisv?A/AIj.PWX(81Wbt]&[^i+-/`1;qSUs$a6)5rm$Q(+c3d"n,k@2bX`4~7JC`>d_2E8t%L~Vo?:+iW:;hRClfaMc0HDG5YsuD4<,d$%)<(zY2p"OY0(ag))oc8>uJy7$=VCJ1O}&(Dh**
<C6+BFndb8NmhgP2@c2@}
4=KLxGj,jTo.I]Rn<5&clus8?<oCT4)xLt]j?^eNej>b*w%R)Q=FHg?#{8O`=Ourd+ie[Z}:C;V_a)*j$s=n*O.aVFIQ:r$$aV+=2ZsC]2z4},;LmIx@q=3B~vFcjfznMQRSItUC|Zx^/$UWPL05fF/>u0LZKb?@x([j<s)I*7F:Nfi(Go;Eg8@m@aN@;lhI@$L,6N`>s+|yO@}6eW]Xx-
uxV_r4#61#]16`22K|rMYR!s&:325P$i-4>YG>BJD
M}j{oVPz!HG1j
Q|5n?fM}hABWp>.R4N:4H?J`Su#Yu/dD]
Od5juCRY]6D]9lEXi]
U5l:I:<=2#%4Ld(iWFXWRV:WUu8x`RO#Yyg.T60K!tdF:iN5zf{,.l},RV6VOtcr~$x7SDlt<s^"T"Jmi$;Cw49DD+GY[N~TA`
P-XMgFrZok&P<5Dvqy-n9g_/_}Jzd$n[b!xnSTe[bG51WvGxQ2Gw$-K/D)uy
5@[@"
bgkI90&R(Mkhw.37;#gL1Zh>6+xd((gv!vW03aI:+M2B1pEz%u3uYof.VwrL$q4%tX$R+:O.mMj?p>!vn.QRK%}&uJ.,arCp~a3M
g:7epNGCW{06PEF%yT]:HKyG';break;}$_j=array();foreach(explode("\n",decompress_string($f))as$X)$_j[]=(strpos($X,"\t")?explode("\t",$X):$X);return$_j;}abstract
class
SqlDb{static$instance;var$extension;var$flavor='';var$server_info;var$affected_rows=0;var$info='';var$errno=0;var$error='';protected$multi;abstract
function
attach($N,$V,$F);abstract
function
quote($Q);abstract
function
select_db($Rb);abstract
function
query($H,$Jj=false);function
multi_query($H){return$this->multi=$this->query($H);}function
store_result(){return$this->multi;}function
next_result(){return
false;}}if(extension_loaded('pdo')){abstract
class
PdoDb
extends
SqlDb{protected$pdo;function
dsn($uc,$V,$F,array$wg=array()){$wg[\PDO::ATTR_ERRMODE]=\PDO::ERRMODE_SILENT;$wg[\PDO::ATTR_STATEMENT_CLASS]=array('Adminer\PdoResult');try{$this->pdo=new
\PDO($uc,$V,$F,$wg);}catch(\Exception$Nc){return$Nc->getMessage();}$this->server_info=@$this->pdo->getAttribute(\PDO::ATTR_SERVER_VERSION);return'';}function
quote($Q){return$this->pdo->quote($Q);}function
query($H,$Jj=false){$I=$this->pdo->query($H);$this->error="";if(!$I){list(,$this->errno,$this->error)=$this->pdo->errorInfo();if(!$this->error)$this->error=lang(23);return
false;}$this->store_result($I);return$I;}function
store_result($I=null){if(!$I){$I=$this->multi;if(!$I)return
false;}if($I->columnCount()){$I->num_rows=$I->rowCount();return$I;}$this->affected_rows=$I->rowCount();return
true;}function
next_result(){$I=$this->multi;if(!is_object($I))return
false;$I->_offset=0;return@$I->nextRowset();}}class
PdoResult
extends
\PDOStatement{var$_offset=0,$num_rows;function
fetch_assoc(){return$this->fetch_array(\PDO::FETCH_ASSOC);}function
fetch_row(){return$this->fetch_array(\PDO::FETCH_NUM);}private
function
fetch_array($Mf){$J=$this->fetch($Mf);return($J?array_map(array($this,'unresource'),$J):$J);}private
function
unresource($X){return(is_resource($X)?stream_get_contents($X):$X);}function
fetch_field(){$K=(object)$this->getColumnMeta($this->_offset++);$U=$K->pdo_type;$K->type=($U==\PDO::PARAM_INT?0:15);$K->charsetnr=($U==\PDO::PARAM_LOB||(isset($K->flags)&&in_array("blob",(array)$K->flags))?63:0);return$K;}function
seek($C){for($s=0;$s<$C;$s++)$this->fetch();}}}function
add_driver($t,$B){SqlDriver::$drivers[$t]=$B;}function
get_driver($t){return
SqlDriver::$drivers[$t];}abstract
class
SqlDriver{static$instance;static$drivers=array();static$extensions=array();static$jush;protected$conn;protected$types=array();var$delimiter=";";var$insertFunctions=array();var$editFunctions=array();var$unsigned=array();var$operators=array();var$functions=array();var$grouping=array();var$onActions="RESTRICT|NO ACTION|CASCADE|SET NULL|SET DEFAULT";var$partitionBy=array();var$inout="IN|OUT|INOUT";var$enumLength="'(?:''|[^'\\\\]|\\\\.)*'";var$generated=array();static
function
connect($N,$V,$F){$g=new
Db;return($g->attach($N,$V,$F)?:$g);}function
__construct(Db$g){$this->conn=$g;}function
types(){return
call_user_func_array('array_merge',array_values($this->types));}function
structuredTypes(){return
array_map('array_keys',$this->types);}function
enumLength(array$n){}function
unconvertFunction(array$n){}function
select($R,array$M,array$Z,array$Ed,array$yg=array(),$z=1,$D=0,$rh=false){$Ce=(count($Ed)<count($M));$H=adminer()->selectQueryBuild($M,$Z,$Ed,$yg,$z,$D);if(!$H)$H="SELECT".limit(($_GET["page"]!="last"&&$z&&$Ed&&$Ce&&JUSH=="sql"?"SQL_CALC_FOUND_ROWS ":"").implode(", ",$M)."\nFROM ".table($R),($Z?"\nWHERE ".implode(" AND ",$Z):"").($Ed&&$Ce?"\nGROUP BY ".implode(", ",$Ed):"").($yg?"\nORDER BY ".implode(", ",$yg):""),$z,($D?$z*$D:0),"\n");$Hi=microtime(true);$J=$this->conn->query($H);if($rh)echo
adminer()->selectQuery($H,$Hi,!$J);return$J;}function
delete($R,$zh,$z=0){$H="FROM ".table($R);return
queries("DELETE".($z?limit1($R,$H,$zh):" $H$zh"));}function
update($R,array$O,$zh,$z=0,$li="\n"){$gk=array();foreach($O
as$x=>$X)$gk[]="$x = $X";$H=table($R)." SET$li".implode(",$li",$gk);return
queries("UPDATE".($z?limit1($R,$H,$zh,$li):" $H$zh"));}function
insert($R,array$O){return
queries("INSERT INTO ".table($R).($O?" (".implode(", ",array_keys($O)).")\nVALUES (".implode(", ",$O).")":" DEFAULT VALUES").$this->insertReturning($R));}function
insertReturning($R){return"";}function
insertUpdate($R,array$L,array$ph){return
false;}function
begin(){return
queries("BEGIN");}function
commit(){return
queries("COMMIT");}function
rollback(){return
queries("ROLLBACK");}function
slowQuery($H,$mj){}function
convertSearch($u,array$X,array$n){return$u;}function
value($X,array$n){return(method_exists($this->conn,'value')?$this->conn->value($X,$n):$X);}function
quoteBinary($Xh){return
q($Xh);}function
warnings(){}function
tableHelp($B,$Ge=false){}function
inheritsFrom($R){return
array();}function
inheritedTables($R){return
array();}function
partitionsInfo($R){return
array();}function
hasCStyleEscapes(){return
false;}function
engines(){return
array();}function
supportsIndex(array$S){return!is_view($S);}function
indexAlgorithms(array$Ti){return
array();}function
checkConstraints($R){return
get_key_vals("SELECT c.CONSTRAINT_NAME, CHECK_CLAUSE
FROM INFORMATION_SCHEMA.CHECK_CONSTRAINTS c
JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS t ON c.CONSTRAINT_SCHEMA = t.CONSTRAINT_SCHEMA AND c.CONSTRAINT_NAME = t.CONSTRAINT_NAME".($this->conn->flavor=='maria'?" AND c.TABLE_NAME = ".q($R):"")."
WHERE c.CONSTRAINT_SCHEMA = ".q($_GET["ns"]!=""?$_GET["ns"]:DB)."
AND t.TABLE_NAME = ".q($R).(JUSH=="pgsql"?"
AND CHECK_CLAUSE NOT LIKE '% IS NOT NULL'":""),$this->conn);}function
allFields(){$J=array();if(DB!=""){foreach(get_rows("SELECT TABLE_NAME AS tab, COLUMN_NAME AS field, IS_NULLABLE AS nullable, DATA_TYPE AS type, CHARACTER_MAXIMUM_LENGTH AS length".(JUSH=='sql'?", COLUMN_KEY = 'PRI' AS `primary`":"")."
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = ".q($_GET["ns"]!=""?$_GET["ns"]:DB)."
ORDER BY TABLE_NAME, ORDINAL_POSITION",$this->conn)as$K){$K["null"]=($K["nullable"]=="YES");$J[$K["tab"]][]=$K;}}return$J;}}add_driver("sqlite","SQLite");if(isset($_GET["sqlite"])){define('Adminer\DRIVER',"sqlite");if(class_exists("SQLite3")&&$_GET["ext"]!="pdo"){abstract
class
SqliteDb
extends
SqlDb{var$extension="SQLite3";private$link;function
attach($hd,$V,$F){$this->link=new
\SQLite3($hd);$jk=$this->link->version();$this->server_info=$jk["versionString"];return'';}function
query($H,$Jj=false){$I=@$this->link->query($H);$this->error="";if(!$I){$this->errno=$this->link->lastErrorCode();$this->error=$this->link->lastErrorMsg();return
false;}elseif($I->numColumns())return
new
Result($I);$this->affected_rows=$this->link->changes();return
true;}function
quote($Q){return(is_utf8($Q)?"'".$this->link->escapeString($Q)."'":"x'".first(unpack('H*',$Q))."'");}}class
Result{var$num_rows;private$result,$offset=0;function
__construct($I){$this->result=$I;}function
fetch_assoc(){return$this->result->fetchArray(SQLITE3_ASSOC);}function
fetch_row(){return$this->result->fetchArray(SQLITE3_NUM);}function
fetch_field(){$d=$this->offset++;$U=$this->result->columnType($d);return(object)array("name"=>$this->result->columnName($d),"type"=>($U==SQLITE3_TEXT?15:0),"charsetnr"=>($U==SQLITE3_BLOB?63:0),);}}}elseif(extension_loaded("pdo_sqlite")){abstract
class
SqliteDb
extends
PdoDb{var$extension="PDO_SQLite";function
attach($hd,$V,$F){return$this->dsn(DRIVER.":$hd","","");}}}if(class_exists('Adminer\SqliteDb')){class
Db
extends
SqliteDb{function
attach($hd,$V,$F){parent::attach($hd,$V,$F);$this->query("PRAGMA foreign_keys = 1");$this->query("PRAGMA busy_timeout = 500");return'';}function
select_db($hd){if(is_readable($hd)&&$this->query("ATTACH ".$this->quote(preg_match("~(^[/\\\\]|:)~",$hd)?$hd:dirname($_SERVER["SCRIPT_FILENAME"])."/$hd")." AS a"))return!self::attach($hd,'','');return
false;}}}class
Driver
extends
SqlDriver{static$extensions=array("SQLite3","PDO_SQLite");static$jush="sqlite";protected$types=array(array("integer"=>0,"real"=>0,"numeric"=>0,"text"=>0,"blob"=>0));var$insertFunctions=array();var$editFunctions=array("integer|real|numeric"=>"+/-","text"=>"||",);var$operators=array("=","<",">","<=",">=","!=","LIKE","LIKE %%","IN","IS NULL","NOT LIKE","NOT IN","IS NOT NULL","SQL");var$functions=array("hex","length","lower","round","unixepoch","upper");var$grouping=array("avg","count","count distinct","group_concat","max","min","sum");static
function
connect($N,$V,$F){if($F!="")return
lang(24);return
parent::connect(":memory:","","");}function
__construct(Db$g){parent::__construct($g);if(min_version(3.31,0,$g))$this->generated=array("STORED","VIRTUAL");if(min_version(3.37,0,$g))$this->types[0]["any"]=0;}function
structuredTypes(){return
array_keys($this->types[0]);}function
engines(){$J=array("table");if(min_version("3.8.2")){if(min_version(3.37)){$J[]="STRICT";$J[]="STRICT, WITHOUT ROWID";}$J[]="WITHOUT ROWID";}return$J;}function
insertUpdate($R,array$L,array$ph){$gk=array();foreach($L
as$O)$gk[]="(".implode(", ",$O).")";return
queries("REPLACE INTO ".table($R)." (".implode(", ",array_keys(reset($L))).") VALUES\n".implode(",\n",$gk));}function
tableHelp($B,$Ge=false){if($B=="sqlite_sequence")return"fileformat2.html#seqtab";if(preg_match('~^sqlite(_temp)?_(master|schema)$~',$B))return"schematab.html";}function
checkConstraints($R){preg_match_all('~ CHECK *(\( *(((?>[^()]*[^() ])|(?1))*) *\))~',get_val("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ".q($R),0,$this->conn),$pf);return
array_combine($pf[2],$pf[2]);}function
allFields(){$J=array();foreach(tables_list()as$R=>$U){foreach(fields($R)as$n)$J[$R][]=$n;}return$J;}}function
idf_escape($u){return'"'.str_replace('"','""',$u).'"';}function
table($u){return
idf_escape($u);}function
get_databases($qd){return
array();}function
limit($H,$Z,$z,$C=0,$li=" "){return" $H$Z".($z?$li."LIMIT $z".($C?" OFFSET $C":""):"");}function
limit1($R,$H,$Z,$li="\n"){return(preg_match('~^INTO~',$H)||get_val("SELECT sqlite_compileoption_used('ENABLE_UPDATE_DELETE_LIMIT')")?limit($H,$Z,1,0,$li):" $H WHERE rowid = (SELECT rowid FROM ".table($R).$Z.$li."LIMIT 1)");}function
db_collation($k,$nb){return
get_val("PRAGMA encoding");}function
logged_user(){return
get_current_user();}function
tables_list(){return
get_key_vals("SELECT name, type FROM sqlite_master WHERE type IN ('table', 'view') ORDER BY (name = 'sqlite_sequence'), name");}function
count_tables($j){return
array();}function
table_status($B="",$Zc=false){$J=array();foreach(get_rows("SELECT name AS Name, type AS Engine, sql, 'rowid' AS Oid, '' AS Auto_increment FROM sqlite_master WHERE type IN ('table', 'view') ".($B!=""?"AND name = ".q($B):"ORDER BY (name = 'sqlite_sequence'), name"))as$K){if($K["Engine"]=="table"){$Ni=preg_replace('~.*\)~s','',$K["sql"]);$K["Engine"]=implode(", ",array_filter(array((preg_match('~\bSTRICT\b~i',$Ni)?"STRICT":0),(preg_match('~\bWITHOUT\s+ROWID\b~i',$Ni)?"WITHOUT ROWID":0),)))?:"table";}unset($K["sql"]);if(!$Zc)$K["Rows"]=get_val("SELECT COUNT(*) FROM ".idf_escape($K["Name"]));$J[$K["Name"]]=$K;}if(!$Zc){foreach(get_rows("SELECT * FROM sqlite_sequence".($B!=""?" WHERE name = ".q($B):""),null,"")as$K)$J[$K["name"]]["Auto_increment"]=$K["seq"];}return$J;}function
is_view($S){return$S["Engine"]=="view";}function
fk_support($S){return!get_val("SELECT sqlite_compileoption_used('OMIT_FOREIGN_KEY')");}function
fields($R){$J=array();$Bi=get_val("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ".q($R));$uh=array("select"=>1,"where"=>1,"order"=>1);if(!preg_match('~^sqlite(_temp)?_(master|schema)$~',$R))$uh+=array("insert"=>1,"update"=>1);foreach(get_rows("PRAGMA table_".(min_version(3.31)?"x":"")."info(".table($R).")")as$K){$B=$K["name"];$U=strtolower($K["type"]);$l=$K["dflt_value"];$J[$B]=array("field"=>$B,"type"=>(preg_match('~int~i',$U)?"integer":(preg_match('~char|clob|text~i',$U)?"text":(preg_match('~blob~i',$U)?"blob":(preg_match('~real|floa|doub~i',$U)?"real":(preg_match('~any~i',$U)?"any":"numeric"))))),"full_type"=>$U,"default"=>(preg_match("~^'(.*)'$~",$l,$A)?str_replace("''","'",$A[1]):($l=="NULL"?null:$l)),"null"=>!$K["notnull"],"privileges"=>$uh,"primary"=>$K["pk"],);if($K["pk"]&&preg_match('~\bAUTOINCREMENT\b~i',$Bi))$J[$B]["auto_increment"]=true;}$u='(("[^"]*+")+|[a-z0-9_]+)';preg_match_all('~'.$u.'\s+text\s+COLLATE\s+(\'[^\']+\'|\S+)~i',$Bi,$pf,PREG_SET_ORDER);foreach($pf
as$A){$B=str_replace('""','"',preg_replace('~^"|"$~','',$A[1]));if($J[$B])$J[$B]["collation"]=trim($A[3],"'");}preg_match_all('~'.$u.'\s.*GENERATED ALWAYS AS \((.+)\) (STORED|VIRTUAL)~i',$Bi,$pf,PREG_SET_ORDER);foreach($pf
as$A){$B=str_replace('""','"',preg_replace('~^"|"$~','',$A[1]));$J[$B]["default"]=$A[3];$J[$B]["generated"]=strtoupper($A[4]);}return$J;}function
indexes($R,$h=null){$h=connection($h);$J=array();$Bi=get_val("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ".q($R),0,$h);if(preg_match('~\bPRIMARY\s+KEY\s*\((([^)"]+|"[^"]*"|`[^`]*`)++)~i',$Bi,$A)){$J[""]=array("type"=>"PRIMARY","columns"=>array(),"lengths"=>array(),"descs"=>array());preg_match_all('~((("[^"]*+")+|(?:`[^`]*+`)+)|(\S+))(\s+(ASC|DESC))?(,\s*|$)~i',$A[1],$pf,PREG_SET_ORDER);foreach($pf
as$A){$J[""]["columns"][]=idf_unescape($A[2]).$A[4];$J[""]["descs"][]=(preg_match('~DESC~i',$A[5])?'1':null);}}if(!$J){foreach(fields($R)as$B=>$n){if($n["primary"])$J[""]=array("type"=>"PRIMARY","columns"=>array($B),"lengths"=>array(),"descs"=>array(null));}}$Fi=get_key_vals("SELECT name, sql FROM sqlite_master WHERE type = 'index' AND tbl_name = ".q($R),$h);foreach(get_rows("PRAGMA index_list(".table($R).")",$h)as$K){$B=$K["name"];$v=array("type"=>($K["unique"]?"UNIQUE":"INDEX"));$v["lengths"]=array();$v["descs"]=array();foreach(get_rows("PRAGMA index_info(".idf_escape($B).")",$h)as$Wh){$v["columns"][]=$Wh["name"];$v["descs"][]=null;}if(preg_match('~^CREATE( UNIQUE)? INDEX '.preg_quote(idf_escape($B).' ON '.idf_escape($R),'~').' \((.*)\)$~i',$Fi[$B],$Jh)){preg_match_all('/("[^"]*+")+( DESC)?/',$Jh[2],$pf);foreach($pf[2]as$x=>$X){if($X)$v["descs"][$x]='1';}}if(!$J[""]||$v["type"]!="UNIQUE"||$v["columns"]!=$J[""]["columns"]||$v["descs"]!=$J[""]["descs"]||!preg_match("~^sqlite_~",$B))$J[$B]=$v;}return$J;}function
foreign_keys($R){$J=array();foreach(get_rows("PRAGMA foreign_key_list(".table($R).")")as$K){$p=&$J[$K["id"]];if(!$p)$p=$K;$p["source"][]=$K["from"];$p["target"][]=$K["to"];}return$J;}function
view($B){return
array("select"=>preg_replace('~^(?:[^`"[]+|`[^`]*`|"[^"]*")* AS\s+~iU','',get_val("SELECT sql FROM sqlite_master WHERE type = 'view' AND name = ".q($B))));}function
collations(){return(isset($_GET["create"])?get_vals("PRAGMA collation_list",1):array());}function
information_schema($k){return
false;}function
error(){return
h(connection()->error);}function
check_sqlite_name($B){$Vc="db|sdb|sqlite";if(!preg_match("~^[^\\0]*\\.($Vc)\$~",$B)){connection()->error=lang(25,str_replace("|",", ",$Vc));return
false;}return
true;}function
create_database($k,$c){if(file_exists($k)){connection()->error=lang(26);return
false;}if(!check_sqlite_name($k))return
false;try{$_=new
Db();$_->attach($k,'','');}catch(\Exception$Nc){connection()->error=$Nc->getMessage();return
false;}$_->query('PRAGMA encoding = "UTF-8"');$_->query('CREATE TABLE adminer (i)');$_->query('DROP TABLE adminer');return
true;}function
drop_databases($j){connection()->attach(":memory:",'','');foreach($j
as$k){if(!check_sqlite_name($k))return
false;if(!@unlink($k)){connection()->error=lang(26);return
false;}}return
true;}function
rename_database($B,$c){if(!check_sqlite_name($B))return
false;connection()->attach(":memory:",'','');connection()->error=lang(26);return@rename(DB,$B);}function
auto_increment(){return" PRIMARY KEY AUTOINCREMENT";}function
alter_table($R,$B,$o,$sd,$sb,$Cc,$c,$Da,$E){$Xj=($R==""||$sd||$Cc);foreach($o
as$n){if($n[0]!=""||!$n[1]||$n[2]){$Xj=true;break;}}$b=array();$Ig=array();foreach($o
as$n){if($n[1]){$b[]=($Xj?$n[1]:"ADD ".implode($n[1]));if($n[0]!="")$Ig[$n[0]]=$n[1][0];}}if(!$Xj){foreach($b
as$X){if(!queries("ALTER TABLE ".table($R)." $X"))return
false;}if($R!=$B&&!queries("ALTER TABLE ".table($R)." RENAME TO ".table($B)))return
false;}elseif(!recreate_table($R,$B,$b,$Ig,$sd,$Da,array(),"","",$Cc))return
false;if($Da){queries("BEGIN");queries("UPDATE sqlite_sequence SET seq = $Da WHERE name = ".q($B));if(!connection()->affected_rows)queries("INSERT INTO sqlite_sequence (name, seq) VALUES (".q($B).", $Da)");queries("COMMIT");}return
true;}function
recreate_table($R,$B,array$o,array$Ig,array$sd,$Da="",$w=array(),$qc="",$ma="",$Cc=""){if($R!=""){if(!$o){foreach(fields($R)as$x=>$n){if($w)$n["auto_increment"]=0;$o[]=process_field($n,$n);$Ig[$x]=idf_escape($x);}}$qh=false;foreach($o
as$n){if($n[6])$qh=true;}$sc=array();foreach($w
as$x=>$X){if($X[2]=="DROP"){$sc[$X[1]]=true;unset($w[$x]);}}foreach(indexes($R)as$Le=>$v){$e=array();foreach($v["columns"]as$x=>$d){if(!$Ig[$d])continue
2;$e[]=$Ig[$d].($v["descs"][$x]?" DESC":"");}if(!$sc[$Le]){if($v["type"]!="PRIMARY"||!$qh)$w[]=array($v["type"],$Le,$e);}}foreach($w
as$x=>$X){if($X[0]=="PRIMARY"){unset($w[$x]);$sd[]="  PRIMARY KEY (".implode(", ",$X[2]).")";}}foreach(foreign_keys($R)as$Le=>$p){foreach($p["source"]as$x=>$d){if(!$Ig[$d])continue
2;$p["source"][$x]=idf_unescape($Ig[$d]);}if(!isset($sd[" $Le"]))$sd[]=" ".format_foreign_key($p);}queries("BEGIN");}$Za=array();foreach($o
as$n){if(preg_match('~GENERATED~',$n[3]))unset($Ig[array_search($n[0],$Ig)]);$Za[]="  ".implode($n);}$Za=array_merge($Za,array_filter($sd));foreach(driver()->checkConstraints($R)as$bb){if($bb!=$qc)$Za[]="  CHECK ($bb)";}if($ma)$Za[]="  CHECK ($ma)";$gj=($R!=""&&$R==$B?"adminer_$B":$B);if(!$Cc&&$R!="")$Cc=idx(table_status1($R),"Engine");if(!queries("CREATE TABLE ".table($gj)." (\n".implode(",\n",$Za)."\n)".($Cc!="table"&&in_array($Cc,driver()->engines())?" $Cc":"")))return
false;if($R!=""){if($Ig&&!queries("INSERT INTO ".table($gj)." (".implode(", ",$Ig).") SELECT ".implode(", ",array_map('Adminer\idf_escape',array_keys($Ig)))." FROM ".table($R)))return
false;$Fj=array();foreach(triggers($R)as$Dj=>$nj){$Cj=trigger($Dj,$R);$Fj[]="CREATE TRIGGER ".idf_escape($Dj)." ".implode(" ",$nj)." ON ".table($B)."\n$Cj[Statement]";}$Da=$Da?"":get_val("SELECT seq FROM sqlite_sequence WHERE name = ".q($R));if(!queries("DROP TABLE ".table($R))||($R==$B&&!queries("ALTER TABLE ".table($gj)." RENAME TO ".table($B)))||!alter_indexes($B,$w))return
false;if($Da)queries("UPDATE sqlite_sequence SET seq = $Da WHERE name = ".q($B));foreach($Fj
as$Cj){if(!queries($Cj))return
false;}queries("COMMIT");}return
true;}function
index_sql($R,$U,$B,$e){return"CREATE $U ".($U!="INDEX"?"INDEX ":"").idf_escape($B!=""?$B:uniqid($R."_"))." ON ".table($R)." $e";}function
alter_indexes($R,$b){foreach($b
as$ph){if($ph[0]=="PRIMARY")return
recreate_table($R,$R,array(),array(),array(),"",$b);}foreach(array_reverse($b)as$X){if(!queries($X[2]=="DROP"?"DROP INDEX ".idf_escape($X[1]):index_sql($R,$X[0],$X[1],"(".implode(", ",$X[2]).")")))return
false;}return
true;}function
truncate_tables($T){return
apply_queries("DELETE FROM",$T);}function
drop_views($lk){return
apply_queries("DROP VIEW",$lk);}function
drop_tables($T){return
apply_queries("DROP TABLE",$T);}function
move_tables($T,$lk,$ej){return
false;}function
trigger($B,$R){if($B=="")return
array("Statement"=>"BEGIN\n\t;\nEND");$u='(?:[^`"\s]+|`[^`]*`|"[^"]*")+';$Ej=trigger_options();preg_match("~^CREATE\\s+TRIGGER\\s*$u\\s*(".implode("|",$Ej["Timing"]).")\\s+([a-z]+)(?:\\s+OF\\s+($u))?\\s+ON\\s*$u\\s*(?:FOR\\s+EACH\\s+ROW\\s)?(.*)~is",get_val("SELECT sql FROM sqlite_master WHERE type = 'trigger' AND name = ".q($B)),$A);$gg=$A[3];return
array("Timing"=>strtoupper($A[1]),"Event"=>strtoupper($A[2]).($gg?" OF":""),"Of"=>idf_unescape($gg),"Trigger"=>$B,"Statement"=>$A[4],);}function
triggers($R){$J=array();$Ej=trigger_options();foreach(get_rows("SELECT * FROM sqlite_master WHERE type = 'trigger' AND tbl_name = ".q($R))as$K){preg_match('~^CREATE\s+TRIGGER\s*(?:[^`"\s]+|`[^`]*`|"[^"]*")+\s*('.implode("|",$Ej["Timing"]).')\s*(.*?)\s+ON\b~i',$K["sql"],$A);$J[$K["name"]]=array($A[1],$A[2]);}return$J;}function
trigger_options(){return
array("Timing"=>array("BEFORE","AFTER","INSTEAD OF"),"Event"=>array("INSERT","UPDATE","UPDATE OF","DELETE"),"Type"=>array("FOR EACH ROW"),);}function
begin(){return
queries("BEGIN");}function
last_id($I){return
get_val("SELECT LAST_INSERT_ROWID()");}function
explain($g,$H){return$g->query("EXPLAIN QUERY PLAN $H");}function
found_rows($S,$Z){}function
types(){return
array();}function
create_sql($R,$Da,$Li){$J=get_val("SELECT sql FROM sqlite_master WHERE type IN ('table', 'view') AND name = ".q($R));foreach(indexes($R)as$B=>$v){if($B=='')continue;$J
.=";\n\n".index_sql($R,$v['type'],$B,"(".implode(", ",array_map('Adminer\idf_escape',$v['columns'])).")");}return$J;}function
truncate_sql($R){return"DELETE FROM ".table($R);}function
use_sql($Rb,$Li=""){}function
trigger_sql($R){return
implode(get_vals("SELECT sql || ';;\n' FROM sqlite_master WHERE type = 'trigger' AND tbl_name = ".q($R)));}function
show_variables(){$J=array();foreach(get_rows("PRAGMA pragma_list")as$K){$B=$K["name"];if($B!="pragma_list"&&$B!="compile_options"){$J[$B]=array($B,'');foreach(get_rows("PRAGMA $B")as$K)$J[$B][1].=implode(", ",$K)."\n";}}return$J;}function
show_status(){$J=array();foreach(get_vals("PRAGMA compile_options")as$vg)$J[]=explode("=",$vg,2)+array('','');return$J;}function
convert_field($n){}function
unconvert_field($n,$J){return$J;}function
support($ad){return
preg_match('~^(check|columns|database|drop_col|dump|indexes|descidx|move_col|sql|status|table|trigger|variables|view|view_trigger)$~',$ad);}}add_driver("pgsql","PostgreSQL");if(isset($_GET["pgsql"])){define('Adminer\DRIVER',"pgsql");if(extension_loaded("pgsql")&&$_GET["ext"]!="pdo"){class
PgsqlDb
extends
SqlDb{var$extension="PgSQL";var$timeout=0;private$link,$string,$database=true;function
_error($Ic,$m){if(ini_bool("html_errors"))$m=html_entity_decode(strip_tags($m));$m=preg_replace('~^[^:]*: ~','',$m);$this->error=$m;}function
attach($N,$V,$F){$k=adminer()->database();set_error_handler(array($this,'_error'));list($Vd,$hh)=host_port($N);$this->string="host='$Vd'".($hh?" port=$hh":"")." user='".addcslashes($V,"'\\")."' password='".addcslashes($F,"'\\")."'";$Gi=adminer()->connectSsl();if(isset($Gi["mode"]))$this->string
.=" sslmode=$Gi[mode]";$this->link=@pg_connect("$this->string dbname='".($k!=""?addcslashes($k,"'\\"):"postgres")."'",PGSQL_CONNECT_FORCE_NEW);if(!$this->link&&$k!=""){$this->database=false;$this->link=@pg_connect("$this->string dbname='postgres'",PGSQL_CONNECT_FORCE_NEW);}restore_error_handler();if($this->link)pg_set_client_encoding($this->link,"UTF8");return($this->link?'':$this->error);}function
quote($Q){return(function_exists('pg_escape_literal')?pg_escape_literal($this->link,$Q):"'".pg_escape_string($this->link,$Q)."'");}function
value($X,array$n){return($n["type"]=="bytea"&&$X!==null?pg_unescape_bytea($X):$X);}function
select_db($Rb){if($Rb==adminer()->database())return$this->database;$J=@pg_connect("$this->string dbname='".addcslashes($Rb,"'\\")."'",PGSQL_CONNECT_FORCE_NEW);if($J)$this->link=$J;return$J;}function
close(){$this->link=@pg_connect("$this->string dbname='postgres'");}function
query($H,$Jj=false){$I=@pg_query($this->link,$H);$this->error="";if(!$I){$this->error=pg_last_error($this->link);$J=false;}elseif(!pg_num_fields($I)){$this->affected_rows=pg_affected_rows($I);$J=true;}else$J=new
Result($I);if($this->timeout){$this->timeout=0;$this->query("RESET statement_timeout");}return$J;}function
warnings(){if(PHP_VERSION_ID>=70100){$J=implode("\n",pg_last_notice($this->link,2));pg_last_notice($this->link,3);}else$J=pg_last_notice($this->link);return
nl_br(h($J));}function
copyFrom($R,array$L){$this->error='';set_error_handler(function($Ic,$m){$this->error=(ini_bool('html_errors')?html_entity_decode($m):$m);return
true;});$J=pg_copy_from($this->link,$R,$L);restore_error_handler();return$J;}}class
Result{var$num_rows;private$result,$offset=0;function
__construct($I){$this->result=$I;$this->num_rows=pg_num_rows($I);}function
fetch_assoc(){return
pg_fetch_assoc($this->result);}function
fetch_row(){return
pg_fetch_row($this->result);}function
fetch_field(){$d=$this->offset++;$J=new
\stdClass;$J->orgtable=pg_field_table($this->result,$d);$J->name=pg_field_name($this->result,$d);$U=pg_field_type($this->result,$d);$J->type=(preg_match(number_type(),$U)?0:15);$J->charsetnr=($U=="bytea"?63:0);return$J;}}}elseif(extension_loaded("pdo_pgsql")){class
PgsqlDb
extends
PdoDb{var$extension="PDO_PgSQL";var$timeout=0;function
attach($N,$V,$F){$k=adminer()->database();list($Vd,$hh)=host_port($N);$uc="pgsql:host='$Vd'".($hh?" port=$hh":"")." client_encoding=utf8 dbname='".($k!=""?addcslashes($k,"'\\"):"postgres")."'";$Gi=adminer()->connectSsl();if(isset($Gi["mode"]))$uc
.=" sslmode=$Gi[mode]";return$this->dsn($uc,$V,$F);}function
select_db($Rb){return(adminer()->database()==$Rb);}function
query($H,$Jj=false){$J=parent::query($H,$Jj);if($this->timeout){$this->timeout=0;parent::query("RESET statement_timeout");}return$J;}function
warnings(){}function
copyFrom($R,array$L){$J=$this->pdo->pgsqlCopyFromArray($R,$L);$this->error=idx($this->pdo->errorInfo(),2)?:'';return$J;}function
close(){}}}if(class_exists('Adminer\PgsqlDb')){class
Db
extends
PgsqlDb{function
multi_query($H){if(preg_match('~\bCOPY\s+(.+?)\s+FROM\s+stdin;\n?(.*)\n\\\\\.$~is',str_replace("\r\n","\n",$H),$A)){$L=explode("\n",$A[2]);$this->affected_rows=count($L);return$this->copyFrom($A[1],$L);}return
parent::multi_query($H);}}}class
Driver
extends
SqlDriver{static$extensions=array("PgSQL","PDO_PgSQL");static$jush="pgsql";var$operators=array("=","<",">","<=",">=","!=","~","~*","!~","LIKE","LIKE %%","ILIKE","ILIKE %%","IN","IS NULL","NOT LIKE","NOT ILIKE","NOT IN","IS NOT NULL","SQL");var$functions=array("char_length","lower","round","to_hex","to_timestamp","upper");var$grouping=array("avg","count","count distinct","max","min","sum");var$nsOid="(SELECT oid FROM pg_namespace WHERE nspname = current_schema())";static
function
connect($N,$V,$F){$g=parent::connect($N,$V,$F);if(is_string($g))return$g;$jk=get_val("SELECT version()",0,$g);$g->flavor=(preg_match('~CockroachDB~',$jk)?'cockroach':'');$g->server_info=preg_replace('~^\D*([\d.]+[-\w]*).*~','\1',$jk);if(min_version(9,0,$g))$g->query("SET application_name = 'Adminer'");if($g->flavor=='cockroach')add_driver(DRIVER,"CockroachDB");return$g;}function
__construct(Db$g){parent::__construct($g);$this->types=array(lang(27)=>array("smallint"=>5,"integer"=>10,"bigint"=>19,"boolean"=>1,"numeric"=>0,"real"=>7,"double precision"=>16,"money"=>20),lang(28)=>array("date"=>13,"time"=>17,"timestamp"=>20,"timestamptz"=>21,"interval"=>0),lang(29)=>array("character"=>0,"character varying"=>0,"text"=>0,"tsquery"=>0,"tsvector"=>0,"uuid"=>0,"xml"=>0),lang(30)=>array("bit"=>0,"bit varying"=>0,"bytea"=>0),lang(31)=>array("cidr"=>43,"inet"=>43,"macaddr"=>17,"macaddr8"=>23,"txid_snapshot"=>0),lang(32)=>array("box"=>0,"circle"=>0,"line"=>0,"lseg"=>0,"path"=>0,"point"=>0,"polygon"=>0),);if(min_version(9.2,0,$g)){$this->types[lang(29)]["json"]=4294967295;if(min_version(9.4,0,$g))$this->types[lang(29)]["jsonb"]=4294967295;}$this->insertFunctions=array("char"=>"md5","date|time"=>"now",);$this->editFunctions=array(number_type()=>"+/-","date|time"=>"+ interval/- interval","char|text"=>"||",);if(min_version(12,0,$g)){$this->generated[]="STORED";if(min_version(18,0,$g))$this->generated[]="VIRTUAL";}$this->partitionBy=array("RANGE","LIST");if(!$g->flavor)$this->partitionBy[]="HASH";}function
enumLength(array$n){$Ec=$this->types[lang(6)][$n["type"]];return($Ec?type_values($Ec):"");}function
setUserTypes($Ij){$this->types[lang(6)]=array_flip($Ij);}function
insertReturning($R){$Da=array_filter(fields($R),function($n){return$n['auto_increment'];});return(count($Da)==1?" RETURNING ".idf_escape(key($Da)):"");}function
insertUpdate($R,array$L,array$ph){foreach($L
as$O){$Rj=array();$Z=array();foreach($O
as$x=>$X){$Rj[]="$x = $X";if(isset($ph[idf_unescape($x)]))$Z[]="$x = $X";}if(!(($Z&&queries("UPDATE ".table($R)." SET ".implode(", ",$Rj)." WHERE ".implode(" AND ",$Z))&&$this->conn->affected_rows)||queries("INSERT INTO ".table($R)." (".implode(", ",array_keys($O)).") VALUES (".implode(", ",$O).")")))return
false;}return
true;}function
slowQuery($H,$mj){$this->conn->query("SET statement_timeout = ".(1000*$mj));$this->conn->timeout=1000*$mj;return$H;}function
convertSearch($u,array$X,array$n){$jj="char|text";if(strpos($X["op"],"LIKE")===false)$jj
.="|date|time(stamp)?|boolean|uuid|inet|cidr|macaddr|".number_type();return(preg_match("~$jj~",$n["type"])?$u:"CAST($u AS text)");}function
quoteBinary($Xh){return"'\\x".bin2hex($Xh)."'";}function
warnings(){return$this->conn->warnings();}function
tableHelp($B,$Ge=false){$ef=array("information_schema"=>"infoschema","pg_catalog"=>($Ge?"view":"catalog"),);$_=$ef[$_GET["ns"]];if($_)return"$_-".str_replace("_","-",$B).".html";}function
inheritsFrom($R){return
get_rows("SELECT relname AS table, nspname AS ns FROM pg_class JOIN pg_inherits ON inhparent = oid JOIN pg_namespace ON relnamespace = pg_namespace.oid WHERE inhrelid = ".$this->tableOid($R)." ORDER BY 2, 1");}function
inheritedTables($R){return
get_rows("SELECT relname AS table, nspname AS ns FROM pg_inherits JOIN pg_class ON inhrelid = oid JOIN pg_namespace ON relnamespace = pg_namespace.oid WHERE inhparent = ".$this->tableOid($R)." ORDER BY 2, 1");}function
partitionsInfo($R){$K=(min_version(10)?$this->conn->query("SELECT * FROM pg_partitioned_table WHERE partrelid = ".$this->tableOid($R))->fetch_assoc():null);if($K){$Ba=get_vals("SELECT attname FROM pg_attribute WHERE attrelid = $K[partrelid] AND attnum IN (".str_replace(" ",", ",$K["partattrs"]).")");$Ta=array('h'=>'HASH','l'=>'LIST','r'=>'RANGE');return
array("partition_by"=>$Ta[$K["partstrat"]],"partition"=>implode(", ",array_map('Adminer\idf_escape',$Ba)),);}return
array();}function
tableOid($R){return"(SELECT oid FROM pg_class WHERE relnamespace = $this->nsOid AND relname = ".q($R)." AND relkind IN ('r', 'm', 'v', 'f', 'p'))";}function
indexAlgorithms(array$Ti){static$J=array();if(!$J)$J=get_vals("SELECT amname FROM pg_am".(min_version(9.6)?" WHERE amtype = 'i'":"")." ORDER BY amname = '".($this->conn->flavor=='cockroach'?"prefix":"btree")."' DESC, amname");return$J;}function
supportsIndex(array$S){return$S["Engine"]!="view";}function
hasCStyleEscapes(){static$Va;if($Va===null)$Va=(get_val("SHOW standard_conforming_strings",0,$this->conn)=="off");return$Va;}}function
idf_escape($u){return'"'.str_replace('"','""',$u).'"';}function
table($u){return
idf_escape($u);}function
get_databases($qd){return
get_vals("SELECT datname FROM pg_database
WHERE datallowconn = TRUE AND has_database_privilege(datname, 'CONNECT')
ORDER BY datname");}function
limit($H,$Z,$z,$C=0,$li=" "){return" $H$Z".($z?$li."LIMIT $z".($C?" OFFSET $C":""):"");}function
limit1($R,$H,$Z,$li="\n"){return(preg_match('~^INTO~',$H)?limit($H,$Z,1,0,$li):" $H".(is_view(table_status1($R))?$Z:$li."WHERE ctid = (SELECT ctid FROM ".table($R).$Z.$li."LIMIT 1)"));}function
db_collation($k,$nb){return
get_val("SELECT datcollate FROM pg_database WHERE datname = ".q($k));}function
logged_user(){return
get_val("SELECT user");}function
tables_list(){$H="SELECT table_name, table_type FROM information_schema.tables WHERE table_schema = current_schema()";if(support("materializedview"))$H
.="
UNION ALL
SELECT matviewname, 'MATERIALIZED VIEW'
FROM pg_matviews
WHERE schemaname = current_schema()";$H
.="
ORDER BY 1";return
get_key_vals($H);}function
count_tables($j){$J=array();foreach($j
as$k){if(connection()->select_db($k))$J[$k]=count(tables_list());}return$J;}function
table_status($B=""){static$Od;if($Od===null)$Od=get_val("SELECT 'pg_table_size'::regproc");$J=array();foreach(get_rows("SELECT
	relname AS \"Name\",
	CASE relkind WHEN 'v' THEN 'view' WHEN 'm' THEN 'materialized view' ELSE 'table' END AS \"Engine\"".($Od?",
	pg_table_size(c.oid) AS \"Data_length\",
	pg_indexes_size(c.oid) AS \"Index_length\"":"").",
	obj_description(c.oid, 'pg_class') AS \"Comment\",
	".(min_version(12)?"''":"CASE WHEN relhasoids THEN 'oid' ELSE '' END")." AS \"Oid\",
	reltuples AS \"Rows\",
	".(min_version(10)?"relispartition::int AS partition,":"")."
	current_schema() AS nspname
FROM pg_class c
WHERE relkind IN ('r', 'm', 'v', 'f', 'p')
AND relnamespace = ".driver()->nsOid."
".($B!=""?"AND relname = ".q($B):"ORDER BY relname"))as$K)$J[$K["Name"]]=$K;return$J;}function
is_view($S){return
in_array($S["Engine"],array("view","materialized view"));}function
fk_support($S){return
true;}function
fields($R){$J=array();$ua=array('timestamp without time zone'=>'timestamp','timestamp with time zone'=>'timestamptz',);foreach(get_rows("SELECT
	a.attname AS field,
	format_type(a.atttypid, a.atttypmod) AS full_type,
	pg_get_expr(d.adbin, d.adrelid) AS default,
	a.attnotnull::int,
	i.indrelid AS primary,
	col_description(a.attrelid, a.attnum) AS comment".(min_version(10)?",
	a.attidentity".(min_version(12)?",
	a.attgenerated":""):"")."
FROM pg_attribute a
LEFT JOIN pg_attrdef d ON a.attrelid = d.adrelid AND a.attnum = d.adnum
LEFT JOIN pg_index i ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey) AND i.indisprimary
WHERE a.attrelid = ".driver()->tableOid($R)."
AND NOT a.attisdropped
AND a.attnum > 0
ORDER BY a.attnum")as$K){preg_match('~([^([]+)(\((.*)\))?([a-z ]+)?((\[[0-9]*])*)$~',$K["full_type"],$A);list(,$U,$y,$K["length"],$na,$za)=$A;$K["length"].=$za;$db=$U.$na;if(isset($ua[$db])){$K["type"]=$ua[$db];$K["full_type"]=$K["type"].$y.$za;}else{$K["type"]=$U;$K["full_type"]=$K["type"].$y.$na.$za;}if(in_array($K['attidentity'],array('a','d')))$K['default']='GENERATED '.($K['attidentity']=='d'?'BY DEFAULT':'ALWAYS').' AS IDENTITY';$K["generated"]=idx(array("s"=>"STORED","v"=>"VIRTUAL"),$K["attgenerated"],"");$K["null"]=!$K["attnotnull"];$K["auto_increment"]=$K['attidentity']||preg_match('~^nextval\(~i',$K["default"])||preg_match('~^unique_rowid\(~',$K["default"]);$K["privileges"]=array("insert"=>1,"select"=>1,"update"=>1,"where"=>1,"order"=>1);if(!$K['generated']&&preg_match('~(.+)::[^,)]+(.*)~',$K["default"],$A))$K["default"]=($A[1]=="NULL"?null:idf_unescape($A[1]).$A[2]);$J[$K["field"]]=$K;}return$J;}function
indexes($R,$h=null){$h=connection($h);$J=array();$Wi=driver()->tableOid($R);$e=get_key_vals("SELECT attnum, attname FROM pg_attribute WHERE attrelid = $Wi AND attnum > 0",$h);foreach(get_rows("SELECT relname, indisunique::int, indisprimary::int, indkey, indoption, amname, pg_get_expr(indpred, indrelid, true) AS partial, pg_get_expr(indexprs, indrelid) AS indexpr
FROM pg_index
JOIN pg_class ON indexrelid = oid
JOIN pg_am ON pg_am.oid = pg_class.relam
WHERE indrelid = $Wi
ORDER BY indisprimary DESC, indisunique DESC",$h)as$K){$Kh=$K["relname"];$J[$Kh]["type"]=($K["indisprimary"]?"PRIMARY":($K["indisunique"]?"UNIQUE":"INDEX"));$J[$Kh]["columns"]=array();$J[$Kh]["descs"]=array();$J[$Kh]["algorithm"]=$K["amname"];$J[$Kh]["partial"]=$K["partial"];$ne=preg_split('~(?<=\)), (?=\()~',$K["indexpr"]);foreach(explode(" ",$K["indkey"])as$oe)$J[$Kh]["columns"][]=($oe?$e[$oe]:array_shift($ne));foreach(explode(" ",$K["indoption"])as$pe)$J[$Kh]["descs"][]=(intval($pe)&1?'1':null);$J[$Kh]["lengths"]=array();}return$J;}function
foreign_keys($R){$J=array();foreach(get_rows("SELECT conname, condeferrable::int AS deferrable, condeferred::int AS deferred, pg_get_constraintdef(oid) AS definition
FROM pg_constraint
WHERE conrelid = ".driver()->tableOid($R)."
AND contype = 'f'::char
ORDER BY conkey, conname")as$K){$K['deferrable']=($K['deferrable']?'':'NOT ').'DEFERRABLE'.($K['deferred']?' INITIALLY DEFERRED':'');if(preg_match('~FOREIGN KEY\s*\((.+)\)\s*REFERENCES (.+)\((.+)\)(.*)$~iA',$K['definition'],$A)){$K['source']=array_map('Adminer\idf_unescape',array_map('trim',explode(',',$A[1])));if(preg_match('~^(("([^"]|"")+"|[^"]+)\.)?"?("([^"]|"")+"|[^"]+)$~',$A[2],$nf)){$K['ns']=idf_unescape($nf[2]);$K['table']=idf_unescape($nf[4]);}$K['target']=array_map('Adminer\idf_unescape',array_map('trim',explode(',',$A[3])));$K['on_delete']=(preg_match("~ON DELETE (".driver()->onActions.")~",$A[4],$nf)?$nf[1]:'NO ACTION');$K['on_update']=(preg_match("~ON UPDATE (".driver()->onActions.")~",$A[4],$nf)?$nf[1]:'NO ACTION');$J[$K['conname']]=$K;}}return$J;}function
view($B){return
array("select"=>trim(get_val("SELECT pg_get_viewdef(".driver()->tableOid($B).")")));}function
collations(){return
array();}function
information_schema($k){return
get_schema()=="information_schema";}function
error(){$J=h(connection()->error);if(preg_match('~^(.*\n)?([^\n]*)\n( *)\^(\n.*)?$~s',$J,$A))$J=$A[1].preg_replace('~((?:[^&]|&[^;]*;){'.strlen($A[3]).'})(.*)~','\1<b>\2</b>',$A[2]).$A[4];return
nl_br($J);}function
create_database($k,$c){return
queries("CREATE DATABASE ".idf_escape($k).($c?" ENCODING ".idf_escape($c):""));}function
drop_databases($j){connection()->close();return
apply_queries("DROP DATABASE",$j,'Adminer\idf_escape');}function
rename_database($B,$c){connection()->close();return
queries("ALTER DATABASE ".idf_escape(DB)." RENAME TO ".idf_escape($B));}function
auto_increment(){return"";}function
alter_table($R,$B,$o,$sd,$sb,$Cc,$c,$Da,$E){$b=array();$yh=array();if($R!=""&&$R!=$B)$yh[]="ALTER TABLE ".table($R)." RENAME TO ".table($B);$mi="";foreach($o
as$n){$d=idf_escape($n[0]);$X=$n[1];if(!$X)$b[]="DROP $d";else{$ek=$X[5];unset($X[5]);if($n[0]==""){if(isset($X[6]))$X[1]=($X[1]==" bigint"?" big":($X[1]==" smallint"?" small":" "))."serial";$b[]=($R!=""?"ADD ":"  ").implode($X);if(isset($X[6]))$b[]=($R!=""?"ADD":" ")." PRIMARY KEY ($X[0])";}else{if($d!=$X[0])$yh[]="ALTER TABLE ".table($B)." RENAME $d TO $X[0]";$b[]="ALTER $d TYPE$X[1]";$ni=$R."_".idf_unescape($X[0])."_seq";$b[]="ALTER $d ".($X[3]?"SET".preg_replace('~GENERATED ALWAYS(.*) (STORED|VIRTUAL)~','EXPRESSION\1',$X[3]):(isset($X[6])?"SET DEFAULT nextval(".q($ni).")":"DROP DEFAULT"));if(isset($X[6]))$mi="CREATE SEQUENCE IF NOT EXISTS ".idf_escape($ni)." OWNED BY ".idf_escape($R).".$X[0]";$b[]="ALTER $d ".($X[2]==" NULL"?"DROP NOT":"SET").$X[2];}if($n[0]!=""||$ek!="")$yh[]="COMMENT ON COLUMN ".table($B).".$X[0] IS ".($ek!=""?substr($ek,9):"''");}}$b=array_merge($b,$sd);if($R==""){$P="";if($E){$jb=(connection()->flavor=='cockroach');$P=" PARTITION BY $E[partition_by]($E[partition])";if($E["partition_by"]=='HASH'){$Xg=+$E["partitions"];for($s=0;$s<$Xg;$s++)$yh[]="CREATE TABLE ".idf_escape($B."_$s")." PARTITION OF ".idf_escape($B)." FOR VALUES WITH (MODULUS $Xg, REMAINDER $s)";}else{$oh="MINVALUE";foreach($E["partition_names"]as$s=>$X){$Y=$E["partition_values"][$s];$Tg=" VALUES ".($E["partition_by"]=='LIST'?"IN ($Y)":"FROM ($oh) TO ($Y)");if($jb)$P
.=($s?",":" (")."\n  PARTITION ".(preg_match('~^DEFAULT$~i',$X)?$X:idf_escape($X))."$Tg";else$yh[]="CREATE TABLE ".idf_escape($B."_$X")." PARTITION OF ".idf_escape($B)." FOR$Tg";$oh=$Y;}$P
.=($jb?"\n)":"");}}array_unshift($yh,"CREATE TABLE ".table($B)." (\n".implode(",\n",$b)."\n)$P");}elseif($b)array_unshift($yh,"ALTER TABLE ".table($R)."\n".implode(",\n",$b));if($mi)array_unshift($yh,$mi);if($sb!==null)$yh[]="COMMENT ON TABLE ".table($B)." IS ".q($sb);foreach($yh
as$H){if(!queries($H))return
false;}return
true;}function
alter_indexes($R,$b){$i=array();$pc=array();$yh=array();foreach($b
as$X){if($X[0]!="INDEX")$i[]=($X[2]=="DROP"?"\nDROP CONSTRAINT ".idf_escape($X[1]):"\nADD".($X[1]!=""?" CONSTRAINT ".idf_escape($X[1]):"")." $X[0] ".($X[0]=="PRIMARY"?"KEY ":"")."(".implode(", ",$X[2]).")");elseif($X[2]=="DROP")$pc[]=idf_escape($X[1]);else$yh[]="CREATE INDEX ".idf_escape($X[1]!=""?$X[1]:uniqid($R."_"))." ON ".table($R).($X[3]?" USING $X[3]":"")." (".implode(", ",$X[2]).")".($X[4]?" WHERE $X[4]":"");}if($i)array_unshift($yh,"ALTER TABLE ".table($R).implode(",",$i));if($pc)array_unshift($yh,"DROP INDEX ".implode(", ",$pc));foreach($yh
as$H){if(!queries($H))return
false;}return
true;}function
truncate_tables($T){return
queries("TRUNCATE ".implode(", ",array_map('Adminer\table',$T)));}function
drop_views($lk){return
drop_tables($lk);}function
drop_tables($T){foreach($T
as$R){$P=table_status1($R);if(!queries("DROP ".strtoupper($P["Engine"])." ".table($R)))return
false;}return
true;}function
move_tables($T,$lk,$ej){foreach(array_merge($T,$lk)as$R){$P=table_status1($R);if(!queries("ALTER ".strtoupper($P["Engine"])." ".table($R)." SET SCHEMA ".idf_escape($ej)))return
false;}return
true;}function
trigger($B,$R){if($B=="")return
array("Statement"=>"EXECUTE PROCEDURE ()");$e=array();$Z="WHERE trigger_schema = current_schema() AND event_object_table = ".q($R)." AND trigger_name = ".q($B);foreach(get_rows("SELECT * FROM information_schema.triggered_update_columns $Z")as$K)$e[]=$K["event_object_column"];$J=array();foreach(get_rows('SELECT trigger_name AS "Trigger", action_timing AS "Timing", event_manipulation AS "Event", \'FOR EACH \' || action_orientation AS "Type", action_statement AS "Statement"
FROM information_schema.triggers'."
$Z
ORDER BY event_manipulation DESC")as$K){if($e&&$K["Event"]=="UPDATE")$K["Event"].=" OF";$K["Of"]=implode(", ",$e);if($J)$K["Event"].=" OR $J[Event]";$J=$K;}return$J;}function
triggers($R){$J=array();foreach(get_rows("SELECT * FROM information_schema.triggers WHERE trigger_schema = current_schema() AND event_object_table = ".q($R))as$K){$Cj=trigger($K["trigger_name"],$R);$J[$Cj["Trigger"]]=array($Cj["Timing"],$Cj["Event"]);}return$J;}function
trigger_options(){return
array("Timing"=>array("BEFORE","AFTER"),"Event"=>array("INSERT","UPDATE","UPDATE OF","DELETE","INSERT OR UPDATE","INSERT OR UPDATE OF","DELETE OR INSERT","DELETE OR UPDATE","DELETE OR UPDATE OF","DELETE OR INSERT OR UPDATE","DELETE OR INSERT OR UPDATE OF"),"Type"=>array("FOR EACH ROW","FOR EACH STATEMENT"),);}function
routine($B,$U){$L=get_rows('SELECT routine_definition AS definition, LOWER(external_language) AS language, *
FROM information_schema.routines
WHERE routine_schema = current_schema() AND specific_name = '.q($B));$J=idx($L,0,array());$J["returns"]=array("type"=>$J["type_udt_name"]);$J["fields"]=get_rows('SELECT COALESCE(parameter_name, ordinal_position::text) AS field, data_type AS type, character_maximum_length AS length, parameter_mode AS inout
FROM information_schema.parameters
WHERE specific_schema = current_schema() AND specific_name = '.q($B).'
ORDER BY ordinal_position');return$J;}function
routines(){return
get_rows('SELECT specific_name AS "SPECIFIC_NAME", routine_type AS "ROUTINE_TYPE", routine_name AS "ROUTINE_NAME", type_udt_name AS "DTD_IDENTIFIER"
FROM information_schema.routines
WHERE routine_schema = current_schema()
ORDER BY SPECIFIC_NAME');}function
routine_languages(){return
get_vals("SELECT LOWER(lanname) FROM pg_catalog.pg_language");}function
routine_id($B,$K){$J=array();foreach($K["fields"]as$n){$y=$n["length"];$J[]=$n["type"].($y?"($y)":"");}return
idf_escape($B)."(".implode(", ",$J).")";}function
last_id($I){$K=(is_object($I)?$I->fetch_row():array());return($K?$K[0]:0);}function
explain($g,$H){return$g->query("EXPLAIN $H");}function
found_rows($S,$Z){if(preg_match("~ rows=([0-9]+)~",get_val("EXPLAIN SELECT * FROM ".idf_escape($S["Name"]).($Z?" WHERE ".implode(" AND ",$Z):"")),$Jh))return$Jh[1];}function
types(){return
get_key_vals("SELECT oid, typname
FROM pg_type
WHERE typnamespace = ".driver()->nsOid."
AND typtype IN ('b','d','e')
AND typelem = 0");}function
type_values($t){$Hc=get_vals("SELECT enumlabel FROM pg_enum WHERE enumtypid = $t ORDER BY enumsortorder");return($Hc?"'".implode("', '",array_map('addslashes',$Hc))."'":"");}function
schemas(){return
get_vals("SELECT nspname FROM pg_namespace ORDER BY nspname");}function
get_schema(){return
get_val("SELECT current_schema()");}function
set_schema($Zh,$h=null){$J=connection($h)->query("SET search_path TO ".idf_escape($Zh));driver()->setUserTypes(types());return$J;}function
foreign_keys_sql($R){$J="";$P=table_status1($R);$bg=idf_escape($P['nspname']);$od=foreign_keys($R);ksort($od);foreach($od
as$nd=>$md)$J
.="ALTER TABLE ONLY $bg.".idf_escape($P['Name'])." ADD CONSTRAINT ".idf_escape($nd)." ".preg_replace('~( REFERENCES )([^(.]+\()~',"\\1$bg.\\2",$md["definition"]).";\n";return($J?"$J\n":$J);}function
create_sql($R,$Da,$Li){$Ph=array();$oi=array();$P=table_status1($R);$bg=idf_escape($P['nspname']);if(is_view($P)){$kk=view($R);return
rtrim("CREATE VIEW $bg.".idf_escape($R)." AS $kk[select]",";");}$o=fields($R);if(count($P)<2||empty($o))return
false;$J="CREATE TABLE $bg.".idf_escape($P['Name'])." (\n    ";foreach($o
as$n){if($n['default']=="nextval('$P[Name]_$n[field]_seq')"){$n['default']=null;$n['full_type']=preg_replace('~int(eger)?~','serial',$n['full_type']);}$Rg=idf_escape($n['field']).' '.$n['full_type'].preg_replace('~(nextval\(\')([^.\']+\')~','\1'.str_replace("'","''",$P['nspname']).'.\2',default_value($n)).($n['null']?"":" NOT NULL");$Ph[]=$Rg;if(preg_match('~nextval\(\'([^\']+)\'\)~',$n['default'],$pf)){$ni=$pf[1];$Ai=first(get_rows((min_version(10)?"SELECT *, cache_size AS cache_value FROM pg_sequences WHERE schemaname = current_schema() AND sequencename = ".q(idf_unescape($ni)):"SELECT * FROM $ni"),null,"-- "));$oi[]=($Li=="DROP+CREATE"?"DROP SEQUENCE IF EXISTS $bg.$ni;\n":"")."CREATE SEQUENCE $bg.$ni INCREMENT $Ai[increment_by] MINVALUE $Ai[min_value] MAXVALUE $Ai[max_value]".($Da&&$Ai['last_value']?" START ".($Ai["last_value"]+1):"")." CACHE $Ai[cache_value];";}}if(!empty($oi))$J=implode("\n\n",$oi)."\n\n$J";$ph="";foreach(indexes($R)as$le=>$v){if($v['type']=='PRIMARY'){$ph=$le;$Ph[]="CONSTRAINT ".idf_escape($le)." PRIMARY KEY (".implode(', ',array_map('Adminer\idf_escape',$v['columns'])).")";}}foreach(driver()->checkConstraints($R)as$yb=>$_b)$Ph[]="CONSTRAINT ".idf_escape($yb)." CHECK ($_b)";$J
.=implode(",\n    ",$Ph)."\n)";$Tg=driver()->partitionsInfo($P['Name']);if($Tg)$J
.="\nPARTITION BY $Tg[partition_by]($Tg[partition])";$J
.="\nWITH (oids = ".($P['Oid']?'true':'false').");";if($P['Comment'])$J
.="\n\nCOMMENT ON TABLE $bg.".idf_escape($P['Name'])." IS ".q($P['Comment']).";";foreach($o
as$cd=>$n){if($n['comment'])$J
.="\n\nCOMMENT ON COLUMN $bg.".idf_escape($P['Name']).".".idf_escape($cd)." IS ".q($n['comment']).";";}foreach(get_rows("SELECT indexdef FROM pg_catalog.pg_indexes WHERE schemaname = current_schema() AND tablename = ".q($R).($ph?" AND indexname != ".q($ph):""),null,"-- ")as$K)$J
.="\n\n$K[indexdef];";return
rtrim($J,';');}function
truncate_sql($R){return"TRUNCATE ".table($R);}function
trigger_sql($R){$P=table_status1($R);$J="";foreach(triggers($R)as$Bj=>$Aj){$Cj=trigger($Bj,$P['Name']);$J
.="\nCREATE TRIGGER ".idf_escape($Cj['Trigger'])." $Cj[Timing] $Cj[Event] ON ".idf_escape($P["nspname"]).".".idf_escape($P['Name'])." $Cj[Type] $Cj[Statement];;\n";}return$J;}function
use_sql($Rb,$Li=""){$B=idf_escape($Rb);$J="";if(preg_match('~CREATE~',$Li)){if($Li=="DROP+CREATE")$J="DROP DATABASE IF EXISTS $B;\n";$J
.="CREATE DATABASE $B;\n";}return"$J\\connect $B";}function
show_variables(){return
get_rows("SHOW ALL");}function
process_list(){return
get_rows("SELECT * FROM pg_stat_activity ORDER BY ".(min_version(9.2)?"pid":"procpid"));}function
convert_field($n){}function
unconvert_field($n,$J){return$J;}function
support($ad){return
preg_match('~^(check|columns|comment|database|drop_col|dump|descidx|indexes|kill|partial_indexes|routine|scheme|sequence|sql|table|trigger|type|variables|view'.(min_version(9.3)?'|materializedview':'').(min_version(11)?'|procedure':'').(connection()->flavor=='cockroach'?'':'|processlist').')$~',$ad);}function
kill_process($X){return
queries("SELECT pg_terminate_backend(".number($X).")");}function
connection_id(){return"SELECT pg_backend_pid()";}function
max_connections(){return
get_val("SHOW max_connections");}}add_driver("oracle","Oracle (beta)");if(isset($_GET["oracle"])){define('Adminer\DRIVER',"oracle");if(extension_loaded("oci8")&&$_GET["ext"]!="pdo"){class
Db
extends
SqlDb{var$extension="oci8";var$_current_db;private$link;function
_error($Ic,$m){if(ini_bool("html_errors"))$m=html_entity_decode(strip_tags($m));$m=preg_replace('~^[^:]*: ~','',$m);$this->error=$m;}function
attach($N,$V,$F){$this->link=@oci_new_connect($V,$F,$N,"AL32UTF8");if($this->link){$this->server_info=oci_server_version($this->link);return'';}$m=oci_error();return$m["message"];}function
quote($Q){return"'".str_replace("'","''",$Q)."'";}function
select_db($Rb){$this->_current_db=$Rb;return
true;}function
query($H,$Jj=false){$I=oci_parse($this->link,$H);$this->error="";if(!$I){$m=oci_error($this->link);$this->errno=$m["code"];$this->error=$m["message"];return
false;}set_error_handler(array($this,'_error'));$J=@oci_execute($I);restore_error_handler();if($J){if(oci_num_fields($I))return
new
Result($I);$this->affected_rows=oci_num_rows($I);oci_free_statement($I);}return$J;}function
timeout($Nf){return
oci_set_call_timeout($this->link,$Nf);}}class
Result{var$num_rows;private$result,$offset=1;function
__construct($I){$this->result=$I;}private
function
convert($K){foreach((array)$K
as$x=>$X){if(is_a($X,'OCILob')||is_a($X,'OCI-Lob'))$K[$x]=$X->load();}return$K;}function
fetch_assoc(){return$this->convert(oci_fetch_assoc($this->result));}function
fetch_row(){return$this->convert(oci_fetch_row($this->result));}function
fetch_field(){$d=$this->offset++;$J=new
\stdClass;$J->name=oci_field_name($this->result,$d);$J->type=oci_field_type($this->result,$d);$J->charsetnr=(preg_match("~raw|blob|bfile~",$J->type)?63:0);return$J;}}}elseif(extension_loaded("pdo_oci")){class
Db
extends
PdoDb{var$extension="PDO_OCI";var$_current_db;function
attach($N,$V,$F){return$this->dsn("oci:dbname=//$N;charset=AL32UTF8",$V,$F);}function
select_db($Rb){$this->_current_db=$Rb;return
true;}}}class
Driver
extends
SqlDriver{static$extensions=array("OCI8","PDO_OCI");static$jush="oracle";var$insertFunctions=array("date"=>"current_date","timestamp"=>"current_timestamp",);var$editFunctions=array("number|float|double"=>"+/-","date|timestamp"=>"+ interval/- interval","char|clob"=>"||",);var$operators=array("=","<",">","<=",">=","!=","LIKE","LIKE %%","IN","IS NULL","NOT LIKE","NOT IN","IS NOT NULL","SQL");var$functions=array("length","lower","round","upper");var$grouping=array("avg","count","count distinct","max","min","sum");function
__construct(Db$g){parent::__construct($g);$this->types=array(lang(27)=>array("number"=>38,"binary_float"=>12,"binary_double"=>21),lang(28)=>array("date"=>10,"timestamp"=>29,"interval year"=>12,"interval day"=>28),lang(29)=>array("char"=>2000,"varchar2"=>4000,"nchar"=>2000,"nvarchar2"=>4000,"clob"=>4294967295,"nclob"=>4294967295),lang(30)=>array("raw"=>2000,"long raw"=>2147483648,"blob"=>4294967295,"bfile"=>4294967296),);}function
begin(){return
true;}function
insertUpdate($R,array$L,array$ph){foreach($L
as$O){$Rj=array();$Z=array();foreach($O
as$x=>$X){$Rj[]="$x = $X";if(isset($ph[idf_unescape($x)]))$Z[]="$x = $X";}if(!(($Z&&queries("UPDATE ".table($R)." SET ".implode(", ",$Rj)." WHERE ".implode(" AND ",$Z))&&$this->conn->affected_rows)||queries("INSERT INTO ".table($R)." (".implode(", ",array_keys($O)).") VALUES (".implode(", ",$O).")")))return
false;}return
true;}function
hasCStyleEscapes(){return
true;}}function
idf_escape($u){return'"'.str_replace('"','""',$u).'"';}function
table($u){return
idf_escape($u);}function
get_databases($qd){return
get_vals("SELECT DISTINCT tablespace_name FROM (
SELECT tablespace_name FROM user_tablespaces
UNION SELECT tablespace_name FROM all_tables WHERE tablespace_name IS NOT NULL
)
ORDER BY 1");}function
limit($H,$Z,$z,$C=0,$li=" "){return($C?" * FROM (SELECT t.*, rownum AS rnum FROM (SELECT $H$Z) t WHERE rownum <= ".($z+$C).") WHERE rnum > $C":($z?" * FROM (SELECT $H$Z) WHERE rownum <= ".($z+$C):" $H$Z"));}function
limit1($R,$H,$Z,$li="\n"){return" $H$Z";}function
db_collation($k,$nb){return
get_val("SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET'");}function
logged_user(){return
get_val("SELECT USER FROM DUAL");}function
get_current_db(){$k=connection()->_current_db?:DB;unset(connection()->_current_db);return$k;}function
where_owner($mh,$Lg="owner"){if(!$_GET["ns"])return'';return"$mh$Lg = sys_context('USERENV', 'CURRENT_SCHEMA')";}function
views_table($e){$Lg=where_owner('');return"(SELECT $e FROM all_views WHERE ".($Lg?:"rownum < 0").")";}function
tables_list(){$kk=views_table("view_name");$Lg=where_owner(" AND ");return
get_key_vals("SELECT table_name, 'table' FROM all_tables WHERE tablespace_name = ".q(DB)."$Lg
UNION SELECT view_name, 'view' FROM $kk
ORDER BY 1");}function
count_tables($j){$J=array();foreach($j
as$k)$J[$k]=get_val("SELECT COUNT(*) FROM all_tables WHERE tablespace_name = ".q($k));return$J;}function
table_status($B=""){$J=array();$ei=q($B);$k=get_current_db();$kk=views_table("view_name");$Lg=where_owner(" AND ");foreach(get_rows('SELECT table_name "Name", \'table\' "Engine", avg_row_len * num_rows "Data_length", num_rows "Rows" FROM all_tables WHERE tablespace_name = '.q($k).$Lg.($B!=""?" AND table_name = $ei":"")."
UNION SELECT view_name, 'view', 0, 0 FROM $kk".($B!=""?" WHERE view_name = $ei":"")."
ORDER BY 1")as$K)$J[$K["Name"]]=$K;return$J;}function
is_view($S){return$S["Engine"]=="view";}function
fk_support($S){return
true;}function
fields($R){$J=array();$Lg=where_owner(" AND ");foreach(get_rows("SELECT * FROM all_tab_columns WHERE table_name = ".q($R)."$Lg ORDER BY column_id")as$K){$U=$K["DATA_TYPE"];$y="$K[DATA_PRECISION],$K[DATA_SCALE]";if($y==",")$y=$K["CHAR_COL_DECL_LENGTH"];$J[$K["COLUMN_NAME"]]=array("field"=>$K["COLUMN_NAME"],"full_type"=>$U.($y?"($y)":""),"type"=>strtolower($U),"length"=>$y,"default"=>$K["DATA_DEFAULT"],"null"=>($K["NULLABLE"]=="Y"),"privileges"=>array("insert"=>1,"select"=>1,"update"=>1,"where"=>1,"order"=>1),);}return$J;}function
indexes($R,$h=null){$J=array();$Lg=where_owner(" AND ","aic.table_owner");foreach(get_rows("SELECT aic.*, ac.constraint_type, atc.data_default
FROM all_ind_columns aic
LEFT JOIN all_constraints ac ON aic.index_name = ac.constraint_name AND aic.table_name = ac.table_name AND aic.index_owner = ac.owner
LEFT JOIN all_tab_cols atc ON aic.column_name = atc.column_name AND aic.table_name = atc.table_name AND aic.index_owner = atc.owner
WHERE aic.table_name = ".q($R)."$Lg
ORDER BY ac.constraint_type, aic.column_position",$h)as$K){$le=$K["INDEX_NAME"];$pb=$K["DATA_DEFAULT"];$pb=($pb?trim($pb,'"'):$K["COLUMN_NAME"]);$J[$le]["type"]=($K["CONSTRAINT_TYPE"]=="P"?"PRIMARY":($K["CONSTRAINT_TYPE"]=="U"?"UNIQUE":"INDEX"));$J[$le]["columns"][]=$pb;$J[$le]["lengths"][]=($K["CHAR_LENGTH"]&&$K["CHAR_LENGTH"]!=$K["COLUMN_LENGTH"]?$K["CHAR_LENGTH"]:null);$J[$le]["descs"][]=($K["DESCEND"]&&$K["DESCEND"]=="DESC"?'1':null);}return$J;}function
view($B){$kk=views_table("view_name, text");$L=get_rows('SELECT text "select" FROM '.$kk.' WHERE view_name = '.q($B));return
reset($L);}function
collations(){return
array();}function
information_schema($k){return
get_schema()=="INFORMATION_SCHEMA";}function
error(){return
h(connection()->error);}function
explain($g,$H){$g->query("EXPLAIN PLAN FOR $H");return$g->query("SELECT * FROM plan_table");}function
found_rows($S,$Z){}function
auto_increment(){return"";}function
alter_table($R,$B,$o,$sd,$sb,$Cc,$c,$Da,$E){$b=$pc=array();$Eg=($R?fields($R):array());foreach($o
as$n){$X=$n[1];if($X&&$n[0]!=""&&idf_escape($n[0])!=$X[0])queries("ALTER TABLE ".table($R)." RENAME COLUMN ".idf_escape($n[0])." TO $X[0]");$Dg=$Eg[$n[0]];if($X&&$Dg){$ig=process_field($Dg,$Dg);if($X[2]==$ig[2])$X[2]="";}if($X)$b[]=($R!=""?($n[0]!=""?"MODIFY (":"ADD ("):"  ").implode($X).($R!=""?")":"");else$pc[]=idf_escape($n[0]);}if($R=="")return
queries("CREATE TABLE ".table($B)." (\n".implode(",\n",$b)."\n)");return(!$b||queries("ALTER TABLE ".table($R)."\n".implode("\n",$b)))&&(!$pc||queries("ALTER TABLE ".table($R)." DROP (".implode(", ",$pc).")"))&&($R==$B||queries("ALTER TABLE ".table($R)." RENAME TO ".table($B)));}function
alter_indexes($R,$b){$pc=array();$yh=array();foreach($b
as$X){if($X[0]!="INDEX"){$X[2]=preg_replace('~ DESC$~','',$X[2]);$i=($X[2]=="DROP"?"\nDROP CONSTRAINT ".idf_escape($X[1]):"\nADD".($X[1]!=""?" CONSTRAINT ".idf_escape($X[1]):"")." $X[0] ".($X[0]=="PRIMARY"?"KEY ":"")."(".implode(", ",$X[2]).")");array_unshift($yh,"ALTER TABLE ".table($R).$i);}elseif($X[2]=="DROP")$pc[]=idf_escape($X[1]);else$yh[]="CREATE INDEX ".idf_escape($X[1]!=""?$X[1]:uniqid($R."_"))." ON ".table($R)." (".implode(", ",$X[2]).")";}if($pc)array_unshift($yh,"DROP INDEX ".implode(", ",$pc));foreach($yh
as$H){if(!queries($H))return
false;}return
true;}function
foreign_keys($R){$J=array();$H="SELECT c_list.CONSTRAINT_NAME as NAME,
c_src.COLUMN_NAME as SRC_COLUMN,
c_dest.OWNER as DEST_DB,
c_dest.TABLE_NAME as DEST_TABLE,
c_dest.COLUMN_NAME as DEST_COLUMN,
c_list.DELETE_RULE as ON_DELETE
FROM ALL_CONSTRAINTS c_list, ALL_CONS_COLUMNS c_src, ALL_CONS_COLUMNS c_dest
WHERE c_list.CONSTRAINT_NAME = c_src.CONSTRAINT_NAME
AND c_list.R_CONSTRAINT_NAME = c_dest.CONSTRAINT_NAME
AND c_list.CONSTRAINT_TYPE = 'R'
AND c_src.TABLE_NAME = ".q($R);foreach(get_rows($H)as$K)$J[$K['NAME']]=array("db"=>$K['DEST_DB'],"table"=>$K['DEST_TABLE'],"source"=>array($K['SRC_COLUMN']),"target"=>array($K['DEST_COLUMN']),"on_delete"=>$K['ON_DELETE'],"on_update"=>null,);return$J;}function
truncate_tables($T){return
apply_queries("TRUNCATE TABLE",$T);}function
drop_views($lk){return
apply_queries("DROP VIEW",$lk);}function
drop_tables($T){return
apply_queries("DROP TABLE",$T);}function
last_id($I){return
0;}function
schemas(){$J=get_vals("SELECT DISTINCT owner FROM dba_segments WHERE owner IN (SELECT username FROM dba_users WHERE default_tablespace NOT IN ('SYSTEM','SYSAUX')) ORDER BY 1");return($J?:get_vals("SELECT DISTINCT owner FROM all_tables WHERE tablespace_name = ".q(DB)." ORDER BY 1"));}function
get_schema(){return
get_val("SELECT sys_context('USERENV', 'SESSION_USER') FROM dual");}function
set_schema($bi,$h=null){return
connection($h)->query("ALTER SESSION SET CURRENT_SCHEMA = ".idf_escape($bi));}function
show_variables(){return
get_rows('SELECT name, display_value FROM v$parameter');}function
show_status(){$J=array();$L=get_rows('SELECT * FROM v$instance');foreach(reset($L)as$x=>$X)$J[]=array($x,$X);return$J;}function
process_list(){return
get_rows('SELECT
	sess.process AS "process",
	sess.username AS "user",
	sess.schemaname AS "schema",
	sess.status AS "status",
	sess.wait_class AS "wait_class",
	sess.seconds_in_wait AS "seconds_in_wait",
	sql.sql_text AS "sql_text",
	sess.machine AS "machine",
	sess.port AS "port"
FROM v$session sess LEFT OUTER JOIN v$sql sql
ON sql.sql_id = sess.sql_id
WHERE sess.type = \'USER\'
ORDER BY PROCESS
');}function
convert_field($n){}function
unconvert_field($n,$J){return$J;}function
support($ad){return
preg_match('~^(columns|database|drop_col|indexes|descidx|processlist|scheme|sql|status|table|variables|view)$~',$ad);}}add_driver("mssql","MS SQL");if(isset($_GET["mssql"])){define('Adminer\DRIVER',"mssql");if(extension_loaded("sqlsrv")&&$_GET["ext"]!="pdo"){class
Db
extends
SqlDb{var$extension="sqlsrv";private$link,$result;private
function
get_error(){$this->error="";foreach(sqlsrv_errors()as$m){$this->errno=$m["code"];$this->error
.="$m[message]\n";}$this->error=rtrim($this->error);}function
attach($N,$V,$F){$zb=array("UID"=>$V,"PWD"=>$F,"CharacterSet"=>"UTF-8");$Gi=adminer()->connectSsl();if(isset($Gi["Encrypt"]))$zb["Encrypt"]=$Gi["Encrypt"];if(isset($Gi["TrustServerCertificate"]))$zb["TrustServerCertificate"]=$Gi["TrustServerCertificate"];$k=adminer()->database();if($k!="")$zb["Database"]=$k;list($Vd,$hh)=host_port($N);$this->link=@sqlsrv_connect($Vd.($hh?",$hh":""),$zb);if($this->link){$qe=sqlsrv_server_info($this->link);$this->server_info=$qe['SQLServerVersion'];}else$this->get_error();return($this->link?'':$this->error);}function
quote($Q){$Kj=strlen($Q)!=strlen(utf8_decode($Q));return($Kj?"N":"")."'".str_replace("'","''",$Q)."'";}function
select_db($Rb){return$this->query(use_sql($Rb));}function
query($H,$Jj=false){$I=sqlsrv_query($this->link,$H);$this->error="";if(!$I){$this->get_error();return
false;}return$this->store_result($I);}function
multi_query($H){$this->result=sqlsrv_query($this->link,$H);$this->error="";if(!$this->result){$this->get_error();return
false;}return
true;}function
store_result($I=null){if(!$I)$I=$this->result;if(!$I)return
false;if(sqlsrv_field_metadata($I))return
new
Result($I);$this->affected_rows=sqlsrv_rows_affected($I);return
true;}function
next_result(){return$this->result?!!sqlsrv_next_result($this->result):false;}}class
Result{var$num_rows;private$result,$offset=0,$fields;function
__construct($I){$this->result=$I;}private
function
convert($K){foreach((array)$K
as$x=>$X){if(is_a($X,'DateTime'))$K[$x]=$X->format("Y-m-d H:i:s");}return$K;}function
fetch_assoc(){return$this->convert(sqlsrv_fetch_array($this->result,SQLSRV_FETCH_ASSOC));}function
fetch_row(){return$this->convert(sqlsrv_fetch_array($this->result,SQLSRV_FETCH_NUMERIC));}function
fetch_field(){if(!$this->fields)$this->fields=sqlsrv_field_metadata($this->result);$n=$this->fields[$this->offset++];$J=new
\stdClass;$J->name=$n["Name"];$J->type=($n["Type"]==1?254:15);$J->charsetnr=0;return$J;}function
seek($C){for($s=0;$s<$C;$s++)sqlsrv_fetch($this->result);}}function
last_id($I){return
get_val("SELECT SCOPE_IDENTITY()");}function
explain($g,$H){$g->query("SET SHOWPLAN_ALL ON");$J=$g->query($H);$g->query("SET SHOWPLAN_ALL OFF");return$J;}}else{abstract
class
MssqlDb
extends
PdoDb{function
select_db($Rb){return$this->query(use_sql($Rb));}function
lastInsertId(){return$this->pdo->lastInsertId();}}function
last_id($I){return
connection()->lastInsertId();}function
explain($g,$H){}if(extension_loaded("pdo_sqlsrv")){class
Db
extends
MssqlDb{var$extension="PDO_SQLSRV";function
attach($N,$V,$F){list($Vd,$hh)=host_port($N);return$this->dsn("sqlsrv:Server=$Vd".($hh?",$hh":""),$V,$F);}}}elseif(extension_loaded("pdo_dblib")){class
Db
extends
MssqlDb{var$extension="PDO_DBLIB";function
attach($N,$V,$F){list($Vd,$hh)=host_port($N);return$this->dsn("dblib:charset=utf8;host=$Vd".($hh?(is_numeric($hh)?";port=":";unix_socket=").$hh:""),$V,$F);}}}}class
Driver
extends
SqlDriver{static$extensions=array("SQLSRV","PDO_SQLSRV","PDO_DBLIB");static$jush="mssql";var$insertFunctions=array("date|time"=>"getdate");var$editFunctions=array("int|decimal|real|float|money|datetime"=>"+/-","char|text"=>"+",);var$operators=array("=","<",">","<=",">=","!=","LIKE","LIKE %%","IN","IS NULL","NOT LIKE","NOT IN","IS NOT NULL");var$functions=array("len","lower","round","upper");var$grouping=array("avg","count","count distinct","max","min","sum");var$generated=array("PERSISTED","VIRTUAL");var$onActions="NO ACTION|CASCADE|SET NULL|SET DEFAULT";static
function
connect($N,$V,$F){if($N=="")$N="localhost:1433";return
parent::connect($N,$V,$F);}function
__construct(Db$g){parent::__construct($g);$this->types=array(lang(27)=>array("tinyint"=>3,"smallint"=>5,"int"=>10,"bigint"=>20,"bit"=>1,"decimal"=>0,"real"=>12,"float"=>53,"smallmoney"=>10,"money"=>20),lang(28)=>array("date"=>10,"smalldatetime"=>19,"datetime"=>19,"datetime2"=>19,"time"=>8,"datetimeoffset"=>10),lang(29)=>array("char"=>8000,"varchar"=>8000,"text"=>2147483647,"nchar"=>4000,"nvarchar"=>4000,"ntext"=>1073741823),lang(30)=>array("binary"=>8000,"varbinary"=>8000,"image"=>2147483647),);}function
insertUpdate($R,array$L,array$ph){$o=fields($R);$Rj=array();$Z=array();$O=reset($L);$e="c".implode(", c",range(1,count($O)));$Ua=0;$we=array();foreach($O
as$x=>$X){$Ua++;$B=idf_unescape($x);if(!$o[$B]["auto_increment"])$we[$x]="c$Ua";if(isset($ph[$B]))$Z[]="$x = c$Ua";else$Rj[]="$x = c$Ua";}$gk=array();foreach($L
as$O)$gk[]="(".implode(", ",$O).")";if($Z){$ae=queries("SET IDENTITY_INSERT ".table($R)." ON");$J=queries("MERGE ".table($R)." USING (VALUES\n\t".implode(",\n\t",$gk)."\n) AS source ($e) ON ".implode(" AND ",$Z).($Rj?"\nWHEN MATCHED THEN UPDATE SET ".implode(", ",$Rj):"")."\nWHEN NOT MATCHED THEN INSERT (".implode(", ",array_keys($ae?$O:$we)).") VALUES (".($ae?$e:implode(", ",$we)).");");if($ae)queries("SET IDENTITY_INSERT ".table($R)." OFF");}else$J=queries("INSERT INTO ".table($R)." (".implode(", ",array_keys($O)).") VALUES\n".implode(",\n",$gk));return$J;}function
begin(){return
queries("BEGIN TRANSACTION");}function
tableHelp($B,$Ge=false){$ef=array("sys"=>"catalog-views/sys-","INFORMATION_SCHEMA"=>"information-schema-views/",);$_=$ef[get_schema()];if($_)return"relational-databases/system-$_".preg_replace('~_~','-',strtolower($B))."-transact-sql";}}function
idf_escape($u){return"[".str_replace("]","]]",$u)."]";}function
table($u){return($_GET["ns"]!=""?idf_escape($_GET["ns"]).".":"").idf_escape($u);}function
get_databases($qd){return
get_vals("SELECT name FROM sys.databases WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb')");}function
limit($H,$Z,$z,$C=0,$li=" "){return($z?" TOP (".($z+$C).")":"")." $H$Z";}function
limit1($R,$H,$Z,$li="\n"){return
limit($H,$Z,1,0,$li);}function
db_collation($k,$nb){return
get_val("SELECT collation_name FROM sys.databases WHERE name = ".q($k));}function
logged_user(){return
get_val("SELECT SUSER_NAME()");}function
tables_list(){return
get_key_vals("SELECT name, type_desc FROM sys.all_objects WHERE schema_id = SCHEMA_ID(".q(get_schema()).") AND type IN ('S', 'U', 'V') ORDER BY name");}function
count_tables($j){$J=array();foreach($j
as$k){connection()->select_db($k);$J[$k]=get_val("SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES");}return$J;}function
table_status($B=""){$J=array();foreach(get_rows("SELECT ao.name AS Name, ao.type_desc AS Engine, (SELECT cast(value as varchar(max)) FROM fn_listextendedproperty(default, 'SCHEMA', schema_name(schema_id), 'TABLE', ao.name, null, null)) AS Comment
FROM sys.all_objects AS ao
WHERE schema_id = SCHEMA_ID(".q(get_schema()).") AND type IN ('S', 'U', 'V') ".($B!=""?"AND name = ".q($B):"ORDER BY name"))as$K)$J[$K["Name"]]=$K;return$J;}function
is_view($S){return$S["Engine"]=="VIEW";}function
fk_support($S){return
true;}function
fields($R){$ub=get_key_vals("SELECT objname, cast(value as varchar(max)) FROM fn_listextendedproperty('MS_DESCRIPTION', 'schema', ".q(get_schema()).", 'table', ".q($R).", 'column', NULL)");$J=array();$Ui=get_val("SELECT object_id FROM sys.all_objects WHERE schema_id = SCHEMA_ID(".q(get_schema()).") AND type IN ('S', 'U', 'V') AND name = ".q($R));foreach(get_rows("SELECT c.max_length, c.precision, c.scale, c.name, c.is_nullable, c.is_identity, c.collation_name, t.name type, d.definition [default], d.name default_constraint, i.is_primary_key
FROM sys.all_columns c
JOIN sys.types t ON c.user_type_id = t.user_type_id
LEFT JOIN sys.default_constraints d ON c.default_object_id = d.object_id
LEFT JOIN sys.index_columns ic ON c.object_id = ic.object_id AND c.column_id = ic.column_id
LEFT JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id
WHERE c.object_id = ".q($Ui))as$K){$U=$K["type"];$y=(preg_match("~char|binary~",$U)?intval($K["max_length"])/($U[0]=='n'?2:1):($U=="decimal"?"$K[precision],$K[scale]":""));$J[$K["name"]]=array("field"=>$K["name"],"full_type"=>$U.($y?"($y)":""),"type"=>$U,"length"=>$y,"default"=>(preg_match("~^\('(.*)'\)$~",$K["default"],$A)?str_replace("''","'",$A[1]):$K["default"]),"default_constraint"=>$K["default_constraint"],"null"=>$K["is_nullable"],"auto_increment"=>$K["is_identity"],"collation"=>$K["collation_name"],"privileges"=>array("insert"=>1,"select"=>1,"update"=>1,"where"=>1,"order"=>1),"primary"=>$K["is_primary_key"],"comment"=>$ub[$K["name"]],);}foreach(get_rows("SELECT * FROM sys.computed_columns WHERE object_id = ".q($Ui))as$K){$J[$K["name"]]["generated"]=($K["is_persisted"]?"PERSISTED":"VIRTUAL");$J[$K["name"]]["default"]=$K["definition"];}return$J;}function
indexes($R,$h=null){$J=array();foreach(get_rows("SELECT i.name, key_ordinal, is_unique, is_primary_key, c.name AS column_name, is_descending_key
FROM sys.indexes i
INNER JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
WHERE OBJECT_NAME(i.object_id) = ".q($R),$h)as$K){$B=$K["name"];$J[$B]["type"]=($K["is_primary_key"]?"PRIMARY":($K["is_unique"]?"UNIQUE":"INDEX"));$J[$B]["lengths"]=array();$J[$B]["columns"][$K["key_ordinal"]]=$K["column_name"];$J[$B]["descs"][$K["key_ordinal"]]=($K["is_descending_key"]?'1':null);}return$J;}function
view($B){return
array("select"=>preg_replace('~^(?:[^[]|\[[^]]*])*\s+AS\s+~isU','',get_val("SELECT VIEW_DEFINITION FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_SCHEMA = SCHEMA_NAME() AND TABLE_NAME = ".q($B))));}function
collations(){$J=array();foreach(get_vals("SELECT name FROM fn_helpcollations()")as$c)$J[preg_replace('~_.*~','',$c)][]=$c;return$J;}function
information_schema($k){return
get_schema()=="INFORMATION_SCHEMA";}function
error(){return
nl_br(h(preg_replace('~^(\[[^]]*])+~m','',connection()->error)));}function
create_database($k,$c){return
queries("CREATE DATABASE ".idf_escape($k).(preg_match('~^[a-z0-9_]+$~i',$c)?" COLLATE $c":""));}function
drop_databases($j){return
queries("DROP DATABASE ".implode(", ",array_map('Adminer\idf_escape',$j)));}function
rename_database($B,$c){if(preg_match('~^[a-z0-9_]+$~i',$c))queries("ALTER DATABASE ".idf_escape(DB)." COLLATE $c");queries("ALTER DATABASE ".idf_escape(DB)." MODIFY NAME = ".idf_escape($B));return
true;}function
auto_increment(){return" IDENTITY".($_POST["Auto_increment"]!=""?"(".number($_POST["Auto_increment"]).",1)":"")." PRIMARY KEY";}function
alter_table($R,$B,$o,$sd,$sb,$Cc,$c,$Da,$E){$b=array();$ub=array();$Eg=fields($R);foreach($o
as$n){$d=idf_escape($n[0]);$X=$n[1];if(!$X)$b["DROP"][]=" COLUMN $d";else{$X[1]=preg_replace("~( COLLATE )'(\\w+)'~",'\1\2',$X[1]);$ub[$n[0]]=$X[5];unset($X[5]);if(preg_match('~ AS ~',$X[3]))unset($X[1],$X[2]);if($n[0]=="")$b["ADD"][]="\n  ".implode("",$X).($R==""?substr($sd[$X[0]],16+strlen($X[0])):"");else{$l=$X[3];unset($X[3]);unset($X[6]);if($d!=$X[0])queries("EXEC sp_rename ".q(table($R).".$d").", ".q(idf_unescape($X[0])).", 'COLUMN'");$b["ALTER COLUMN ".implode("",$X)][]="";$Dg=$Eg[$n[0]];if(default_value($Dg)!=$l){if($Dg["default"]!==null)$b["DROP"][]=" ".idf_escape($Dg["default_constraint"]);if($l)$b["ADD"][]="\n $l FOR $d";}}}}if($R=="")return
queries("CREATE TABLE ".table($B)." (".implode(",",(array)$b["ADD"])."\n)");if($R!=$B)queries("EXEC sp_rename ".q(table($R)).", ".q($B));if($sd)$b[""]=$sd;foreach($b
as$x=>$X){if(!queries("ALTER TABLE ".table($B)." $x".implode(",",$X)))return
false;}foreach($ub
as$x=>$X){$sb=substr($X,9);queries("EXEC sp_dropextendedproperty @name = N'MS_Description', @level0type = N'Schema', @level0name = ".q(get_schema()).", @level1type = N'Table', @level1name = ".q($B).", @level2type = N'Column', @level2name = ".q($x));queries("EXEC sp_addextendedproperty
@name = N'MS_Description',
@value = $sb,
@level0type = N'Schema',
@level0name = ".q(get_schema()).",
@level1type = N'Table',
@level1name = ".q($B).",
@level2type = N'Column',
@level2name = ".q($x));}return
true;}function
alter_indexes($R,$b){$v=array();$pc=array();foreach($b
as$X){if($X[2]=="DROP"){if($X[0]=="PRIMARY")$pc[]=idf_escape($X[1]);else$v[]=idf_escape($X[1])." ON ".table($R);}elseif(!queries(($X[0]!="PRIMARY"?"CREATE $X[0] ".($X[0]!="INDEX"?"INDEX ":"").idf_escape($X[1]!=""?$X[1]:uniqid($R."_"))." ON ".table($R):"ALTER TABLE ".table($R)." ADD PRIMARY KEY")." (".implode(", ",$X[2]).")"))return
false;}return(!$v||queries("DROP INDEX ".implode(", ",$v)))&&(!$pc||queries("ALTER TABLE ".table($R)." DROP ".implode(", ",$pc)));}function
found_rows($S,$Z){}function
foreign_keys($R){$J=array();$pg=array("CASCADE","NO ACTION","SET NULL","SET DEFAULT");foreach(get_rows("EXEC sp_fkeys @fktable_name = ".q($R).", @fktable_owner = ".q(get_schema()))as$K){$p=&$J[$K["FK_NAME"]];$p["db"]=$K["PKTABLE_QUALIFIER"];$p["ns"]=$K["PKTABLE_OWNER"];$p["table"]=$K["PKTABLE_NAME"];$p["on_update"]=$pg[$K["UPDATE_RULE"]];$p["on_delete"]=$pg[$K["DELETE_RULE"]];$p["source"][]=$K["FKCOLUMN_NAME"];$p["target"][]=$K["PKCOLUMN_NAME"];}return$J;}function
truncate_tables($T){return
apply_queries("TRUNCATE TABLE",$T);}function
drop_views($lk){return
queries("DROP VIEW ".implode(", ",array_map('Adminer\table',$lk)));}function
drop_tables($T){return
queries("DROP TABLE ".implode(", ",array_map('Adminer\table',$T)));}function
move_tables($T,$lk,$ej){return
apply_queries("ALTER SCHEMA ".idf_escape($ej)." TRANSFER",array_merge($T,$lk));}function
trigger($B,$R){if($B=="")return
array();$L=get_rows("SELECT s.name [Trigger],
CASE WHEN OBJECTPROPERTY(s.id, 'ExecIsInsertTrigger') = 1 THEN 'INSERT' WHEN OBJECTPROPERTY(s.id, 'ExecIsUpdateTrigger') = 1 THEN 'UPDATE' WHEN OBJECTPROPERTY(s.id, 'ExecIsDeleteTrigger') = 1 THEN 'DELETE' END [Event],
CASE WHEN OBJECTPROPERTY(s.id, 'ExecIsInsteadOfTrigger') = 1 THEN 'INSTEAD OF' ELSE 'AFTER' END [Timing],
c.text
FROM sysobjects s
JOIN syscomments c ON s.id = c.id
WHERE s.xtype = 'TR' AND s.name = ".q($B));$J=reset($L);if($J)$J["Statement"]=preg_replace('~^.+\s+AS\s+~isU','',$J["text"]);return$J;}function
triggers($R){$J=array();foreach(get_rows("SELECT sys1.name,
CASE WHEN OBJECTPROPERTY(sys1.id, 'ExecIsInsertTrigger') = 1 THEN 'INSERT' WHEN OBJECTPROPERTY(sys1.id, 'ExecIsUpdateTrigger') = 1 THEN 'UPDATE' WHEN OBJECTPROPERTY(sys1.id, 'ExecIsDeleteTrigger') = 1 THEN 'DELETE' END [Event],
CASE WHEN OBJECTPROPERTY(sys1.id, 'ExecIsInsteadOfTrigger') = 1 THEN 'INSTEAD OF' ELSE 'AFTER' END [Timing]
FROM sysobjects sys1
JOIN sysobjects sys2 ON sys1.parent_obj = sys2.id
WHERE sys1.xtype = 'TR' AND sys2.name = ".q($R))as$K)$J[$K["name"]]=array($K["Timing"],$K["Event"]);return$J;}function
trigger_options(){return
array("Timing"=>array("AFTER","INSTEAD OF"),"Event"=>array("INSERT","UPDATE","DELETE"),"Type"=>array("AS"),);}function
schemas(){return
get_vals("SELECT name FROM sys.schemas");}function
get_schema(){if($_GET["ns"]!="")return$_GET["ns"];return
get_val("SELECT SCHEMA_NAME()");}function
set_schema($Zh){$_GET["ns"]=$Zh;return
true;}function
create_sql($R,$Da,$Li){if(is_view(table_status1($R))){$kk=view($R);return"CREATE VIEW ".table($R)." AS $kk[select]";}$o=array();$ph=false;foreach(fields($R)as$B=>$n){$X=process_field($n,$n);if($X[6])$ph=true;$o[]=implode("",$X);}foreach(indexes($R)as$B=>$v){if(!$ph||$v["type"]!="PRIMARY"){$e=array();foreach($v["columns"]as$x=>$X)$e[]=idf_escape($X).($v["descs"][$x]?" DESC":"");$B=idf_escape($B);$o[]=($v["type"]=="INDEX"?"INDEX $B":"CONSTRAINT $B ".($v["type"]=="UNIQUE"?"UNIQUE":"PRIMARY KEY"))." (".implode(", ",$e).")";}}foreach(driver()->checkConstraints($R)as$B=>$bb)$o[]="CONSTRAINT ".idf_escape($B)." CHECK ($bb)";return"CREATE TABLE ".table($R)." (\n\t".implode(",\n\t",$o)."\n)";}function
foreign_keys_sql($R){$o=array();foreach(foreign_keys($R)as$sd)$o[]=ltrim(format_foreign_key($sd));return($o?"ALTER TABLE ".table($R)." ADD\n\t".implode(",\n\t",$o).";\n\n":"");}function
truncate_sql($R){return"TRUNCATE TABLE ".table($R);}function
use_sql($Rb,$Li=""){return"USE ".idf_escape($Rb);}function
trigger_sql($R){$J="";foreach(triggers($R)as$B=>$Cj)$J
.=create_trigger(" ON ".table($R),trigger($B,$R)).";";return$J;}function
convert_field($n){}function
unconvert_field($n,$J){return$J;}function
support($ad){return
preg_match('~^(check|comment|columns|database|drop_col|dump|indexes|descidx|scheme|sql|table|trigger|view|view_trigger)$~',$ad);}}class
Adminer{static$instance;var$error='';function
name(){return"<a href='https://www.adminer.org/'".target_blank()." id='h1'><img src='".h(preg_replace("~\\?.*~","",ME)."?file=logo.png&version=5.5.1")."' width='24' height='24' alt='' id='logo'>Adminer</a>";}function
credentials(){return
array(SERVER,$_GET["username"],get_password());}function
connectSsl(){}function
permanentLogin($i=false){return
password_file($i);}function
bruteForceKey(){return$_SERVER["REMOTE_ADDR"];}function
serverName($N){return
h($N);}function
database(){return
DB;}function
databases($qd=true){return
get_databases($qd);}function
pluginsLinks(){}function
operators(){return
driver()->operators;}function
schemas(){return
schemas();}function
queryTimeout(){return
2;}function
afterConnect(){}function
headers(){}function
csp(array$Kb){return$Kb;}function
head($Ob=null){return
true;}function
bodyClass(){echo" adminer";}function
css(){$J=array();foreach(array("","-dark")as$Mf){$hd="adminer$Mf.css";if(file_exists($hd)){$gd=file_get_contents($hd);$J["$hd?v=".crc32($gd)]=($Mf?"dark":(preg_match('~prefers-color-scheme:\s*dark~',$gd)?'':'light'));}}return$J;}function
loginForm(){echo"<table class='layout'>\n",adminer()->loginFormField('driver','<tr><th>'.lang(33).'<td>',html_select("auth[driver]",SqlDriver::$drivers,DRIVER,"loginDriver(this);")),adminer()->loginFormField('server','<tr><th>'.lang(34).'<td>','<input name="auth[server]" value="'.h(SERVER).'" title="'.lang(35).'" placeholder="localhost" autocapitalize="off">'),adminer()->loginFormField('username','<tr><th>'.lang(36).'<td>','<input name="auth[username]" id="username" autofocus value="'.h($_GET["username"]).'" autocomplete="username" autocapitalize="off">'.script("const authDriver = qs('#username').form['auth[driver]']; authDriver && authDriver.onchange();")),adminer()->loginFormField('password','<tr><th>'.lang(37).'<td>','<input type="password" name="auth[password]" autocomplete="current-password">'),adminer()->loginFormField('db','<tr><th>'.lang(38).'<td>','<input name="auth[db]" value="'.h($_GET["db"]).'" autocapitalize="off">'),"</table>\n","<p><input type='submit' value='".lang(39)."'>\n",checkbox("auth[permanent]",1,$_COOKIE["adminer_permanent"],lang(40))."\n";}function
loginFormField($B,$Qd,$Y){return$Qd.$Y."\n";}function
login($jf,$F){if($F=="")return
lang(41,target_blank());return
true;}function
tableName(array$Ti){return
h($Ti["Name"]);}function
fieldName(array$n,$yg=0){$U=$n["full_type"].($n["null"]?" NULL":"");$sb=$n["comment"];return'<span title="'.h($U.($sb!=""?($U?": ":"").$sb:'')).'">'.h($n["field"]).'</span>';}function
selectLinks(array$Ti,$O=""){$B=$Ti["Name"];echo'<p class="links">';$ef=array("select"=>lang(42));if(support("table")||support("indexes"))$ef["table"]=lang(43);$Ge=false;if(support("table")){$Ge=is_view($Ti);if($Ge){if(support("view"))$ef["view"]=lang(44);}elseif(function_exists('Adminer\alter_table')&&$B!="")$ef["create"]=lang(45);}if($O!==null)$ef["edit"]=lang(46);foreach($ef
as$x=>$X)echo" <a href='".h(ME)."$x=".urlencode($B).($x=="edit"?$O:"")."'".bold(isset($_GET[$x])).">$X</a>";echo
doc_link(array(JUSH=>driver()->tableHelp($B,$Ge)),"?"),"\n";}function
foreignKeys($R){return
foreign_keys($R);}function
backwardKeys($R,$Si){return
array();}function
backwardKeysPrint(array$Ia,array$K){}function
selectQuery($H,$Hi,$Yc=false){$J="</p>\n";if(!$Yc&&($ok=driver()->warnings())){$t="warnings";$J=", <a href='#$t'>".lang(47)."</a>".script("qsl('a').onclick = partial(toggle, '$t');","")."$J<div id='$t' class='hidden'>\n$ok</div>\n";}return"<p><code class='jush-".JUSH."'>".h(str_replace("\n"," ",$H))."</code> <span class='time'>(".format_time($Hi).")</span>".(support("sql")?" <a href='".h(ME)."sql=".urlencode($H)."'>".lang(12)."</a>":"").$J;}function
sqlCommandQuery($H){return
shorten_utf8(trim($H),1000);}function
sqlPrintAfter(){}function
rowDescription($R){return"";}function
rowDescriptions(array$L,array$td){return$L;}function
selectLink($X,array$n){}function
selectVal($X,$_,array$n,$Hg){$J=($X===null?"<i>NULL</i>":(preg_match("~char|binary|boolean~",$n["type"])&&!preg_match("~var~",$n["type"])?"<code>$X</code>":(preg_match('~^jsonb?$~',$n["full_type"])?"<code class='jush-js'>$X</code>":$X)));if(is_blob($n)&&!is_utf8($X))$J="<i>".lang(48,strlen($Hg))."</i>";return($_?"<a href='".h($_)."'".(is_url($_)?target_blank():"").">$J</a>":$J);}function
editVal($X,array$n){return$X;}function
config(){return
array();}function
tableStructurePrint(array$o,$Ti=null){echo"<div class='scrollable'>\n","<table class='nowrap odds'>\n","<thead><tr><th>".lang(49)."<td>".lang(50).(support("comment")?"<td>".lang(51):"")."</thead>\n";$Ki=driver()->structuredTypes();foreach($o
as$n){echo"<tr><th>".h($n["field"]);$U=h($n["full_type"]);$c=h($n["collation"]);echo"<td><span title='$c'>".(in_array($U,(array)$Ki[lang(6)])?"<a href='".h(ME.'type='.urlencode($U))."'>$U</a>":$U.($c&&isset($Ti["Collation"])&&$c!=$Ti["Collation"]?" $c":""))."</span>",($n["null"]?" <i>NULL</i>":""),($n["auto_increment"]?" <i>".lang(52)."</i>":"");$l=h($n["default"]);echo(isset($n["default"])?" <span title='".lang(53)."'>[<b>".($n["generated"]?"<code class='jush-".JUSH."'>$l</code>":$l)."</b>]</span>":""),(support("comment")?"<td>".h($n["comment"]):""),"\n";}echo"</table>\n","</div>\n";}function
tableIndexesPrint(array$w,array$Ti){$Sg=false;foreach($w
as$B=>$v)$Sg|=!!$v["partial"];echo"<table>\n";$Wb=first(driver()->indexAlgorithms($Ti));foreach($w
as$B=>$v){ksort($v["columns"]);$rh=array();foreach($v["columns"]as$x=>$X)$rh[]="<i>".h($X)."</i>".($v["lengths"][$x]?"(".$v["lengths"][$x].")":"").($v["descs"][$x]?" DESC":"");echo"<tr title='".h($B)."'>","<th>$v[type]".($Wb&&$v['algorithm']!=$Wb?" ($v[algorithm])":""),"<td>".implode(", ",$rh);if($Sg)echo"<td>".($v['partial']?"<code class='jush-".JUSH."'>WHERE ".h($v['partial']):"");echo"\n";}echo"</table>\n";}function
selectColumnsPrint(array$M,array$e){print_fieldset("select",lang(54),$M);$s=0;$M[""]=array();foreach($M
as$x=>$X){$X=idx($_GET["columns"],$x,array());$d=select_input(" name='columns[$s][col]'",$e,$X["col"],($x!==""?"selectFieldChange":"selectAddRow"));echo"<div>".(driver()->functions||driver()->grouping?html_select("columns[$s][fun]",array(-1=>"")+array_filter(array(lang(55)=>driver()->functions,lang(56)=>driver()->grouping)),$X["fun"]).on_help("event.target.value && event.target.value.replace(/ |\$/, '(') + ')'",1).script("qsl('select').onchange = function () { helpClose();".($x!==""?"":" qsl('select, input', this.parentNode).onchange();")." };","")."($d)":$d)."</div>\n";$s++;}echo"</div></fieldset>\n";}function
selectSearchPrint(array$Z,array$e,array$w){print_fieldset("search",lang(57),$Z);foreach($w
as$s=>$v){if($v["type"]=="FULLTEXT")echo"<div>(<i>".implode("</i>, <i>",array_map('Adminer\h',$v["columns"]))."</i>) AGAINST"," <input type='search' name='fulltext[$s]' value='".h(idx($_GET["fulltext"],$s))."'>",script("qsl('input').oninput = selectFieldChange;",""),(JUSH=='sql'?checkbox("boolean[$s]",1,isset($_GET["boolean"][$s]),"BOOL"):''),"</div>\n";}$Ya="this.parentNode.firstChild.onchange();";foreach(array_merge((array)$_GET["where"],array(array()))as$s=>$X){if(!$X||("$X[col]$X[val]"!=""&&in_array($X["op"],adminer()->operators())))echo"<div>".select_input(" name='where[$s][col]'",$e,$X["col"],($X?"selectFieldChange":"selectAddRow"),"(".lang(58).")"),html_select("where[$s][op]",adminer()->operators(),$X["op"],$Ya),"<input type='search' name='where[$s][val]' value='".h($X["val"])."'>",script("mixin(qsl('input'), {oninput: function () { $Ya }, onkeydown: selectSearchKeydown, onsearch: selectSearchSearch});",""),"</div>\n";}echo"</div></fieldset>\n";}function
selectOrderPrint(array$yg,array$e,array$w){print_fieldset("sort",lang(59),$yg);$s=0;foreach((array)$_GET["order"]as$x=>$X){if($X!=""){echo"<div>".select_input(" name='order[$s]'",$e,$X,"selectFieldChange"),checkbox("desc[$s]",1,isset($_GET["desc"][$x]),lang(60))."</div>\n";$s++;}}echo"<div>".select_input(" name='order[$s]'",$e,"","selectAddRow"),checkbox("desc[$s]",1,false,lang(60))."</div>\n","</div></fieldset>\n";}function
selectLimitPrint($z){echo"<fieldset><legend>".lang(61)."</legend><div>","<input type='number' name='limit' class='size' value='".intval($z)."'>",script("qsl('input').oninput = selectFieldChange;",""),"</div></fieldset>\n";}function
selectLengthPrint($kj){if($kj!==null)echo"<fieldset><legend>".lang(62)."</legend><div>","<input type='number' name='text_length' class='size' value='".h($kj)."'>","</div></fieldset>\n";}function
selectActionPrint(array$w){echo"<fieldset><legend>".lang(63)."</legend><div>","<input type='submit' value='".lang(54)."'>"," <span id='noindex' title='".lang(64)."'></span>","<script".nonce().">\n","const indexColumns = ";$e=array();foreach($w
as$v){$Nb=reset($v["columns"]);if($v["type"]!="FULLTEXT"&&$Nb)$e[$Nb]=1;}$e[""]=1;foreach($e
as$x=>$X)json_row($x);echo";\n","selectFieldChange.call(qs('#form')['select']);\n","</script>\n","</div></fieldset>\n";}function
selectCommandPrint(){return!information_schema(DB);}function
selectImportPrint(){return!information_schema(DB);}function
selectEmailPrint(array$_c,array$e){}function
selectColumnsProcess(array$e,array$w){$M=array();$Ed=array();foreach((array)$_GET["columns"]as$x=>$X){if($X["fun"]=="count"||($X["col"]!=""&&(!$X["fun"]||in_array($X["fun"],driver()->functions)||in_array($X["fun"],driver()->grouping)))){$M[$x]=apply_sql_function($X["fun"],($X["col"]!=""?idf_escape($X["col"]):"*"));if(!in_array($X["fun"],driver()->grouping))$Ed[]=$M[$x];}}return
array($M,$Ed);}function
selectSearchProcess(array$o,array$w){$J=array();foreach($w
as$s=>$v){if($v["type"]=="FULLTEXT"&&idx($_GET["fulltext"],$s)!="")$J[]="MATCH (".implode(", ",array_map('Adminer\idf_escape',$v["columns"])).") AGAINST (".q($_GET["fulltext"][$s]).(isset($_GET["boolean"][$s])?" IN BOOLEAN MODE":"").")";}foreach((array)$_GET["where"]as$x=>$X){$lb=$X["col"];if("$lb$X[val]"!=""&&in_array($X["op"],adminer()->operators())){$wb=array();foreach(($lb!=""?array($lb=>$o[$lb]):$o)as$B=>$n){$mh="";$vb=" $X[op]";if(preg_match('~IN$~',$X["op"])){$fe=process_length($X["val"]);$vb
.=" ".($fe!=""?$fe:"(NULL)");}elseif($X["op"]=="SQL")$vb=" $X[val]";elseif(preg_match('~^(I?LIKE) %%$~',$X["op"],$A))$vb=" $A[1] ".adminer()->processInput($n,"%$X[val]%");elseif($X["op"]=="FIND_IN_SET"){$mh="$X[op](".q($X["val"]).", ";$vb=")";}elseif(!preg_match('~NULL$~',$X["op"]))$vb
.=" ".adminer()->processInput($n,$X["val"]);if($lb!=""||(isset($n["privileges"]["where"])&&(preg_match('~^[-\d.'.(preg_match('~IN$~',$X["op"])?',':'').']+$~',$X["val"])||!preg_match('~'.number_type().'|bit~',$n["type"]))&&(!preg_match("~[\x80-\xFF]~",$X["val"])||preg_match('~char|text|enum|set~',$n["type"]))&&(!preg_match('~date|timestamp~',$n["type"])||preg_match('~^\d+-\d+-\d+~',$X["val"]))))$wb[]=$mh.driver()->convertSearch(idf_escape($B),$X,$n).$vb;}$J[]=(count($wb)==1?$wb[0]:($wb?"(".implode(" OR ",$wb).")":"1 = 0"));}}return$J;}function
selectOrderProcess(array$o,array$w){$J=array();foreach((array)$_GET["order"]as$x=>$X){if($X!="")$J[]=(preg_match('~^((COUNT\(DISTINCT |[A-Z0-9_]+\()(`(?:[^`]|``)+`|"(?:[^"]|"")+")\)|COUNT\(\*\))$~',$X)?$X:idf_escape($X)).(isset($_GET["desc"][$x])?" DESC".(JUSH=='pgsql'&&idx($o[$X],"null")?" NULLS LAST":""):"");}return$J;}function
selectLimitProcess(){return(isset($_GET["limit"])?intval($_GET["limit"]):50);}function
selectLengthProcess(){return(isset($_GET["text_length"])?"$_GET[text_length]":"100");}function
selectEmailProcess(array$Z,array$td){return
false;}function
selectQueryBuild(array$M,array$Z,array$Ed,array$yg,$z,$D){return"";}function
messageQuery($H,$lj,$Yc=false){restart_session();$Sd=&get_session("queries");if(!idx($Sd,$_GET["db"]))$Sd[$_GET["db"]]=array();if(strlen($H)>1e6)$H=preg_replace('~[\x80-\xFF]+$~','',substr($H,0,1e6))."\n…";$Sd[$_GET["db"]][]=array($H,time(),$lj);$Di="sql-".count($Sd[$_GET["db"]]);$J="<a href='#$Di' class='toggle'>".lang(65)."</a> <a href='' class='jsonly copy'>🗐</a>\n";if(!$Yc&&($ok=driver()->warnings())){$t="warnings-".count($Sd[$_GET["db"]]);$J="<a href='#$t' class='toggle'>".lang(47)."</a>, $J<div id='$t' class='hidden'>\n$ok</div>\n";}return" <span class='time'>".@date("H:i:s")."</span>"." $J<div id='$Di' class='hidden'><pre><code class='jush-".JUSH."'>".shorten_utf8($H,1e4)."</code></pre>".($lj?" <span class='time'>($lj)</span>":'').(support("sql")?'<p><a href="'.h(str_replace("db=".urlencode(DB),"db=".urlencode($_GET["db"]),ME).'sql=&history='.(count($Sd[$_GET["db"]])-1)).'">'.lang(12).'</a>':'').'</div>';}function
editRowPrint($R,array$o,$K,$Rj){}function
editFunctions(array$n){$J=($n["null"]?"NULL/":"");$Rj=isset($_GET["select"])||where($_GET);foreach(array(driver()->insertFunctions,driver()->editFunctions)as$x=>$_d){if(!$x||(!isset($_GET["call"])&&$Rj)){foreach($_d
as$bh=>$X){if(!$bh||preg_match("~$bh~",$n["type"]))$J
.="/$X";}}if($x&&$_d&&!preg_match('~set|bool~',$n["type"])&&!is_blob($n))$J
.="/SQL";}if($n["auto_increment"]&&!$Rj)$J=lang(52);return
explode("/",$J);}function
editInput($R,array$n,$Ba,$Y){if($n["type"]=="enum")return(isset($_GET["select"])?"<label><input type='radio'$Ba value='orig' checked><i>".lang(10)."</i></label> ":"").enum_input("radio",$Ba,$n,$Y,"NULL");return"";}function
editHint($R,array$n,$Y){return"";}function
processInput(array$n,$Y,$r=""){if($r=="SQL")return$Y;$B=$n["field"];$J=q($Y);if(preg_match('~^(now|getdate|uuid)$~',$r))$J="$r()";elseif(preg_match('~^current_(date|timestamp)$~',$r))$J=$r;elseif(preg_match('~^([+-]|\|\|)$~',$r))$J=idf_escape($B)." $r $J";elseif(preg_match('~^[+-] interval$~',$r))$J=idf_escape($B)." $r ".(preg_match("~^(\\d+|'[0-9.: -]') [A-Z_]+\$~i",$Y)&&JUSH!="pgsql"?$Y:$J);elseif(preg_match('~^(addtime|subtime|concat)$~',$r))$J="$r(".idf_escape($B).", $J)";elseif(preg_match('~^(md5|sha1|password|encrypt)$~',$r))$J="$r($J)";return
unconvert_field($n,$J);}function
dumpOutput(){$J=array('text'=>lang(66),'file'=>lang(67));if(function_exists('gzencode'))$J['gz']='gzip';return$J;}function
dumpFormat(){return(support("dump")?array('sql'=>'SQL'):array())+array('csv'=>'CSV,','csv;'=>'CSV;','tsv'=>'TSV');}function
dumpDatabase($k){}function
dumpTable($R,$Li,$Ge=0){if($_POST["format"]!="sql"){echo"\xef\xbb\xbf";if($Li)dump_csv(array_keys(fields($R)));}else{if($Ge==2){$o=array();foreach(fields($R)as$B=>$n)$o[]=idf_escape($B)." $n[full_type]";$i="CREATE TABLE ".table($R)." (".implode(", ",$o).")";}else$i=create_sql($R,$_POST["auto_increment"],$Li);set_utf8mb4($i);if($Li&&$i){if($Li=="DROP+CREATE"||$Ge==1)echo"DROP ".($Ge==2?"VIEW":"TABLE")." IF EXISTS ".table($R).";\n";if($Ge==1)$i=remove_definer($i);echo"$i;\n\n";}}}function
dumpData($R,$Li,$H){if($Li){$tf=(JUSH=="sqlite"?0:1048576);$o=array();$be=false;if($_POST["format"]=="sql"){if($Li=="TRUNCATE+INSERT")echo
truncate_sql($R).";\n";$o=fields($R);if(JUSH=="mssql"){foreach($o
as$n){if($n["auto_increment"]){echo"SET IDENTITY_INSERT ".table($R)." ON;\n";$be=true;break;}}}}$I=connection()->query($H,1);if($I){$we="";$Sa="";$Me=array();$Ad=array();$Ni="";$bd=($R!=''?'fetch_assoc':'fetch_row');$Gb=0;while($K=$I->$bd()){if(!$Me){$gk=array();foreach($K
as$X){$n=$I->fetch_field();if(idx($o[$n->name],'generated')){$Ad[$n->name]=true;continue;}$Me[]=$n->name;$x=idf_escape($n->name);$gk[]="$x = VALUES($x)";}$Ni=($Li=="INSERT+UPDATE"?"\nON DUPLICATE KEY UPDATE ".implode(", ",$gk):"").";\n";}if($_POST["format"]!="sql"){if($Li=="table"){dump_csv($Me);$Li="INSERT";}dump_csv($K);}else{if(!$we)$we="INSERT INTO ".table($R)." (".implode(", ",array_map('Adminer\idf_escape',$Me)).") VALUES";foreach($K
as$x=>$X){if($Ad[$x]){unset($K[$x]);continue;}$n=$o[$x];$K[$x]=($X===null?"NULL":($X===false?0:unconvert_field($n,preg_match(number_type(),$n["type"])&&!preg_match('~\[~',$n["full_type"])&&is_numeric($X)?$X:(!is_blob($n)||is_utf8($X)?q($X):driver()->quoteBinary($X)))));}$Xh=($tf?"\n":" ")."(".implode(",\t",$K).")";if(!$Sa)$Sa=$we.$Xh;elseif(JUSH=='mssql'?$Gb%1000!=0:strlen($Sa)+4+strlen($Xh)+strlen($Ni)<$tf)$Sa
.=",$Xh";else{echo$Sa.$Ni;$Sa=$we.$Xh;}}$Gb++;}if($Sa)echo$Sa.$Ni;}elseif($_POST["format"]=="sql")echo"-- ".str_replace("\n"," ",connection()->error)."\n";if($be)echo"SET IDENTITY_INSERT ".table($R)." OFF;\n";}}function
dumpFilename($Zd){return
friendly_url($Zd!=""?$Zd:(SERVER?:"localhost"));}function
dumpHeaders($Zd,$Pf=false){$Kg=$_POST["output"];$Tc=(preg_match('~sql~',$_POST["format"])?"sql":($Pf?"tar":"csv"));header("Content-Type: ".($Kg=="gz"?"application/x-gzip":($Tc=="tar"?"application/x-tar":($Tc=="sql"||$Kg!="file"?"text/plain":"text/csv")."; charset=utf-8")));if($Kg=="gz"){ob_start(function($Q){return
gzencode($Q);},1e6);}return$Tc;}function
dumpFooter(){if($_POST["format"]=="sql")echo"-- ".gmdate("Y-m-d H:i:s e")."\n";}function
importServerPath(){return"adminer.sql";}function
homepage(){echo'<p class="links">'.($_GET["ns"]==""&&support("database")?'<a href="'.h(ME).'database=">'.lang(68)."</a>\n":""),(support("scheme")?"<a href='".h(ME)."scheme='>".($_GET["ns"]!=""?lang(69):lang(70))."</a>\n":""),($_GET["ns"]!==""?'<a href="'.h(ME).'schema=">'.lang(71)."</a>\n":""),(support("privileges")?"<a href='".h(ME)."privileges='>".lang(72)."</a>\n":"");if($_GET["ns"]!=="")echo(support("routine")?"<a href='#routines'>".lang(73)."</a>\n":""),(support("sequence")?"<a href='#sequences'>".lang(74)."</a>\n":""),(support("type")?"<a href='#user-types'>".lang(6)."</a>\n":""),(support("event")?"<a href='#events'>".lang(75)."</a>\n":"");return
true;}function
navigation($Lf){echo"<h1>".adminer()->name()." <span class='version'>".VERSION;$Yf=$_COOKIE["adminer_version"];echo" <a href='https://www.adminer.org/#download'".target_blank()." id='version'>".(version_compare(VERSION,$Yf)<0?h($Yf):"")."</a>","</span></h1>\n";switch_lang();if($Lf=="auth"){$Kg="";foreach((array)$_SESSION["pwds"]as$ik=>$qi){foreach($qi
as$N=>$bk){$B=h(get_setting("vendor-$ik-$N")?:get_driver($ik));foreach($bk
as$V=>$F){if($F!==null){$Ub=$_SESSION["db"][$ik][$N][$V];foreach(($Ub?array_keys($Ub):array(""))as$k)$Kg
.="<li><a href='".h(auth_url($ik,$N,$V,$k))."'>($B) ".h("$V@".($N!=""?adminer()->serverName($N):"").($k!=""?" - $k":""))."</a>\n";}}}}if($Kg)echo"<ul id='logins'>\n$Kg</ul>\n".script("mixin(qs('#logins'), {onmouseover: menuOver, onmouseout: menuOut});");}else{$T=array();if($_GET["ns"]!==""&&!$Lf&&DB!=""){connection()->select_db(DB);$T=table_status('',true);}adminer()->syntaxHighlighting($T);adminer()->databasesPrint($Lf);$la=array();if(DB==""||!$Lf){if(support("sql")){$la['sql']="<a href='".h(ME)."sql='".bold(isset($_GET["sql"])&&!isset($_GET["import"])).">".lang(65)."</a>";$la['import']="<a href='".h(ME)."import='".bold(isset($_GET["import"])).">".lang(76)."</a>";}$la['dump']="<a href='".h(ME)."dump=".urlencode(isset($_GET["table"])?$_GET["table"]:$_GET["select"])."' id='dump'".bold(isset($_GET["dump"])).">".lang(77)."</a>";}$ge=$_GET["ns"]!==""&&!$Lf&&DB!="";if($ge&&function_exists('Adminer\alter_table'))$la['create']='<a href="'.h(ME).'create="'.bold($_GET["create"]==="").">".lang(78)."</a>";$la=adminer()->menuActions($la,$Lf);echo($la?"<p class='links'>\n".implode("\n",$la)."\n":"");if($ge){if($T)adminer()->tablesPrint($T);else
echo"<p class='message'>".lang(11)."</p>\n";}}}function
syntaxHighlighting(array$T){echo
script_src(preg_replace("~\\?.*~","",ME)."?file=jush.js&version=5.5.1",true);if(support("sql")){echo"<script".nonce().">\n";if($T){$ef=array();foreach($T
as$R=>$U)$ef[]=preg_quote($R,'/');echo"var jushLinks = { ".JUSH.":";json_row(js_escape(ME).(support("table")?"table":"select").'=$&','/\b('.implode('|',$ef).')\b/g',false);if(support('routine')){foreach(routines()as$K)json_row(js_escape(ME).'function='.urlencode($K["SPECIFIC_NAME"]).'&name=$&','/\b'.preg_quote($K["ROUTINE_NAME"],'/').'(?=["`]?\()/g',false);}json_row('');echo"};\n";foreach(array("bac","bra","sqlite_quo","mssql_bra")as$X)echo"jushLinks.$X = jushLinks.".JUSH.";\n";if(isset($_GET["sql"])||isset($_GET["trigger"])||isset($_GET["check"])){$aj=array_fill_keys(array_keys($T),array());foreach(driver()->allFields()as$R=>$o){foreach($o
as$n)$aj[$R][]=$n["field"];}echo"addEventListener('DOMContentLoaded', () => { autocompleter = jush.autocompleteSql('".idf_escape("")."', ".json_encode($aj)."); });\n";}}echo"</script>\n";}echo
script("syntaxHighlighting('".(preg_match('~^\d\.?\d~',connection()->server_info,$A)?$A[0]:"")."', '".connection()->flavor."');");}function
databasesPrint($Lf){$j=adminer()->databases();if(DB&&$j&&!in_array(DB,$j))array_unshift($j,DB);echo"<form action=''>\n<p id='dbs'>\n";hidden_fields_get();$Sb=script("mixin(qsl('select'), {onmousedown: dbMouseDown, onchange: dbChange});");echo"<label title='".lang(38)."'>".lang(79).": ".($j?html_select("db",array(""=>"")+$j,DB).$Sb:"<input name='db' value='".h(DB)."' autocapitalize='off' size='19'>\n")."</label>","<input type='submit' value='".lang(22)."'".($j?" class='hidden'":"").">\n";if(support("scheme")){if($Lf!="db"&&DB!=""&&connection()->select_db(DB)){echo"<br><label>".lang(80).": ".html_select("ns",array(""=>"")+adminer()->schemas(),$_GET["ns"])."$Sb</label>";if($_GET["ns"]!="")set_schema($_GET["ns"]);}}foreach(array("import","sql","schema","dump","privileges")as$X){if(isset($_GET[$X])){echo
input_hidden($X);break;}}echo"</p></form>\n";}function
menuActions(array$la,$Lf){return$la;}function
tablesPrint(array$T){echo"<ul id='tables'>".script("mixin(qs('#tables'), {onmouseover: menuOver, onmouseout: menuOut});");foreach($T
as$R=>$P){$R="$R";$B=adminer()->tableName($P);if($B!=""&&!$P["partition"])echo'<li><a href="'.h(ME).'select='.urlencode($R).'"'.bold($_GET["select"]==$R||$_GET["edit"]==$R,"select")." title='".lang(42)."'>".lang(81)."</a> ",(support("table")||support("indexes")?'<a href="'.h(ME).'table='.urlencode($R).'"'.bold(in_array($R,array($_GET["table"],$_GET["create"],$_GET["indexes"],$_GET["foreign"],$_GET["trigger"],$_GET["check"],$_GET["view"])),(is_view($P)?"view":"structure"))." title='".lang(43)."'>$B</a>":"<span>$B</span>")."\n";}echo"</ul>\n";}function
showVariables(){return
show_variables();}function
showStatus(){return
show_status();}function
processList(){return
process_list();}function
killProcess($t){return
kill_process($t);}}class
Plugins{private
static$append=array('dumpFormat'=>true,'dumpOutput'=>true,'editRowPrint'=>true,'editFunctions'=>true,'config'=>true);var$plugins;var$error='';private$hooks=array();function
__construct($gh){if($gh===null){$gh=array();$Ma="adminer-plugins";if(is_dir($Ma)){foreach(glob("$Ma/*.php")as$hd)$this->includeOnce($hd);}$Rd=" href='https://www.adminer.org/plugins/#use'".target_blank();if(file_exists("$Ma.php")){$he=$this->includeOnce("$Ma.php");if(is_array($he)){foreach($he
as$fh)$gh[get_class($fh)]=$fh;}else$this->error
.=lang(82,"<b>$Ma.php</b>",$Rd)."<br>";}foreach(get_declared_classes()as$ib){if(!$gh[$ib]&&(preg_match('~^Adminer\w~i',$ib)||is_subclass_of($ib,'Adminer\Plugin'))){$Hh=new
\ReflectionClass($ib);$Ab=$Hh->getConstructor();if($Ab&&$Ab->getNumberOfRequiredParameters())$this->error
.=lang(83,$Rd,"<b>$ib</b>","<b>$Ma.php</b>")."<br>";else$gh[$ib]=new$ib;}}}$this->plugins=$gh;$oa=new
Adminer;$gh[]=$oa;$Hh=new
\ReflectionObject($oa);foreach($Hh->getMethods()as$Jf){foreach($gh
as$fh){$B=$Jf->getName();if(method_exists($fh,$B))$this->hooks[$B][]=$fh;}}}function
includeOnce($hd){return
include_once"./$hd";}function
__call($B,array$Pg){$ya=array();foreach($Pg
as$x=>$X)$ya[]=&$Pg[$x];$J=null;foreach($this->hooks[$B]as$fh){$Y=call_user_func_array(array($fh,$B),$ya);if($Y!==null){if(!self::$append[$B])return$Y;$J=$Y+(array)$J;}}return$J;}}abstract
class
Plugin{protected$translations=array();function
description(){return$this->lang('');}function
screenshot(){return"";}protected
function
lang($u,$eg=null){$ya=func_get_args();$ya[0]=idx($this->translations[LANG],$u)?:$u;return
call_user_func_array('Adminer\lang_format',$ya);}}Adminer::$instance=(function_exists('adminer_object')?adminer_object():(is_dir("adminer-plugins")||file_exists("adminer-plugins.php")?new
Plugins(null):new
Adminer));SqlDriver::$drivers=array("server"=>"MySQL / MariaDB")+SqlDriver::$drivers;if(!defined('Adminer\DRIVER')){define('Adminer\DRIVER',"server");if(extension_loaded("mysqli")&&$_GET["ext"]!="pdo"){class
Db
extends
\MySQLi{static$instance;var$extension="MySQLi",$flavor='';function
__construct(){parent::init();}function
attach($N,$V,$F){mysqli_report(MYSQLI_REPORT_OFF);list($Vd,$hh)=host_port($N);$Gi=adminer()->connectSsl();if($Gi)$this->ssl_set($Gi['key'],$Gi['cert'],$Gi['ca'],'','');$J=@$this->real_connect(($N!=""?$Vd:ini_get("mysqli.default_host")),($N.$V!=""?$V:ini_get("mysqli.default_user")),($N.$V.$F!=""?$F:ini_get("mysqli.default_pw")),null,(is_numeric($hh)?intval($hh):ini_get("mysqli.default_port")),(is_numeric($hh)?null:$hh),($Gi?($Gi['verify']!==false?2048:64):0));$this->options(MYSQLI_OPT_LOCAL_INFILE,0);return($J?'':$this->error);}function
set_charset($ab){if(parent::set_charset($ab))return
true;parent::set_charset('utf8');return$this->query("SET NAMES $ab");}function
next_result(){return
self::more_results()&&parent::next_result();}function
quote($Q){return"'".$this->escape_string($Q)."'";}}}elseif(extension_loaded("mysql")&&!((ini_bool("sql.safe_mode")||ini_bool("mysql.allow_local_infile"))&&extension_loaded("pdo_mysql"))){class
Db
extends
SqlDb{private$link;function
attach($N,$V,$F){if(ini_bool("mysql.allow_local_infile"))return
lang(84,"'mysql.allow_local_infile'","MySQLi","PDO_MySQL");$this->link=@mysql_connect(($N!=""?$N:ini_get("mysql.default_host")),($N.$V!=""?$V:ini_get("mysql.default_user")),($N.$V.$F!=""?$F:ini_get("mysql.default_password")),true,131072);if(!$this->link)return
mysql_error();$this->server_info=mysql_get_server_info($this->link);return'';}function
set_charset($ab){return
mysql_set_charset($ab,$this->link)||mysql_set_charset('utf8',$this->link);}function
quote($Q){return"'".mysql_real_escape_string($Q,$this->link)."'";}function
select_db($Rb){return
mysql_select_db($Rb,$this->link);}function
query($H,$Jj=false){$I=@($Jj?mysql_unbuffered_query($H,$this->link):mysql_query($H,$this->link));$this->error="";if(!$I){$this->errno=mysql_errno($this->link);$this->error=mysql_error($this->link);return
false;}if($I===true){$this->affected_rows=mysql_affected_rows($this->link);$this->info=mysql_info($this->link);return
true;}return
new
Result($I);}}class
Result{var$num_rows;private$result;private$offset=0;function
__construct($I){$this->result=$I;$this->num_rows=mysql_num_rows($I);}function
fetch_assoc(){return
mysql_fetch_assoc($this->result);}function
fetch_row(){return
mysql_fetch_row($this->result);}function
fetch_field(){$J=mysql_fetch_field($this->result,$this->offset++);$J->orgtable=$J->table;$J->charsetnr=($J->blob?63:0);return$J;}}}elseif(extension_loaded("pdo_mysql")){class
Db
extends
PdoDb{var$extension="PDO_MySQL";function
attach($N,$V,$F){$wg=array(\PDO::MYSQL_ATTR_LOCAL_INFILE=>false);$Gi=adminer()->connectSsl();if($Gi){if($Gi['key'])$wg[\PDO::MYSQL_ATTR_SSL_KEY]=$Gi['key'];if($Gi['cert'])$wg[\PDO::MYSQL_ATTR_SSL_CERT]=$Gi['cert'];if($Gi['ca'])$wg[\PDO::MYSQL_ATTR_SSL_CA]=$Gi['ca'];if(isset($Gi['verify']))$wg[\PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT]=$Gi['verify'];}list($Vd,$hh)=host_port($N);return$this->dsn("mysql:charset=utf8".($Vd!=""?";host=$Vd":'').($hh?(is_numeric($hh)?";port=":";unix_socket=").$hh:""),$V,$F,$wg);}function
set_charset($ab){return$this->query("SET NAMES $ab");}function
select_db($Rb){return$this->query("USE ".idf_escape($Rb));}function
query($H,$Jj=false){$this->pdo->setAttribute(\PDO::MYSQL_ATTR_USE_BUFFERED_QUERY,!$Jj);return
parent::query($H,$Jj);}}}class
Driver
extends
SqlDriver{static$extensions=array("MySQLi","MySQL","PDO_MySQL");static$jush="sql";var$unsigned=array("unsigned","zerofill","unsigned zerofill");var$operators=array("=","<",">","<=",">=","!=","LIKE","LIKE %%","REGEXP","IN","FIND_IN_SET","IS NULL","NOT LIKE","NOT REGEXP","NOT IN","IS NOT NULL","SQL");var$functions=array("char_length","date","from_unixtime","lower","round","floor","ceil","sec_to_time","time_to_sec","upper");var$grouping=array("avg","count","count distinct","group_concat","max","min","sum");var$partitionBy=array("HASH","LINEAR HASH","KEY","LINEAR KEY","RANGE","LIST");static
function
connect($N,$V,$F){$g=parent::connect($N,$V,$F);if(is_string($g)){if(function_exists('iconv')&&!is_utf8($g)&&strlen($Xh=iconv("windows-1250","utf-8",$g))>strlen($g))$g=$Xh;return$g;}$g->set_charset(charset($g));$g->query("SET sql_quote_show_create = 1, autocommit = 1");$g->flavor=(preg_match('~MariaDB~',$g->server_info)?'maria':'mysql');add_driver(DRIVER,($g->flavor=='maria'?"MariaDB":"MySQL"));return$g;}function
__construct(Db$g){parent::__construct($g);$this->types=array(lang(27)=>array("tinyint"=>3,"smallint"=>5,"mediumint"=>8,"int"=>10,"bigint"=>20,"decimal"=>66,"float"=>12,"double"=>21),lang(28)=>array("date"=>10,"datetime"=>19,"timestamp"=>19,"time"=>10,"year"=>4),lang(29)=>array("char"=>255,"varchar"=>65535,"tinytext"=>255,"text"=>65535,"mediumtext"=>16777215,"longtext"=>4294967295),lang(85)=>array("enum"=>65535,"set"=>64),lang(30)=>array("bit"=>20,"binary"=>255,"varbinary"=>65535,"tinyblob"=>255,"blob"=>65535,"mediumblob"=>16777215,"longblob"=>4294967295),lang(32)=>array("geometry"=>0,"point"=>0,"linestring"=>0,"polygon"=>0,"multipoint"=>0,"multilinestring"=>0,"multipolygon"=>0,"geometrycollection"=>0),);$this->insertFunctions=array("char"=>"md5/sha1/password/encrypt/uuid","binary"=>"md5/sha1","date|time"=>"now",);$this->editFunctions=array(number_type()=>"+/-","date"=>"+ interval/- interval","time"=>"addtime/subtime","char|text"=>"concat",);if(min_version('5.7.8',10.2,$g))$this->types[lang(29)]["json"]=4294967295;if(min_version('',10.7,$g)){$this->types[lang(29)]["uuid"]=128;$this->insertFunctions['uuid']='uuid';}if(min_version('',10.5,$g)){$this->types[lang(31)]["inet6"]=39;if(min_version('','10.10',$g))$this->types[lang(31)]["inet4"]=15;}if(min_version(9,11.7,$g))$this->types[lang(27)]["vector"]=16383;if(min_version(5.7,10.2,$g))$this->generated=array("STORED","VIRTUAL");}function
unconvertFunction(array$n){return(preg_match("~binary~",$n["type"])?"<code class='jush-sql'>UNHEX</code>":($n["type"]=="bit"?doc_link(array('sql'=>'bit-value-literals.html'),"<code>b''</code>"):($n["type"]=="vector"?"<code class='jush-sql'>".($this->conn->flavor=='maria'?"VEC_FromText":"STRING_TO_VECTOR")."</code>":(preg_match("~geometry|point|linestring|polygon~",$n["type"])?"<code class='jush-sql'>GeomFromText</code>":""))));}function
insert($R,array$O){return($O?parent::insert($R,$O):queries("INSERT INTO ".table($R)." ()\nVALUES ()"));}function
insertUpdate($R,array$L,array$ph){$e=array_keys(reset($L));$mh="INSERT INTO ".table($R)." (".implode(", ",$e).") VALUES\n";$gk=array();foreach($e
as$x)$gk[$x]="$x = VALUES($x)";$Ni="\nON DUPLICATE KEY UPDATE ".implode(", ",$gk);$gk=array();$y=0;foreach($L
as$O){$Y="(".implode(", ",$O).")";if($gk&&(strlen($mh)+$y+strlen($Y)+strlen($Ni)>1e6)){if(!queries($mh.implode(",\n",$gk).$Ni))return
false;$gk=array();$y=0;}$gk[]=$Y;$y+=strlen($Y)+2;}return
queries($mh.implode(",\n",$gk).$Ni);}function
slowQuery($H,$mj){if(min_version('5.7.8','10.1.2')){if($this->conn->flavor=='maria')return"SET STATEMENT max_statement_time=$mj FOR $H";elseif(preg_match('~^(SELECT\b)(.+)~is',$H,$A))return"$A[1] /*+ MAX_EXECUTION_TIME(".($mj*1000).") */ $A[2]";}}function
convertSearch($u,array$X,array$n){return(preg_match('~char|text|enum|set~',$n["type"])&&!preg_match("~^utf8~",$n["collation"])&&preg_match('~[\x80-\xFF]~',$X['val'])?"CONVERT($u USING ".charset($this->conn).")":$u);}function
quoteBinary($Xh){return"X".q(bin2hex($Xh));}function
warnings(){$I=$this->conn->query("SHOW WARNINGS");if($I&&$I->num_rows){ob_start();print_select_result($I);return
ob_get_clean();}}function
tableHelp($B,$Ge=false){$lf=($this->conn->flavor=='maria');if(information_schema(DB))return
strtolower("information-schema-".($lf?"$B-table/":str_replace("_","-",$B)."-table.html"));if(DB=="mysql")return($lf?"mysql$B-table/":"system-schema.html");}function
partitionsInfo($R){$yd="FROM information_schema.PARTITIONS WHERE TABLE_SCHEMA = ".q(DB)." AND TABLE_NAME = ".q($R);$I=$this->conn->query("SELECT PARTITION_METHOD, PARTITION_EXPRESSION, PARTITION_ORDINAL_POSITION $yd ORDER BY PARTITION_ORDINAL_POSITION DESC LIMIT 1");$J=array();list($J["partition_by"],$J["partition"],$J["partitions"])=$I->fetch_row();$Xg=get_key_vals("SELECT PARTITION_NAME, PARTITION_DESCRIPTION $yd AND PARTITION_NAME != '' ORDER BY PARTITION_ORDINAL_POSITION");$J["partition_names"]=array_keys($Xg);$J["partition_values"]=array_values($Xg);return$J;}function
hasCStyleEscapes(){static$Va;if($Va===null){$Ei=get_val("SHOW VARIABLES LIKE 'sql_mode'",1,$this->conn);$Va=(strpos($Ei,'NO_BACKSLASH_ESCAPES')===false);}return$Va;}function
engines(){$J=array();foreach(get_rows("SHOW ENGINES")as$K){if(preg_match("~YES|DEFAULT~",$K["Support"]))$J[]=$K["Engine"];}return$J;}function
indexAlgorithms(array$Ti){return(preg_match('~^(MEMORY|NDB)$~',$Ti["Engine"])?array("HASH","BTREE"):array());}}function
idf_escape($u){return"`".str_replace("`","``",$u)."`";}function
table($u){return
idf_escape($u);}function
get_databases($qd){$J=get_session("dbs");if($J===null){$H="SELECT SCHEMA_NAME FROM information_schema.SCHEMATA ORDER BY SCHEMA_NAME";$J=($qd?slow_query($H):get_vals($H));restart_session();set_session("dbs",$J);stop_session();}return$J;}function
limit($H,$Z,$z,$C=0,$li=" "){return" $H$Z".($z?$li."LIMIT $z".($C?" OFFSET $C":""):"");}function
limit1($R,$H,$Z,$li="\n"){return
limit($H,$Z,1,0,$li);}function
db_collation($k,array$nb){$J=null;$i=get_val("SHOW CREATE DATABASE ".idf_escape($k),1);if(preg_match('~ COLLATE ([^ ]+)~',$i,$A))$J=$A[1];elseif(preg_match('~ CHARACTER SET ([^ ]+)~',$i,$A))$J=$nb[$A[1]][-1];return$J;}function
logged_user(){return
get_val("SELECT USER()");}function
tables_list(){return
get_key_vals("SELECT TABLE_NAME, TABLE_TYPE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME");}function
count_tables(array$j){$J=array();foreach($j
as$k)$J[$k]=count(get_vals("SHOW TABLES IN ".idf_escape($k)));return$J;}function
table_status($B="",$Zc=false){$J=array();foreach(get_rows($Zc?"SELECT TABLE_NAME AS Name, ENGINE AS Engine, TABLE_COMMENT AS Comment FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() ".($B!=""?"AND TABLE_NAME = ".q($B):"ORDER BY Name"):"SHOW TABLE STATUS".($B!=""?" LIKE ".q(addcslashes($B,"%_\\")):""))as$K){if($K["Engine"]=="InnoDB")$K["Comment"]=preg_replace('~(?:(.+); )?InnoDB free: .*~','\1',$K["Comment"]);if(!isset($K["Engine"]))$K["Comment"]="";if($B!="")$K["Name"]=$B;$J[$K["Name"]]=$K;}return$J;}function
is_view(array$S){return$S["Engine"]===null;}function
fk_support(array$S){return
preg_match('~InnoDB|IBMDB2I'.(min_version(5.6)?'|NDB':'').'~i',$S["Engine"]);}function
fields($R){$lf=(connection()->flavor=='maria');$J=array();foreach(get_rows("SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ".q($R)." ORDER BY ORDINAL_POSITION")as$K){$n=$K["COLUMN_NAME"];$U=$K["COLUMN_TYPE"];$Bd=$K["GENERATION_EXPRESSION"];$Wc=$K["EXTRA"];preg_match('~^(VIRTUAL|PERSISTENT|STORED)~',$Wc,$Ad);preg_match('~^([^( ]+)(?:\((.+)\))?( unsigned)?( zerofill)?$~',$U,$of);$l=$K["COLUMN_DEFAULT"];if($l!=""){$Fe=preg_match('~text|json~',$of[1]);if(!$lf&&$Fe)$l=preg_replace("~^(_\w+)?('.*')$~",'\2',stripslashes($l));if($lf||$Fe){$l=($l=="NULL"?null:preg_replace_callback("~^'(.*)'$~",function($A){return
stripslashes(str_replace("''","'",$A[1]));},$l));}if(!$lf&&preg_match('~binary~',$of[1])&&preg_match('~^0x(\w*)$~',$l,$A))$l=pack("H*",$A[1]);}$J[$n]=array("field"=>$n,"full_type"=>$U,"type"=>$of[1],"length"=>$of[2],"unsigned"=>ltrim($of[3].$of[4]),"default"=>($Ad?($lf?$Bd:stripslashes($Bd)):$l),"null"=>($K["IS_NULLABLE"]=="YES"),"auto_increment"=>($Wc=="auto_increment"),"on_update"=>(preg_match('~\bon update (\w+)~i',$Wc,$A)?$A[1]:""),"collation"=>$K["COLLATION_NAME"],"privileges"=>array_flip(explode(",","$K[PRIVILEGES],where,order")),"comment"=>$K["COLUMN_COMMENT"],"primary"=>($K["COLUMN_KEY"]=="PRI"),"generated"=>($Ad[1]=="PERSISTENT"?"STORED":$Ad[1]),);}return$J;}function
indexes($R,$h=null){$J=array();foreach(get_rows("SHOW INDEX FROM ".table($R),$h)as$K){$B=$K["Key_name"];$J[$B]["type"]=($B=="PRIMARY"?"PRIMARY":($K["Index_type"]=="FULLTEXT"?"FULLTEXT":($K["Non_unique"]?(preg_match('~^(SPATIAL|VECTOR)$~',$K["Index_type"])?$K["Index_type"]:"INDEX"):"UNIQUE")));$J[$B]["columns"][]=$K["Column_name"];$J[$B]["lengths"][]=($K["Index_type"]=="SPATIAL"?null:$K["Sub_part"]);$J[$B]["descs"][]=null;$J[$B]["algorithm"]=$K["Index_type"];}return$J;}function
foreign_keys($R){static$bh='(?:`(?:[^`]|``)+`|"(?:[^"]|"")+")';$J=array();$Hb=get_val("SHOW CREATE TABLE ".table($R),1);if($Hb){preg_match_all("~CONSTRAINT ($bh) FOREIGN KEY ?\\(((?:$bh,? ?)+)\\) REFERENCES ($bh)(?:\\.($bh))? \\(((?:$bh,? ?)+)\\)(?: ON DELETE (".driver()->onActions."))?(?: ON UPDATE (".driver()->onActions."))?~",$Hb,$pf,PREG_SET_ORDER);foreach($pf
as$A){preg_match_all("~$bh~",$A[2],$zi);preg_match_all("~$bh~",$A[5],$ej);$J[idf_unescape($A[1])]=array("db"=>idf_unescape($A[4]!=""?$A[3]:$A[4]),"table"=>idf_unescape($A[4]!=""?$A[4]:$A[3]),"source"=>array_map('Adminer\idf_unescape',$zi[0]),"target"=>array_map('Adminer\idf_unescape',$ej[0]),"on_delete"=>($A[6]?:"RESTRICT"),"on_update"=>($A[7]?:"RESTRICT"),);}}return$J;}function
view($B){return
array("select"=>preg_replace('~^(?:[^`]|`[^`]*`)*\s+AS\s+~isU','',get_val("SHOW CREATE VIEW ".table($B),1)));}function
collations(){$J=array();foreach(get_rows("SHOW COLLATION")as$K){if($K["Default"])$J[$K["Charset"]][-1]=$K["Collation"];else$J[$K["Charset"]][]=$K["Collation"];}ksort($J);foreach($J
as$x=>$X)sort($J[$x]);return$J;}function
information_schema($k){return($k=="information_schema")||(min_version(5.5)&&$k=="performance_schema");}function
error(){return
h(preg_replace('~^You have an error.*syntax to use~U',"Syntax error",connection()->error));}function
create_database($k,$c){return
queries("CREATE DATABASE ".idf_escape($k).($c?" COLLATE ".q($c):""));}function
drop_databases(array$j){$J=apply_queries("DROP DATABASE",$j,'Adminer\idf_escape');restart_session();set_session("dbs",null);return$J;}function
rename_database($B,$c){$J=false;if(create_database($B,$c)){$T=array();$lk=array();foreach(tables_list()as$R=>$U){if($U=='VIEW')$lk[]=$R;else$T[]=$R;}$J=(!$T&&!$lk)||move_tables($T,$lk,$B);drop_databases($J?array(DB):array());}return$J;}function
auto_increment(){$Ea=" PRIMARY KEY";if($_GET["create"]!=""&&$_POST["auto_increment_col"]){foreach(indexes($_GET["create"])as$v){if(in_array($_POST["fields"][$_POST["auto_increment_col"]]["orig"],$v["columns"],true)){$Ea="";break;}if($v["type"]=="PRIMARY")$Ea=" UNIQUE";}}return" AUTO_INCREMENT$Ea";}function
alter_table($R,$B,array$o,array$sd,$sb,$Cc,$c,$Da,$E){$b=array();foreach($o
as$n){if($n[1]){$l=$n[1][3];if(preg_match('~ GENERATED~',$l)){$n[1][3]=(connection()->flavor=='maria'?"":$n[1][2]);$n[1][2]=$l;}$b[]=($R!=""?($n[0]!=""?"CHANGE ".idf_escape($n[0]):"ADD"):" ")." ".implode($n[1]).($R!=""?$n[2]:"");}else$b[]="DROP ".idf_escape($n[0]);}$b=array_merge($b,$sd);$P=($sb!==null?" COMMENT=".q($sb):"").($Cc?" ENGINE=".q($Cc):"").($c?" COLLATE ".q($c):"").($Da!=""?" AUTO_INCREMENT=$Da":"");if($E){$Xg=array();if($E["partition_by"]=='RANGE'||$E["partition_by"]=='LIST'){foreach($E["partition_names"]as$x=>$X){$Y=$E["partition_values"][$x];$Xg[]="\n  PARTITION ".idf_escape($X)." VALUES ".($E["partition_by"]=='RANGE'?"LESS THAN":"IN").($Y!=""?" ($Y)":" MAXVALUE");}}$P
.="\nPARTITION BY $E[partition_by]($E[partition])";if($Xg)$P
.=" (".implode(",",$Xg)."\n)";elseif($E["partitions"])$P
.=" PARTITIONS ".(+$E["partitions"]);}elseif($E===null)$P
.="\nREMOVE PARTITIONING";if($R=="")return
queries("CREATE TABLE ".table($B)." (\n".implode(",\n",$b)."\n)$P");if($R!=$B)$b[]="RENAME TO ".table($B);if($P)$b[]=ltrim($P);return($b?queries("ALTER TABLE ".table($R)."\n".implode(",\n",$b)):true);}function
alter_indexes($R,$b){$Za=array();foreach($b
as$X)$Za[]=($X[2]=="DROP"?"\nDROP INDEX ".idf_escape($X[1]):"\nADD $X[0] ".($X[0]=="PRIMARY"?"KEY ":"").($X[1]!=""?idf_escape($X[1])." ":"")."(".implode(", ",$X[2]).")");return
queries("ALTER TABLE ".table($R).implode(",",$Za));}function
truncate_tables(array$T){return
apply_queries("TRUNCATE TABLE",$T);}function
drop_views(array$lk){return
queries("DROP VIEW ".implode(", ",array_map('Adminer\table',$lk)));}function
drop_tables(array$T){return
queries("DROP TABLE ".implode(", ",array_map('Adminer\table',$T)));}function
move_tables(array$T,array$lk,$ej){$Lh=array();foreach($T
as$R)$Lh[]=table($R)." TO ".idf_escape($ej).".".table($R);if(!$Lh||queries("RENAME TABLE ".implode(", ",$Lh))){$ac=array();foreach($lk
as$R)$ac[table($R)]=view($R);connection()->select_db($ej);$k=idf_escape(DB);foreach($ac
as$B=>$kk){if(!queries("CREATE VIEW $B AS ".str_replace(" $k."," ",$kk["select"]))||!queries("DROP VIEW $k.$B"))return
false;}return
true;}return
false;}function
copy_tables(array$T,array$lk,$ej){queries("SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO'");foreach($T
as$R){$B=($ej==DB?table("copy_$R"):idf_escape($ej).".".table($R));if(($_POST["overwrite"]&&!queries("\nDROP TABLE IF EXISTS $B"))||!queries("CREATE TABLE $B LIKE ".table($R))||!queries("INSERT INTO $B SELECT * FROM ".table($R)))return
false;foreach(get_rows("SHOW TRIGGERS LIKE ".q(addcslashes($R,"%_\\")))as$K){$Cj=$K["Trigger"];if(!queries("CREATE TRIGGER ".($ej==DB?idf_escape("copy_$Cj"):idf_escape($ej).".".idf_escape($Cj))." $K[Timing] $K[Event] ON $B FOR EACH ROW\n$K[Statement];"))return
false;}}foreach($lk
as$R){$B=($ej==DB?table("copy_$R"):idf_escape($ej).".".table($R));$kk=view($R);if(($_POST["overwrite"]&&!queries("DROP VIEW IF EXISTS $B"))||!queries("CREATE VIEW $B AS $kk[select]"))return
false;}return
true;}function
trigger($B,$R){if($B=="")return
array();$L=get_rows("SHOW TRIGGERS WHERE `Trigger` = ".q($B));return
reset($L);}function
triggers($R){$J=array();foreach(get_rows("SHOW TRIGGERS LIKE ".q(addcslashes($R,"%_\\")))as$K)$J[$K["Trigger"]]=array($K["Timing"],$K["Event"]);return$J;}function
trigger_options(){return
array("Timing"=>array("BEFORE","AFTER"),"Event"=>array("INSERT","UPDATE","DELETE"),"Type"=>array("FOR EACH ROW"),);}function
routine($B,$U){$o=get_rows("SELECT
	PARAMETER_NAME field,
	DATA_TYPE type,
	REGEXP_REPLACE(DTD_IDENTIFIER, '^[^(]+\\\\(?|\\\\)$', '') length,
	REGEXP_REPLACE(DTD_IDENTIFIER, '^[^ ]+ ', '') `unsigned`,
	1 `null`,
	DTD_IDENTIFIER full_type,
	".($U=="FUNCTION"?"''":"PARAMETER_MODE")." `inout`,
	CHARACTER_SET_NAME collation
FROM information_schema.PARAMETERS
WHERE SPECIFIC_SCHEMA = DATABASE() AND ROUTINE_TYPE = '$U' AND SPECIFIC_NAME = ".q($B)."
ORDER BY ORDINAL_POSITION");$J=connection()->query("SELECT
	ROUTINE_COMMENT comment,
	CONCAT(IF(IS_DETERMINISTIC = 'YES', 'DETERMINISTIC\\n', ''), IF(SQL_DATA_ACCESS != 'CONTAINS SQL', CONCAT(SQL_DATA_ACCESS, '\\n'), ''), ROUTINE_DEFINITION) definition,
	'SQL' language
FROM information_schema.ROUTINES
WHERE ROUTINE_SCHEMA = DATABASE() AND ROUTINE_TYPE = '$U' AND ROUTINE_NAME = ".q($B))->fetch_assoc();if($o&&$o[0]['field']=='')$J['returns']=array_shift($o);$J['fields']=$o;return$J;}function
routines(){return
get_rows("SELECT SPECIFIC_NAME, ROUTINE_NAME, ROUTINE_TYPE, DTD_IDENTIFIER FROM information_schema.ROUTINES WHERE ROUTINE_SCHEMA = DATABASE()");}function
routine_languages(){return
array();}function
routine_id($B,array$K){return
idf_escape($B);}function
last_id($I){return
get_val("SELECT LAST_INSERT_ID()");}function
explain(Db$g,$H){return$g->query("EXPLAIN ".(min_version(5.7)?"":"PARTITIONS ").$H);}function
found_rows(array$S,array$Z){return($Z||$S["Engine"]!="InnoDB"?null:$S["Rows"]);}function
create_sql($R,$Da,$Li){$J=get_val("SHOW CREATE TABLE ".table($R),1);if(!$Da)$J=preg_replace('~ AUTO_INCREMENT=\d+~','',$J);return$J;}function
truncate_sql($R){return"TRUNCATE ".table($R);}function
use_sql($Rb,$Li=""){$B=idf_escape($Rb);$J="";if(preg_match('~CREATE~',$Li)&&($i=get_val("SHOW CREATE DATABASE $B",1))){set_utf8mb4($i);if($Li=="DROP+CREATE")$J="DROP DATABASE IF EXISTS $B;\n";$J
.="$i;\n";}return$J."USE $B";}function
trigger_sql($R){$J="";foreach(get_rows("SHOW TRIGGERS LIKE ".q(addcslashes($R,"%_\\")),null,"-- ")as$K)$J
.="\nCREATE TRIGGER ".idf_escape($K["Trigger"])." $K[Timing] $K[Event] ON ".table($K["Table"])." FOR EACH ROW\n$K[Statement];;\n";return$J;}function
show_variables(){return
get_rows("SHOW VARIABLES");}function
show_status(){return
get_rows("SHOW STATUS");}function
process_list(){return
get_rows("SHOW FULL PROCESSLIST");}function
convert_field(array$n){if(preg_match("~binary~",$n["type"]))return"HEX(".idf_escape($n["field"]).")";if($n["type"]=="bit")return"BIN(".idf_escape($n["field"])." + 0)";if($n["type"]=="vector")return(connection()->flavor=='maria'?"VEC_ToText":"VECTOR_TO_STRING")."(".idf_escape($n["field"]).")";if(preg_match("~geometry|point|linestring|polygon~",$n["type"]))return(min_version(8)?"ST_":"")."AsWKT(".idf_escape($n["field"]).")";}function
unconvert_field(array$n,$J){if(preg_match("~binary~",$n["type"]))$J="UNHEX($J)";if($n["type"]=="bit")$J="CONVERT(b$J, UNSIGNED)";if($n["type"]=="vector")$J=(connection()->flavor=='maria'?"VEC_FromText":"STRING_TO_VECTOR")."($J)";if(preg_match("~geometry|point|linestring|polygon~",$n["type"])){$mh=(min_version(8)?"ST_":"");$J=$mh."GeomFromText($J, $mh"."SRID($n[field]))";}return$J;}function
support($ad){return
preg_match('~^(comment|columns|copy|database|drop_col|dump|event|indexes|kill|privileges|move_col|procedure|processlist|routine|sql|status|table|trigger|variables|view'.(min_version(8)?'|descidx':'').(min_version('8.0.16','10.2.1')?'|check':'').')$~',$ad);}function
kill_process($t){return
queries("KILL ".number($t));}function
connection_id(){return"SELECT CONNECTION_ID()";}function
max_connections(){return
get_val("SELECT @@max_connections");}function
types(){return
array();}function
type_values($t){return"";}function
schemas(){return
array();}function
get_schema(){return"";}function
set_schema($Zh,$h=null){return
true;}}define('Adminer\JUSH',Driver::$jush);define('Adminer\SERVER',"".$_GET[DRIVER]);define('Adminer\DB',"$_GET[db]");define('Adminer\ME',preg_replace('~\?.*~','',relative_uri()).'?'.(sid()?SID.'&':'').(SERVER!==null?DRIVER."=".urlencode(SERVER).'&':'').($_GET["ext"]?"ext=".urlencode($_GET["ext"]).'&':'').(isset($_GET["username"])?"username=".urlencode($_GET["username"]).'&':'').(DB!=""?'db='.urlencode(DB).'&'.(isset($_GET["ns"])?"ns=".urlencode($_GET["ns"])."&":""):''));function
page_header($oj,$m="",$Ra=array(),$pj=""){page_headers();if(is_ajax()&&$m){page_messages($m);exit;}if(!ob_get_level())ob_start('ob_gzhandler',4096);$qj=$oj.($pj!=""?": $pj":"");$rj=strip_tags($qj.(SERVER!=""&&SERVER!="localhost"?h(" - ".SERVER):"")." - ".adminer()->name());echo'<!DOCTYPE html>
<html lang="',LANG,'" dir="',lang(86),'">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="robots" content="noindex">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>',$rj,'</title>
<link rel="stylesheet" href="',h(preg_replace("~\\?.*~","",ME)."?file=default.css&version=5.5.1"),'">
';$Lb=adminer()->css();if(is_int(key($Lb)))$Lb=array_fill_keys($Lb,'light');$Nd=in_array('light',$Lb)||in_array('',$Lb);$Ld=in_array('dark',$Lb)||in_array('',$Lb);$Ob=($Nd?($Ld?null:false):($Ld?:null));$zf=" media='(prefers-color-scheme: dark)'";if($Ob!==false)echo"<link rel='stylesheet'".($Ob?"":$zf)." href='".h(preg_replace("~\\?.*~","",ME)."?file=dark.css&version=5.5.1")."'>\n";echo"<meta name='color-scheme' content='".($Ob===null?"light dark":($Ob?"dark":"light"))."'>\n",script_src(preg_replace("~\\?.*~","",ME)."?file=functions.js&version=5.5.1");if(adminer()->head($Ob))echo"<link rel='icon' href='data:image/gif;base64,R0lGODlhEAAQAJEAAAQCBPz+/PwCBAROZCH5BAEAAAAALAAAAAAQABAAAAI2hI+pGO1rmghihiUdvUBnZ3XBQA7f05mOak1RWXrNq5nQWHMKvuoJ37BhVEEfYxQzHjWQ5qIAADs='>\n","<link rel='apple-touch-icon' href='".h(preg_replace("~\\?.*~","",ME)."?file=logo.png&version=5.5.1")."'>\n";foreach($Lb
as$Vj=>$Mf){$Ba=($Mf=='dark'&&!$Ob?$zf:($Mf=='light'&&$Ld?" media='(prefers-color-scheme: light)'":""));echo"<link rel='stylesheet'$Ba href='".h($Vj)."'>\n";}echo"\n<body class='".lang(86)." nojs";adminer()->bodyClass();echo"'>\n",script("mixin(document.body, {onkeydown: bodyKeydown, onclick: bodyClick".(isset($_COOKIE["adminer_version"])?"":", onload: partial(verifyVersion, '".VERSION."')")."});
document.body.classList.replace('nojs', 'js');
if (!window.isSecureContext) {
	document.body.classList.add('insecure');
}
const offlineMessage = '".js_escape(lang(87))."';
const thousandsSeparator = '".js_escape(lang(4))."';"),"<div id='help' class='jush-".JUSH." jsonly hidden'></div>\n",script("mixin(qs('#help'), {onmouseover: () => { helpOpen = 1; }, onmouseout: helpMouseout});"),"<div id='content'>\n","<span id='menuopen' class='jsonly'>".icon("move","","menu","")."</span>".script("qs('#menuopen').onclick = event => { qs('#foot').classList.toggle('foot'); event.stopPropagation(); }");if($Ra!==null){$_=substr(preg_replace('~\b(username|db|ns)=[^&]*&~','',ME),0,-1);echo'<p id="breadcrumb"><a href="'.h($_?:".").'">'.get_driver(DRIVER).'</a> » ';$_=substr(preg_replace('~\b(db|ns)=[^&]*&~','',ME),0,-1);$N=adminer()->serverName(SERVER);$N=($N!=""?$N:lang(34));if($Ra===false)echo"$N\n";else{echo"<a href='".h($_)."' accesskey='1' title='Alt+Shift+1'>$N</a> » ";if($_GET["ns"]!=""||(DB!=""&&is_array($Ra)))echo'<a href="'.h($_."&db=".urlencode(DB).(support("scheme")?"&ns=":"")).'">'.h(DB).'</a> » ';if(is_array($Ra)){if($_GET["ns"]!="")echo'<a href="'.h(substr(ME,0,-1)).'">'.h($_GET["ns"]).'</a> » ';foreach($Ra
as$x=>$X){$cc=(is_array($X)?$X[1]:h($X));if($cc!="")echo"<a href='".h(ME."$x=").urlencode(is_array($X)?$X[0]:$X)."'>$cc</a> » ";}}echo"$oj\n";}}echo"<h2>$qj</h2>\n","<div id='ajaxstatus' class='jsonly hidden'></div>\n";restart_session();page_messages($m);$j=&get_session("dbs");if(DB!=""&&$j&&!in_array(DB,$j,true))$j=null;stop_session();define('Adminer\PAGE_HEADER',1);}function
page_headers(){header("Content-Type: text/html; charset=utf-8");header("Cache-Control: no-cache");header("X-Frame-Options: deny");header("X-XSS-Protection: 0");header("X-Content-Type-Options: nosniff");header("Referrer-Policy: origin-when-cross-origin");foreach(adminer()->csp(csp())as$Kb){$Pd=array();foreach($Kb
as$x=>$X)$Pd[]="$x $X";header("Content-Security-Policy: ".implode("; ",$Pd));}adminer()->headers();}function
csp(){return
array(array("script-src"=>"'self' 'unsafe-inline' 'nonce-".get_nonce()."' 'strict-dynamic'","connect-src"=>"'self' https://www.adminer.org","frame-src"=>"'none'","object-src"=>"'none'","base-uri"=>"'none'","form-action"=>"'self'",),);}function
get_nonce(){static$ag;if(!$ag)$ag=base64_encode(rand_string());return$ag;}function
page_messages($m){$Uj=preg_replace('~^[^?]*~','',$_SERVER["REQUEST_URI"]);$Ff=idx($_SESSION["messages"],$Uj);if($Ff){echo"<div class='message'>".implode("</div>\n<div class='message'>",$Ff)."</div>".script("messagesPrint();");unset($_SESSION["messages"][$Uj]);}if($m)echo"<div class='error'>$m</div>\n";if(adminer()->error)echo"<div class='error'>".adminer()->error."</div>\n";}function
page_footer($Lf=""){echo"</div>\n\n<div id='foot' class='foot'>\n<div id='menu'>\n";adminer()->navigation($Lf);echo"</div>\n";if($Lf!="auth")echo'<form action="" method="post">
<p class="logout">
<span>',h($_GET["username"])."\n",'</span>
<input type="submit" name="logout" value="',lang(88),'" id="logout">
',input_token(),'</form>
';echo"</div>\n\n",script("setupSubmitHighlight(document);");}function
int32($Rf){while($Rf>=2147483648)$Rf-=4294967296;while($Rf<=-2147483649)$Rf+=4294967296;return(int)$Rf;}function
long2str(array$W,$nk){$Xh='';foreach($W
as$X)$Xh
.=pack('V',$X);if($nk)return
substr($Xh,0,end($W));return$Xh;}function
str2long($Xh,$nk){$W=array_values(unpack('V*',str_pad($Xh,4*ceil(strlen($Xh)/4),"\0")));if($nk)$W[]=strlen($Xh);return$W;}function
xxtea_mx($tk,$sk,$Oi,$Ke){return
int32((($tk>>5&0x7FFFFFF)^$sk<<2)+(($sk>>3&0x1FFFFFFF)^$tk<<4))^int32(($Oi^$sk)+($Ke^$tk));}function
encrypt_string($Ji,$x){if($Ji=="")return"";$x=array_values(unpack("V*",pack("H*",md5($x))));$W=str2long($Ji,true);$Rf=count($W)-1;$tk=$W[$Rf];$sk=$W[0];$xh=floor(6+52/($Rf+1));$Oi=0;while($xh-->0){$Oi=int32($Oi+0x9E3779B9);$vc=$Oi>>2&3;for($Mg=0;$Mg<$Rf;$Mg++){$sk=$W[$Mg+1];$Qf=xxtea_mx($tk,$sk,$Oi,$x[$Mg&3^$vc]);$tk=int32($W[$Mg]+$Qf);$W[$Mg]=$tk;}$sk=$W[0];$Qf=xxtea_mx($tk,$sk,$Oi,$x[$Mg&3^$vc]);$tk=int32($W[$Rf]+$Qf);$W[$Rf]=$tk;}return
long2str($W,false);}function
decrypt_string($Ji,$x){if($Ji=="")return"";if(!$x)return
false;$x=array_values(unpack("V*",pack("H*",md5($x))));$W=str2long($Ji,false);$Rf=count($W)-1;$tk=$W[$Rf];$sk=$W[0];$xh=floor(6+52/($Rf+1));$Oi=int32($xh*0x9E3779B9);while($Oi){$vc=$Oi>>2&3;for($Mg=$Rf;$Mg>0;$Mg--){$tk=$W[$Mg-1];$Qf=xxtea_mx($tk,$sk,$Oi,$x[$Mg&3^$vc]);$sk=int32($W[$Mg]-$Qf);$W[$Mg]=$sk;}$tk=$W[$Rf];$Qf=xxtea_mx($tk,$sk,$Oi,$x[$Mg&3^$vc]);$sk=int32($W[0]-$Qf);$W[0]=$sk;$Oi=int32($Oi-0x9E3779B9);}return
long2str($W,true);}$dh=array();if($_COOKIE["adminer_permanent"]){foreach(explode(" ",$_COOKIE["adminer_permanent"])as$X){list($x)=explode(":",$X);$dh[$x]=$X;}}function
add_invalid_login(){$Ka=get_temp_dir()."/adminer-invalid";foreach(glob("$Ka*")?:array($Ka)as$hd){$q=file_open_lock($hd);if($q)break;}if(!$q)$q=file_open_lock("$Ka-".rand_string());if(!$q)return;$Ae=json_decode(stream_get_contents($q),true);$lj=time();if($Ae){foreach($Ae
as$Be=>$X){if($X[0]<$lj)unset($Ae[$Be]);}}$_e=&$Ae[adminer()->bruteForceKey()];if(!$_e)$_e=array($lj+30*60,0);$_e[1]++;file_write_unlock($q,json_encode($Ae));}function
check_invalid_login(array&$dh){$Ae=array();foreach(glob(get_temp_dir()."/adminer-invalid*")as$hd){$q=file_open_lock($hd);if($q){$Ae=json_decode(stream_get_contents($q),true);file_unlock($q);break;}}$_e=idx($Ae,adminer()->bruteForceKey(),array());$Zf=($_e[1]>29?$_e[0]-time():0);if($Zf>0)auth_error(lang(89,ceil($Zf/60)),$dh);}$Ca=$_POST["auth"];if($Ca){session_regenerate_id();$ik=$Ca["driver"];$N=$Ca["server"];$V=$Ca["username"];$F=(string)$Ca["password"];$k=$Ca["db"];set_password($ik,$N,$V,$F);$_SESSION["db"][$ik][$N][$V][$k]=true;if($Ca["permanent"]){$x=implode("-",array_map('base64_encode',array($ik,$N,$V,$k)));$sh=adminer()->permanentLogin(true);$dh[$x]="$x:".base64_encode($sh?encrypt_string($F,$sh):"");cookie("adminer_permanent",implode(" ",$dh));}if(count($_POST)==1||DRIVER!=$ik||SERVER!=$N||$_GET["username"]!==$V||DB!=$k)redirect(auth_url($ik,$N,$V,$k));}elseif($_POST["logout"]&&(!$_SESSION["token"]||verify_token())){foreach(array("pwds","db","dbs","queries")as$x)set_session($x,null);unset_permanent($dh);redirect(substr(preg_replace('~\b(username|db|ns)=[^&]*&~','',ME),0,-1),lang(90).' '.lang(91));}elseif($dh&&!$_SESSION["pwds"]){session_regenerate_id();$sh=adminer()->permanentLogin();foreach($dh
as$x=>$X){list(,$hb)=explode(":",$X);list($ik,$N,$V,$k)=array_map('base64_decode',explode("-",$x));set_password($ik,$N,$V,decrypt_string(base64_decode($hb),$sh));$_SESSION["db"][$ik][$N][$V][$k]=true;}}function
unset_permanent(array&$dh){foreach($dh
as$x=>$X){list($ik,$N,$V,$k)=array_map('base64_decode',explode("-",$x));if($ik==DRIVER&&$N==SERVER&&$V==$_GET["username"]&&$k==DB)unset($dh[$x]);}cookie("adminer_permanent",implode(" ",$dh));}function
auth_error($m,array&$dh){$ri=session_name();if(isset($_GET["username"])){header("HTTP/1.1 403 Forbidden");if(($_COOKIE[$ri]||$_GET[$ri])&&!$_SESSION["token"])$m=lang(92);else{restart_session();add_invalid_login();$F=get_password();if($F!==null){if($F===false)$m
.=($m?'<br>':'').lang(93,target_blank(),'<code>permanentLogin()</code>');set_password(DRIVER,SERVER,$_GET["username"],null);}unset_permanent($dh);}}if(!$_COOKIE[$ri]&&$_GET[$ri]&&ini_bool("session.use_only_cookies"))$m=lang(94);$Pg=session_get_cookie_params();cookie("adminer_key",($_COOKIE["adminer_key"]?:rand_string()),$Pg["lifetime"]);if(!$_SESSION["token"])$_SESSION["token"]=rand(1,1e6);page_header(lang(39),$m,null);echo"<form action='' method='post'>\n","<div>";if(hidden_fields($_POST,array("auth")))echo"<p class='message'>".lang(95)."\n";echo"</div>\n";adminer()->loginForm();echo"</form>\n";page_footer("auth");exit;}if(isset($_GET["username"])&&!class_exists('Adminer\Db')){unset($_SESSION["pwds"][DRIVER]);unset_permanent($dh);page_header(lang(96),lang(97,implode(", ",Driver::$extensions)),false);page_footer("auth");exit;}$g='';if(isset($_GET["username"])&&is_string(get_password())){list($Vd,$hh)=host_port(SERVER);if(preg_match('~[^-\w.:/]~',$Vd.$hh))auth_error(lang(98),$dh);if(preg_match('~^-?\d+~',$hh,$A)&&($A[0]<1024||$A[0]>65535))auth_error(lang(99),$dh);check_invalid_login($dh);$Jb=adminer()->credentials();$g=Driver::connect($Jb[0],$Jb[1],$Jb[2]);if(is_object($g)){Db::$instance=$g;Driver::$instance=new
Driver($g);if($g->flavor)save_settings(array("vendor-".DRIVER."-".SERVER=>get_driver(DRIVER)));}}$jf=null;if(!is_object($g)||($jf=adminer()->login($_GET["username"],get_password()))!==true){$m=(is_string($g)?nl_br(h($g)):(is_string($jf)?$jf:lang(100))).(preg_match('~^ | $~',get_password())?'<br>'.lang(101):'');auth_error($m,$dh);}if($_POST["logout"]&&$_SESSION["token"]&&!verify_token()){page_header(lang(88),lang(102));page_footer("db");exit;}if(!$_SESSION["token"])$_SESSION["token"]=rand(1,1e6);stop_session(true);if($Ca&&$_POST["token"])$_POST["token"]=get_token();$m='';if($_POST){if(!verify_token()){$te="max_input_vars";$xf=ini_get($te);if(extension_loaded("suhosin")){foreach(array("suhosin.request.max_vars","suhosin.post.max_vars")as$x){$X=ini_get($x);if($X&&(!$xf||$X<$xf)){$te=$x;$xf=$X;}}}$m=(!$_POST["token"]&&$xf?lang(103,"'$te'"):lang(102).' '.lang(104));}}elseif($_SERVER["REQUEST_METHOD"]=="POST"){$m=lang(105,"'post_max_size'");if(isset($_GET["sql"]))$m
.=' '.lang(106);}function
print_select_result($I,$h=null,array$Bg=array(),$z=0){$ef=array();$w=array();$e=array();$Pa=array();$Ij=array();$J=array();for($s=0;(!$z||$s<$z)&&($K=$I->fetch_row());$s++){if(!$s){echo"<div class='scrollable'>\n","<table class='nowrap odds'>\n","<thead><tr>";for($He=0;$He<count($K);$He++){$n=$I->fetch_field();$B=$n->name;$Ag=(isset($n->orgtable)?$n->orgtable:"");$_g=(isset($n->orgname)?$n->orgname:$B);if($Bg&&JUSH=="sql")$ef[$He]=($B=="table"?"table=":($B=="possible_keys"?"indexes=":null));elseif($Ag!=""){if(isset($n->table))$J[$n->table]=$Ag;if(!isset($w[$Ag])){$w[$Ag]=array();foreach(indexes($Ag,$h)as$v){if($v["type"]=="PRIMARY"){$w[$Ag]=array_flip($v["columns"]);break;}}$e[$Ag]=$w[$Ag];}if(isset($e[$Ag][$_g])){unset($e[$Ag][$_g]);$w[$Ag][$_g]=$He;$ef[$He]=$Ag;}}if($n->charsetnr==63)$Pa[$He]=true;$Ij[$He]=$n->type;echo"<th".($Ag!=""||$n->name!=$_g?" title='".h(($Ag!=""?"$Ag.":"").$_g)."'":"").">".h($B).($Bg?doc_link(array('sql'=>"explain-output.html#explain_".strtolower($B),'mariadb'=>"explain/#the-columns-in-explain-select",)):"");}echo"</thead>\n";}echo"<tr>";foreach($K
as$x=>$X){$_="";if(isset($ef[$x])&&!$e[$ef[$x]]){if($Bg&&JUSH=="sql"){$R=$K[array_search("table=",$ef)];$_=ME.$ef[$x].urlencode($Bg[$R]!=""?$Bg[$R]:$R);}else{$_=ME."edit=".urlencode($ef[$x]);foreach($w[$ef[$x]]as$lb=>$He){if($K[$He]===null){$_="";break;}$_
.="&where".urlencode("[".bracket_escape($lb)."]")."=".urlencode($K[$He]);}}}$n=array('type'=>($Pa[$x]?'blob':($Ij[$x]==254?'char':'')),);$X=select_value($X,$_,$n,null);echo"<td".($Ij[$x]<=9||$Ij[$x]==246?" class='number'":"").">$X";}}echo($s?"</table>\n</div>":"<p class='message'>".lang(14))."\n";return$J;}function
referencable_primary($ji){$J=array();foreach(table_status('',true)as$Vi=>$R){if($Vi!=$ji&&fk_support($R)){foreach(fields($Vi)as$n){if($n["primary"]){if($J[$Vi]){unset($J[$Vi]);break;}$J[$Vi]=$n;}}}}return$J;}function
textarea($B,$Y,$L=10,$ob=80){echo"<textarea name='".h($B)."' rows='$L' cols='$ob' class='sqlarea jush-".JUSH."' spellcheck='false' wrap='off'>";if(is_array($Y)){foreach($Y
as$X)echo
h($X[0])."\n\n\n";}else
echo
h($Y);echo"</textarea>";}function
select_input($Ba,array$wg,$Y="",$qg="",$eh=""){$dj=($wg?"select":"input");return"<$dj$Ba".($wg?"><option value=''>$eh".optionlist($wg,$Y,true)."</select>":" size='10' value='".h($Y)."' placeholder='$eh'>").($qg?script("qsl('$dj').onchange = $qg;",""):"");}function
json_row($x,$X=null,$Lc=true){static$kd=true;if($kd)echo"{";if($x!=""){echo($kd?"":",")."\n\t\"".addcslashes($x,"\r\n\t\"\\/").'": '.($X!==null?($Lc?'"'.addcslashes($X,"\r\n\"\\/").'"':$X):'null');$kd=false;}else{echo"\n}\n";$kd=true;}}function
edit_type($x,array$n,array$nb,array$ud=array(),array$Xc=array()){$U=$n["type"];echo"<td><select name='".h($x)."[type]' class='type' aria-labelledby='label-type'>";if($U&&!array_key_exists($U,driver()->types())&&!isset($ud[$U])&&!in_array($U,$Xc))$Xc[]=$U;$Ki=driver()->structuredTypes();if($ud)$Ki[lang(107)]=$ud;echo
optionlist(array_merge($Xc,$Ki),$U),"</select><td>","<input name='".h($x)."[length]' value='".h($n["length"])."' size='3'".(!$n["length"]&&preg_match('~var(char|binary)$~',$U)?" class='required'":"")." aria-labelledby='label-length'>","<td class='options'>",($nb?"<input list='collations' name='".h($x)."[collation]'".(preg_match('~(char|text|enum|set)$~',$U)?"":" class='hidden'")." value='".h($n["collation"])."' placeholder='(".lang(108).")'>":''),(driver()->unsigned?"<select name='".h($x)."[unsigned]'".(!$U||preg_match(number_type(),$U)?"":" class='hidden'").'><option>'.optionlist(driver()->unsigned,$n["unsigned"]).'</select>':''),(isset($n['on_update'])?"<select name='".h($x)."[on_update]'".(preg_match('~timestamp|datetime~',$U)?"":" class='hidden'").'>'.optionlist(array(""=>"(".lang(109).")","CURRENT_TIMESTAMP"),(preg_match('~^CURRENT_TIMESTAMP~i',$n["on_update"])?"CURRENT_TIMESTAMP":$n["on_update"])).'</select>':''),($ud?"<select name='".h($x)."[on_delete]'".(preg_match("~`~",$U)?"":" class='hidden'")."><option value=''>(".lang(110).")".optionlist(explode("|",driver()->onActions),$n["on_delete"])."</select> ":" ");}function
process_length($y){$Gc=driver()->enumLength;return(preg_match("~^\\s*\\(?\\s*$Gc(?:\\s*,\\s*$Gc)*+\\s*\\)?\\s*\$~",$y)&&preg_match_all("~$Gc~",$y,$pf)?"(".implode(",",$pf[0]).")":preg_replace('~^[0-9].*~','(\0)',preg_replace('~[^-0-9,+()[\]]~','',$y)));}function
process_type(array$n,$mb="COLLATE"){return" $n[type]".process_length($n["length"]).(preg_match(number_type(),$n["type"])&&in_array($n["unsigned"],driver()->unsigned)?" $n[unsigned]":"").(preg_match('~char|text|enum|set~',$n["type"])&&$n["collation"]?" $mb ".(JUSH=="mssql"?$n["collation"]:q($n["collation"])):"");}function
process_field(array$n,array$Hj){if($n["on_update"])$n["on_update"]=str_ireplace("current_timestamp()","CURRENT_TIMESTAMP",$n["on_update"]);return
array(idf_escape(trim($n["field"])),process_type($Hj),($n["null"]?" NULL":" NOT NULL"),default_value($n),(preg_match('~timestamp|datetime~',$n["type"])&&$n["on_update"]?" ON UPDATE $n[on_update]":""),(support("comment")&&$n["comment"]!=""?" COMMENT ".q($n["comment"]):""),($n["auto_increment"]?auto_increment():null),);}function
default_value(array$n){if($n["default"]===null)return"";$l=str_replace("\r","",$n["default"]);$Ad=$n["generated"];return(in_array($Ad,driver()->generated)?(JUSH=="mssql"?" AS ($l)".($Ad=="VIRTUAL"?"":" $Ad"):" GENERATED ALWAYS AS ($l) $Ad"):(preg_match('~^GENERATED ~i',$l)?" $l":" DEFAULT ".(preg_match('~char|binary|text|json|enum|set~',$n["type"])||preg_match('~^(?![a-z])~i',$l)?(JUSH=="sql"&&preg_match('~text|json~',$n["type"])?"(".q($l).")":q($l)):str_ireplace("current_timestamp()","CURRENT_TIMESTAMP",(JUSH=="sqlite"?"($l)":$l)))));}function
type_class($U){foreach(array('char'=>'text','date'=>'time|year','binary'=>'blob','enum'=>'set',)as$x=>$X){if(preg_match("~$x|$X~",$U))return" class='$x'";}}function
edit_fields(array$o,array$nb,$U="TABLE",array$ud=array()){$o=array_values($o);$Xb=(($_POST?$_POST["defaults"]:get_setting("defaults"))?"":" class='hidden'");$tb=(($_POST?$_POST["comments"]:get_setting("comments"))?"":" class='hidden'");echo"<thead><tr>\n",($U=="PROCEDURE"?"<td>":""),"<th id='label-name'>".($U=="TABLE"?lang(111):lang(112)),"<td id='label-type'>".lang(50)."<textarea id='enum-edit' rows='4' cols='12' wrap='off' style='display: none;'></textarea>".script("qs('#enum-edit').onblur = editingLengthBlur;"),"<td id='label-length'>".lang(113),"<td>".lang(114);if($U=="TABLE")echo"<td id='label-null'>NULL\n","<td><input type='radio' name='auto_increment_col' value=''><abbr id='label-ai' title='".lang(52)."'>AI</abbr>",doc_link(array('sql'=>"example-auto-increment.html",'mariadb'=>"auto_increment/",'sqlite'=>"autoinc.html",'pgsql'=>"datatype-numeric.html#DATATYPE-SERIAL",'mssql'=>"t-sql/statements/create-table-transact-sql-identity-property",)),"<td id='label-default'$Xb>".lang(53),(support("comment")?"<td id='label-comment'$tb>".lang(51):"");echo"<td>".icon("plus","add[".(support("move_col")?0:count($o))."]","+",lang(115)),"</thead>\n<tbody>\n",script("mixin(qsl('tbody'), {onclick: editingClick, onkeydown: editingKeydown, oninput: editingInput});");foreach($o
as$s=>$n){$s++;$Cg=$n[($_POST?"orig":"field")];$fc=(isset($_POST["add"][$s-1])||(isset($n["field"])&&!idx($_POST["drop_col"],$s)))&&(support("drop_col")||$Cg=="");echo"<tr".($fc?"":" style='display: none;'").">\n",($U=="PROCEDURE"?"<td>".html_select("fields[$s][inout]",explode("|",driver()->inout),$n["inout"]):"")."<th>",(support("move_col")?icon("move","","↕",lang(116))." ":"");if($fc)echo"<input name='fields[$s][field]' value='".h($n["field"])."' data-maxlength='64' autocapitalize='off' aria-labelledby='label-name'".(isset($_POST["add"][$s-1])?" autofocus":"").">";echo
input_hidden("fields[$s][orig]",$Cg);edit_type("fields[$s]",$n,$nb,$ud);if($U=="TABLE"){echo"<td>".checkbox("fields[$s][null]",1,$n["null"],"","","block","label-null"),"<td><label class='block'><input type='radio' name='auto_increment_col' value='$s'".($n["auto_increment"]?" checked":"")." aria-labelledby='label-ai'></label>","<td$Xb>".(driver()->generated?html_select("fields[$s][generated]",array_merge(array("","DEFAULT"),driver()->generated),$n["generated"])." ":checkbox("fields[$s][generated]",1,$n["generated"],"","","","label-default"));$Ba=" name='fields[$s][default]' aria-labelledby='label-default'";$Y=h($n["default"]);echo(preg_match('~\n~',$n["default"])?"<textarea$Ba rows='2' cols='30' style='vertical-align: bottom;'>\n$Y</textarea>":"<input$Ba value='$Y'>"),(support("comment")?"<td$tb><input name='fields[$s][comment]' value='".h($n["comment"])."' data-maxlength='".(min_version(5.5)?1024:255)."' aria-labelledby='label-comment'>":"");}echo"<td>",(support("move_col")?icon("plus","add[$s]","+",lang(115))." ":""),($Cg==""||support("drop_col")?icon("cross","drop_col[$s]","x",lang(117)):"");}}function
process_fields(array&$o){if($_POST["add"]){$o=array_values($o);array_splice($o,key($_POST["add"]),0,array(array()));}return$_POST["add"]||$_POST["drop_col"];}function
normalize_enum(array$A){$X=$A[0];return"'".str_replace("'","''",addcslashes(stripcslashes(str_replace($X[0].$X[0],$X[0],substr($X,1,-1))),'\\'))."'";}function
grant($Cd,array$uh,$e,$ng){if(!$uh)return
true;if($uh==array("ALL PRIVILEGES","GRANT OPTION"))return($Cd=="GRANT"?queries("$Cd ALL PRIVILEGES$ng WITH GRANT OPTION"):queries("$Cd ALL PRIVILEGES$ng")&&queries("$Cd GRANT OPTION$ng"));return
queries("$Cd ".preg_replace('~(GRANT OPTION)\([^)]*\)~','\1',implode("$e, ",$uh).$e).$ng);}function
drop_create($pc,$i,$rc,$hj,$tc,$if,$Ef,$Cf,$Df,$lg,$Wf){if($_POST["drop"])query_redirect($pc,$if,$Ef);elseif($lg=="")query_redirect($i,$if,$Df);elseif($lg!=$Wf){$Ib=queries($i);queries_redirect($if,$Cf,$Ib&&queries($pc));if($Ib)queries($rc);}else
queries_redirect($if,$Cf,queries($hj)&&queries($tc)&&queries($pc)&&queries($i));}function
create_trigger($ng,array$K){$nj=" $K[Timing] $K[Event]".(preg_match('~ OF~',$K["Event"])?" $K[Of]":"");return"CREATE TRIGGER ".idf_escape($K["Trigger"]).(JUSH=="mssql"?$ng.$nj:$nj.$ng).rtrim(" $K[Type]\n$K[Statement]",";").";";}function
create_routine($Th,array$K){$O=array();$o=(array)$K["fields"];ksort($o);foreach($o
as$n){if($n["field"]!="")$O[]=(preg_match("~^(".driver()->inout.")\$~",$n["inout"])?"$n[inout] ":"").idf_escape($n["field"]).process_type($n,"CHARACTER SET");}$Zb=rtrim($K["definition"],";");return"CREATE $Th ".idf_escape(trim($K["name"]))." (".implode(", ",$O).")".($Th=="FUNCTION"?" RETURNS".process_type($K["returns"],"CHARACTER SET"):"").($K["language"]?" LANGUAGE $K[language]":"").(JUSH=="pgsql"?" AS ".q($Zb):"\n$Zb;");}function
remove_definer($H){return
preg_replace('~^([A-Z =]+) DEFINER=`'.preg_replace('~@(.*)~','`@`(%|\1)',logged_user()).'`~','\1',$H);}function
format_foreign_key(array$p){$k=$p["db"];$bg=$p["ns"];return" FOREIGN KEY (".implode(", ",array_map('Adminer\idf_escape',$p["source"])).") REFERENCES ".($k!=""&&$k!=$_GET["db"]?idf_escape($k).".":"").($bg!=""&&$bg!=$_GET["ns"]?idf_escape($bg).".":"").idf_escape($p["table"])." (".implode(", ",array_map('Adminer\idf_escape',$p["target"])).")".(preg_match("~^(".driver()->onActions.")\$~",$p["on_delete"])?" ON DELETE $p[on_delete]":"").(preg_match("~^(".driver()->onActions.")\$~",$p["on_update"])?" ON UPDATE $p[on_update]":"").($p["deferrable"]?" $p[deferrable]":"");}function
tar_file($hd,$sj){$J=pack("a100a8a8a8a12a12",$hd,644,0,0,decoct($sj->size),decoct(time()));$gb=8*32;for($s=0;$s<strlen($J);$s++)$gb+=ord($J[$s]);$J
.=sprintf("%06o",$gb)."\0 ";echo$J,str_repeat("\0",512-strlen($J));$sj->send();echo
str_repeat("\0",511-($sj->size+511)%512);}function
doc_link(array$ah,$ij="<sup>?</sup>"){$pi=connection()->server_info;$jk=preg_replace('~^(\d\.?\d).*~s','\1',$pi);$Wj=array('sql'=>"https://dev.mysql.com/doc/refman/$jk/en/",'sqlite'=>"https://www.sqlite.org/",'pgsql'=>"https://www.postgresql.org/docs/".(connection()->flavor=='cockroach'?"current":$jk)."/",'mssql'=>"https://learn.microsoft.com/en-us/sql/",'oracle'=>"https://www.oracle.com/pls/topic/lookup?ctx=db".preg_replace('~^.* (\d+)\.(\d+)\.\d+\.\d+\.\d+.*~s','\1\2',$pi)."&id=",);if(connection()->flavor=='maria'){$Wj['sql']="https://mariadb.com/kb/en/";$ah['sql']=(isset($ah['mariadb'])?$ah['mariadb']:str_replace(".html","/",$ah['sql']));}return($ah[JUSH]?"<a href='".h($Wj[JUSH].$ah[JUSH].(JUSH=='mssql'?"?view=sql-server-ver$jk":""))."'".target_blank().">$ij</a>":"");}function
db_size($k){if(!connection()->select_db($k))return"?";$J=0;foreach(table_status()as$S)$J+=$S["Data_length"]+$S["Index_length"];return
format_number($J);}function
set_utf8mb4($i){static$O=false;if(!$O&&preg_match('~\butf8mb4~i',$i)){$O=true;echo"SET NAMES ".charset(connection()).";\n\n";}}if(isset($_GET["status"]))$_GET["variables"]=$_GET["status"];if(isset($_GET["import"]))$_GET["sql"]=$_GET["import"];if(!(DB!=""?connection()->select_db(DB):isset($_GET["sql"])||isset($_GET["dump"])||isset($_GET["database"])||isset($_GET["processlist"])||isset($_GET["privileges"])||isset($_GET["user"])||isset($_GET["variables"])||$_GET["script"]=="connect"||$_GET["script"]=="kill")){if(DB!=""||$_GET["refresh"]){restart_session();set_session("dbs",null);}if(DB!=""){header("HTTP/1.1 404 Not Found");page_header(lang(38).": ".h(DB),lang(118),true);}else{if($_POST["db"]&&!$m)queries_redirect(substr(ME,0,-1),lang(119),drop_databases($_POST["db"]));page_header(lang(120),$m,false);echo"<p class='links'>\n";foreach(array('database'=>lang(121),'privileges'=>lang(72),'processlist'=>lang(122),'variables'=>lang(123),'status'=>lang(124),)as$x=>$X){if(support($x))echo"<a href='".h(ME)."$x='>$X</a>\n";}echo"<p>".lang(125,get_driver(DRIVER),"<b>".h(connection()->server_info)."</b>","<b>".connection()->extension."</b>")."\n","<p>".lang(126,"<b>".h(logged_user())."</b>")."\n";$j=adminer()->databases();if($j){$bi=support("scheme");$nb=collations();echo"<form action='' method='post'>\n","<table class='checkable odds'>\n",script("mixin(qsl('table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true)});"),"<thead><tr>".(support("database")?"<td>":"")."<th>".lang(38).(get_session("dbs")!==null?" - <a href='".h(ME)."refresh=1'>".lang(127)."</a>":"")."<td>".lang(128)."<td>".lang(129)."<td>".lang(130)." - <a href='".h(ME)."dbsize=1'>".lang(131)."</a>".script("qsl('a').onclick = partial(ajaxSetHtml, '".js_escape(ME)."script=connect');","")."</thead>\n";$j=($_GET["dbsize"]?count_tables($j):array_flip($j));foreach($j
as$k=>$T){$Sh=h(ME)."db=".urlencode($k);$t=h("Db-".$k);echo"<tr>".(support("database")?"<td>".checkbox("db[]",$k,in_array($k,(array)$_POST["db"]),"","","",$t):""),"<th><a href='$Sh' id='$t'>".h($k)."</a>";$c=h(db_collation($k,$nb));echo"<td>".(support("database")?"<a href='$Sh".($bi?"&amp;ns=":"")."&amp;database=' title='".lang(68)."'>$c</a>":$c),"<td align='right'><a href='$Sh&amp;schema=' id='tables-".h($k)."' title='".lang(71)."'>".($_GET["dbsize"]?$T:"?")."</a>","<td align='right' id='size-".h($k)."'>".($_GET["dbsize"]?db_size($k):"?"),"\n";}echo"</table>\n",(support("database")?"<div class='footer'><div>\n"."<fieldset><legend>".lang(132)." <span id='selected'></span></legend><div>\n".input_hidden("all").script("qsl('input').onclick = function () { selectCount('selected', formChecked(this, /^db/)); };")."<input type='submit' name='drop' value='".lang(133)."'>".confirm()."\n"."</div></fieldset>\n"."</div></div>\n":""),input_token(),"</form>\n",script("tableCheck();");}if(!empty(adminer()->plugins)){echo"<div class='plugins'>\n","<h3>".lang(134)."</h3>\n<ul>\n";foreach(adminer()->plugins
as$fh){$dc=(method_exists($fh,'description')?$fh->description():"");if(!$dc){$Hh=new
\ReflectionObject($fh);if(preg_match('~^/[\s*]+(.+)~',$Hh->getDocComment(),$A))$dc=$A[1];}$ci=(method_exists($fh,'screenshot')?$fh->screenshot():"");echo"<li><b>".get_class($fh)."</b>".h($dc?": $dc":"").($ci?" (<a href='".h($ci)."'".target_blank().">".lang(135)."</a>)":"")."\n";}echo"</ul>\n";adminer()->pluginsLinks();echo"</div>\n";}}page_footer("db");exit;}if(support("scheme")){if(DB!=""&&$_GET["ns"]!==""){if(!isset($_GET["ns"]))redirect(preg_replace('~ns=[^&]*&~','',ME)."ns=".get_schema());if(!set_schema($_GET["ns"])){header("HTTP/1.1 404 Not Found");page_header(lang(80).": ".h($_GET["ns"]),lang(136),true);page_footer("ns");exit;}}}adminer()->afterConnect();class
TmpFile{private$handler;var$size;function
__construct(){$this->handler=tmpfile();}function
write($Cb){$this->size+=strlen($Cb);fwrite($this->handler,$Cb);}function
send(){fseek($this->handler,0);fpassthru($this->handler);fclose($this->handler);}}if(isset($_GET["select"])&&($_POST["edit"]||$_POST["clone"])&&!$_POST["save"])$_GET["edit"]=$_GET["select"];if(isset($_GET["callf"]))$_GET["call"]=$_GET["callf"];if(isset($_GET["function"]))$_GET["procedure"]=$_GET["function"];if(isset($_GET["download"])){$a=$_GET["download"];$o=fields($a);header("Content-Type: application/octet-stream");header("Content-Disposition: attachment; filename=".friendly_url("$a-".implode("_",$_GET["where"])).".".friendly_url($_GET["field"]));$M=array(idf_escape($_GET["field"]));$I=driver()->select($a,$M,array(where($_GET,$o)),$M);$K=($I?$I->fetch_row():array());echo
driver()->value($K[0],$o[$_GET["field"]]);exit;}elseif(isset($_GET["table"])){$a=$_GET["table"];$o=fields($a);if(!$o)$m=error()?:lang(11);$S=table_status1($a);$B=adminer()->tableName($S);page_header(($o&&is_view($S)?$S['Engine']=='materialized view'?lang(137):lang(138):lang(139)).": ".($B!=""?$B:h($a)),$m);$Rh=array();foreach($o
as$x=>$n)$Rh+=$n["privileges"];adminer()->selectLinks($S,(isset($Rh["insert"])||!support("table")?"":null));$sb=$S["Comment"];if($sb!="")echo"<p class='nowrap'>".lang(51).": ".h($sb)."\n";if($o)adminer()->tableStructurePrint($o,$S);function
tables_links(array$T){echo"<ul>\n";foreach($T
as$K){$_=preg_replace('~ns=[^&]*~',"ns=".urlencode($K["ns"]),ME);echo"<li><a href='".h($_."table=".urlencode($K["table"]))."'>".($K["ns"]!=$_GET["ns"]?"<b>".h($K["ns"])."</b>.":"").h($K["table"])."</a>";}echo"</ul>\n";}$se=driver()->inheritsFrom($a);if($se){echo"<h3>".lang(140)."</h3>\n";tables_links($se);}if(support("indexes")&&driver()->supportsIndex($S)){echo"<h3 id='indexes'>".lang(141)."</h3>\n";$w=indexes($a);if($w)adminer()->tableIndexesPrint($w,$S);echo'<p class="links"><a href="'.h(ME).'indexes='.urlencode($a).'">'.lang(142)."</a>\n";}if(!is_view($S)){if(fk_support($S)){echo"<h3 id='foreign-keys'>".lang(107)."</h3>\n";$ud=foreign_keys($a);if($ud){echo"<table>\n","<thead><tr><th>".lang(143)."<td>".lang(144)."<td>".lang(110)."<td>".lang(109)."<td></thead>\n";foreach($ud
as$B=>$p){echo"<tr title='".h($B)."'>","<th><i>".implode("</i>, <i>",array_map('Adminer\h',$p["source"]))."</i>";$_=($p["db"]!=""?preg_replace('~db=[^&]*~',"db=".urlencode($p["db"]),ME):($p["ns"]!=""?preg_replace('~ns=[^&]*~',"ns=".urlencode($p["ns"]),ME):ME));echo"<td><a href='".h($_."table=".urlencode($p["table"]))."'>".($p["db"]!=""&&$p["db"]!=DB?"<b>".h($p["db"])."</b>.":"").($p["ns"]!=""&&$p["ns"]!=$_GET["ns"]?"<b>".h($p["ns"])."</b>.":"").h($p["table"])."</a>","(<i>".implode("</i>, <i>",array_map('Adminer\h',$p["target"]))."</i>)","<td>".h($p["on_delete"]),"<td>".h($p["on_update"]),'<td><a href="'.h(ME.'foreign='.urlencode($a).'&name='.urlencode($B)).'">'.lang(145).'</a>',"\n";}echo"</table>\n";}echo'<p class="links"><a href="'.h(ME).'foreign='.urlencode($a).'">'.lang(146)."</a>\n";}if(support("check")){echo"<h3 id='checks'>".lang(147)."</h3>\n";$cb=driver()->checkConstraints($a);if($cb){echo"<table>\n";foreach($cb
as$x=>$X)echo"<tr title='".h($x)."'>","<td><code class='jush-".JUSH."'>".h($X),"<td><a href='".h(ME.'check='.urlencode($a).'&name='.urlencode($x))."'>".lang(145)."</a>","\n";echo"</table>\n";}echo'<p class="links"><a href="'.h(ME).'check='.urlencode($a).'">'.lang(148)."</a>\n";}}if(support(is_view($S)?"view_trigger":"trigger")){echo"<h3 id='triggers'>".lang(149)."</h3>\n";$Fj=triggers($a);if($Fj){echo"<table>\n";foreach($Fj
as$x=>$X)echo"<tr valign='top'><td>".h($X[0])."<td>".h($X[1])."<th>".h($x)."<td><a href='".h(ME.'trigger='.urlencode($a).'&name='.urlencode($x))."'>".lang(145)."</a>\n";echo"</table>\n";}echo'<p class="links"><a href="'.h(ME).'trigger='.urlencode($a).'">'.lang(150)."</a>\n";}$re=driver()->inheritedTables($a);if($re){echo"<h3 id='partitions'>".lang(151)."</h3>\n";$Tg=driver()->partitionsInfo($a);if($Tg)echo"<p><code class='jush-".JUSH."'>BY ".h("$Tg[partition_by]($Tg[partition])")."</code>\n";tables_links($re);}}elseif(isset($_GET["schema"])){page_header(lang(71),"",array(),h(DB.($_GET["ns"]?".$_GET[ns]":"")));$Xi=array();$Yi=array();$dd=array();$da=($_GET["schema"]?:$_COOKIE["adminer_schema-".str_replace(".","_",DB)]);preg_match_all('~([^:]+):([-0-9.]+)x([-0-9.]+)(_|$)~',$da,$pf,PREG_SET_ORDER);foreach($pf
as$s=>$A){$Xi[$A[1]]=array((float)$A[2],(float)$A[3]);$Yi[]="\n\t'".js_escape($A[1])."': [ $A[2], $A[3] ]";}$vj=0;$La=-1;$Zh=array();$Gh=array();$Xe=array();$va=driver()->allFields();foreach(table_status('',true)as$R=>$S){if(is_view($S))continue;$G=0;$Zh[$R]["fields"]=array();foreach($va[$R]as$n){$G+=1.25;$dd[$R][$n["field"]]=$G;$Zh[$R]["fields"][$n["field"]]=$n;}$Zh[$R]["pos"]=($Xi[$R]?:array($vj,0));foreach(adminer()->foreignKeys($R)as$X){if(!$X["db"]){$Ve=$La;if(idx($Xi[$R],1)||idx($Xi[$X["table"]],1))$Ve=min(idx($Xi[$R],1,0),idx($Xi[$X["table"]],1,0))-1;else$La-=.1;while($Xe[(string)$Ve])$Ve-=.0001;$Zh[$R]["references"][$X["table"]][(string)$Ve]=array($X["source"],$X["target"]);$Gh[$X["table"]][$R][(string)$Ve]=$X["target"];$Xe[(string)$Ve]=true;}}$vj=max($vj,$Zh[$R]["pos"][0]+2.5+$G);}echo'<div id="schema" style="height: ',$vj,'em;">
<script',nonce(),'>
qs(\'#schema\').onselectstart = () => false;
const tablePos = {',implode(",",$Yi)."\n",'};
const em = qs(\'#schema\').offsetHeight / ',$vj,';
document.onmousemove = schemaMousemove;
document.onmouseup = partialArg(schemaMouseup, \'',js_escape(DB),'\');
</script>
';foreach($Zh
as$B=>$R){echo"<div class='table' style='top: ".$R["pos"][0]."em; left: ".$R["pos"][1]."em;'>",'<a href="'.h(ME).'table='.urlencode($B).'"><b>'.h($B)."</b></a>",script("qsl('div').onmousedown = schemaMousedown;");foreach($R["fields"]as$n){$X='<span'.type_class($n["type"]).' title="'.h($n["type"].($n["length"]?"($n[length])":"").($n["null"]?" NULL":'')).'">'.h($n["field"]).'</span>';echo"<br>".($n["primary"]?"<i>$X</i>":$X);}foreach((array)$R["references"]as$fj=>$Ih){foreach($Ih
as$Ve=>$Dh){$We=$Ve-idx($Xi[$B],1);$s=0;foreach($Dh[0]as$zi)echo"\n<div class='references' title='".h($fj)."' id='refs$Ve-".($s++)."' style='left: $We"."em; top: ".$dd[$B][$zi]."em; padding-top: .5em;'>"."<div style='border-top: 1px solid gray; width: ".(-$We)."em;'></div></div>";}}foreach((array)$Gh[$B]as$fj=>$Ih){foreach($Ih
as$Ve=>$e){$We=$Ve-idx($Xi[$B],1);$s=0;foreach($e
as$ej)echo"\n<div class='references arrow' title='".h($fj)."' id='refd$Ve-".($s++)."' style='left: $We"."em; top: ".$dd[$B][$ej]."em;'>"."<div style='height: .5em; border-bottom: 1px solid gray; width: ".(-$We)."em;'></div>"."</div>";}}echo"\n</div>\n";}foreach($Zh
as$B=>$R){foreach((array)$R["references"]as$fj=>$Ih){if($Zh[$fj]){foreach($Ih
as$Ve=>$Dh){$Kf=$vj;$vf=-10;foreach($Dh[0]as$x=>$zi){$ih=$R["pos"][0]+$dd[$B][$zi];$jh=$Zh[$fj]["pos"][0]+$dd[$fj][$Dh[1][$x]];$Kf=min($Kf,$ih,$jh);$vf=max($vf,$ih,$jh);}echo"<div class='references' id='refl$Ve' style='left: $Ve"."em; top: $Kf"."em; padding: .5em 0;'><div style='border-right: 1px solid gray; margin-top: 1px; height: ".($vf-$Kf)."em;'></div></div>\n";}}}}echo'</div>
<p class="links"><a href="',h(ME."schema=".urlencode($da)),'" id="schema-link">',lang(152),'</a>
';}elseif(isset($_GET["dump"])){$a=$_GET["dump"];if($_POST&&!$m){$l=array("auto_increment"=>'');foreach(array("type","routine","event","trigger")as$Qi){if(support($Qi))$l[$Qi."s"]='';}save_settings(array_intersect_key($_POST+$l,array_flip(array("output","format","db_style","table_style","data_style"))+$l),"adminer_export");$T=array_flip((array)$_POST["tables"])+array_flip((array)$_POST["data"]);$Tc=dump_headers((count($T)==1?key($T):DB),(DB==""||$_GET["ns"]===""||count($T)>1));$Ee=preg_match('~sql~',$_POST["format"]);if($Ee){echo"-- Adminer ".VERSION." ".get_driver(DRIVER)." ".str_replace("\n"," ",connection()->server_info)." dump\n\n";if(JUSH=="sql"){echo"SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
".($_POST["data_style"]?"SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';
":"")."
";connection()->query("SET time_zone = '+00:00'");connection()->query("SET sql_mode = ''");}}$Li=$_POST["db_style"];$j=array(DB);if(DB==""){$j=$_POST["databases"];if(is_string($j))$j=explode("\n",rtrim(str_replace("\r","",$j),"\n"));}foreach((array)$j
as$k){adminer()->dumpDatabase($k);if(connection()->select_db($k)){if($Ee){if($Li)echo
use_sql($k,$Li).";\n\n";$Jg="";if($_POST["types"]){foreach(types()as$t=>$U){$Hc=type_values($t);if($Hc)$Jg
.=($Li!='DROP+CREATE'?"DROP TYPE IF EXISTS ".idf_escape($U).";;\n":"")."CREATE TYPE ".idf_escape($U)." AS ENUM ($Hc);\n\n";else$Jg
.="-- Could not export type $U\n\n";}}if($_POST["routines"]){foreach(routines()as$K){$B=$K["ROUTINE_NAME"];$Th=$K["ROUTINE_TYPE"];$i=create_routine($Th,array("name"=>$B)+routine($K["SPECIFIC_NAME"],$Th));set_utf8mb4($i);$Jg
.=($Li!='DROP+CREATE'?"DROP $Th IF EXISTS ".idf_escape($B).";;\n":"")."$i;\n\n";}}if($_POST["events"]){foreach(get_rows("SHOW EVENTS",null,"-- ")as$K){$i=remove_definer(get_val("SHOW CREATE EVENT ".idf_escape($K["Name"]),3));set_utf8mb4($i);$Jg
.=($Li!='DROP+CREATE'?"DROP EVENT IF EXISTS ".idf_escape($K["Name"]).";;\n":"")."$i;;\n\n";}}echo($Jg&&JUSH=='sql'?"DELIMITER ;;\n\n$Jg"."DELIMITER ;\n\n":$Jg);}if($_POST["table_style"]||$_POST["data_style"]){foreach(($_GET["ns"]===""?(array)$_POST["schemas"]:(DB!=""||!support("scheme")?array(""):adminer()->schemas()))as$Zh){if($Zh!=""){set_schema($Zh);if(DB==""&&(information_schema(DB)||$Zh=="pg_catalog"))continue;}$lk=array();foreach(table_status('',true)as$B=>$S){$R=(DB==""||$_GET["ns"]===""||in_array($B,(array)$_POST["tables"]));$Pb=(DB==""||$_GET["ns"]===""||in_array($B,(array)$_POST["data"]));if($R||$Pb){$sj=null;if($Tc=="tar"){$sj=new
TmpFile;ob_start(array($sj,'write'),1e5);}adminer()->dumpTable($B,($R?$_POST["table_style"]:""),(is_view($S)?2:0));if(is_view($S))$lk[]=$B;elseif($Pb){$o=fields($B);adminer()->dumpData($B,$_POST["data_style"],"SELECT *".convert_fields($o,$o)." FROM ".table($B));}if($Ee&&$_POST["triggers"]&&$R&&($Fj=trigger_sql($B)))echo"\nDELIMITER ;;\n$Fj\nDELIMITER ;\n";if($Tc=="tar"){ob_end_flush();tar_file((DB!=""?"":"$k/")."$B.csv",$sj);}elseif($Ee)echo"\n";}}if(function_exists('Adminer\foreign_keys_sql')){foreach(table_status('',true)as$B=>$S){$R=(DB==""||$_GET["ns"]===""||in_array($B,(array)$_POST["tables"]));if($R&&!is_view($S))echo
foreign_keys_sql($B);}}foreach($lk
as$kk)adminer()->dumpTable($kk,$_POST["table_style"],1);if($Tc=="tar")echo
pack("x512");}}}}adminer()->dumpFooter();exit;}page_header(lang(77),$m,($_GET["export"]!=""?array("table"=>$_GET["export"]):array()),h(DB));echo'
<form action="" method="post">
<table class="layout">
';$Tb=array('','USE','DROP+CREATE','CREATE');$Zi=array('','DROP+CREATE','CREATE');$Qb=array('','TRUNCATE+INSERT','INSERT');if(JUSH=="sql")$Qb[]='INSERT+UPDATE';$K=get_settings("adminer_export");if(!$K)$K=array("output"=>"text","format"=>"sql","db_style"=>(DB!=""?"":"CREATE"),"table_style"=>"DROP+CREATE","data_style"=>"INSERT");echo"<tr><th>".lang(153)."<td>".html_radios("output",adminer()->dumpOutput(),$K["output"])."\n","<tr><th>".lang(154)."<td>".html_radios("format",adminer()->dumpFormat(),$K["format"])."\n",(JUSH=="sqlite"?"":"<tr><th>".lang(38)."<td>".html_select('db_style',$Tb,$K["db_style"]).(support("type")?checkbox("types",1,$K["types"],lang(6)):"").(support("routine")?checkbox("routines",1,$K["routines"],lang(73)):"").(support("event")?checkbox("events",1,$K["events"],lang(75)):"")),"<tr><th>".lang(129)."<td>".html_select('table_style',$Zi,$K["table_style"]).checkbox("auto_increment",1,$K["auto_increment"],lang(52)).(support("trigger")?checkbox("triggers",1,$K["triggers"],lang(149)):""),"<tr><th>".lang(155)."<td>".html_select('data_style',$Qb,$K["data_style"]),'</table>
<p><input type="submit" value="',lang(77),'">
',input_token(),'
<table>
',script("qsl('table').onclick = dumpClick;");$nh=array();if($_GET["ns"]===""){echo"<thead><tr><th style='text-align: left;'>","<label class='block'><input type='checkbox' id='check-schemas' checked class='jsonly'>".lang(80)."</label>","</thead>\n",script("qs('#check-schemas').onclick = partial(formCheck, /^schemas\\[/);");foreach(adminer()->schemas()as$Zh)echo"<tr><td>".checkbox("schemas[]",$Zh,true,$Zh,"","block")."\n";}elseif(DB!=""){$eb=($a!=""?"":" checked");echo"<thead><tr>","<th style='text-align: left;'><label class='block'><input type='checkbox' id='check-tables'$eb class='jsonly'>".lang(139)."</label>".script("qs('#check-tables').onclick = partial(formCheck, /^tables\\[/);",""),"<th style='text-align: right;'><label class='block'>".lang(155)."<input type='checkbox' id='check-data'$eb class='jsonly'></label>".script("qs('#check-data').onclick = partial(formCheck, /^data\\[/);",""),"</thead>\n";$lk="";$bj=tables_list();foreach($bj
as$B=>$U){$mh=preg_replace('~_.*~','',$B);$eb=($a==""||$a==(substr($a,-1)=="%"?"$mh%":$B));$rh="<tr><td>".checkbox("tables[]",$B,$eb,$B,"","block");if($U!==null&&!preg_match('~table~i',$U))$lk
.="$rh\n";else
echo"$rh<td align='right'><label class='block'><span id='Rows-".h($B)."'></span>".checkbox("data[]",$B,$eb)."</label>\n";$nh[$mh]++;}echo$lk;if($bj)echo
script("ajaxSetHtml('".js_escape(ME)."script=db');");}else{$j=adminer()->databases();echo"<thead><tr><th style='text-align: left;'>","<label class='block'>".($j?"<input type='checkbox' id='check-databases'".($a==""?" checked":"")." class='jsonly'>".script("qs('#check-databases').onclick = partial(formCheck, /^databases\\[/);",""):"").lang(38)."</label>","</thead>\n";if($j){foreach($j
as$k){if(!information_schema($k)){$mh=preg_replace('~_.*~','',$k);echo"<tr><td>".checkbox("databases[]",$k,$a==""||$a=="$mh%",$k,"","block")."\n";$nh[$mh]++;}}}else
echo"<tr><td><textarea name='databases' rows='10' cols='20'></textarea>";}echo'</table>
</form>
';$kd=true;foreach($nh
as$x=>$X){if($x!=""&&$X>1){echo($kd?"<p>":" ")."<a href='".h(ME)."dump=".urlencode("$x%")."'>".h($x)."</a>";$kd=false;}}}elseif(isset($_GET["privileges"])){page_header(lang(72));echo'<p class="links"><a href="'.h(ME).'user=">'.lang(156)."</a>";$I=connection()->query("SELECT User, Host FROM mysql.".(DB==""?"user":"db WHERE ".q(DB)." LIKE Db")." ORDER BY Host, User");$Cd=$I;if(!$I)$I=connection()->query("SELECT SUBSTRING_INDEX(CURRENT_USER, '@', 1) AS User, SUBSTRING_INDEX(CURRENT_USER, '@', -1) AS Host");echo"<form action=''><p>\n";hidden_fields_get();echo
input_hidden("db",DB),($Cd?"":input_hidden("grant")),"<table class='odds'>\n","<thead><tr><th>".lang(36)."<th>".lang(34)."<th></thead>\n";while($K=$I->fetch_assoc())echo'<tr><td>'.h($K["User"])."<td>".h($K["Host"]).'<td><a href="'.h(ME.'user='.urlencode($K["User"]).'&host='.urlencode($K["Host"])).'">'.lang(12)."</a>\n";if(!$Cd||DB!="")echo"<tr><td><input name='user' autocapitalize='off'><td><input name='host' value='localhost' autocapitalize='off'><td><input type='submit' value='".lang(12)."'>\n";echo"</table>\n","</form>\n";}elseif(isset($_GET["sql"])){if(!$m&&$_POST["export"]){save_settings(array("output"=>$_POST["output"],"format"=>$_POST["format"]),"adminer_import");dump_headers("sql");if($_POST["format"]=="sql")echo"$_POST[query]\n";else{adminer()->dumpTable("","");adminer()->dumpData("","table",$_POST["query"]);adminer()->dumpFooter();}exit;}restart_session();$Td=&get_session("queries");$Sd=&$Td[DB];if(!$m&&$_POST["clear"]){$Sd=array();redirect(remove_from_uri("history"));}stop_session();page_header((isset($_GET["import"])?lang(76):lang(65)),$m);$df='--'.(JUSH=='sql'?' ':'');if(!$m&&$_POST){$q=false;if(!isset($_GET["import"]))$H=$_POST["query"];elseif($_POST["webfile"]){$Ci=adminer()->importServerPath();$q=@fopen((file_exists($Ci)?$Ci:"compress.zlib://$Ci.gz"),"rb");$H=($q?fread($q,1e6):false);}else$H=get_file("sql_file",true,";");if(is_string($H)){if(($_f=ini_bytes("memory_limit"))!="-1")ini_set("memory_limit",max($_f,strval(2*strlen($H)+memory_get_usage()+8e6)));if($H!=""&&strlen($H)<1e6){$xh=$H.(preg_match("~;[ \t\r\n]*\$~",$H)?"":";");if(!$Sd||first(end($Sd))!=$xh){restart_session();$Sd[]=array($xh,time());set_session("queries",$Td);stop_session();}}$_i="(?:\\s|/\\*[\s\S]*?\\*/|(?:#|$df)[^\n]*\n?|--\r?\n)";$bc=driver()->delimiter;$C=0;$Bc=true;$h=connect();if($h&&DB!=""){$h->select_db(DB);if($_GET["ns"]!="")set_schema($_GET["ns"],$h);}$rb=0;$Jc=array();$Qg='[\'"'.(JUSH=="sql"?'`#':(JUSH=="sqlite"?'`[':(JUSH=="mssql"?'[':''))).']|/\*|'.$df.'|$'.(JUSH=="pgsql"?'|\$([a-zA-Z]\w*)?\$':'');$wj=microtime(true);$pa=get_settings("adminer_import");while($H!=""){if(!$C&&preg_match("~^$_i*+DELIMITER\\s+(\\S+)~i",$H,$A)){$bc=preg_quote($A[1]);$H=substr($H,strlen($A[0]));}elseif(!$C&&JUSH=='pgsql'&&preg_match("~^($_i*+COPY\\s+)[^;]+\\s+FROM\\s+stdin;~i",$H,$A)){$bc="\n\\\\\\.\r?\n";$C=strlen($A[0]);}else{preg_match("($bc\\s*|$Qg)",$H,$A,PREG_OFFSET_CAPTURE,$C);list($wd,$G)=$A[0];if(!$wd&&$q&&!feof($q))$H
.=fread($q,1e5);else{if(!$wd&&rtrim($H)=="")break;$C=$G+strlen($wd);if($wd&&!preg_match("(^$bc)",$wd)){$Wa=driver()->hasCStyleEscapes()||(JUSH=="pgsql"&&($G>0&&strtolower($H[$G-1])=="e"));$bh=($wd=='/*'?'\*/':($wd=='['?']':(preg_match("~^$df|^#~",$wd)?"\n":preg_quote($wd).($Wa?'|\\\\.':''))));while(preg_match("($bh|\$)s",$H,$A,PREG_OFFSET_CAPTURE,$C)){$Xh=$A[0][0];if(!$Xh&&$q&&!feof($q))$H
.=fread($q,1e5);else{$C=$A[0][1]+strlen($Xh);if(!$Xh||$Xh[0]!="\\")break;}}}else{$Bc=false;$xh=substr($H,0,$G+($bc[0]=="\n"?3:0));$rb++;$rh="<pre id='sql-$rb'><code class='jush-".JUSH."'>".adminer()->sqlCommandQuery($xh)."</code></pre>\n";if(JUSH=="sqlite"&&preg_match("~^$_i*+(ATTACH|VACUUM\\b.*\\bINTO)\\b~is",$xh,$A)!==0){echo$rh,"<p class='error'>".lang(157,preg_match('~ATTACH~i',$A[1])?'ATTACH':'VACUUM INTO')."\n";$Jc[]=" <a href='#sql-$rb'>$rb</a>";if($_POST["error_stops"])break;}else{if(!$_POST["only_errors"]){echo$rh;ob_flush();flush();}$Hi=microtime(true);if(connection()->multi_query($xh)&&$h&&preg_match("~^$_i*+USE\\b~i",$xh))$h->query($xh);do{$I=connection()->store_result();if(connection()->error){echo($_POST["only_errors"]?$rh:""),"<p class='error'>".lang(158).(connection()->errno?" (".connection()->errno.")":"").": ".error()."\n";$Jc[]=" <a href='#sql-$rb'>$rb</a>";if($_POST["error_stops"])break
2;}else{$lj=" <span class='time'>(".format_time($Hi).")</span>".(strlen($xh)<1000?" <a href='".h(ME)."sql=".urlencode(trim($xh))."'>".lang(12)."</a>":"");$ra=connection()->affected_rows;$ok=($_POST["only_errors"]?"":driver()->warnings());$pk="warnings-$rb";if($ok)$lj
.=", <a href='#$pk'>".lang(47)."</a>".script("qsl('a').onclick = partial(toggle, '$pk');","");$Rc=null;$Bg=null;$Sc="explain-$rb";if(is_object($I)){$z=$_POST["limit"];$Bg=print_select_result($I,$h,array(),$z);if(!$_POST["only_errors"]){echo"<form action='' method='post'>\n";$dg=$I->num_rows;echo"<p class='sql-footer'>".($dg?($z&&$dg>$z?lang(159,$z):"").lang(160,$dg):""),$lj;if($h&&preg_match("~^($_i|\\()*+SELECT\\b~i",$xh)&&($Rc=explain($h,$xh)))echo", <a href='#$Sc'>Explain</a>".script("qsl('a').onclick = partial(toggle, '$Sc');","");$t="export-$rb";echo", <a href='#$t'>".lang(77)."</a>".script("qsl('a').onclick = partial(toggle, '$t');","")."<span id='$t' class='hidden'>: ".html_select("output",adminer()->dumpOutput(),$pa["output"])." ".html_select("format",adminer()->dumpFormat(),$pa["format"]).input_hidden("query",$xh)."<input type='submit' name='export' value='".lang(77)."'>".input_token()."</span>\n"."</form>\n";}}else{if(preg_match("~^$_i*+(CREATE|DROP|ALTER)$_i++(DATABASE|SCHEMA)\\b~i",$xh)){restart_session();set_session("dbs",null);stop_session();}if(!$_POST["only_errors"])echo"<p class='message' title='".h(connection()->info)."'>".lang(161,$ra)."$lj\n";}echo($ok?"<div id='$pk' class='hidden'>\n$ok</div>\n":"");if($Rc){echo"<div id='$Sc' class='hidden explain'>\n";print_select_result($Rc,$h,$Bg);echo"</div>\n";}}$Hi=microtime(true);}while(connection()->next_result());}$H=substr($H,$C);$C=0;}}}}if($Bc)echo"<p class='message'>".lang(162)."\n";elseif($_POST["only_errors"])echo"<p class='message'>".lang(163,$rb-count($Jc))," <span class='time'>(".format_time($wj).")</span>\n";elseif($Jc&&$rb>1)echo"<p class='error'>".lang(158).": ".implode("",$Jc)."\n";}else
echo"<p class='error'>".upload_error($H)."\n";}echo'
<form action="" method="post" enctype="multipart/form-data" id="form">
';$Pc="<input type='submit' value='".lang(164)."' title='Ctrl+Enter'>";if(!isset($_GET["import"])){$xh=$_GET["sql"];if($_POST)$xh=$_POST["query"];elseif($_GET["history"]=="all")$xh=$Sd;elseif($_GET["history"]!="")$xh=idx($Sd[$_GET["history"]],0);echo"<p>";textarea("query",$xh,20);echo
script(($_POST?"":"qs('textarea').focus();\n")."qs('#form').onsubmit = partial(sqlSubmit, qs('#form'), '".js_escape(remove_from_uri("sql|limit|error_stops|only_errors|history"))."');"),"<p>";adminer()->sqlPrintAfter();echo"$Pc\n",lang(165).": <input type='number' name='limit' class='size' value='".h($_POST?$_POST["limit"]:$_GET["limit"])."'>\n";}else{$Id=(extension_loaded("zlib")?"[.gz]":"");echo"<fieldset><legend>".lang(166)."</legend><div>",file_input("SQL$Id: <input type='file' name='sql_file[]' multiple>\n$Pc"),"</div></fieldset>\n";$ee=adminer()->importServerPath();if($ee)echo"<fieldset><legend>".lang(167)."</legend><div>",lang(168,"<code>".h($ee)."$Id</code>"),' <input type="submit" name="webfile" value="'.lang(169).'">',"</div></fieldset>\n";echo"<p>";}echo
checkbox("error_stops",1,($_POST?$_POST["error_stops"]:isset($_GET["import"])||$_GET["error_stops"]),lang(170))."\n",checkbox("only_errors",1,($_POST?$_POST["only_errors"]:isset($_GET["import"])||$_GET["only_errors"]),lang(171))."\n",input_token();if(!isset($_GET["import"])&&$Sd){print_fieldset("history",lang(172),$_GET["history"]!="");for($X=end($Sd);$X;$X=prev($Sd)){$x=key($Sd);list($xh,$lj,$yc)=$X;echo'<a href="'.h(ME."sql=&history=$x").'">'.lang(12)."</a>"." <span class='time' title='".@date('Y-m-d',$lj)."'>".@date("H:i:s",$lj)."</span>"." <code class='jush-".JUSH."'>".shorten_utf8(ltrim(str_replace("\n"," ",str_replace("\r","",preg_replace("~^(#|$df).*~m",'',$xh)))),80,"</code>").($yc?" <span class='time'>($yc)</span>":"")."<br>\n";}echo"<input type='submit' name='clear' value='".lang(173)."'>\n","<a href='".h(ME."sql=&history=all")."'>".lang(174)."</a>\n","</div></fieldset>\n";}echo'</form>
';}elseif(isset($_GET["edit"])){$a=$_GET["edit"];$o=fields($a);$Z=(isset($_GET["select"])?($_POST["check"]&&count($_POST["check"])==1?where_check($_POST["check"][0],$o):""):where($_GET,$o));$Rj=(isset($_GET["select"])?$_POST["edit"]:$Z);foreach($o
as$B=>$n){if((!$Rj&&!isset($n["privileges"]["insert"]))||adminer()->fieldName($n)=="")unset($o[$B]);}if($_POST&&!$m&&!isset($_GET["select"])){$if=$_POST["referer"];if($_POST["insert"])$if=($Rj?null:$_SERVER["REQUEST_URI"]);elseif(!preg_match('~^.+&select=.+$~',$if))$if=ME."select=".urlencode($a);$w=indexes($a);$Mj=unique_array($_GET["where"],$w);$_h="\nWHERE $Z";if(isset($_POST["delete"]))queries_redirect($if,lang(175),driver()->delete($a,$_h,$Mj?0:1));else{$O=array();foreach($o
as$B=>$n){$X=process_input($n);if($X!==false&&$X!==null)$O[idf_escape($B)]=$X;}if($Rj){if(!$O)redirect($if);queries_redirect($if,lang(176),driver()->update($a,$O,$_h,$Mj?0:1));if(is_ajax()){page_headers();page_messages($m);exit;}}else{$I=driver()->insert($a,$O);$Ue=($I?last_id($I):0);queries_redirect($if,lang(177,($Ue?" $Ue":"")),$I);}}}$K=null;if($Z){$M=array();foreach($o
as$B=>$n){if(isset($n["privileges"]["select"])){$_a=($_POST["clone"]&&$n["auto_increment"]?"''":convert_field($n));$M[]=($_a?"$_a AS ":"").idf_escape($B);}}$K=array();if(!support("table"))$M=array("*");if($M){$I=driver()->select($a,$M,array($Z),$M,array(),(isset($_GET["select"])?2:1));if(!$I)$m=error();else{$K=$I->fetch_assoc();if(!$K)$K=false;}if(isset($_GET["select"])&&(!$K||$I->fetch_assoc()))$K=null;}}if(!support("table")&&!$o){if(!$Z){$I=driver()->select($a,array("*"),array(),array("*"));$K=($I?$I->fetch_assoc():false);if(!$K)$K=array(driver()->primary=>"");}if($K){foreach($K
as$x=>$X){if(!$Z)$K[$x]=null;$o[$x]=array("field"=>$x,"null"=>($x!=driver()->primary),"auto_increment"=>($x==driver()->primary));}}}if($_POST["save"])$K=(array)$_POST["fields"]+($K?$K:array());edit_form($a,$o,$K,$Rj,$m);}elseif(isset($_GET["create"])){$a=$_GET["create"];$Vg=driver()->partitionBy;$Yg=($Vg?driver()->partitionsInfo($a):array());$Fh=referencable_primary($a);$ud=array();foreach($Fh
as$Vi=>$n)$ud[str_replace("`","``",$Vi)."`".str_replace("`","``",$n["field"])]=$Vi;$Eg=array();$S=array();if($a!=""){$Eg=fields($a);$S=table_status1($a);if(count($S)<2)$m=lang(11);}$K=$_POST;$K["fields"]=(array)$K["fields"];if($K["auto_increment_col"])$K["fields"][$K["auto_increment_col"]]["auto_increment"]=true;if($_POST&&!$m)save_settings(array("comments"=>$_POST["comments"],"defaults"=>$_POST["defaults"]));if($_POST&&!process_fields($K["fields"])&&!$m){if($_POST["drop"])queries_redirect(substr(ME,0,-1),lang(178),drop_tables(array($a)));else{$o=array();$va=array();$Xj=false;$sd=array();$Dg=reset($Eg);$ta=" FIRST";foreach($K["fields"]as$x=>$n){$p=$ud[$n["type"]];$Hj=($p!==null?$Fh[$p]:$n);if($n["field"]!=""){if(!$n["generated"])$n["default"]=null;$wh=process_field($n,$Hj);$va[]=array($n["orig"],$wh,$ta);if(!$Dg||$wh!==process_field($Dg,$Dg)){$o[]=array($n["orig"],$wh,$ta);if($n["orig"]!=""||$ta)$Xj=true;}if($p!==null)$sd[idf_escape($n["field"])]=($a!=""&&JUSH!="sqlite"?"ADD":" ").format_foreign_key(array('table'=>$ud[$n["type"]],'source'=>array($n["field"]),'target'=>array($Hj["field"]),'on_delete'=>$n["on_delete"],));$ta=" AFTER ".idf_escape($n["field"]);}elseif($n["orig"]!=""){$Xj=true;$o[]=array($n["orig"]);}if($n["orig"]!=""){$Dg=next($Eg);if(!$Dg)$ta="";}}$E=array();if(in_array($K["partition_by"],$Vg)){foreach($K
as$x=>$X){if(preg_match('~^partition~',$x))$E[$x]=$X;}foreach($E["partition_names"]as$x=>$B){if($B==""){unset($E["partition_names"][$x]);unset($E["partition_values"][$x]);}}$E["partition_names"]=array_values($E["partition_names"]);$E["partition_values"]=array_values($E["partition_values"]);if($E==$Yg)$E=array();}elseif(preg_match("~partitioned~",$S["Create_options"]))$E=null;$Bf=lang(179);if($a==""){cookie("adminer_engine",$K["Engine"]);$Bf=lang(180);}$B=trim($K["name"]);queries_redirect(ME.(support("table")?"table=":"select=").urlencode($B),$Bf,alter_table($a,$B,(JUSH=="sqlite"&&($Xj||$sd)?$va:$o),$sd,($K["Comment"]!=$S["Comment"]?$K["Comment"]:null),($K["Engine"]&&$K["Engine"]!=$S["Engine"]?$K["Engine"]:""),($K["Collation"]&&$K["Collation"]!=$S["Collation"]?$K["Collation"]:""),($K["Auto_increment"]!=""?number($K["Auto_increment"]):""),$E));}}page_header(($a!=""?lang(45):lang(78)),$m,array("table"=>$a),h($a));if(!$_POST){$Ij=driver()->types();$K=array("Engine"=>$_COOKIE["adminer_engine"],"fields"=>array(array("field"=>"","type"=>(isset($Ij["int"])?"int":(isset($Ij["integer"])?"integer":"")),"on_update"=>"")),"partition_names"=>array(""),);if($a!=""){$K=$S;$K["name"]=$a;$K["fields"]=array();if(!$_GET["auto_increment"])$K["Auto_increment"]="";foreach($Eg
as$n){$n["generated"]=$n["generated"]?:(isset($n["default"])?"DEFAULT":"");$K["fields"][]=$n;}if($Vg){$K+=$Yg;$K["partition_names"][]="";$K["partition_values"][]="";}}}$nb=collations();if(is_array(reset($nb)))$nb=call_user_func_array('array_merge',array_values($nb));$Dc=driver()->engines();foreach($Dc
as$Cc){if(!strcasecmp($Cc,$K["Engine"])){$K["Engine"]=$Cc;break;}}echo'
<form action="" method="post" id="form">
<p>
';if(support("columns")||$a==""){echo
lang(181).": <input name='name'".($a==""&&!$_POST?" autofocus":"")." data-maxlength='64' value='".h($K["name"])."' autocapitalize='off'>\n",($Dc?html_select("Engine",array(""=>"(".lang(182).")")+$Dc,$K["Engine"]).on_help("event.target.value",1).script("qsl('select').onchange = helpClose;")."\n":"");if($nb)echo"<datalist id='collations'>".optionlist($nb)."</datalist>\n",(preg_match("~sqlite|mssql~",JUSH)?"":"<input list='collations' name='Collation' value='".h($K["Collation"])."' placeholder='(".lang(108).")'>\n");echo"<input type='submit' value='".lang(16)."'>\n";}if(support("columns")){echo"<div class='scrollable'>\n","<table id='edit-fields' class='nowrap'>\n";edit_fields($K["fields"],$nb,"TABLE",$ud);echo"</table>\n",script("editFields();"),"</div>\n<p>\n",lang(52).": <input type='number' name='Auto_increment' class='size' value='".h($K["Auto_increment"])."'>\n",checkbox("defaults",1,($_POST?$_POST["defaults"]:get_setting("defaults")),lang(183),"columnShow(this.checked, 5)","jsonly");$ub=($_POST?$_POST["comments"]:get_setting("comments"));echo(support("comment")?checkbox("comments",1,$ub,lang(51),"editingCommentsClick(this, true);","jsonly").' '.(preg_match('~\n~',$K["Comment"])?"<textarea name='Comment' rows='2' cols='20'".($ub?"":" class='hidden'").">".h($K["Comment"])."</textarea>":'<input name="Comment" value="'.h($K["Comment"]).'" data-maxlength="'.(min_version(5.5)?2048:60).'"'.($ub?"":" class='hidden'").'>'):''),'<p>
<input type="submit" value="',lang(16),'">
';}echo'
';if($a!="")echo'<input type="submit" name="drop" value="',lang(133),'">',confirm(lang(184,$a));if($Vg&&(JUSH=='sql'||$a=="")){$Wg=preg_match('~RANGE|LIST~',$K["partition_by"]);print_fieldset("partition",lang(185),$K["partition_by"]);echo"<p>".html_select("partition_by",array_merge(array(""),$Vg),$K["partition_by"]).on_help("event.target.value.replace(/./, 'PARTITION BY \$&')",1).script("qsl('select').onchange = partitionByChange;"),"(<input name='partition' value='".h($K["partition"])."'>)\n",lang(186).": <input type='number' name='partitions' class='size".($Wg||!$K["partition_by"]?" hidden":"")."' value='".h($K["partitions"])."'>\n","<table id='partition-table'".($Wg?"":" class='hidden'").">\n","<thead><tr><th>".lang(187)."<th>".lang(188)."</thead>\n";foreach($K["partition_names"]as$x=>$X)echo'<tr>','<td><input name="partition_names[]" value="'.h($X).'" autocapitalize="off">',($x==count($K["partition_names"])-1?script("qsl('input').oninput = partitionNameChange;"):''),'<td><input name="partition_values[]" value="'.h(idx($K["partition_values"],$x)).'">';echo"</table>\n</div></fieldset>\n";}echo
input_token(),'</form>
';}elseif(isset($_GET["indexes"])){$a=$_GET["indexes"];$me=array("PRIMARY","UNIQUE","INDEX");$S=table_status1($a,true);$je=driver()->indexAlgorithms($S);if(preg_match('~MyISAM|M?aria'.(min_version(5.6,'10.0.5')?'|InnoDB':'').'~i',$S["Engine"]))$me[]="FULLTEXT";if(preg_match('~MyISAM|M?aria'.(min_version(5.7,'10.2.2')?'|InnoDB':'').'~i',$S["Engine"]))$me[]="SPATIAL";if(min_version('',11.7)&&preg_match('~MyISAM|InnoDB~i',$S["Engine"]))$me[]="VECTOR";$w=indexes($a);$o=fields($a);$ph=array();if(JUSH=="mongo"){$ph=$w["_id_"];unset($me[0]);unset($w["_id_"]);}$K=$_POST;if($K)save_settings(array("index_options"=>$K["options"]));if($_POST&&!$m&&!$_POST["add"]&&!$_POST["drop_col"]){$b=array();foreach($K["indexes"]as$v){$B=$v["name"];if(in_array($v["type"],$me)){$e=array();$bf=array();$ec=array();$ke=(support("partial_indexes")?$v["partial"]:"");$ie=(in_array($v["algorithm"],$je)?$v["algorithm"]:"");$O=array();ksort($v["columns"]);foreach($v["columns"]as$x=>$d){if($d!=""){$y=idx($v["lengths"],$x);$cc=idx($v["descs"],$x);$O[]=($o[$d]?idf_escape($d):$d).($y?"(".(+$y).")":"").($cc?" DESC":"");$e[]=$d;$bf[]=($y?:null);$ec[]=$cc;}}$Qc=$w[$B];if($Qc){ksort($Qc["columns"]);ksort($Qc["lengths"]);ksort($Qc["descs"]);if($v["type"]==$Qc["type"]&&array_values($Qc["columns"])===$e&&(!$Qc["lengths"]||array_values($Qc["lengths"])===$bf)&&array_values($Qc["descs"])===$ec&&$Qc["partial"]==$ke&&(!$je||$Qc["algorithm"]==$ie)){unset($w[$B]);continue;}}if($e)$b[]=array($v["type"],$B,$O,$ie,$ke);}}foreach($w
as$B=>$Qc)$b[]=array($Qc["type"],$B,"DROP");if(!$b)redirect(ME."table=".urlencode($a));queries_redirect(ME."table=".urlencode($a),lang(189),alter_indexes($a,$b));}page_header(lang(141),$m,array("table"=>$a),h($a));$fd=array_keys($o);if($_POST["add"]){foreach($K["indexes"]as$x=>$v){if($v["columns"][count($v["columns"])]!="")$K["indexes"][$x]["columns"][]="";}$v=end($K["indexes"]);if($v["type"]||array_filter($v["columns"],'strlen'))$K["indexes"][]=array("columns"=>array(1=>""));}if(!$K){foreach($w
as$x=>$v){$w[$x]["name"]=$x;$w[$x]["columns"][]="";}$w[]=array("columns"=>array(1=>""));$K["indexes"]=$w;}$bf=(JUSH=="sql"||JUSH=="mssql");$ui=($_POST?$_POST["options"]:get_setting("index_options"));echo'
<form action="" method="post">
<div class="scrollable">
<table class="nowrap">
<thead><tr>
<th id="label-type">',lang(190);$ce=" class='idxopts".($ui?"":" hidden")."'";if($je)echo"<th id='label-algorithm'$ce>".lang(191).doc_link(array('sql'=>'create-index.html#create-index-storage-engine-index-types','mariadb'=>'storage-engine-index-types/','pgsql'=>'indexes-types.html',));echo'<th><input type="submit" class="wayoff">',lang(192).($bf?"<span$ce> (".lang(193).")</span>":"");if($bf||support("descidx"))echo
checkbox("options",1,$ui,lang(114),"indexOptionsShow(this.checked)","jsonly")."\n";echo'<th id="label-name">',lang(194);if(support("partial_indexes"))echo"<th id='label-condition'$ce>".lang(195);echo'<th><noscript>',icon("plus","add[0]","+",lang(115)),'</noscript>
</thead>
';if($ph){echo"<tr><td>PRIMARY<td>";foreach($ph["columns"]as$x=>$d)echo
select_input(" disabled",$fd,$d),"<label><input disabled type='checkbox'>".lang(60)."</label> ";echo"<td><td>\n";}$He=1;foreach($K["indexes"]as$v){if(!$_POST["drop_col"]||$He!=key($_POST["drop_col"])){echo"<tr><td>".html_select("indexes[$He][type]",array(-1=>"")+$me,$v["type"],($He==count($K["indexes"])?"indexesAddRow.call(this);":""),"label-type");if($je)echo"<td$ce>".html_select("indexes[$He][algorithm]",array_merge(array(""),$je),$v['algorithm'],"label-algorithm");echo"<td>";ksort($v["columns"]);$s=1;foreach($v["columns"]as$x=>$d){echo"<span>".select_input(" name='indexes[$He][columns][$s]' title='".lang(49)."'",($o&&($d==""||$o[$d])?array_combine($fd,$fd):array()),$d,"partial(".($s==count($v["columns"])?"indexesAddColumn":"indexesChangeColumn").", '".js_escape(JUSH=="sql"?"":$_GET["indexes"]."_")."')"),"<span$ce>",($bf?"<input type='number' name='indexes[$He][lengths][$s]' class='size' value='".h(idx($v["lengths"],$x))."' title='".lang(113)."'>":""),(support("descidx")?checkbox("indexes[$He][descs][$s]",1,idx($v["descs"],$x),lang(60)):""),"</span> </span>";$s++;}echo"<td><input name='indexes[$He][name]' value='".h($v["name"])."' autocapitalize='off' aria-labelledby='label-name'>\n";if(support("partial_indexes"))echo"<td$ce><input name='indexes[$He][partial]' value='".h($v["partial"])."' autocapitalize='off' aria-labelledby='label-condition'>\n";echo"<td>".icon("cross","drop_col[$He]","x",lang(117)).script("qsl('button').onclick = partial(editingRemoveRow, 'indexes\$1[type]');");}$He++;}echo'</table>
</div>
<p>
<input type="submit" value="',lang(16),'">
',input_token(),'</form>
';}elseif(isset($_GET["database"])){$K=$_POST;if($_POST&&!$m&&!$_POST["add"]){$B=trim($K["name"]);if($_POST["drop"]){$_GET["db"]="";queries_redirect(remove_from_uri("db|database"),lang(196),drop_databases(array(DB)));}elseif(DB!==$B){if(DB!=""){$_GET["db"]=$B;queries_redirect(preg_replace('~\bdb=[^&]*&~','',ME)."db=".urlencode($B),lang(197),rename_database($B,$K["collation"]));}else{$j=explode("\n",str_replace("\r","",$B));$Mi=true;$Te="";foreach($j
as$k){if(count($j)==1||$k!=""){if(!create_database($k,$K["collation"]))$Mi=false;$Te=$k;}}restart_session();set_session("dbs",null);queries_redirect(ME."db=".urlencode($Te),lang(198),$Mi);}}else{if(!$K["collation"])redirect(substr(ME,0,-1));query_redirect("ALTER DATABASE ".idf_escape($B).(preg_match('~^[a-z0-9_]+$~i',$K["collation"])?" COLLATE $K[collation]":""),substr(ME,0,-1),lang(199));}}page_header(DB!=""?lang(68):lang(121),$m,array(),h(DB));$nb=collations();$B=DB;if($_POST)$B=$K["name"];elseif(DB!="")$K["collation"]=db_collation(DB,$nb);elseif(JUSH=="sql"){foreach(get_vals("SHOW GRANTS")as$Cd){if(preg_match('~ ON (`(([^\\\\`]|``|\\\\.)*)%`\.\*)?~',$Cd,$A)&&$A[1]){$B=stripcslashes(idf_unescape("`$A[2]`"));break;}}}echo'
<form action="" method="post">
<p>
',($_POST["add"]||strpos($B,"\n")?'<textarea autofocus name="name" rows="10" cols="40">'.h($B).'</textarea><br>':'<input name="name" autofocus value="'.h($B).'" data-maxlength="64" autocapitalize="off">')."\n".($nb?html_select("collation",array(""=>"(".lang(108).")")+$nb,$K["collation"]).doc_link(array('sql'=>"charset-charsets.html",'mariadb'=>"supported-character-sets-and-collations/",'mssql'=>"relational-databases/system-functions/sys-fn-helpcollations-transact-sql",)):""),'<input type="submit" value="',lang(16),'">
';if(DB!="")echo"<input type='submit' name='drop' value='".lang(133)."'>".confirm(lang(184,DB))."\n";elseif(!$_POST["add"]&&$_GET["db"]=="")echo
icon("plus","add[0]","+",lang(115))."\n";echo
input_token(),'</form>
';}elseif(isset($_GET["scheme"])){$K=$_POST;if($_POST&&!$m){$_=preg_replace('~ns=[^&]*&~','',ME)."ns=";if($_POST["drop"])query_redirect("DROP SCHEMA ".idf_escape($_GET["ns"]),$_,lang(200));else{$B=trim($K["name"]);$_
.=urlencode($B);if($_GET["ns"]=="")query_redirect("CREATE SCHEMA ".idf_escape($B),$_,lang(201));elseif($_GET["ns"]!=$B)query_redirect("ALTER SCHEMA ".idf_escape($_GET["ns"])." RENAME TO ".idf_escape($B),$_,lang(202));else
redirect($_);}}page_header($_GET["ns"]!=""?lang(69):lang(70),$m);if(!$K)$K["name"]=$_GET["ns"];echo'
<form action="" method="post">
<p><input name="name" autofocus value="',h($K["name"]),'" autocapitalize="off">
<input type="submit" value="',lang(16),'">
';if($_GET["ns"]!="")echo"<input type='submit' name='drop' value='".lang(133)."'>".confirm(lang(184,$_GET["ns"]))."\n";echo
input_token(),'</form>
';}elseif(isset($_GET["call"])){$ca=($_GET["name"]?:$_GET["call"]);page_header(lang(203).": ".h($ca),$m);$Th=routine($_GET["call"],(isset($_GET["callf"])?"FUNCTION":"PROCEDURE"));$fe=array();$Jg=array();foreach($Th["fields"]as$s=>$n){if(substr($n["inout"],-3)=="OUT"&&JUSH=='sql')$Jg[$s]="@".idf_escape($n["field"])." AS ".idf_escape($n["field"]);if(!$n["inout"]||substr($n["inout"],0,2)=="IN")$fe[]=$s;}if(!$m&&$_POST){$Xa=array();foreach($Th["fields"]as$x=>$n){$X="";if(in_array($x,$fe)){$X=process_input($n);if($X===false)$X="''";if(isset($Jg[$x]))connection()->query("SET @".idf_escape($n["field"])." = $X");}if(isset($Jg[$x]))$Xa[]="@".idf_escape($n["field"]);elseif(in_array($x,$fe))$Xa[]=$X;}$H=(isset($_GET["callf"])?"SELECT ":"CALL ").(idx($Th["returns"],"type")=="record"?"* FROM ":"").table($ca)."(".implode(", ",$Xa).")";$Hi=microtime(true);$I=connection()->multi_query($H);$ra=connection()->affected_rows;echo
adminer()->selectQuery($H,$Hi,!$I);if(!$I)echo"<p class='error'>".error()."\n";else{$h=connect();if($h)$h->select_db(DB);do{$I=connection()->store_result();if(is_object($I))print_select_result($I,$h);else
echo"<p class='message'>".lang(204,$ra)." <span class='time'>".@date("H:i:s")."</span>\n";}while(connection()->next_result());if($Jg)print_select_result(connection()->query("SELECT ".implode(", ",$Jg)));}}echo'
<form action="" method="post">
';if($fe){echo"<table class='layout'>\n";foreach($fe
as$x){$n=$Th["fields"][$x];$B=$n["field"];echo"<tr><th>".adminer()->fieldName($n);$Y=idx($_POST["fields"],$B);if($Y!=""){if($n["type"]=="set")$Y=implode(",",$Y);}input($n,$Y,idx($_POST["function"],$B,""));echo"\n";}echo"</table>\n";}echo'<p>
<input type="submit" value="',lang(203),'">
',input_token(),'</form>

<pre>
';function
pre_tr($Xh){return
preg_replace('~^~m','<tr>',preg_replace('~\|~','<td>',preg_replace('~\|$~m',"",rtrim($Xh))));}$R='(\+--[-+]+\+\n)';$K='(\| .* \|\n)';echo
preg_replace_callback("~^$R?$K$R?($K*)$R?~m",function($A){$ld=pre_tr($A[2]);return"<table>\n".($A[1]?"<thead>$ld</thead>\n":$ld).pre_tr($A[4])."\n</table>";},preg_replace('~(\n(    -|mysql)&gt; )(.+)~',"\\1<code class='jush-sql'>\\3</code>",preg_replace('~(.+)\n---+\n~',"<b>\\1</b>\n",h($Th['comment']))));echo'</pre>
';}elseif(isset($_GET["foreign"])){$a=$_GET["foreign"];$B=$_GET["name"];$K=$_POST;if($_POST&&!$m&&!$_POST["add"]&&!$_POST["change"]&&!$_POST["change-js"]){if(!$_POST["drop"]){$K["source"]=array_filter($K["source"],'strlen');ksort($K["source"]);$ej=array();foreach($K["source"]as$x=>$X)$ej[$x]=$K["target"][$x];$K["target"]=$ej;}if(JUSH=="sqlite")$I=recreate_table($a,$a,array(),array(),array(" $B"=>($K["drop"]?"":" ".format_foreign_key($K))));else{$b="ALTER TABLE ".table($a);$I=($B==""||queries("$b DROP ".(JUSH=="sql"?"FOREIGN KEY ":"CONSTRAINT ").idf_escape($B)));if(!$K["drop"])$I=queries("$b ADD".format_foreign_key($K));}queries_redirect(ME."table=".urlencode($a),($K["drop"]?lang(205):($B!=""?lang(206):lang(207))),$I);if(!$K["drop"])$m=lang(208);}page_header(lang(209),$m,array("table"=>$a),h($a));if($_POST){ksort($K["source"]);if($_POST["change"]||$_POST["change-js"])$K["target"]=array();else$K["source"][]="";}elseif($B!=""){$ud=foreign_keys($a);$K=$ud[$B];$K["source"][]="";}else{$K["table"]=$a;$K["source"]=array("");}echo'
<form action="" method="post">
';$zi=array_keys(fields($a));if($K["db"]!="")connection()->select_db($K["db"]);if($K["ns"]!=""){$Fg=get_schema();set_schema($K["ns"]);}$Eh=array_keys(array_filter(table_status('',true),'Adminer\fk_support'));$ej=array_keys(fields(in_array($K["table"],$Eh)?$K["table"]:reset($Eh)));$qg="this.form['change-js'].value = '1'; this.form.submit();";echo"<p><label>".lang(210).": ".html_select("table",$Eh,$K["table"],$qg)."</label>\n";if(support("scheme")){$ai=array_filter(adminer()->schemas(),function($Zh){return!preg_match('~^information_schema$~i',$Zh);});echo"<label>".lang(80).": ".html_select("ns",$ai,$K["ns"]!=""?$K["ns"]:$_GET["ns"],$qg)."</label>";if($K["ns"]!="")set_schema($Fg);}elseif(JUSH!="sqlite"){$Ub=array();foreach(adminer()->databases()as$k){if(!information_schema($k))$Ub[]=$k;}echo"<label>".lang(79).": ".html_select("db",$Ub,$K["db"]!=""?$K["db"]:$_GET["db"],$qg)."</label>";}echo
input_hidden("change-js"),'<noscript><p><input type="submit" name="change" value="',lang(211),'"></noscript>
<table>
<thead><tr><th id="label-source">',lang(143),'<th id="label-target">',lang(144),'</thead>
';$He=0;foreach($K["source"]as$x=>$X){echo"<tr>","<td>".html_select("source[".(+$x)."]",array(-1=>"")+$zi,$X,($He==count($K["source"])-1?"foreignAddRow.call(this);":""),"label-source"),"<td>".html_select("target[".(+$x)."]",$ej,idx($K["target"],$x),"","label-target");$He++;}echo'</table>
<p>
<label>',lang(110),': ',html_select("on_delete",array(-1=>"")+explode("|",driver()->onActions),$K["on_delete"]),'</label>
<label>',lang(109),': ',html_select("on_update",array(-1=>"")+explode("|",driver()->onActions),$K["on_update"]),'</label>
',(DRIVER==='pgsql'?html_select("deferrable",array('NOT DEFERRABLE','DEFERRABLE','DEFERRABLE INITIALLY DEFERRED'),$K["deferrable"]).' ':''),doc_link(array('sql'=>"innodb-foreign-key-constraints.html",'mariadb'=>"foreign-keys/",'pgsql'=>"sql-createtable.html#SQL-CREATETABLE-PARMS-REFERENCES",'mssql'=>"t-sql/statements/create-table-transact-sql",'oracle'=>"SQLRF01111",)),'<p>
<input type="submit" value="',lang(16),'">
<noscript><p><input type="submit" name="add" value="',lang(212),'"></noscript>
';if($B!="")echo'<input type="submit" name="drop" value="',lang(133),'">',confirm(lang(184,$B));echo
input_token(),'</form>
';}elseif(isset($_GET["view"])){$a=$_GET["view"];$K=$_POST;$Gg="VIEW";if(JUSH=="pgsql"&&$a!=""){$P=table_status1($a);$Gg=strtoupper($P["Engine"]);}if($_POST&&!$m){$B=trim($K["name"]);$_a=" AS\n$K[select]";$if=ME."table=".urlencode($B);$Bf=lang(213);$U=($_POST["materialized"]?"MATERIALIZED VIEW":"VIEW");if(!$_POST["drop"]&&$a==$B&&JUSH!="sqlite"&&$U=="VIEW"&&$Gg=="VIEW")query_redirect((JUSH=="mssql"?"ALTER":"CREATE OR REPLACE")." VIEW ".table($B).$_a,$if,$Bf);else{$gj=$B."_adminer_".uniqid();drop_create("DROP $Gg ".table($a),"CREATE $U ".table($B).$_a,"DROP $U ".table($B),"CREATE $U ".table($gj).$_a,"DROP $U ".table($gj),($_POST["drop"]?substr(ME,0,-1):$if),lang(214),$Bf,lang(215),$a,$B);}}if(!$_POST&&$a!=""){$K=view($a);$K["name"]=$a;$K["materialized"]=($Gg!="VIEW");if(!$m)$m=error();}page_header(($a!=""?lang(44):lang(216)),$m,array("table"=>$a),h($a));echo'
<form action="" method="post">
<p>',lang(194),': <input name="name" value="',h($K["name"]),'" data-maxlength="64" autocapitalize="off">
',(support("materializedview")?" ".checkbox("materialized",1,$K["materialized"],lang(137)):""),'<p>';textarea("select",$K["select"]);echo'<p>
<input type="submit" value="',lang(16),'">
';if($a!="")echo'<input type="submit" name="drop" value="',lang(133),'">',confirm(lang(184,$a));echo
input_token(),'</form>
';}elseif(isset($_GET["event"])){$aa=$_GET["event"];$ze=array("YEAR","QUARTER","MONTH","DAY","HOUR","MINUTE","WEEK","SECOND","YEAR_MONTH","DAY_HOUR","DAY_MINUTE","DAY_SECOND","HOUR_MINUTE","HOUR_SECOND","MINUTE_SECOND");$Ii=array("ENABLED"=>"ENABLE","DISABLED"=>"DISABLE","SLAVESIDE_DISABLED"=>"DISABLE ON SLAVE");$K=$_POST;if($_POST&&!$m){if($_POST["drop"])query_redirect("DROP EVENT ".idf_escape($aa),substr(ME,0,-1),lang(217));elseif(in_array($K["INTERVAL_FIELD"],$ze)&&isset($Ii[$K["STATUS"]])){$Yh="\nON SCHEDULE ".($K["INTERVAL_VALUE"]?"EVERY ".q($K["INTERVAL_VALUE"])." $K[INTERVAL_FIELD]".($K["STARTS"]?" STARTS ".q($K["STARTS"]):"").($K["ENDS"]?" ENDS ".q($K["ENDS"]):""):"AT ".q($K["STARTS"]))." ON COMPLETION".($K["ON_COMPLETION"]?"":" NOT")." PRESERVE";queries_redirect(substr(ME,0,-1),($aa!=""?lang(218):lang(219)),queries(($aa!=""?"ALTER EVENT ".idf_escape($aa).$Yh.($aa!=$K["EVENT_NAME"]?"\nRENAME TO ".idf_escape($K["EVENT_NAME"]):""):"CREATE EVENT ".idf_escape($K["EVENT_NAME"]).$Yh)."\n".$Ii[$K["STATUS"]]." COMMENT ".q($K["EVENT_COMMENT"]).rtrim(" DO\n$K[EVENT_DEFINITION]",";").";"));}}page_header(($aa!=""?lang(220).": ".h($aa):lang(221)),$m);if(!$K&&$aa!=""){$L=get_rows("SELECT * FROM information_schema.EVENTS WHERE EVENT_SCHEMA = ".q(DB)." AND EVENT_NAME = ".q($aa));$K=reset($L);}echo'
<form action="" method="post">
<table class="layout">
<tr><th>',lang(194),'<td><input name="EVENT_NAME" value="',h($K["EVENT_NAME"]),'" data-maxlength="64" autocapitalize="off">
<tr><th title="datetime">',lang(222),'<td><input name="STARTS" value="',h("$K[EXECUTE_AT]$K[STARTS]"),'">
<tr><th title="datetime">',lang(223),'<td><input name="ENDS" value="',h($K["ENDS"]),'">
<tr><th>',lang(224),'<td><input type="number" name="INTERVAL_VALUE" value="',h($K["INTERVAL_VALUE"]),'" class="size"> ',html_select("INTERVAL_FIELD",$ze,$K["INTERVAL_FIELD"]),'<tr><th>',lang(124),'<td>',html_select("STATUS",$Ii,$K["STATUS"]),'<tr><th>',lang(51),'<td><input name="EVENT_COMMENT" value="',h($K["EVENT_COMMENT"]),'" data-maxlength="64">
<tr><th><td>',checkbox("ON_COMPLETION","PRESERVE",$K["ON_COMPLETION"]=="PRESERVE",lang(225)),'</table>
<p>';textarea("EVENT_DEFINITION",$K["EVENT_DEFINITION"]);echo'<p>
<input type="submit" value="',lang(16),'">
';if($aa!="")echo'<input type="submit" name="drop" value="',lang(133),'">',confirm(lang(184,$aa));echo
input_token(),'</form>
';}elseif(isset($_GET["procedure"])){$ca=($_GET["name"]?:$_GET["procedure"]);$Th=(isset($_GET["function"])?"FUNCTION":"PROCEDURE");$K=$_POST;$K["fields"]=(array)$K["fields"];if($_POST&&!process_fields($K["fields"])&&!$m){foreach($K["fields"]as$x=>$n){if($n["field"]=="")unset($K["fields"][$x]);}$kg=routine_id($ca,routine($_GET["procedure"],$Th));$Vf=routine_id($K["name"],$K);$i=create_routine($Th,$K);$if=substr(ME,0,-1);$Bf=lang(226);if(!$_POST["drop"]&&$kg==$Vf&&connection()->flavor!="mysql")query_redirect(substr_replace($i,' OR REPLACE',6,0),$if,$Bf);else{$gj="$K[name]_adminer_".uniqid();drop_create("DROP $Th $kg",$i,"DROP $Th $Vf",create_routine($Th,array("name"=>$gj)+$K),"DROP $Th ".routine_id($gj,$K),$if,lang(227),$Bf,lang(228),$ca,$K["name"]);}}page_header(($ca!=""?(isset($_GET["function"])?lang(229):lang(230)).": ".h($ca):(isset($_GET["function"])?lang(231):lang(232))),$m);if(!$_POST){if($ca=="")$K["language"]="sql";else{$K=routine($_GET["procedure"],$Th);$K["name"]=$ca;}}$nb=get_vals("SHOW CHARACTER SET");sort($nb);$Uh=routine_languages();echo($nb?"<datalist id='collations'>".optionlist($nb)."</datalist>":""),'
<form action="" method="post" id="form">
<p>',lang(194),': <input name="name" value="',h($K["name"]),'" data-maxlength="64" autocapitalize="off">
',($Uh?"<label>".lang(21).": ".html_select("language",$Uh,$K["language"])."</label>\n":""),'<input type="submit" value="',lang(16),'">
<div class="scrollable">
<table id="edit-fields" class="nowrap">
';edit_fields($K["fields"],$nb,$Th);if(isset($_GET["function"])){echo"<tr><td>".lang(233);edit_type("returns",(array)$K["returns"],$nb,array(),(JUSH=="pgsql"?array("void","trigger"):array()));}echo'</table>
',script("editFields();"),'</div>
<p>';textarea("definition",$K["definition"],20);echo'<p>
<input type="submit" value="',lang(16),'">
';if($ca!="")echo'<input type="submit" name="drop" value="',lang(133),'">',confirm(lang(184,$ca));echo
input_token(),'</form>
';}elseif(isset($_GET["sequence"])){$ea=$_GET["sequence"];$K=$_POST;if($_POST&&!$m){$_=substr(ME,0,-1);$B=trim($K["name"]);if($_POST["drop"])query_redirect("DROP SEQUENCE ".idf_escape($ea),$_,lang(234));elseif($ea=="")query_redirect("CREATE SEQUENCE ".idf_escape($B),$_,lang(235));elseif($ea!=$B)query_redirect("ALTER SEQUENCE ".idf_escape($ea)." RENAME TO ".idf_escape($B),$_,lang(236));else
redirect($_);}page_header($ea!=""?lang(237).": ".h($ea):lang(238),$m);if(!$K)$K["name"]=$ea;echo'
<form action="" method="post">
<p><input name="name" value="',h($K["name"]),'" autocapitalize="off">
<input type="submit" value="',lang(16),'">
';if($ea!="")echo"<input type='submit' name='drop' value='".lang(133)."'>".confirm(lang(184,$ea))."\n";echo
input_token(),'</form>
';}elseif(isset($_GET["type"])){$fa=$_GET["type"];$K=$_POST;if($_POST&&!$m){$_=substr(ME,0,-1);if($_POST["drop"])query_redirect("DROP TYPE ".idf_escape($fa),$_,lang(239));else
query_redirect("CREATE TYPE ".idf_escape(trim($K["name"]))." $K[as]",$_,lang(240));}page_header($fa!=""?lang(241).": ".h($fa):lang(242),$m);if(!$K)$K["as"]="AS ";echo'
<form action="" method="post">
<p>
';if($fa!=""){$Ij=driver()->types();$Hc=type_values($Ij[$fa]);if($Hc)echo"<code class='jush-".JUSH."'>ENUM (".h($Hc).")</code>\n<p>";echo"<input type='submit' name='drop' value='".lang(133)."'>".confirm(lang(184,$fa))."\n";}else{echo
lang(194).": <input name='name' value='".h($K['name'])."' autocapitalize='off'>\n",doc_link(array('pgsql'=>"datatype-enum.html",),"?");textarea("as",$K["as"]);echo"<p><input type='submit' value='".lang(16)."'>\n";}echo
input_token(),'</form>
';}elseif(isset($_GET["check"])){$a=$_GET["check"];$B=$_GET["name"];$K=$_POST;if($K&&!$m){if(JUSH=="sqlite")$I=recreate_table($a,$a,array(),array(),array(),"",array(),"$B",($K["drop"]?"":$K["clause"]));else{$I=($B==""||queries("ALTER TABLE ".table($a)." DROP CONSTRAINT ".idf_escape($B)));if(!$K["drop"])$I=queries("ALTER TABLE ".table($a)." ADD".($K["name"]!=""?" CONSTRAINT ".idf_escape($K["name"]):"")." CHECK ($K[clause])");}queries_redirect(ME."table=".urlencode($a),($K["drop"]?lang(243):($B!=""?lang(244):lang(245))),$I);}page_header(($B!=""?lang(246).": ".h($B):lang(148)),$m,array("table"=>$a));if(!$K){$fb=driver()->checkConstraints($a);$K=array("name"=>$B,"clause"=>$fb[$B]);}echo'
<form action="" method="post">
<p>';if(JUSH!="sqlite")echo
lang(194).': <input name="name" value="'.h($K["name"]).'" data-maxlength="64" autocapitalize="off"> ';echo
doc_link(array('sql'=>"create-table-check-constraints.html",'mariadb'=>"constraint/",'pgsql'=>"ddl-constraints.html#DDL-CONSTRAINTS-CHECK-CONSTRAINTS",'mssql'=>"relational-databases/tables/create-check-constraints",'sqlite'=>"lang_createtable.html#check_constraints",),"?"),'<p>';textarea("clause",$K["clause"]);echo'<p><input type="submit" value="',lang(16),'">
';if($B!="")echo'<input type="submit" name="drop" value="',lang(133),'">',confirm(lang(184,$B));echo
input_token(),'</form>
';}elseif(isset($_GET["trigger"])){$a=$_GET["trigger"];$B="$_GET[name]";$Ej=trigger_options();$K=(array)trigger($B,$a)+array("Trigger"=>$a."_bi");if($_POST){if(!$m&&in_array($_POST["Timing"],$Ej["Timing"])&&in_array($_POST["Event"],$Ej["Event"])&&in_array($_POST["Type"],$Ej["Type"])){$ng=" ON ".table($a);$pc="DROP TRIGGER ".idf_escape($B).(JUSH=="pgsql"?$ng:"");$if=ME."table=".urlencode($a);if($_POST["drop"])query_redirect($pc,$if,lang(247));else{if($B!="")queries($pc);queries_redirect($if,($B!=""?lang(248):lang(249)),queries(create_trigger($ng,$_POST)));if($B!="")queries(create_trigger($ng,$K+array("Type"=>reset($Ej["Type"]))));}}$K=$_POST;}page_header(($B!=""?lang(250).": ".h($B):lang(251)),$m,array("table"=>$a));echo'
<form action="" method="post" id="form">
<table class="layout">
<tr><th>',lang(252),'<td>',html_select("Timing",$Ej["Timing"],$K["Timing"],"triggerChange(/^".preg_quote($a,"/")."_[ba][iud]$/, '".js_escape($a)."', this.form);"),'<tr><th>',lang(253),'<td>',html_select("Event",$Ej["Event"],$K["Event"],"this.form['Timing'].onchange();"),(in_array("UPDATE OF",$Ej["Event"])?" <input name='Of' value='".h($K["Of"])."' class='hidden'>":""),'<tr><th>',lang(50),'<td>',html_select("Type",$Ej["Type"],$K["Type"]),'</table>
<p>',lang(194),': <input name="Trigger" value="',h($K["Trigger"]),'" data-maxlength="64" autocapitalize="off">
',script("qs('#form')['Timing'].onchange();"),'<p>';textarea("Statement",$K["Statement"]);echo'<p>
<input type="submit" value="',lang(16),'">
';if($B!="")echo'<input type="submit" name="drop" value="',lang(133),'">',confirm(lang(184,$B));echo
input_token(),'</form>
';}elseif(isset($_GET["user"])){$ga=$_GET["user"];$uh=array(""=>array("All privileges"=>""));foreach(get_rows("SHOW PRIVILEGES")as$K){foreach(explode(",",($K["Privilege"]=="Grant option"?"":$K["Context"]))as$Db)$uh[$Db=="File access on server"?"Server Admin":$Db][$K["Privilege"]]=$K["Comment"];}unset($uh["Server Admin"]["Usage"]);foreach($uh["Tables"]as$x=>$X)unset($uh["Databases"][$x]);$Uf=array();if($_POST){foreach($_POST["objects"]as$x=>$X)$Uf[$X]=(array)$Uf[$X]+idx($_POST["grants"],$x,array());}$Dd=array();if(isset($_GET["host"])&&($I=connection()->query("SHOW GRANTS FOR ".q($ga)."@".q($_GET["host"])))){while($K=$I->fetch_row()){if(preg_match('~GRANT (.*) ON (.*) TO ~',$K[0],$A)&&preg_match_all('~ *([^(,]*[^ ,(])( *\([^)]+\))?~',$A[1],$pf,PREG_SET_ORDER)){foreach($pf
as$X){if($X[1]!="USAGE")$Dd["$A[2]$X[2]"][$X[1]]=true;if(preg_match('~ WITH GRANT OPTION~',$K[0]))$Dd["$A[2]$X[2]"]["GRANT OPTION"]=true;}}}}if($_POST&&!$m){$mg=(isset($_GET["host"])?q($ga)."@".q($_GET["host"]):"''");if($_POST["drop"])query_redirect("DROP USER $mg",ME."privileges=",lang(254));else{$Xf=q($_POST["user"])."@".q($_POST["host"]);$Zg=$_POST["pass"];$Ib=false;$I=true;if($mg!=$Xf){$Ib=queries("CREATE USER $Xf IDENTIFIED BY ".($_POST["hashed"]?"PASSWORD ":"").q($Zg));$I=$Ib;}elseif($Zg!="")$I=queries("SET PASSWORD FOR $Xf = ".(min_version(8,99)||$_POST["hashed"]?q($Zg):"PASSWORD(".q($Zg).")"));if($I){$Qh=array();foreach($Uf
as$fg=>$Cd){if(isset($_GET["grant"]))$Cd=array_filter($Cd);$Cd=array_keys($Cd);if(isset($_GET["grant"]))$Qh=array_diff(array_keys(array_filter($Uf[$fg],'strlen')),$Cd);elseif($mg==$Xf){$jg=array_keys((array)$Dd[$fg]);$Qh=array_diff($jg,$Cd);$Cd=array_diff($Cd,$jg);unset($Dd[$fg]);}if(preg_match('~^(.+)\s*(\(.*\))?$~U',$fg,$A)&&(!grant("REVOKE",$Qh,$A[2]," ON $A[1] FROM $Xf")||!grant("GRANT",$Cd,$A[2]," ON $A[1] TO $Xf"))){$I=false;break;}}}if($I&&isset($_GET["host"])){if($mg!=$Xf)queries("DROP USER $mg");elseif(!isset($_GET["grant"])){foreach($Dd
as$fg=>$Qh){if(preg_match('~^(.+)(\(.*\))?$~U',$fg,$A))grant("REVOKE",array_keys($Qh),$A[2]," ON $A[1] FROM $Xf");}}}queries_redirect(ME."privileges=",(isset($_GET["host"])?lang(255):lang(256)),$I);if($Ib)connection()->query("DROP USER $Xf");}}page_header((isset($_GET["host"])?lang(36).": ".h("$ga@$_GET[host]"):lang(156)),$m,array("privileges"=>array('',lang(72))));$K=$_POST;if($K)$Dd=$Uf;else{$K=$_GET+array("host"=>get_val("SELECT SUBSTRING_INDEX(CURRENT_USER, '@', -1)"));$Dd[(DB==""||$Dd?"":idf_escape(addcslashes(DB,"%_\\"))).".*"]=array();}echo'<form action="" method="post">
<table class="layout">
<tr><th>',lang(34),'<td><input name="host" data-maxlength="60" value="',h($K["host"]),'" autocapitalize="off">
<tr><th>',lang(36),'<td><input name="user" data-maxlength="80" value="',h($K["user"]),'" autocapitalize="off">
<tr><th>',lang(37),'<td><input name="pass" id="pass" value="',h($K["pass"]),'" autocomplete="new-password">
',($K["hashed"]?"":script("typePassword(qs('#pass'));")),(min_version(8,99)?"":checkbox("hashed",1,$K["hashed"],lang(257),"typePassword(this.form['pass'], this.checked);")),'</table>

',"<table class='odds'>\n","<thead><tr><th colspan='2'>".lang(72).doc_link(array('sql'=>"grant.html#priv_level"));$s=0;foreach($Dd
as$fg=>$Cd){echo'<th>'.($fg!="*.*"?"<input name='objects[$s]' value='".h($fg)."' size='10' autocapitalize='off'>":input_hidden("objects[$s]","*.*")."*.*");$s++;}echo"</thead>\n";foreach(array(""=>"","Server Admin"=>lang(34),"Databases"=>lang(38),"Tables"=>lang(139),"Procedures"=>lang(258),)as$Db=>$cc){foreach((array)$uh[$Db]as$th=>$sb){echo"<tr><td".($cc?">$cc<td":" colspan='2'").' lang="en" title="'.h($sb).'">'.h($th);$s=0;foreach($Dd
as$fg=>$Cd){$B="'grants[$s][".h(strtoupper($th))."]'";$Y=$Cd[strtoupper($th)];if($Db=="Server Admin"&&$fg!=(isset($Dd["*.*"])?"*.*":".*"))echo"<td>";elseif(isset($_GET["grant"]))echo"<td><select name=$B><option><option value='1'".($Y?" selected":"").">".lang(259)."<option value='0'".($Y=="0"?" selected":"").">".lang(260)."</select>";else
echo"<td align='center'><label class='block'>","<input type='checkbox' name=$B value='1'".($Y?" checked":"").($th=="All privileges"?" id='grants-$s-all'>":">".($th=="Grant option"?"":script("qsl('input').onclick = function () { if (this.checked) formUncheck('grants-$s-all'); };"))),"</label>";$s++;}}}echo"</table>\n",'<p>
<input type="submit" value="',lang(16),'">
';if(isset($_GET["host"]))echo'<input type="submit" name="drop" value="',lang(133),'">',confirm(lang(184,"$ga@$_GET[host]"));echo
input_token(),'</form>
';}elseif(isset($_GET["processlist"])){if(support("kill")){if($_POST&&!$m){$Oe=0;foreach((array)$_POST["kill"]as$X){if(adminer()->killProcess($X))$Oe++;}queries_redirect(ME."processlist=",lang(261,$Oe),$Oe||!$_POST["kill"]);}}page_header(lang(122),$m);echo'
<form action="" method="post">
<div class="scrollable">
<table class="nowrap checkable odds">
',script("mixin(qsl('table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true)});");$s=-1;foreach(adminer()->processList()as$s=>$K){if(!$s){echo"<thead><tr lang='en'>".(support("kill")?"<th>":"");foreach($K
as$x=>$X)echo"<th>$x".doc_link(array('sql'=>"show-processlist.html#processlist_".strtolower($x),'pgsql'=>"monitoring-stats.html#PG-STAT-ACTIVITY-VIEW",'oracle'=>"REFRN30223",));echo"</thead>\n";}echo"<tr>".(support("kill")?"<td>".checkbox("kill[]",$K[JUSH=="sql"?"Id":"pid"],0):"");foreach($K
as$x=>$X)echo"<td>".($X!=""&&((JUSH=="sql"&&$x=="Info"&&preg_match("~Query|Killed~",$K["Command"]))||(JUSH=="pgsql"&&$x=="query")||(JUSH=="oracle"&&$x=="sql_text"))?"<code class='jush-".JUSH."' data-full='".h($X)."'>".shorten_utf8($X,100,"</code>").' <a href="'.h(ME.($K["db"]!=""?"db=".urlencode($K["db"])."&":"")."sql=".urlencode($X)).'">'.lang(262).'</a>'.' <a href="" class="jsonly copy">🗐</a>':h($X));echo"\n";}echo'</table>
</div>
<p>
',script("copyCode(qsl('table'));");if(support("kill"))echo($s+1)."/".lang(263,max_connections()),"<p><input type='submit' value='".lang(264)."'>\n";echo
input_token(),'</form>
',script("tableCheck();");}elseif(isset($_GET["select"])){$a=$_GET["select"];$S=table_status1($a);$w=indexes($a);$o=fields($a);$ud=column_foreign_keys($a);$hg=$S["Oid"];$qa=get_settings("adminer_import");$Rh=array();$e=array();$fi=array();$zg=array();$kj="";foreach($o
as$x=>$n){$B=adminer()->fieldName($n);$Sf=html_entity_decode(strip_tags($B),ENT_QUOTES);if(isset($n["privileges"]["select"])&&$B!=""){$e[$x]=$Sf;if(is_shortable($n))$kj=adminer()->selectLengthProcess();}if(isset($n["privileges"]["where"])&&$B!="")$fi[$x]=$Sf;if(isset($n["privileges"]["order"])&&$B!="")$zg[$x]=$Sf;$Rh+=$n["privileges"];}list($M,$Ed)=adminer()->selectColumnsProcess($e,$w);$M=array_unique($M);$Ed=array_unique($Ed);$Ce=count($Ed)<count($M);$Z=adminer()->selectSearchProcess($o,$w);$yg=adminer()->selectOrderProcess($o,$w);$z=adminer()->selectLimitProcess();if($_GET["val"]&&is_ajax()){header("Content-Type: text/plain; charset=utf-8");foreach($_GET["val"]as$Nj=>$K){$_a=convert_field($o[key($K)]);$M=array($_a?:idf_escape(key($K)));$Z[]=where_check($Nj,$o);$J=driver()->select($a,$M,$Z,$M);if($J)echo
first($J->fetch_row());}exit;}$ph=$Pj=array();foreach($w
as$v){if($v["type"]=="PRIMARY"){$ph=array_flip($v["columns"]);$Pj=($M?$ph:array());foreach($Pj
as$x=>$X){if(in_array(idf_escape($x),$M))unset($Pj[$x]);}break;}}if($hg&&!$ph){$ph=$Pj=array($hg=>0);$w[]=array("type"=>"PRIMARY","columns"=>array($hg));}if($_POST&&!$m){$rk=$Z;if(!$_POST["all"]&&is_array($_POST["check"])){$fb=array();foreach($_POST["check"]as$bb)$fb[]=where_check($bb,$o);$rk[]="((".implode(") OR (",$fb)."))";}$rk=($rk?"\nWHERE ".implode(" AND ",$rk):"");if($_POST["export"]){save_settings(array("output"=>$_POST["output"],"format"=>$_POST["format"]),"adminer_import");dump_headers($a);adminer()->dumpTable($a,"");$yd=($M?implode(", ",$M):"*").convert_fields($e,$o,$M)."\nFROM ".table($a);$Gd=($Ed&&$Ce?"\nGROUP BY ".implode(", ",$Ed):"").($yg?"\nORDER BY ".implode(", ",$yg):"");$H="SELECT $yd$rk$Gd";if(is_array($_POST["check"])&&!$ph){$Lj=array();foreach($_POST["check"]as$X)$Lj[]="(SELECT".limit($yd,"\nWHERE ".($Z?implode(" AND ",$Z)." AND ":"").where_check($X,$o).$Gd,1).")";$H=implode(" UNION ALL ",$Lj);}adminer()->dumpData($a,"table",$H);adminer()->dumpFooter();exit;}if(!adminer()->selectEmailProcess($Z,$ud)){if($_POST["save"]||$_POST["delete"]){$I=true;$ra=0;$O=array();if(!$_POST["delete"]){foreach($o
as$B=>$X){$u=bracket_escape($B);if(isset($_POST["fields"][$u])||$_FILES["fields-$u"]){$X=process_input($o[$B]);if($X!==null&&($_POST["clone"]||$X!==false))$O[idf_escape($B)]=($X!==false?$X:idf_escape($B));}}}if($_POST["delete"]||$O){$H=($_POST["clone"]?"INTO ".table($a)." (".implode(", ",array_keys($O)).")\nSELECT ".implode(", ",$O)."\nFROM ".table($a):"");if($_POST["all"]||($ph&&is_array($_POST["check"]))||$Ce){$I=($_POST["delete"]?driver()->delete($a,$rk):($_POST["clone"]?queries("INSERT $H$rk".driver()->insertReturning($a)):driver()->update($a,$O,$rk)));$ra=connection()->affected_rows;if(is_object($I))$ra+=$I->num_rows;}else{foreach((array)$_POST["check"]as$X){$qk="\nWHERE ".($Z?implode(" AND ",$Z)." AND ":"").where_check($X,$o);$I=($_POST["delete"]?driver()->delete($a,$qk,1):($_POST["clone"]?queries("INSERT".limit1($a,$H,$qk)):driver()->update($a,$O,$qk,1)));if(!$I)break;$ra+=connection()->affected_rows;}}}$Bf=lang(265,$ra);if($_POST["clone"]&&$I&&$ra==1){$Ue=last_id($I);if($Ue)$Bf=lang(177," $Ue");}queries_redirect(remove_from_uri($_POST["all"]&&$_POST["delete"]?"page":""),$Bf,$I);if(!$_POST["delete"]){$kh=(array)$_POST["fields"];edit_form($a,array_intersect_key($o,$kh),$kh,!$_POST["clone"],$m);page_footer();exit;}}elseif(!$_POST["import"]){if(!$_POST["val"])$m=lang(266);else{$I=true;$ra=0;foreach($_POST["val"]as$Nj=>$K){$O=array();foreach($K
as$x=>$X){$x=bracket_escape($x,true);$O[idf_escape($x)]=(preg_match('~char|text~',$o[$x]["type"])||$X!=""?adminer()->processInput($o[$x],$X):"NULL");}$I=driver()->update($a,$O," WHERE ".($Z?implode(" AND ",$Z)." AND ":"").where_check($Nj,$o),($Ce||$ph?0:1)," ");if(!$I)break;$ra+=connection()->affected_rows;}queries_redirect(remove_from_uri(),lang(265,$ra),$I);}}elseif(!is_string($gd=get_file("csv_file",true)))$m=upload_error($gd);elseif(!preg_match('~~u',$gd))$m=lang(267);else{save_settings(array("output"=>$qa["output"],"format"=>$_POST["separator"]),"adminer_import");$I=true;$ob=array_keys($o);preg_match_all('~(?>"[^"]*"|[^"\r\n]+)+~',$gd,$pf);$ra=count($pf[0]);driver()->begin();$li=($_POST["separator"]=="csv"?",":($_POST["separator"]=="tsv"?"\t":";"));$L=array();foreach($pf[0]as$x=>$X){preg_match_all("~((?>\"[^\"]*\")+|[^$li]*)$li~",$X.$li,$qf);if(!$x&&!array_diff($qf[1],$ob)){$ob=$qf[1];$ra--;}else{$O=array();foreach($qf[1]as$s=>$lb)$O[idf_escape($ob[$s])]=($lb==""&&$o[$ob[$s]]["null"]?"NULL":q(preg_match('~^".*"$~s',$lb)?str_replace('""','"',substr($lb,1,-1)):$lb));$L[]=$O;}}$I=(!$L||driver()->insertUpdate($a,$L,$ph));if($I)driver()->commit();queries_redirect(remove_from_uri("page"),lang(268,$ra),$I);driver()->rollback();}}}$Vi=adminer()->tableName($S);if(is_ajax()){page_headers();ob_start();}else
page_header(lang(54).": $Vi",$m);$O=null;if(isset($Rh["insert"])||!support("table")){$Pg=array();foreach((array)$_GET["where"]as$X){if(isset($ud[$X["col"]])&&count($ud[$X["col"]])==1&&($X["op"]=="="||(!$X["op"]&&(is_array($X["val"])||!preg_match('~[_%]~',$X["val"])))))$Pg["set"."[".bracket_escape($X["col"])."]"]=$X["val"];}$O=$Pg?"&".http_build_query($Pg):"";}adminer()->selectLinks($S,$O);if(!$e&&support("table"))echo"<p class='error'>".lang(269).($o?".":": ".error())."\n";else{echo"<form action='' id='form'>\n","<div style='display: none;'>";hidden_fields_get();echo(DB!=""?input_hidden("db",DB).(isset($_GET["ns"])?input_hidden("ns",$_GET["ns"]):""):""),input_hidden("select",$a),"</div>\n";adminer()->selectColumnsPrint($M,$e);adminer()->selectSearchPrint($Z,$fi,$w);adminer()->selectOrderPrint($yg,$zg,$w);adminer()->selectLimitPrint($z);adminer()->selectLengthPrint($kj);adminer()->selectActionPrint($w);echo"</form>\n";$D=$_GET["page"];$xd=null;if($D=="last"){$xd=get_val(count_rows($a,$Z,$Ce,$Ed));$D=floor(max(0,intval($xd)-1)/$z);}$gi=$M;$Fd=$Ed;if(!$gi){$gi[]="*";$Eb=convert_fields($e,$o,$M);if($Eb)$gi[]=substr($Eb,2);}foreach($M
as$x=>$X){$n=$o[idf_unescape($X)];if($n&&($_a=convert_field($n)))$gi[$x]="$_a AS $X";}if(!$Ce&&$Pj){foreach($Pj
as$x=>$X){$gi[]=idf_escape($x);if($Fd)$Fd[]=idf_escape($x);}}$I=driver()->select($a,$gi,$Z,$Fd,$yg,$z,$D,true);if(!$I)echo"<p class='error'>".error()."\n";else{if(JUSH=="mssql"&&$D)$I->seek($z*$D);$Ac=array();echo"<form action='' method='post' enctype='multipart/form-data'>\n";$L=array();while($K=$I->fetch_assoc()){if($D&&JUSH=="oracle")unset($K["RNUM"]);$L[]=$K;}if($_GET["page"]!="last"&&$z&&$Ed&&$Ce&&JUSH=="sql")$xd=get_val(" SELECT FOUND_ROWS()");if(!$L)echo"<p class='message'>".lang(14)."\n";else{$Ja=adminer()->backwardKeys($a,$Vi);echo"<div class='scrollable'>","<table id='table' class='nowrap checkable odds'>",script("mixin(qs('#table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true), onkeydown: editingKeydown});"),"<thead><tr>".(!$Ed&&$M?"":"<td><input type='checkbox' id='all-page' class='jsonly'>".script("qs('#all-page').onclick = partial(formCheck, /check/);","")." <a href='".h($_GET["modify"]?remove_from_uri("modify"):$_SERVER["REQUEST_URI"]."&modify=1")."'>".lang(270)."</a>");$Tf=array();$_d=array();reset($M);$Bh=1;foreach($L[0]as$x=>$X){if(!isset($Pj[$x])){$X=idx($_GET["columns"],key($M))?:array();$n=$o[$M?($X?$X["col"]:current($M)):$x];$B=($n?adminer()->fieldName($n,$Bh):($X["fun"]?"*":h($x)));if($B!=""){$Bh++;$Tf[$x]=$B;$d=idf_escape($x);$Wd=remove_from_uri('(order|desc)[^=]*|page').'&order%5B0%5D='.urlencode($x);$cc="&desc%5B0%5D=1";echo"<th id='th[".h(bracket_escape($x))."]'>".script("mixin(qsl('th'), {onmouseover: partial(columnMouse), onmouseout: partial(columnMouse, ' hidden')});","");$zd=apply_sql_function($X["fun"],$B);$yi=isset($n["privileges"]["order"])||$zd!=$B;echo($yi?"<a href='".h($Wd.($yg[0]==$d||$yg[0]==$x?$cc:''))."'>$zd</a>":$zd);$Af=($yi?"<a href='".h($Wd.$cc)."' title='".lang(60)."' class='text'> ↓</a>":'');if(!$X["fun"]&&isset($n["privileges"]["where"])){$Af
.='<a href="#fieldset-search" title="'.lang(57).'" class="text jsonly"> =</a>';$Af
.=script("qsl('a').onclick = partial(selectSearch, '".js_escape($x)."');");}echo($Af?"<span class='column hidden'>$Af</span>":"");}$_d[$x]=$X["fun"];next($M);}}$bf=array();if($_GET["modify"]){foreach($L
as$K){foreach($K
as$x=>$X)$bf[$x]=max($bf[$x],min(40,strlen(utf8_decode($X))));}}echo($Ja?"<th>".lang(271):"")."</thead>\n";if(is_ajax())ob_end_clean();foreach(adminer()->rowDescriptions($L,$ud)as$Rf=>$K){$Mj=unique_array($L[$Rf],$w);if(!$Mj){$Mj=array();reset($M);foreach($L[$Rf]as$x=>$X){if(!preg_match('~^(COUNT|AVG|GROUP_CONCAT|MAX|MIN|SUM)\(~',current($M)))$Mj[$x]=$X;next($M);}}$Nj="";foreach($Mj
as$x=>$X){$n=(array)$o[$x];if((JUSH=="sql"||JUSH=="pgsql")&&preg_match('~char|text|enum|set~',$n["type"])&&strlen($X)>64){$x=(strpos($x,'(')?$x:idf_escape($x));$x="MD5(".(JUSH!='sql'||preg_match("~^utf8~",$n["collation"])?$x:"CONVERT($x USING ".charset(connection()).")").")";$X=md5($X);}$Nj
.="&".($X!==null?urlencode("where[".bracket_escape($x)."]")."=".urlencode($X===false?"f":$X):"null%5B%5D=".urlencode($x));}echo"<tr>".(!$Ed&&$M?"":"<td>".checkbox("check[]",substr($Nj,1),in_array(substr($Nj,1),(array)$_POST["check"])).($Ce||information_schema(DB)?"":" <a href='".h(ME."edit=".urlencode($a).$Nj)."' class='edit'>".lang(272)."</a>"));reset($M);foreach($K
as$x=>$X){if(isset($Tf[$x])){$d=current($M);$n=(array)$o[$x];if($X!=""&&(!isset($Ac[$x])||$Ac[$x]!=""))$Ac[$x]=(is_mail($X)?$Tf[$x]:"");$_="";if(is_blob($n)&&$X!="")$_=ME.'download='.urlencode($a).'&field='.urlencode($x).$Nj;if(!$_&&$X!==null){foreach((array)$ud[$x]as$p){if(count($ud[$x])==1||end($p["source"])==$x){$_="";foreach($p["source"]as$s=>$zi)$_
.=where_link($s,$p["target"][$s],$L[$Rf][$zi]);$_=($p["db"]!=""?preg_replace('~([?&]db=)[^&]+~','\1'.urlencode($p["db"]),ME):ME).'select='.urlencode($p["table"]).$_;if($p["ns"])$_=preg_replace('~([?&]ns=)[^&]+~','\1'.urlencode($p["ns"]),$_);if(count($p["source"])==1)break;}}}if($d=="COUNT(*)"){$_=ME."select=".urlencode($a);$s=0;foreach((array)$_GET["where"]as$W){if(!array_key_exists($W["col"],$Mj))$_
.=where_link($s++,$W["col"],$W["val"],$W["op"]);}foreach($Mj
as$Ke=>$W)$_
.=where_link($s++,$Ke,$W);}$Xd=select_value($X,$_,$n,$kj);$t=h("val[$Nj][".bracket_escape($x)."]");$lh=idx(idx($_POST["val"],$Nj),bracket_escape($x));$Rj=idx($n["privileges"],"update");$xc=!is_array($K[$x])&&is_utf8($Xd)&&$L[$Rf][$x]==$K[$x]&&!$_d[$x]&&!$n["generated"]&&$Rj;$U=(preg_match('~^(AVG|MIN|MAX)\((.+)\)~',$d,$A)?$o[idf_unescape($A[2])]["type"]:$n["type"]);$ij=preg_match('~text|json|lob~',$U);$De=preg_match(number_type(),$U)||preg_match('~^(CHAR_LENGTH|ROUND|FLOOR|CEIL|TIME_TO_SEC|COUNT|SUM)\(~',$d);echo"<td id='$t'".($De&&($X===null||is_numeric(strip_tags($Xd))||$U=="money")?" class='number'":"");if(($_GET["modify"]&&$xc&&$X!==null)||$lh!==null){$Jd=h($lh!==null?$lh:$K[$x]);echo">".($ij?"<textarea name='$t' cols='30' rows='".(substr_count($K[$x],"\n")+1)."'>$Jd</textarea>":"<input name='$t' value='$Jd' size='$bf[$x]'>");}else{$kf=strpos($Xd,"<i>…</i>");echo($Rj?" data-text='".($kf?2:($ij?1:0))."'".($xc?"":" data-warning='".h(lang(273))."'"):"").">$Xd";}}next($M);}if($Ja)echo"<td>";adminer()->backwardKeysPrint($Ja,$L[$Rf]);echo"</tr>\n";}if(is_ajax())exit;echo"</table>\n","</div>\n";}if(!is_ajax()){if($L||$D){$Oc=true;if($_GET["page"]!="last"){if(!$z||(count($L)<$z&&($L||!$D)))$xd=($D?$D*$z:0)+count($L);elseif(JUSH!="sql"||!$Ce){$xd=($Ce?false:found_rows($S,$Z));if(intval($xd)<max(1e4,2*($D+1)*$z))$xd=first(slow_query(count_rows($a,$Z,$Ce,$Ed)));elseif(JUSH=='sql'||JUSH=='pgsql')$Oc=false;}}$Ng=($z&&($xd===false||$xd>$z||$D));if($Ng)echo(($xd===false?count($L)+1:$xd-$D*$z)>$z?'<p><a href="'.h(remove_from_uri("page|next").($_GET["next"]?"&next=".urlencode($_GET["next"]):"")."&page=".($D+1)).'" class="loadmore">'.lang(274).'</a>'.script("qsl('a').onclick = partial(selectLoadMore, $z, '".lang(275)."…');",""):''),"\n";echo"<div class='footer'><div>\n";if($Ng){$uf=($xd===false?$D+($L?(count($L)>=$z?2:1):0):floor(($xd-1)/$z));echo"<fieldset>";if(JUSH!="simpledb"&&JUSH!="redis"){echo"<legend><a href='".h(remove_from_uri("page"))."'>".lang(276)."</a></legend>",script("qsl('a').onclick = function () { pageClick(this.href, +prompt('".lang(276)."', '".($D+1)."')); return false; };"),pagination(0,$D).($D>5?" …":"");for($s=max(1,$D-4);$s<min($uf,$D+5);$s++)echo
pagination($s,$D);if($uf>0)echo($D+5<$uf?" …":""),($Oc&&$xd!==false?pagination($uf,$D):" <a href='".h(remove_from_uri("page")."&page=last")."' title='~$uf'>".lang(277)."</a>");}else
echo"<legend>".lang(276)."</legend>",pagination(0,$D).($D>1?" …":""),($D?pagination($D,$D):""),($uf>$D?pagination($D+1,$D).($uf>$D+1?" …":""):"");echo"</fieldset>\n";}echo"<fieldset>","<legend>".lang(278)."</legend>";$gc=($Oc?"":"~ ").$xd;$rg="const checked = formChecked(this, /check/); selectCount('selected', this.checked ? '$gc' : checked); selectCount('selected2', this.checked || !checked ? '$gc' : checked);";echo
checkbox("all",1,0,($xd!==false?($Oc?"":"~ ").lang(160,$xd):""),$rg)."\n","</fieldset>\n";if(adminer()->selectCommandPrint())echo'<fieldset',($_GET["modify"]?'':' class="jsonly"'),'><legend>',lang(270),'</legend><div>
<input type="submit" value="',lang(16),'"',($_GET["modify"]?'':' title="'.lang(266).'"'),'>
</div></fieldset>
<fieldset><legend>',lang(132),' <span id="selected"></span></legend><div>
<input type="submit" name="edit" value="',lang(12),'">
<input type="submit" name="clone" value="',lang(262),'">
<input type="submit" name="delete" value="',lang(20),'">',confirm(),'</div></fieldset>
';$vd=adminer()->dumpFormat();foreach((array)$_GET["columns"]as$d){if($d["fun"]){unset($vd['sql']);break;}}if($vd){print_fieldset("export",lang(77)." <span id='selected2'></span>");$Kg=adminer()->dumpOutput();echo($Kg?html_select("output",$Kg,$qa["output"])." ":""),html_select("format",$vd,$qa["format"])," <input type='submit' name='export' value='".lang(77)."'>\n","</div></fieldset>\n";}adminer()->selectEmailPrint(array_filter($Ac,'strlen'),$e);echo"</div></div>\n";}if(adminer()->selectImportPrint())echo"<p>","<a href='#import'>".lang(76)."</a>",script("qsl('a').onclick = partial(toggle, 'import');",""),"<span id='import'".($_POST["import"]?"":" class='hidden'").">: ",file_input("<input type='file' name='csv_file'> ".html_select("separator",array("csv"=>"CSV,","csv;"=>"CSV;","tsv"=>"TSV"),$qa["format"])." <input type='submit' name='import' value='".lang(76)."'>"),"</span>";echo
input_token(),"</form>\n",(!$Ed&&$M?"":script("tableCheck();"));}}}if(is_ajax()){ob_end_clean();exit;}}elseif(isset($_GET["variables"])){$P=isset($_GET["status"]);page_header($P?lang(124):lang(123));$hk=($P?adminer()->showStatus():adminer()->showVariables());if(!$hk)echo"<p class='message'>".lang(14)."\n";else{echo"<table>\n";foreach($hk
as$K){echo"<tr>";$x=array_shift($K);echo"<th><code class='jush-".JUSH.($P?"status":"set")."'>".h($x)."</code>";foreach($K
as$X)echo"<td>".nl_br(h($X));}echo"</table>\n";}}elseif(isset($_GET["script"])){header("Content-Type: text/javascript; charset=utf-8");if($_GET["script"]=="db"){$Pi=array("Data_length"=>0,"Index_length"=>0,"Data_free"=>0);foreach(table_status()as$B=>$S){json_row("Comment-$B",h($S["Comment"]));if(!is_view($S)||preg_match('~materialized~i',$S["Engine"])){foreach(array("Engine","Collation")as$x)json_row("$x-$B",h($S[$x]));foreach($Pi+array("Auto_increment"=>0,"Rows"=>0)as$x=>$X){if($S[$x]!=""){$X=format_number($S[$x]);if($X>=0)json_row("$x-$B",($x=="Rows"&&$X&&$S["Engine"]==(JUSH=="pgsql"?"table":"InnoDB")?"~ $X":$X));if(isset($Pi[$x]))$Pi[$x]+=($S["Engine"]!="InnoDB"||$x!="Data_free"?$S[$x]:0);}elseif(array_key_exists($x,$S))json_row("$x-$B","?");}}}foreach($Pi
as$x=>$X)json_row("sum-$x",format_number($X));json_row("");}elseif($_GET["script"]=="kill")connection()->query("KILL ".number($_POST["kill"]));else{foreach(count_tables(adminer()->databases())as$k=>$X){json_row("tables-$k",$X);json_row("size-$k",db_size($k));}json_row("");}exit;}else{$cj=array_merge((array)$_POST["tables"],(array)$_POST["views"]);if($cj&&!$m&&!$_POST["search"]){$I=true;$Bf="";if(JUSH=="sql"&&$_POST["tables"]&&count($_POST["tables"])>1&&($_POST["drop"]||$_POST["truncate"]||$_POST["copy"]))queries("SET foreign_key_checks = 0");if($_POST["truncate"]){if($_POST["tables"])$I=truncate_tables($_POST["tables"]);$Bf=lang(279);}elseif($_POST["move"]){$I=move_tables((array)$_POST["tables"],(array)$_POST["views"],$_POST["target"]);$Bf=lang(280);}elseif($_POST["copy"]){$I=copy_tables((array)$_POST["tables"],(array)$_POST["views"],$_POST["target"]);$Bf=lang(281);}elseif($_POST["drop"]){if($_POST["views"])$I=drop_views($_POST["views"]);if($I&&$_POST["tables"])$I=drop_tables($_POST["tables"]);$Bf=lang(282);}elseif(JUSH=="sqlite"&&$_POST["check"]){foreach((array)$_POST["tables"]as$R){foreach(get_rows("PRAGMA integrity_check(".q($R).")")as$K)$Bf
.="<b>".h($R)."</b>: ".h($K["integrity_check"])."<br>";}}elseif(JUSH!="sql"){$I=(JUSH=="sqlite"?queries("VACUUM"):apply_queries("VACUUM".($_POST["optimize"]?" ANALYZE":""),$_POST["tables"]));$Bf=lang(283);}elseif(!$_POST["tables"])$Bf=lang(11);elseif($I=queries(($_POST["optimize"]?"OPTIMIZE":($_POST["check"]?"CHECK":($_POST["repair"]?"REPAIR":"ANALYZE")))." TABLE ".implode(", ",array_map('Adminer\idf_escape',$_POST["tables"])))){while($K=$I->fetch_assoc())$Bf
.="<b>".h($K["Table"])."</b>: ".h($K["Msg_text"])."<br>";}queries_redirect($_SERVER["REQUEST_URI"],$Bf,$I);}page_header(($_GET["ns"]==""?lang(38).": ".h(DB):lang(80).": ".h($_GET["ns"])),$m,true);if(adminer()->homepage()){if($_GET["ns"]!==""){$yg=$_GET["order"];echo"<h3 id='tables-views'>".lang(284)."</h3>\n";$bj=($yg?table_status():tables_list());if(!$bj)echo"<p class='message'>".lang(11)."\n";else{echo"<form action='' method='post'>\n";if(support("table")){echo"<fieldset><legend>".lang(285)." <span id='selected2'></span></legend><div>",html_select("op",adminer()->operators(),idx($_POST,"op",JUSH=="elastic"?"should":"LIKE %%"))," <input type='search' name='query' value='".h($_POST["query"])."'>",script("qsl('input').onkeydown = partialArg(bodyKeydown, 'search');","")," <input type='submit' name='search' value='".lang(57)."'>\n","</div></fieldset>\n";if($_POST["search"]&&$_POST["query"]!=""){$_GET["where"][0]["op"]=$_POST["op"];search_tables();}}echo"<div class='scrollable'>\n","<table class='nowrap checkable odds'>\n",script("mixin(qsl('table'), {onclick: tableClick, ondblclick: partialArg(tableClick, true)});"),'<thead><tr class="wrap">','<td><input id="check-all" type="checkbox" class="jsonly">'.script("qs('#check-all').onclick = partial(formCheck, /^(tables|views)\[/);",""),'<th><a href="'.h(substr(ME,0,-1)).'">'.lang(139).'</a>';$e=array("Engine"=>array(lang(286).doc_link(array('sql'=>'storage-engines.html'))));if(collations())$e["Collation"]=array(lang(128).doc_link(array('sql'=>'charset-charsets.html','mariadb'=>'supported-character-sets-and-collations/')));if(function_exists('Adminer\alter_table'))$e["Data_length"]=array(lang(287).doc_link(array('sql'=>'show-table-status.html','pgsql'=>'functions-admin.html#FUNCTIONS-ADMIN-DBOBJECT','oracle'=>'REFRN20286')),"create",lang(45));if(support('indexes'))$e["Index_length"]=array(lang(288).doc_link(array('sql'=>'show-table-status.html','pgsql'=>'functions-admin.html#FUNCTIONS-ADMIN-DBOBJECT')),"indexes",lang(142));$e["Data_free"]=array(lang(289).doc_link(array('sql'=>'show-table-status.html')),"edit",lang(46));if(function_exists('Adminer\alter_table'))$e["Auto_increment"]=array(lang(52).doc_link(array('sql'=>'example-auto-increment.html','mariadb'=>'auto_increment/')),"auto_increment=1&create",lang(45));$e["Rows"]=array(lang(290).doc_link(array('sql'=>'show-table-status.html','pgsql'=>'catalog-pg-class.html#CATALOG-PG-CLASS','oracle'=>'REFRN20286')),"select",lang(42));if(support("comment"))$e["Comment"]=array(lang(51).doc_link(array('sql'=>'show-table-status.html','pgsql'=>'functions-info.html#FUNCTIONS-INFO-COMMENT-TABLE')));foreach($e
as$x=>$d)echo"<th><a href='".h(ME)."order=$x'>$d[0]</a>";echo"</thead>\n";if($yg){uasort($bj,function($ja,$Ga)use($yg){$J=($ja[$yg]<$Ga[$yg]?-1:($ja[$yg]>$Ga[$yg]?1:0));return(in_array($yg,array('Engine','Collation','Comment'))?$J:-$J);});}$T=0;foreach($bj
as$B=>$P){$kk=($yg?is_view($P):$P!==null&&!preg_match('~table|sequence~i',$P));$P=($yg?$P:array('Engine'=>$P));$t=h("Table-".$B);echo'<tr><td>'.checkbox(($kk?"views[]":"tables[]"),$B,in_array("$B",$cj,true),"","","",$t),'<th>'.(support("table")||support("indexes")?"<a href='".h(ME)."table=".urlencode($B)."' title='".lang(43)."' id='$t'>".h($B).'</a>':h($B));if($kk&&!preg_match('~materialized~i',$P['Engine'])){$oj=lang(138);echo'<td colspan="'.(count($e)-(support("comment")?2:1)).'">'.(support("view")?"<a href='".h(ME)."view=".urlencode($B)."' title='".lang(44)."'>$oj</a>":$oj),'<td align="right"><a href="'.h(ME)."select=".urlencode($B).'" title="'.lang(42).'">?</a>';if(support("comment"))echo'<td>'.h($P['Comment']);}else{foreach($e
as$x=>$d){$t=" id='$x-".h($B)."'";$X=idx($P,$x,'?');echo($d[1]?"<td align='right'><a href='".h(ME."$d[1]=").urlencode($B)."'$t title='$d[2]'>".(is_numeric($X)?($X<0?'?':($x=="Rows"&&$X&&$P["Engine"]==(JUSH=="pgsql"?"table":"InnoDB")?'~ ':'').format_number($X)):$X)."</a>":"<td id='$x-".h($B)."'>".h($X));}$T++;}echo"\n";}echo"<tr><td><th>".lang(263,count($bj)),"<td>".h(JUSH=="sql"?get_val("SELECT @@default_storage_engine"):""),(collations()?"<td>".h(db_collation(DB,collations())):'');foreach(array("Data_length","Index_length","Data_free")as$x)echo($e[$x]?"<td align='right' id='sum-$x'>":"");echo"\n","</table>\n",($yg?'':script("ajaxSetHtml('".js_escape(ME)."script=db');")),"</div>\n";if(!information_schema(DB)){$dk="<input type='submit' value='".lang(291)."'> ".on_help("'VACUUM'");$ug="<input type='submit' name='optimize' value='".lang(292)."'> ".on_help(JUSH=="sql"?"'OPTIMIZE TABLE'":"'VACUUM ANALYZE'");$rh=(JUSH=="sqlite"?$dk."<input type='submit' name='check' value='".lang(293)."'> ".on_help("'PRAGMA integrity_check'"):(JUSH=="pgsql"?$dk.$ug:(JUSH=="sql"?"<input type='submit' value='".lang(294)."'> ".on_help("'ANALYZE TABLE'").$ug."<input type='submit' name='check' value='".lang(293)."'> ".on_help("'CHECK TABLE'")."<input type='submit' name='repair' value='".lang(295)."'> ".on_help("'REPAIR TABLE'"):""))).(function_exists('Adminer\truncate_tables')?"<input type='submit' name='truncate' value='".lang(296)."'> ".on_help(JUSH=="sqlite"?"'DELETE'":"'TRUNCATE".(JUSH=="pgsql"?"'":" TABLE'")).confirm():"").(function_exists('Adminer\drop_tables')?"<input type='submit' name='drop' value='".lang(133)."'>".on_help("'DROP TABLE'").confirm():"");echo($rh?"<div class='footer'><div>\n<fieldset><legend>".lang(132)." <span id='selected'></span></legend><div>$rh\n</div></fieldset>\n":"");$j=(support("scheme")?adminer()->schemas():adminer()->databases());$di="";if(count($j)!=1&&function_exists('Adminer\move_tables')){echo"<fieldset><legend>".lang(297)." <span id='selected3'></span></legend><div>";$k=(isset($_POST["target"])?$_POST["target"]:(support("scheme")?$_GET["ns"]:DB));echo($j?html_select("target",$j,$k):'<input name="target" value="'.h($k).'" autocapitalize="off">'),"</label> <input type='submit' name='move' value='".lang(116)."'>",(support("copy")?" <input type='submit' name='copy' value='".lang(298)."'> ".checkbox("overwrite",1,$_POST["overwrite"],lang(299)):""),"</div></fieldset>\n";$di=" selectCount('selected3', formChecked(this, /^(tables|views)\[/));";}echo"<input type='hidden' name='all' value=''>",script("qsl('input').onclick = function () { selectCount('selected', formChecked(this, /^(tables|views)\[/));".(support("table")?" selectCount('selected2', formChecked(this, /^tables\[/) || $T);":"")."$di }"),input_token(),"</div></div>\n";}echo"</form>\n",script("tableCheck();");}echo(function_exists('Adminer\alter_table')?"<p class='links'><a href='".h(ME)."create='>".lang(78)."</a>\n":''),(support("view")?"<a href='".h(ME)."view='>".lang(216)."</a>\n":"");if(support("routine")){echo"<h3 id='routines'>".lang(73)."</h3>\n";$Vh=routines();if($Vh){echo"<table class='odds'>\n",'<thead><tr><th>'.lang(194).'<td>'.lang(50).'<td>'.lang(233)."<td></thead>\n";foreach($Vh
as$K){$B=($K["SPECIFIC_NAME"]==$K["ROUTINE_NAME"]?"":"&name=".urlencode($K["ROUTINE_NAME"]));echo'<tr>','<th><a href="'.h(ME.($K["ROUTINE_TYPE"]!="PROCEDURE"?'callf=':'call=').urlencode($K["SPECIFIC_NAME"]).$B).'">'.h($K["ROUTINE_NAME"]).'</a>','<td>'.h($K["ROUTINE_TYPE"]),'<td>'.h($K["DTD_IDENTIFIER"]),'<td><a href="'.h(ME.($K["ROUTINE_TYPE"]!="PROCEDURE"?'function=':'procedure=').urlencode($K["SPECIFIC_NAME"]).$B).'">'.lang(145)."</a>";}echo"</table>\n";}echo'<p class="links">'.(support("procedure")?'<a href="'.h(ME).'procedure=">'.lang(232).'</a>':'').'<a href="'.h(ME).'function=">'.lang(231)."</a>\n";}if(support("sequence")){echo"<h3 id='sequences'>".lang(74)."</h3>\n";$oi=get_vals("SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema = current_schema() ORDER BY sequence_name");if($oi){echo"<table class='odds'>\n","<thead><tr><th>".lang(194)."</thead>\n";foreach($oi
as$X)echo"<tr><th><a href='".h(ME)."sequence=".urlencode($X)."'>".h($X)."</a>\n";echo"</table>\n";}echo"<p class='links'><a href='".h(ME)."sequence='>".lang(238)."</a>\n";}if(support("type")){echo"<h3 id='user-types'>".lang(6)."</h3>\n";$ak=types();if($ak){echo"<table class='odds'>\n","<thead><tr><th>".lang(194)."</thead>\n";foreach($ak
as$X)echo"<tr><th><a href='".h(ME)."type=".urlencode($X)."'>".h($X)."</a>\n";echo"</table>\n";}echo"<p class='links'><a href='".h(ME)."type='>".lang(242)."</a>\n";}if(support("event")){echo"<h3 id='events'>".lang(75)."</h3>\n";$L=get_rows("SHOW EVENTS");if($L){echo"<table>\n","<thead><tr><th>".lang(194)."<td>".lang(300)."<td>".lang(222)."<td>".lang(223)."<td></thead>\n";foreach($L
as$K)echo"<tr>","<th>".h($K["Name"]),"<td>".($K["Execute at"]?lang(301)."<td>".$K["Execute at"]:lang(224)." ".$K["Interval value"]." ".$K["Interval field"]."<td>$K[Starts]"),"<td>$K[Ends]",'<td><a href="'.h(ME).'event='.urlencode($K["Name"]).'">'.lang(145).'</a>';echo"</table>\n";$Mc=get_val("SELECT @@event_scheduler");if($Mc&&$Mc!="ON")echo"<p class='error'><code class='jush-sqlset'>event_scheduler</code>: ".h($Mc)."\n";}echo'<p class="links"><a href="'.h(ME).'event=">'.lang(221)."</a>\n";}}}}page_footer();